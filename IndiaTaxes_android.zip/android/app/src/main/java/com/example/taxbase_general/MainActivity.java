package com.sinewave.myindiataxes;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {


}
