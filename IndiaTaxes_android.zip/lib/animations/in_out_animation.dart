import 'package:flutter/material.dart';
import 'package:flutter_animator/flutter_animator.dart';
import 'package:flutter_animator/widgets/in_out_animation.dart';

class InOutAnimations extends StatelessWidget {
  final AnimationDefinition inDefination;
  final AnimationDefinition outDefination;
  final Widget child;

  const InOutAnimations({
    Key key,
    this.inDefination ,
    this.outDefination,
    this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InOutAnimation(
      inDefinition: inDefination ?? BounceInDownAnimation(),
      outDefinition: outDefination ??  BounceInRightAnimation(),
      
      child: child ?? Container(),
    );
  }
}
