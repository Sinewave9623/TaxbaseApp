import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:taxbase_general/values/values.dart';

const Widget horizontalSpaceTiny = SizedBox(width: 5.0);
const Widget horizontalSpaceSmall = SizedBox(width: 10.0);
const Widget horizontalSpaceMediumSmall = SizedBox(width: 16.0);
const Widget horizontalSpaceMedium = SizedBox(width: 25.0);

const Widget verticalSpaceTiny = SizedBox(height: 5.0);
const Widget verticalSpaceSmall = SizedBox(height: 10.0);
const Widget verticalSpaceMediumSmall = SizedBox(height: 16.0);
const Widget verticalSpaceMedium = SizedBox(height: 25.0);
const Widget verticalSpaceLarge = SizedBox(height: 50.0);
const Widget verticalSpaceMassive = SizedBox(height: 120.0);

Widget indentSpacedDivider = Column(
  children: const <Widget>[
    verticalSpaceMediumSmall,
    Divider(
      indent: 16.0,
      endIndent: 16.0,
    ),
    verticalSpaceMediumSmall,
  ],
);

double paddingTop(BuildContext context) => MediaQuery.of(context).padding.top;
double paddingBottom(BuildContext context) =>
    MediaQuery.of(context).padding.bottom;

Widget verticalSpace(double height) => SizedBox(height: height);

Widget horizontalSpace(double width) => SizedBox(width: width);

double screenWidth(BuildContext context) => MediaQuery.of(context).size.width;

double screenHeight(BuildContext context) => MediaQuery.of(context).size.height;

double screenHeightFraction(BuildContext context,
        {int dividedBy = 1, double offsetBy = 0}) =>
    (screenHeight(context) - offsetBy) / dividedBy;

double screenWidthFraction(BuildContext context,
        {int dividedBy = 1, double offsetBy = 0}) =>
    (screenWidth(context) - offsetBy) / dividedBy;

double halfScreenWidth(BuildContext context) =>
    screenWidthFraction(context, dividedBy: 2);

double thirdScreenWidth(BuildContext context) =>
    screenWidthFraction(context, dividedBy: 3);

void onWidgetDidBuild(Function callback) {
  WidgetsBinding.instance.addPostFrameCallback((_) {
    callback();
  });
}

SizedBox sizedBox({double height, double width}) {
  return SizedBox(
    height: height,
    width: width ?? 0.0,
  );
}

// Text Style Variables
final errorTitleStyle = GoogleFonts.poppins(
    fontWeight: FontWeight.w900, color: AppColors.primaryColor, fontSize: 18.0);

final errorMessageStyle = GoogleFonts.poppins(
    fontWeight: FontWeight.w400, color: AppColors.primaryColor, fontSize: 16.0);

final errorButtonStyle = GoogleFonts.poppins(
    fontSize: 16.0, color: AppColors.primaryColor, fontWeight: FontWeight.w700);

final buttonTextStyle = GoogleFonts.poppins(
    fontWeight: FontWeight.w700, color: AppColors.primaryColor, fontSize: 16.0);
