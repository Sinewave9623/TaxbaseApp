import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:taxbase_general/router/route_names.dart';
import 'package:taxbase_general/ui/views/CALENDERUI/calendarCarouselScreen.dart';
import 'package:taxbase_general/ui/views/DASHBOARD/dashboard_screen.dart';
import 'package:taxbase_general/ui/views/GSTIN/gstin_numbers_screen.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/generate_otp_screen.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/user_details_screen.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/verify_otp_screen.dart';
import 'package:taxbase_general/ui/views/RETURNS/gst_auth_returns_screen.dart';
import 'package:taxbase_general/ui/views/RETURNS/view_track_returns_screen.dart';
import 'package:taxbase_general/ui/views/TAXCALCULATION/calculation_detail_screen.dart';
import 'package:taxbase_general/ui/views/TAXCALCULATION/output_screen.dart';
import 'package:taxbase_general/ui/views/TAXCALCULATION/tax_calculation_screen.dart';
import 'package:taxbase_general/ui/views/USER_PROFILE/user_profile_screen.dart';

import 'package:taxbase_general/ui/widgets/error_widget.dart';

Route<dynamic> generateRoute(RouteSettings settings) {
  switch (settings.name) {
    case GENERATE_OTP_SCREEN_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: GenerateOtpScreen(),
      );
    case VERIFY_OTP_SCREEN_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: VerifyOtpScreen(mobileNumber: settings.arguments),
      );
    case DASHBOARD_SCREEN_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: DashBoardScreen(),
      );
    case GSTREMINDER_SCREEN_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: CalendarCarouselScreen(),
      );
    case TAX_CALCULATION_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: TaxCalculationScreen(),
      );
    case CALCULATION_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: CalculationDetailScreen(child: settings.arguments),
      );
    case OUTPUT_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: OutputScreen(model: settings.arguments),
      );
    case USERDETAILS_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: UserDetailScreen(mobileNumber: settings.arguments),
      );
    case VIEWRETURNS_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: ViewReturnsScreen(),
      );
    case VIEWTRACKRETURNS_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: ViewTrackReturns(
          gstinNo: settings.arguments,
        ),
      );
    case GSTIN_NUMBER_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: GSTINNUMBERSCREEN(),
      );
    case USER_PROFILE_ROUTEPAGE:
      return _getPageRoute(
        routeName: settings.name,
        viewToShow: UserProfileScreen(),
      );
    default:
      return CupertinoPageRoute(
        builder: (_) => ErrorPopupView(
          icon: "assets/images/error.png",
          title: 'assets/images/oops.png',
          message: 'Page Not Found',
          showButton: false,
        ),
      );
  }
}

PageRoute _getPageRoute({String routeName, Widget viewToShow}) {
  return CupertinoPageRoute(
      settings: RouteSettings(
        name: routeName,
      ),
      builder: (_) => viewToShow);
}
