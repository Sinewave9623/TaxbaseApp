

import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:taxbase_general/services/common/dio_injector.dart';
import 'package:taxbase_general/services/common/navigation_services.dart';
import 'package:taxbase_general/services/repository/api_repository.dart';
import 'package:taxbase_general/services/repository/repository_service.dart';
import 'package:taxbase_general/services/storage/local_storage.dart';
import 'package:taxbase_general/services/storage/storage_service.dart';

import 'services/common/dialog_service.dart';

GetIt locator = GetIt.instance;

Future<void> setUpLocator() async {
  final prefs = await SharedPreferences.getInstance();
  locator
      .registerLazySingleton<StorageService>(() => LocalStorage(prefs: prefs));
  locator.registerLazySingleton<NavigationService>(() => NavigationService());
  locator.registerLazySingleton<DialogService>(() => DialogService());
  injector.init();
  locator.registerLazySingleton<RepositoryService>(
      () => ApiRepository(dio: injector.dio));
  // locator.registerLazySingleton<LocationService>(() => LocationService());
}
