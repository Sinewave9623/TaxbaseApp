part of 'values.dart';

BoxDecoration boxDecorationWithGradient = BoxDecoration(
  gradient: LinearGradient(
    begin: Alignment.topCenter,
    colors: [
      Colors.green[900],
      Colors.green[800],
      Colors.green[400],
    ],
  ),
);
