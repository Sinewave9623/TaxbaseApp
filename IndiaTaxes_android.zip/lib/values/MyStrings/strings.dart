part of values;

const AppNameTitle = "Taxbase General";
const MOBILE_VERIFICATION = "Mobile Verification";
const ENTER_MOBILE = "Please Enter Your Mobile Number";
const MOBILE_NUMBER = "Mobile Number";
const PAN_NUMBER_HINT = "Pan Number";
const TERMS_AND_CONDITION = "Terms & Conditions";
const BEARER_TOKEN = "Bearer ";
const OUTPUT_TITLE = "Tax Calculator ";
const OPEN_SIGNAL_APP_ID = "5ecaa66f-8f77-4d8c-a58e-bb1db2305efe";
const GSTIN_NUMBER = "Gstin Number";
const USER_NAME = "User Name";
const USER_OTP = "Enter OTP";

const OTP_VERIFICATION =
    "Please Type The Verification Code Sent To Your Number";
const ENTER_OTP = "Enter OTP";
const CA_CODE_VERIFICATION = "Please Enter The CA Verification Code";
const ENTER_DETAILS = "Please Enter The Following Details";
const ENTER_CA_CODE = "ENTER CA CODE";

const MYDOCUMENTSLABEL = "My Documents";
const MYDOCUMENTSMSG = "View Uploaded Documents";

const CREATEFOLDER = "Create Folder";
const CREATEFILE = "Create File";

const FOLDERNAME_HINT = "Please Enter Folder Name";
const FOLDERDESC_HINT = "Please Enter Folder Description";

const FILENAME_HINT = "Please Enter File Name";
const FILEERDESC_HINT = "Please Enter File Description";

const TAXCALCULATIONLABEL = "Income Tax Calculations";
const TAXCALCULATIONMSG = "Automated Tax Calculations";

const GSTIN = "27AAGCS3463G1Z9";
const USERNAME = "SRS_27820016472";
const CUSTOMER_ID = "20011053";
const HKEY = "8R2VR-2N2CR-JW2CR-8C8CR-XU7FR";
const LKEY =
    "X9L6OYBDL6-Q089MG75G4-MVGMQ5GK0S-I31QL2OSGV-5DR5L36Y4B-22QUXQQZZ9";

const RETURNS_LABEL = "GST Return Status";
const RETURNS_MSG = "View your GST Returns";

const GST_RETURN = "GST Returns";
const TDS_RETURN = "TDS Returns";
const ITR_RETURN = "ITR Returns";

const TAXPLANNERLABEL = "Tax Planner";
const PERSONAL_INFOLABEL = "Personal Information";
const INCOME_INFOLABEL = "Income";

const DOCTYPE_FOLDER = "Folder";
const DOCTYPE_FILE = "File";
const FILETYPE_JPG = "JPG";
const FILETYPE_PDF = "PDF";
const FILETYPE_PNG = "PNG";
const FILETYPE_DOC = "DOC";
const FILETYPE_DOCX = "DOCX";
const FILETYPE_XLSX = "XLSX";
const FILETYPE_PPT = "PPT";
const FILETYPE_PPTX = "PPTX";
const FILETYPE_TXT = "TXT";

const CANCEL = "Cancel";
const SAVE = "Save";
const OK = "Ok";
const GROSS_TOTAL_INCOME = "Gross Total Income";

const BASIC_DETAILS = "Basic Details";

const FIRST_NAME = "First Name";
const MIDDLE_NAME = "Middle Name";
const LAST_NAME = "Last Name";
const GENDERS = "GENDER";
const DOB = "Date of Birth";
const PAN = "PAN";
const FATHER_NAME = "Father Name";
const FLAT_NUMBER = "Flat/Door/Block Number";
const PREMISE_NAME = "Premise Name";
const STREET_NAME = "Road/Street Name";
const AREA = "Area/Locality";
const TOWN = "Town/City";
const PIN = "Pin";
const STATE = "State";
const COUNTRY = "Country";
const MOBILE = "Mobile Number";
const AADHAR = "Aadhar Number";
const EMAIL = "Email ID";

//----- STEP 1 ---------
const SALARY = "Salary";
const CALCULATED_SALARY = "Calculeted salary will be here";
const NAME_OF_EMPLOYER = "Name of Employer";
const TAN_OF_EMPLOYER = "TAN of Employer";
const EMPLOYER_TYPE = "Employer Type/ Category";
const SALARY_PER_17 = "Salary  by section 17(1) ";
const BASIC = "Basic";
const ALLOWANCE_PERQUISITES = "Allowances and Perquisites u/s 17(2)";
const HRA = "HRA";
const LEAVE_TRAVEL_ALLOWANCE = "LTA";
const OTHER = "Other ";
const VALUE_OF_PERQUISITES = "Value of Perquisites";
const PROFIT_IN_LIEU_SALARY = "Profit in Lieu of Salary";
const EXEMPT_ALLOWANCE = "Exempt Allowances u/s 10";
const DESC_ALLOWANCE = "Description";
const BALANCE = "Balance";
const STD_DEDUCTION = "Standard Deduction";
const PROFESSION_TAX = "Professional Tax u/s 16(ii) ";
const INCOME = "Income from Salary";
const SELECT_FILE = "Upload Form 16";
const SELECT_FILE_26 = "Select Form 26";
const SELECT_FILE_16 = "Select Form 16";
const SELECT_FILE_FORM = "Please select Form 26 & Form 16 file and Upload";
const UPLOAD_FILE = "Upload";

//----- STEP 2 ---------

const HOUSE_PROPERTY = "House Property";
const INTREST_PAID = "Interest Paid on Self Occupied House ";
const RENT_RECEIVED = " Rent Received from Rented Property ";
const INCOME_FROM_HP = "Income from House Property ";
const MUNCIPLE_TAX = "Municipal tax paid";
const UNREALISED = "Arrears/Unrealised rent received";

//----- STEP 3 ---------

const BUSINESS = "Business";
const INCOME_FROM_FIRMS = "Income from Firms";
const PROFIT = "Profit";
const REMUNERATION = "Remuneration";
const INTEREST = "Interest";
const NAME_OF_BUSINESS = "Name of Business";
const ENTERTAINMENT = "Entertainment allowance";
// ------ STEP 4 ---------------

const CAPITAL_GAIN = "Capital Gain";
const STCG_NORMAL = "STCG Normal";
const STCG_111A = "STCG 111A (15%)";
const LTCG_112A = "LTCG 112A";
const LTCG_10 = "LTCG 10%";
const LTCG_20 = "LTCG 20%";
const F15_06 = "15/06";
const F15_09 = "15/09";
const F15_12 = "15/12";
const F15_03 = "15/03";
const F31_3 = "31/3";

// --------------Step 5--------------------

const OTHER_SOURCES = "Other Sources";
const INTEREST_FROM_BANK_DEPOSITS = "Interest from Bank Deposits";
const INTEREST_FROM_BANK_SAVINGS = "Interest from Savings";
const INTEREST_FROM_INCOME_TAX_REFUND = "Interest on Income Tax refund";
const OTHER_INCOME = "Other Income";
const PENSION_RECEIVED = "Pension received";
const DEDUCTION_57 = "Deduction u/s 57";
const LOTTERY = "Lottery";

// --------------------Step 6 ---------------------------

const OTHER_SPECIAL_INCOME = "Other Special Income";
const DIVIDEND_1506 = "Dividend 15/6";
const DIVIDEND_1509 = "Dividend 15/9";
const DIVIDEND_1512 = "Dividend 15/12";
const DIVIDEND_1503 = "Dividend 15/03";
const DIVIDEND_3103 = "Dividend 31/03";

const INSURANCE_TITLE = "Insurance";
const LIFE_INSURANCE_TITLE = "Life Insurance Premium";
const HEALTH_INSURANCE_TITLE = "Health Insurance Premium";
const PREVENTIVE_INSURANCE_TITLE = "Preventive Health Check-up";
const PARENT_HEALTH_INSURANCE_TITLE = "Parent Health Insurance";
const SENIOR_CITIZEN_TITLE = "My Parents are senior citizen";

// -------------------STEP 7 ------------------------

const LOSS_BF_AND_ADJUSTED = "Loss B/f and Adjusted";

// -------------------STEP 8---------------------------

const DEDUCTIONS = "Deductions";
const DEDUCTIONS_UNDER_VIA = "Deductions under Chapter VIA";
const LIC = "LIC Payments";
const QUALIFIED_AMT_TITLE = "Qualified Amount";
const ACTUAL_AMT_TITLE = "Actual Amount";
const PF = "Provident Fund";
const HL = "Repayment of Housing Loan";
const PUBLIC_PF = "Public Provident Fund";
const NSC_ACCURED_INTEREST = "NSC Accrued Interest";
const NSC_NEW_DEPOSITS = "NSC New Deposits";
const EDUCATION_EXPENSES = "Education Expenses";
const DEDUCTION_CERTAIN_FUNDS = "Deduction in Certain Funds";
const GROUP_INSURANCE = "Group Insurance";
const MUTUAL_FUNDS = "Mutual Funds";
const DEDUCTION_IN_MEDI_INSURANCE = "Medical Insurance Premium";
const DEDUCTION_IN_MAINTENANCE_HANDICAPPED = "Handicapped Maintenance";
const INTREST_HIGHER_EDU_LOAN = "Interest on Higher eduction Loan";
const DONATIONS_100 = "Donatations to certain funds 100%";
const DONATIONS_50 = "Donatations to certain funds 50%";
const QUALIFYING_AMOUNT = "Qualifying Amount";
const RENTS_PAID = "Rents Paid";
const SELF = "Self";
const PARENT = "Parent";
const SEVERE = "Severe";
const HANDICAP = "Handicap";
const NON_SEVERE_AMOUNT = "Rs. 75000";
const SEVERE_AMOUNT = "Rs. 125000";
const ADJUSTED_GTI = "Adjusted GTI";
const SEC_80_G = "rents paid  u/s 80GG";
const RENT_PAID = "Rent Paid";
const TOTAL = "Total";

// ----------------------STEP 10 ---------------------

const EXEMPT_INCOME = "Exempt Income";
const INCOME_CLAIMED_EXEMPT = "Income Claimed Exempt (Others)";

// ------------------STEP 11 ------------------------
const AGRICULTURE_INCOME = " Agriculture Income ";

// --------------------STEP 12 ------------------------------

//-------------------- OUTPUT FIELDS ------------------------------
const TAX_ON_NORMAL_INCOME = "Tax on Normal Income";
const TAX_ON_SPECIAL_INCOME = "Tax on Special Income";
const INTEREST_US_234A = "Interest u/s  234A";
const INTEREST_US_234B = "Interest u/s  234B";
const INTEREST_US_234C = "Interest u/s  234C";
const INTEREST_US_234F = "Interest u/s  234F";
const REBATE = "Rebate u/s 87 A";
const RELIEF = "Relief";
const T80_COUT = "T80cout";
const TAXWO_SURCHARGE = "Tax with Education Cess & SC";
const LESS_REBATE87A = "Less Rebate 87 A";
const SURCHARGE = "Surcharge";
const EDUCATION_CESS = "Education Cess";
const TAX_PAYABLE = "Balance Payable (Refundable)";
const BALANCE_PAYABLE = "Tax Payable (Refundable)";
const TAX_PAYABLE_REFUNDABLE = "Tax Payable Refundable";
const INCOME_TAX = "Income Tax";
const TOTAL_234 = "Total 234";
const TOTAL_TAX = "Total Tax";
const TAXABLE_INCOME = "Taxable Income";
const TOTAL_INCOME = "Total Income";
const FILING_DATE = "Filing Date";
const DUE_DATE = "Due Date";

// -------------------STEP 14 ---------------------------------

const TDS = "TDS";
const PAID_AMOUNT = "Paid Amount";
const DEDUCTED_TAX = "Deducted Tax";
const DEPOSITED_TAX = "Deposited Tax";
const ADD_TDS = "Add TDS";

// -------------------STEP 15 ---------------------------------
const ADVANCED_TAX = "Advance Tax";
const DATE = "Date";
const BSR = "BSR Code";
const CIN = "CIN";
const AMOUNT = "Amount";
const FIRST = "First";
const SECOND = "Second";
const THIRD = "Third";
const FOURTH = "Fourth";
const FIFTH = "Fifth";
const ADD_TAX = "Add Tax";

// -------------------STEP 16 ---------------------------------

const SELF_ASSESMENT_TAX = "Self Assesment Tax";

// -----------------STEP 17 ITR INFORMATION ---------------------
const ITR_INFORMATION = "ITR Information";

// ----------------ERROR ------
const NO_INTERNET_CONNECTION_TITLE = "No Internet Connection";
const NO_INTERNET_CONNECTION_MESSAGE = "No Signal. Please Try Again Later.";
const ErrorTitle = "error_title";
const ErrorMessage = "error_message";
const OKButtonLabel = "Ok";

// ------------ DRAWER -------

const MYSUBSCRIBTION = "View My Subscriptions";
const TAX_CALCULATION = "Tax Calculation";
const GSTIN_NUMBERS = "Gstin Numbers";
const USER_PROFILE = "My Profile";
//
const GSTREMINDER = "Set Reminders";
const GSTREMINDERMSG = "Set Reminder for Gst Filing";

//  - -------------- JSON MODEL ------------------

const String SWVersionNo = "R1";
const String SWCreatedBy = "SW28450842";
const String JSONCreatedBy = "SW92202020";
const String IntermediaryCity = "Pune";
const String Digest = "7MqPRN7B3ovTtLW4B56TVNGyWmswke5ZoNdpUOFrq3o=";

const String FormName = "ITR-1";
const String FormVer = "Ver1.0";
const String SchemaVer = "Ver1.0.1";
const String AssessmentYear = "2021";
const String Description =
    "For Indls having Income from Salary, Pension, family pension and Interest";

//  ------ DESCRIPTION FIELDS ----------------

const String YEAR_DESC =
    "The assessment year (AY) is the year that comes after the FY. This is the time in which the income earned during FY is assessed and taxed. Both FY and AY start on 1 April and end on 31 March. For instance, FY 2019-20 and AY 2020-21 are one and the same.";

const String DATE_DESC = " Enter The Filling Date and Due Date";
const String TAX_DESC = "  it can be seen that taxpayers who do not have many deductions to claim can opt for the new regime, and those who have substantial deductions to claim resulting in lower tax can continue with the old regime.";
const String ITR_DESC = "It means that the Income-tax department has processed your return and Refund request is generated. The details are forwarded to the refund banker for processing the same.";
