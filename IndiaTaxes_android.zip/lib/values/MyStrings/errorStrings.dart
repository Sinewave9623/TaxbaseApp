const CUSTOMER_DOES_NOT_EXIST = "Customer Does Not Exist";
