part of values;

class Gradients {
  
}
