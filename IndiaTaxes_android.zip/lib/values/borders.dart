
part of values;


class Borders {
  static const BorderSide primaryBorder = BorderSide(
    color: Color.fromARGB(255, 112, 112, 112),
    width: 0.33333,
    style: BorderStyle.solid,
  );
  static const BorderSide secondaryBorder = BorderSide(
    color: Color.fromARGB(255, 138, 152, 186),
    width: 0.33333,
    style: BorderStyle.solid,
  );
}