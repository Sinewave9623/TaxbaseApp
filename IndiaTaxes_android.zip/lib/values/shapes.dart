

part of values ;

RoundedRectangleBorder cardBorder =  RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(20),
          ),
        );