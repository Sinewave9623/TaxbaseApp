part of values;

class AppColors {
  // blue colors
  static const primaryColor = Color(0xffea0027);
  static const primaryColorLight = Color(0xffffccd5);
  static const primaryColorDark = Color(0xff99001a);
  static const accentColor = Color(0xffffc200);
  static const errorColor = Color(0xffd32f2f);
  static const whiteColor = Color(0xFFFFFFFF);
  static const titleColor = Color(0xFF3E3D3D);
  static const subtitleColor = Color(0xFF7E7D7D);
  static const mydocumentBG_COLOR = Color(0xffea0027);
  static const mydocumentBG_COLOR2 = Color(0xffff6680);
  static const onBoardingScreenColor = Color(0xffff6680);
  static const onBoardingScreenColor2 = Color(0xfffaba2a);
  static const SplashScreenColor = Color(0xffffccd5);
  static const onDateSelectedColor = Color(0xff91db44);
}
