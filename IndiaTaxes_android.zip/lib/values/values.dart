library values;

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

part 'MyStrings/strings.dart';
part 'borders.dart';
part 'colors.dart';
part 'decorations.dart';
part 'gradients.dart';
part 'shadows.dart';
part 'shapes.dart';
part 'sizes.dart';
