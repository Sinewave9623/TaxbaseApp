class ImagePath {
  static const String image = "assets/images";
  static const String CA_CODE = image + "/ca_code.jpg";
  static const String VERIFICATION = image + "/verification.jpg";
  static const String PDF_ICON_IMAGE = image + "/pdf_icon.png";
  static const String PNG_ICON_IMAGE = image + "/png_icon.png";
  static const String JPG_ICON_IMAGE = image + "/jpg_icon.png";
  static const String DOC_ICON_IMAGE = image + "/doc_icon.png";
  static const String DOCX_ICON_IMAGE = image + "/docx_icon.png";
  static const String FILE_ICON_IMAGE = image + "/file_icon.png";
  static const String LOGO = image + "/appLogo.png";
}
