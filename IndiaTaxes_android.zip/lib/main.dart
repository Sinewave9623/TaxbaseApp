import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:taxbase_general/locator.dart';
import 'package:taxbase_general/router/router.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/services/common/connectivity_service.dart';
import 'package:taxbase_general/services/common/dialog_service.dart';
import 'package:taxbase_general/services/common/navigation_services.dart';
import 'package:taxbase_general/services/permission_handler/permissions_service.dart';
import 'package:taxbase_general/services/storage/hive_storage.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/base_views.dart';
import 'package:taxbase_general/ui/views/CALENDERUI/calendarCarouselScreen.dart';
import 'package:taxbase_general/ui/views/DASHBOARD/dashboard_screen.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/user_details_screen.dart';
import 'package:taxbase_general/ui/views/SPLASHSCREEN/splashscreen.dart';
import 'package:taxbase_general/values/theme.dart';
import 'package:taxbase_general/values/values.dart';

import 'ui/views/OTPSCREEN/generate_otp_screen.dart';

// import 'package:hive_flutter/hive_flutter.dart';

String mobileNumber;
Future<void> main() async {
  // await Hive.initFlutter();
  // Hive.registerAdapter(GstinDataAdapter());
  // Hive.registerAdapter(YearsAdapter());
  // Hive.registerAdapter(FyearDataAdapter());
  // await Hive.openBox<GstinData>("GstinData");

  WidgetsFlutterBinding.ensureInitialized();
  await setUpLocator();
  requestPermission();
  final services = AuthenticationServices();
  mobileNumber = services.user;
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarColor: AppColors.whiteColor,
      statusBarIconBrightness: Brightness.dark));
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]).then((_) {
    runApp(MyApp());
  });
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: AppColors.whiteColor,
        statusBarIconBrightness: Brightness.dark));
    return StreamProvider<ConnectivityStatus>(
      create: (context) => ConnectivityService().connectivityStream,
      child: MaterialApp(
        title: 'TaxBase General',
        theme: myTheme,
        debugShowCheckedModeBanner: false,
        navigatorObservers: [],
        builder: (context, child) => Navigator(
          key: locator<DialogService>().navigatorKey,
          onGenerateRoute: (settings) => MaterialPageRoute(
            builder: (context) => BaseView(child: child),
          ),
        ),
        home: mobileNumber == null ? SplashScreen() : DashBoardScreen(),
        // home: mobileNumber == null ? DashBoardScreen() : DashBoardScreen(),
        navigatorKey: locator<NavigationService>().navigationKey,
        onGenerateRoute: generateRoute,
        onGenerateTitle: (context) => (AppNameTitle),
      ),
    );
  }
}
