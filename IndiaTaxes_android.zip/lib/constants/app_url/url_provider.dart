// const baseUrl = "https://api.indiataxes.com";
const baseUrl = "https://productionapi.indiataxes.com";
const baseUrlSinewave = "https://taxapi.sinewave.co.in/API";

const get_token_url = "/api/token/";
const get_auth_token_url = "/CRM/Authtoken/";
const form16_upload_url = "/TaxCalculator/UploadForm16";
const form26_upload_url = "/TaxCalculator/UploadForm26AS";
const tax_calculator_url = "/TaxCalculator/CalculateTax";
const head_income_url = "/TaxCalculator/GetHeadOfIncome";
const returns_url = "/filing/getCustomerFiling/";
const store_to_backend_url = "/leads/create_or_update_calculation/";
const read_from_backend_url = "/leads/read_calculation/";

const getotp_url = "/leads/loginRegisterLead/";
const verifyotp_url = "/leads/verifyLead/";
const ca_codeverify_url = "/commons/verifycustomer/";
const customer_documents_url = "/filesandfolders/filefilter/";
const customer_Alldocuments_url = "/filesandfolders/filelist/";
const create_folder_url = "/filesandfolders/createfolder/";
const create_file_url = "/filesandfolders/createfile/";
const notification_seen_url = "/notifications/notification_seen/";
const send_deviceId_url = "/notifications/device/";
const update_user_details_url = "/leads/updateDetailsLead/";
const create_device_url = "/reminders/create_device/";
const getDurationList_url = "/reminders/get_frequency/";
const set_reminder_url = "/reminders/set_reminder/";
const get_type_url = "/reminders/get_type/";
const financial_years_action_url = "/filing/getFinancialYear/";
const readLeadGstin_url = "/leads/readLeadsGstin/";
const createLeadGstin_url = "/leads/createLeadsGstin/";
const updateLeadsGstin_url = "/leads/updateLeadsGstin/";
const deleteLeadsGstin_url = "/leads/deleteLeadsGstin/";
const creatGst_return_url = "/leads/createLeadsGstReturns";
const readGst_return_url = "/leads/readLeadsGstReturns";

const baseUrlSinewaveServices = "http://services.gstindia.services/Services";
const requestFor_otp_url = "/GSTR1/GSTR1_Service.svc/RequestForOTP";
const requestForVerify_otp_url =
    "/GSTR1/GSTR1_Service.svc/RequestForAuthorizationToken";
const viewTrackReturn_url = "/CommonApi/SearchTaxpayer.svc/ViewTrackReturns";
const requestRefreshToken_url =
    "/GSTR1/GSTR1_Service.svc/RequestForRefreshToken";
