import 'dart:async';

import 'package:taxbase_general/constants/extensions/string_extension.dart';

const mobileRegex = r"^([0-9][\s]*){10,16}$";

const codeRegex = r"^([0-9][\s]*){4,4}$";

const carNumberRegex = r"[A-Z]{2}[-][0-9]{2}[-][A-Z]{2}[-][0-9]{3}$";

RegExp tanNumberRegex =RegExp( r"[A-Z]{5}[0-9]{4}[A-Z]{1}$");

final StreamTransformer<String, String> validateEmail =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (email, sink) {
    final RegExp _emailRegExp = RegExp(
      r"^[a-zA-Z0-9.]+@[a-zA-Z0-9.]+\.[a-zA-Z]{2,4}",
    );
    if (_emailRegExp.hasMatch(email)) {
      sink.add(email);
    } else {
      sink.addError('Enter a valid email');
    }
  },
);

final StreamTransformer<String, String> validateTan =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (tan, sink) {
   
    if (tanNumberRegex.hasMatch(tan)) {
      sink.add(tan);
    } else {
      sink.addError('Enter a valid TAN');
    }
  },
);

final StreamTransformer<String, String> mobileValidator =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (phone, sink) {
    if (phone.isNotNullOrEmpty && RegExp(mobileRegex).hasMatch(phone)) {
      sink.add(phone);
    } else {
      sink.addError('Enter valid mobile number');
    }
  },
);

final StreamTransformer<String, String> passwordValidator =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (password, sink) {
    if (password.isNotNullOrEmpty && password.length > 1) {
      sink.add(password);
    } else {
      sink.addError('Enter valid password');
    }
  },
);

final StreamTransformer<String, String> nameValidator =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (password, sink) {
    if (password.isNotNullOrEmpty && password.length > 1) {
      sink.add(password);
    } else {
      sink.addError('Enter valid name');
    }
  },
);

final StreamTransformer<String, String> validInput =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (phone, sink) {
    if (phone.isNotNullOrEmpty && phone.length > 0) {
      sink.add(phone);
    } else {
      sink.addError('Enter valid Input');
    }
  },
);

final StreamTransformer<String, String> otpValidator =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (pincode, sink) {
    if (pincode.isNotNullOrEmpty && pincode.length == 4) {
      sink.add(pincode);
    } else {
      sink.addError('Enter valid OTP');
    }
  },
);

final StreamTransformer<String, String> cardNoValidator =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (pincode, sink) {
    if (pincode.isNotNullOrEmpty && pincode.length == 16) {
      sink.add(pincode);
    } else {
      sink.addError('Enter valid Card Number');
    }
  },
);

final StreamTransformer<String, String> cardCvvValidator =
    StreamTransformer<String, String>.fromHandlers(
  handleData: (pincode, sink) {
    if (pincode.isNotNullOrEmpty && pincode.length == 3) {
      sink.add(pincode);
    } else {
      sink.addError('Enter valid CVV');
    }
  },
);

String validateCarNumber(String carNumber) {
  if (RegExp(carNumberRegex).hasMatch(carNumber)) {
  } else {
    return 'Enter valid Car number';
  }
}

String validateGstNumber(String gstNumber) {
  if (gstNumber.isEmpty ||
      gstNumber == null.toString() ||
      gstNumber == "" ||
      gstNumber.length != 15) {
    return "Please Enter valid Gst Number";
  }
}

String validateCompanyName(String companyName) {
  if (companyName.isEmpty ||
      companyName == null.toString() ||
      companyName == "" ||
      companyName.length < 5) {
    return "Please Enter valid Company Name";
  }
}
