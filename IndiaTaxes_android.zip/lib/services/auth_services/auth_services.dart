import 'dart:io';

import 'package:flutter/src/widgets/framework.dart';
import 'package:taxbase_general/locator.dart';
import 'package:taxbase_general/models/GstinModel/create_gstin_responseModel.dart';
import 'package:taxbase_general/models/GstinModel/gstin_responseModel.dart';
import 'package:taxbase_general/models/OTP/get_otp_responseModel.dart';
import 'package:taxbase_general/models/OTP/updateUserDetailsModel.dart';
import 'package:taxbase_general/models/OTP/verify_otp_responseModel.dart';
import 'package:taxbase_general/models/RequestOtpSineWave/requeset_otp_model.dart';
import 'package:taxbase_general/models/durationModel/durationResponseModel.dart';
import 'package:taxbase_general/models/notificationsModel/notification_response_model.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_responseModel.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_type_responseModel.dart';
import 'package:taxbase_general/models/returnsModel/create_returnStatusModel.dart';
import 'package:taxbase_general/models/returnsModel/read_gstinDataModel.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/view_track_return_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/models/sinewaveModel/calculate_tax_response_model.dart';
import 'package:taxbase_general/models/sinewaveModel/form_16_model.dart';
import 'package:taxbase_general/models/sinewaveModel/get_token_model.dart';
import 'package:taxbase_general/models/sinewaveModel/head_income_model.dart';
import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
import 'package:taxbase_general/router/route_names.dart';
import 'package:taxbase_general/services/common/common_base_services.dart';
import 'package:taxbase_general/services/repository/repository_service.dart';
import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
import 'package:taxbase_general/models/sinewaveModel/storage_model.dart';

class AuthenticationServices extends CommonBaseServices {
  final _repository = locator<RepositoryService>();

  RepositoryService get repository => _repository;

  String get mytoken => storageService.mytoken;
  String get user => storageService.userMobileNo;
  String get trans_id => storageService.transaction_id;
  String get birthDate => storageService.birthDate;
  String get getUserBday => storageService.getUserBday;
  String get sinewaveToken => storageService.sineWaveToken;
  String get getUserDetails => storageService.getUserDetails;
  String get getAccessToken => storageService.getAccessToken;
  String get getUserName => storageService.getUserName;
  
  String get getUserAge => storageService.getUserAge;
  String get getUserAddress => storageService.getUserAddress;
  String get getUserTown => storageService.getUserTown;
  String get getUserFlatNo => storageService.getUserFlatNo;
  String get getUserPremise => storageService.getUserPremise;
  String get getUserRoad => storageService.getUserRoad;
  String get getUserArea => storageService.getUserArea;
  String get getUserPin => storageService.getUserPin;
  String get getUserState => storageService.getUserState;
  String get getUserCountry => storageService.getUserCountry;
  String get getUserDOB => storageService.getUserBday;
  String get getUserFirstName => storageService.getUserFirstName;
  String get getUserMiddleName => storageService.getUserMiddleName;
  String get getUserLastName => storageService.getUserLastName;

  String get getUserPan => storageService.getUserPan;
  String get getUserToken => storageService.getAccessToken;
  String get getGstInNo => storageService.getGstInNo;
  String get getSineWaveUserName => storageService.getSineWaveUserName;
  String get getDate => storageService.getDate;
  String get getUserGender => storageService.getUserGender;
  String get getUserBasicDetailsFromApi =>
      storageService.getUserBasicDetailsFromApi;

      

  Future<bool> get clearAll => storageService.clearAll();

  //-----------------------------SHARED PREFERENCE-----------------------------

  Future<bool> saveToken(String access) {
    return storageService.saveToken(access);
  }

  Future<bool> saveUserMobile(String mobileNo) {
    return storageService.saveUserMobile(mobileNo);
  }

  Future<bool> saveAccessToken(String token) {
    return storageService.saveAccessToken(token);
  }

  Future<bool> saveUserName(String name) {
    return storageService.saveUserName(name);
  }

  Future<bool> saveUserPan(String pan) {
    return storageService.saveUserPan(pan);
  }
  Future<bool> saveUserAddress(String pan) {
    return storageService.saveUserAddress(pan);
  }

  Future<bool> saveUserTown(String address) {
    return storageService.saveUserTown(address);
  }
  Future<bool> saveFlatNo(String address) {
    return storageService.saveFlatNo(address);
  }
  Future<bool> savepremiseName(String address) {
    return storageService.savePremise(address);
  }
  Future<bool> saveStreetName(String address) {
    return storageService.saveRoad(address);
  }
  Future<bool> saveArea(String address) {
    return storageService.saveArea(address);
  }
  Future<bool> saveUserPin(String address) {
    return storageService.savePin(address);
  }
  Future<bool> saveUserState(String address) {
    return storageService.saveState(address);
  }
  Future<bool> saveUserCountry(String address) {
    return storageService.saveCountry(address);
  }
  Future<bool> saveBirthDate(String bdate) {
    return storageService.saveBirthDate(bdate);
  }

  Future<bool> saveUserAge(String age) {
    return storageService.saveUserAge(age);
  }

  Future<bool> saveTransactionId(String transaction_id) {
    return storageService.saveTransactionId(transaction_id);
  }

  Future<bool> saveSinewaveToken(String authToken) {
    return storageService.saveSinewaveToken(authToken);
  }

  Future<bool> saveUserDetails(String user) {
    return storageService.saveUserDetails(user);
  }

  Future<bool> saveGstInNo(String gstinNo) {
    return storageService.saveGstInNo(gstinNo);
  }

  Future<bool> saveSineWaveusername(String username) {
    return storageService.saveSineWaveusername(username);
  }

  Future<bool> saveDate(String saveDate) {
    return storageService.saveDate(saveDate);
  }

  Future<bool> saveUserBirthDate(String birthDate) {
    return storageService.saveUserBirthDate(birthDate);
  }

  Future<bool> saveGender(String gender) {
    return storageService.saveGender(gender);
  }
  Future<bool> saveIsalaried(bool isSalariedYes) {
    return storageService.saveIsalaried(isSalariedYes);
  }
  Future<bool> saveUserFirstName(String firstName) {
    return storageService.saveUserFirstName(firstName);
  }
  Future<bool> saveUserMiddleName(String middleName) {
    return storageService.saveUserMiddleName(middleName);
  }
  Future<bool> saveUserLastName(String lastName) {
    return storageService.saveUserLastName(lastName);
  }


// -----------------------------  NAVIGATIONS-----------------------------
  Future<dynamic> navigateToVerifyOTPScreen(String mobileNumber) {
    return navigationServices.navigatePushReplacement(
        VERIFY_OTP_SCREEN_ROUTEPAGE,
        arguments: mobileNumber);
  }

  Future<dynamic> navigateToLoginScreen() {
    return navigationServices.pushAndRemoveUntil(GENERATE_OTP_SCREEN_ROUTEPAGE);
  }

  Future<dynamic> navigateToDashboardScreen() {
    return navigationServices
        .navigatePushReplacement(DASHBOARD_SCREEN_ROUTEPAGE);
  }

  Future<dynamic> navigateToGstReminderScreen() {
    return navigationServices.navigateTo(GSTREMINDER_SCREEN_ROUTEPAGE);
  }

  Future<dynamic> navigateToTaxCalculationScreen() {
    return navigationServices.navigateTo(TAX_CALCULATION_ROUTEPAGE);
  }

  Future<dynamic> navigateToCalculationScreen(Widget child) {
    return navigationServices.navigateTo(CALCULATION_ROUTEPAGE,
        arguments: child);
  }

  Future<dynamic> navigateToOutputScreen(TaxCalculationViewModel model) {
    return navigationServices.navigateTo(OUTPUT_ROUTEPAGE, arguments: model);
  }

  Future<dynamic> navigateToUserDetailScreen(String mobileNumber) {
    return navigationServices.navigateTo(USERDETAILS_ROUTEPAGE,
        arguments: mobileNumber);
  }

  // Future<dynamic> navigateToViewReturnScreen(
  //     YearModel yearmodel, List<GSTdata> gstData) {
  //   return navigationServices.navigateTo(VIEWRETURNS_ROUTEPAGE, arguments: {"GST":gstData,"Year":yearmodel});
  // }

  Future<dynamic> navigateToViewReturnScreen() {
    return navigationServices.navigatePushReplacement(VIEWRETURNS_ROUTEPAGE);
  }

  Future<dynamic> navigateToViewReturnnoScreen() {
    return navigationServices.navigateTo(VIEWRETURNS_ROUTEPAGE);
  }

  Future<dynamic> navigateToViewTrackReturns() {
    return navigationServices.navigateTo(VIEWTRACKRETURNS_ROUTEPAGE);
  }

  Future<dynamic> navigateToViewTrackReturnsAfterOTP(String gstinNo) {
    return navigationServices
        .navigatePushReplacement(VIEWTRACKRETURNS_ROUTEPAGE);
  }

  Future<dynamic> navigateToGSTINNUMBERScreen() {
    return navigationServices.navigateTo(GSTIN_NUMBER_ROUTEPAGE);
  }

  Future<dynamic> navigateToProfileScreen() {
    return navigationServices.navigateTo(USER_PROFILE_ROUTEPAGE);
  }


// -----------------------------  API CALLS-----------------------------

  Future<GetOtpResponseModel> getOtp(Map data) {
    return repository.getOtp(data);
  }

  Future<VerifyResponseOtpModel> verifyOTP(Map data) {
    return repository.verifyOTP(data);
  }

  // Future<TokenResponse> getToken(Map data) {
  //   return repository.getToken(data);
  // }

  Future<GetTokenModel> getSinewaveToken(Map map) {
    return repository.getSinewaveToken(map);
  }

  Future<CalculateTaxResponseModel> calculateTax(
      Map map, String sinewaveToken) {
    return repository.calculateTax(map, sinewaveToken);
  }

  Future<UpdateUserDetailsModel> updateUser(Map data) {
    return repository.updateUser(data);
  }

  Future<NotificationSeenResponseModel> createDeviceId(Map data) {
    return repository.createDeviceId(data);
  }

  Future<DurationListModel> getDurationList(String data) {
    return repository.getDurationList(data);
  }

  Future<ReminderResponseModel> setReminder(Map data) {
    return repository.setReminder(data);
  }

  Future<ReminderTypeResponseModel> getType(String token) {
    return repository.getType(token);
  }

  Future<YearModel> getFinancialYears(String token) {
    return repository.getFinancialYears(token);
  }

  Future<ReturnsModel> getAllReturns(Map request, String token) {
    return repository.getAllReturns(request, token);
  }

  Future<RequestOTPSineWaveModel> requestForOtp(Map map) {
    return repository.requestForOtp(map);
  }

  Future<RequestOTPSineWaveModel> requestForVerifyOtp(Map map) {
    return repository.requestForVerifyOtp(map);
  }

  Future<ViewTrackReturnsModel> viewTackReturn(Map map) {
    return repository.viewTackReturn(map);
  }

  Future<ViewTrackReturnsModel> requestForRefreshToken(Map map) {
    return repository.requestForRefreshToken(map);
  }

  Future<GstinResponseModel> getUserGstin(Map map) {
    return repository.getUserGstin(map);
  }

  Future<CreateGSTINResponseModel> createGstinUser(Map map) {
    return repository.createGstinUser(map);
  }

  Future<CreateGSTINResponseModel> updateGstinNumber(Map map) {
    return repository.updateGstinNumber(map);
  }

  Future<CreateGSTINResponseModel> deleteGstinNumber(Map map) {
    return repository.deleteGstinNumber(map);
  }

  Future<CreateReturnStatusModel> createReturnStatus(Map map) {
    return repository.createReturnStatus(map);
  }

  Future<ReadGstinDataModel> getReturnStatusTech(Map map) {
    return repository.getReturnStatusTech(map);
  }

  Future<StorageModel> saveToBackend(String token, Map map) {
    return repository.saveToBackend(token, map);
  }

  Future<ReadStorageModel> readStorage(Map map, String token) {
    return repository.readStorage(map, token);
  }

  Future<HeadIncomeModel> headIncome(String token, Map map) {
    return repository.headIncome(map, token);
  }

  Future<Form16Model> uploadForm16(File form16File, String sinewaveToken) {
    return repository.uploadForm16(form16File, sinewaveToken);
  }

  

}
