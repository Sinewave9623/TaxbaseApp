import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:taxbase_general/constants/app_url/url_provider.dart';
import 'package:taxbase_general/models/GstinModel/create_gstin_responseModel.dart';
import 'package:taxbase_general/models/GstinModel/gstin_responseModel.dart';
import 'package:taxbase_general/models/OTP/get_otp_responseModel.dart';
import 'package:taxbase_general/models/OTP/updateUserDetailsModel.dart';
import 'package:taxbase_general/models/OTP/verify_otp_responseModel.dart';
import 'package:taxbase_general/models/RequestOtpSineWave/requeset_otp_model.dart';
import 'package:taxbase_general/models/durationModel/durationResponseModel.dart';
import 'package:taxbase_general/models/notificationsModel/notification_response_model.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_responseModel.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_type_responseModel.dart';
import 'package:taxbase_general/models/returnsModel/create_returnStatusModel.dart';
import 'package:taxbase_general/models/returnsModel/read_gstinDataModel.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/view_track_return_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/models/sinewaveModel/calculate_tax_response_model.dart';
import 'package:taxbase_general/models/sinewaveModel/form_16_model.dart';
import 'package:taxbase_general/models/sinewaveModel/get_token_model.dart';
import 'package:taxbase_general/models/sinewaveModel/head_income_model.dart';
import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/values/values.dart';
import 'repository_service.dart';
import 'package:taxbase_general/models/sinewaveModel/storage_model.dart';

class ApiRepository extends RepositoryService {
  final Dio dio;

  ApiRepository({this.dio}) : assert(dio != null);

  AuthenticationServices _services;

  @override
  Future<GetOtpResponseModel> getOtp(Map data) async {
    // try {
    // Dio diocall;
    dio.options.extra['removeHeader'] = false;
    print("MAP DATA");
    print(data.toString());
    dio.options.baseUrl = baseUrl;
    final response = await dio.post(getotp_url,
        data: data, options: Options(contentType: 'application/json'));
    if (response.statusCode == 200 || response.statusCode == 304) {
      GetOtpResponseModel result;
      result = GetOtpResponseModel.fromJson(response.data);
      if (result.responseCode == "200") {
        return result;
      }
      return GetOtpResponseModel.withError(
        responseCode: result.responseCode,
        msg: result.msg.trim(),
      );
    }
    // } on DioError catch (error) {
    //   print("DIO ERROR");
    //   print(error.toString());
    //   return GetOtpResponseModel.withError(
    //     responseCode: error.response.statusCode.toString(),
    //     msg: error.response.data["msg"].toString(),
    //   );
    // } catch (e) {
    //   print("TRY CACHE ERROR");
    //   return GetOtpResponseModel.withError(
    //     responseCode: e.response.statusCode.toString(),
    //     msg: e.toString(),
    //   );
    // }
  }

  @override
  Future<VerifyResponseOtpModel> verifyOTP(Map data) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      print("MAP DATA");
      print(data.toString());
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(verifyotp_url,
          data: data, options: Options(contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        VerifyResponseOtpModel result;
        result = VerifyResponseOtpModel.fromJson(response.data);
        if (result.responseCode == "200") {
          return result;
        }
        return VerifyResponseOtpModel.withError(
          responseCode: result.responseCode,
          result: result.result.trim(),
        );
      }
    } on DioError catch (error) {
      print("DIO ERROR");
      print(error.toString());
      return VerifyResponseOtpModel.withError(
        responseCode: error.response.statusCode.toString(),
        result: error.response.data["result"].toString(),
      );
    } catch (e) {
      print(e.response.statusCode.toString());
      print("TRY CACHE ERROR");
      return VerifyResponseOtpModel.withError(
        responseCode: e.response.statusCode.toString(),
        result: e.toString(),
      );
    }
  }

  // @override
  // Future<TokenResponse> getToken(Map data) async {
  //   try {
  //     // Dio diocall;
  //     dio.options.extra['removeHeader'] = false;
  //     print("MAP DATA");
  //     print(data.toString());

  //     final response = await dio.post(get_token_url,
  //         data: data, options: Options(contentType: 'application/json'));
  //     if (response.statusCode == 200 || response.statusCode == 304) {
  //       TokenResponse result;
  //       result = TokenResponse.fromJson(response.data);
  //       if (result.refresh != null) {
  //         return result;
  //       }
  //     }
  //   } on DioError catch (error) {
  //     print("DIO ERROR");
  //     return TokenResponse.withError(
  //       responseCode: error.response.statusCode.toString(),
  //       msg: error.response.data.toString(),
  //     );
  //   } catch (e) {
  //     print(e.response.statusCode.toString());
  //     print("TRY CACHE ERROR");
  //   }
  // }

  @override
  Future<GetTokenModel> getSinewaveToken(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewave;
      final response = await dio.post(get_auth_token_url,
          data: map,
          options: Options(headers: {
            // "Authorization": map["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        GetTokenModel result;
        result = GetTokenModel.fromJson(response.data);
        if (result.authToken != null) {
          return result;
        }
      }
    } on DioError catch (error) {
      return GetTokenModel.withError(
        statusCode: error.response.data["status_cd"].toString(),
        msg: error.response.data["message"].toString(),
      );
    } catch (e) {
      return GetTokenModel.withError(
        statusCode: e.response.data["status_cd"].toString(),
        msg: e.response.data["message"].toString(),
      );
    }
  }

  @override
  Future<CalculateTaxResponseModel> calculateTax(
      Map map, String sinewaveToken) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewave;
      final response = await dio.post(tax_calculator_url,
          data: map,
          options: Options(headers: {
            "AuthToken": sinewaveToken, // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        CalculateTaxResponseModel result;
        result = CalculateTaxResponseModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return CalculateTaxResponseModel.withError(
        msg: error.response.data["message"].toString(),
        statusCode: error.response.data['status_code'],
      );
    } catch (e) {
      return CalculateTaxResponseModel.withError(
        msg: "Went wrong",
        statusCode: 500,
      );
    }
  }

  @override
  Future<UpdateUserDetailsModel> updateUser(Map data) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      print("MAP DATA");
      print(data.toString());
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(update_user_details_url,
          data: data,
          options: Options(headers: {
            "Authorization": data["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        UpdateUserDetailsModel result;
        result = UpdateUserDetailsModel.fromJson(response.data);
        if (result.responseCode == "200") {
          return result;
        }
        return UpdateUserDetailsModel.withError(
          responseCode: result.responseCode,
          msg: result.msg.trim(),
        );
      }
    } on DioError catch (error) {
      print("DIO ERROR");
      print(error.toString());
      return UpdateUserDetailsModel.withError(
        responseCode: error.response.statusCode.toString(),
        msg: error.response.data["msg"].toString(),
      );
    } catch (e) {
      print(e.response.statusCode.toString());
      print("TRY CACHE ERROR");
      return UpdateUserDetailsModel.withError(
        responseCode: e.response.statusCode.toString(),
        msg: e.toString(),
      );
    }
  }

  @override
  Future<NotificationSeenResponseModel> createDeviceId(Map data) async {
// try {
    // Dio diocall;
    dio.options.extra['removeHeader'] = false;
    print("MAP DATA");
    print(data.toString());
    dio.options.baseUrl = baseUrl;
    final response = await dio.post(create_device_url,
        data: data, options: Options(contentType: 'application/json'));
    if (response.statusCode == 200 || response.statusCode == 304) {
      NotificationSeenResponseModel result;
      result = NotificationSeenResponseModel.fromJson(response.data);
      if (result.responseCode == "200") {
        return result;
      }
      return NotificationSeenResponseModel.withError(
        responseCode: result.responseCode,
        msg: result.msg.trim(),
      );
    }
    // } on DioError catch (error) {
    //   print("DIO ERROR");
    //   print(error.toString());
    //   return NotificationSeenResponseModel.withError(
    //     responseCode: error.response.statusCode.toString(),
    //     msg: error.response.data["msg"].toString(),
    //   );
    // } catch (e) {
    //   print(e.response.statusCode.toString());
    //   print("TRY CACHE ERROR");
    //   return NotificationSeenResponseModel.withError(
    //     responseCode: e.response.statusCode.toString(),
    //     msg: e.toString(),
    //   );
    // }
  }

  @override
  Future<DurationListModel> getDurationList(String data) async {
    // try {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      print("MAP DATA");
      print(data.toString());
      dio.options.baseUrl = baseUrl;
      final response = await dio.get(getDurationList_url,
          options: Options(
              headers: {"Authorization": "Bearer " + data},
              contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        DurationListModel result;
        result = DurationListModel.fromJson(response.data);
        if (result.responseCode == "200") {
          return result;
        }
        return DurationListModel.withError(
          responseCode: result.responseCode,
          msg: result.msg.trim(),
        );
      }
    } on DioError catch (error) {
      print("DIO ERROR");
      print(error.toString());
      return DurationListModel.withError(
        responseCode: error.response.statusCode.toString(),
        msg: error.response.data["msg"].toString(),
      );
    } catch (e) {
      print(e.response.statusCode.toString());
      print("TRY CACHE ERROR");
      return DurationListModel.withError(
        responseCode: e.response.statusCode.toString(),
        msg: e.toString(),
      );
    }
  }

  @override
  Future<ReminderResponseModel> setReminder(Map data) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      print("MAP DATA");
      print(data.toString());
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(set_reminder_url,
          data: data,
          options: Options(
              headers: {"Authorization": "Bearer " + data["token"]},
              contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        ReminderResponseModel result;
        result = ReminderResponseModel.fromJson(response.data);
        if (result.responseCode == "200") {
          return result;
        }
        return ReminderResponseModel.withError(
          responseCode: result.responseCode,
          msg: result.msg.trim(),
        );
      }
    } on DioError catch (error) {
      print("DIO ERROR");
      print(error.toString());
      return ReminderResponseModel.withError(
        responseCode: error.response.statusCode.toString(),
        msg: error.message.toString(),
      );
    } catch (e) {
      print(e.response.statusCode.toString());
      print("TRY CACHE ERROR");
      return ReminderResponseModel.withError(
        responseCode: e.response.statusCode.toString(),
        msg: e.toString(),
      );
    }
  }

  @override
  Future<ReminderTypeResponseModel> getType(String token) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      print("MAP DATA");
      dio.options.baseUrl = baseUrl;
      final response = await dio.get(get_type_url,
          options: Options(
              headers: {"Authorization": "Bearer " + token},
              contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        ReminderTypeResponseModel result;
        result = ReminderTypeResponseModel.fromJson(response.data);
        if (result.responseCode == "200") {
          return result;
        }
        return ReminderTypeResponseModel.withError(
          responseCode: result.responseCode,
          msg: result.msg.trim(),
        );
      }
    } on DioError catch (error) {
      print("DIO ERROR");
      print(error.toString());
      return ReminderTypeResponseModel.withError(
        responseCode: error.response.statusCode.toString(),
        msg: error.message.toString(),
      );
    } catch (e) {
      print(e.response.statusCode.toString());
      print("TRY CACHE ERROR");
      return ReminderTypeResponseModel.withError(
        responseCode: e.response.statusCode.toString(),
        msg: e.toString(),
      );
    }
  }

  @override
  Future<YearModel> getFinancialYears(String token) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.get(financial_years_action_url,
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + token, // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        YearModel result;
        result = YearModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return YearModel.withError(
        msg: error.response.data["message"].toString(),
        responseCode: error.response.statusCode.toString(),
      );
    } catch (e) {
      return YearModel.withError(
        msg: e.response.data["msg"].toString(),
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<Form16Model> uploadForm16(
      File form16file, String sinewaveToken) async {
    FormData data;
    final Map<String, dynamic> someMap = {
      "Form16": await MultipartFile.fromFile(form16file.path),
    };
    data = FormData.fromMap(someMap);

    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewave;
      final response = await dio.post(form16_upload_url,
          data: data,
          options: Options(
              headers: {
                "AuthToken": sinewaveToken,
                // set content-length
              },
              contentType:
                  'multipart/form-data;boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW'));

      if (response.statusCode == 200 || response.statusCode == 304) {
        Form16Model result;
        result = Form16Model.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return Form16Model.withError(
          msg: error.response.data["message"].toString(),
          statusCode: error.response.data['status_code']);
    } catch (e) {
      return Form16Model.withError(
          msg: e.response.data["message"].toString(),
          statusCode: e.response.data['status_code']);
    }
  }

  @override
  Future<ReturnsModel> getAllReturns(Map request, String token) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(returns_url,
          data: request,
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + token, // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        ReturnsModel result;
        result = ReturnsModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return ReturnsModel.withError(
        msg: error.response.data["message"].toString(),
        responseCode: error.response.data['response_code'],
      );
    } catch (e) {
      return ReturnsModel.withError(
        msg: e.response.data["message"].toString(),
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<RequestOTPSineWaveModel> requestForOtp(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewaveServices;
      final response = await dio.post(requestFor_otp_url,
          options: Options(headers: {
            "gstin": map["gstin"],
            "username": map["username"],
            "customer_id": CUSTOMER_ID,
            "ip_address": "",
            "hkey": HKEY,
            "lkey": LKEY, // set content-length
          }, contentType: 'application/json'));
      Logger().e(response);
      if (response.statusCode == 200 || response.statusCode == 304) {
        RequestOTPSineWaveModel result;
        result = RequestOTPSineWaveModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      // return ReturnsModel.withError(
      //   msg: error.response .data["message"].toString(),
      //   responseCode: error.response.data['response_code'],
      // );
    } catch (e) {
      // return ReturnsModel.withError(
      //   msg: e.response .data["message"].toString(),
      //   responseCode: e.response .data["response_code"].toString(),
      // );
    }
  }

  @override
  Future<RequestOTPSineWaveModel> requestForVerifyOtp(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewaveServices;
      final response = await dio.post(requestForVerify_otp_url,
          options: Options(headers: {
            "gstin": map["gstin"],
            "username": map["username"],
            "customer_id": CUSTOMER_ID,
            "ip_address": "",
            "hkey": HKEY,
            "lkey": LKEY,
            "otp": map["otp"],
          }, contentType: 'application/json'));
      Logger().e(response);
      if (response.statusCode == 200 || response.statusCode == 304) {
        RequestOTPSineWaveModel result;
        result = RequestOTPSineWaveModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      // return ReturnsModel.withError(
      //   msg: error.response .data["message"].toString(),
      //   responseCode: error.response.data['response_code'],
      // );
    } catch (e) {
      // return ReturnsModel.withError(
      //   msg: e.response .data["message"].toString(),
      //   responseCode: e.response .data["response_code"].toString(),
      // );
    }
  }

  @override
  Future<ViewTrackReturnsModel> viewTackReturn(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewaveServices;
      final response = await dio.get(viewTrackReturn_url,
          options: Options(headers: {
            "gstin": map["gstin"],
            "username": map["username"],
            "customer_id": CUSTOMER_ID,
            "ip_address": "",
            "hkey": HKEY,
            "lkey": LKEY,
            "ret_period": map["ret_period"],
          }, contentType: 'application/json'));
      Logger().e(response.data.toString());
      if (response.statusCode == 200 || response.statusCode == 304) {
        ViewTrackReturnsModel result;
        result = ViewTrackReturnsModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      // return ReturnsModel.withError(
      //   msg: error.response .data["message"].toString(),
      //   responseCode: error.response.data['response_code'],
      // );
    } catch (e) {
      // return ReturnsModel.withError(
      //   msg: e.response .data["message"].toString(),
      //   responseCode: e.response .data["response_code"].toString(),
      // );
    }
  }

  @override
  Future<ViewTrackReturnsModel> requestForRefreshToken(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewaveServices;
      final response = await dio.get(requestRefreshToken_url,
          options: Options(headers: {
            "gstin": map["gstin"],
            "username": map["username"],
            "customer_id": CUSTOMER_ID,
            "hkey": HKEY,
            "lkey": LKEY,
          }, contentType: 'application/json'));
      Logger().e(response);
      if (response.statusCode == 200 || response.statusCode == 304) {
        ViewTrackReturnsModel result;
        result = ViewTrackReturnsModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      // return ReturnsModel.withError(
      //   msg: error.response .data["message"].toString(),
      //   responseCode: error.response.data['response_code'],
      // );
    } catch (e) {
      // return ReturnsModel.withError(
      //   msg: e.response .data["message"].toString(),
      //   responseCode: e.response .data["response_code"].toString(),
      // );
    }
  }

  @override
  Future<GstinResponseModel> getUserGstin(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(readLeadGstin_url,
          data: map,
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + map["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        GstinResponseModel result;
        result = GstinResponseModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return GstinResponseModel.withError(
        responseCode: error.response.statusCode.toString(),
      );
    } catch (e) {
      return GstinResponseModel.withError(
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<CreateGSTINResponseModel> createGstinUser(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(createLeadGstin_url,
          data: map,
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + map["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        CreateGSTINResponseModel result;
        result = CreateGSTINResponseModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return CreateGSTINResponseModel.withError(
        responseCode: error.response.data['response_code'],
      );
    } catch (e) {
      return CreateGSTINResponseModel.withError(
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<CreateGSTINResponseModel> updateGstinNumber(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(updateLeadsGstin_url,
          data: map,
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + map["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        CreateGSTINResponseModel result;
        result = CreateGSTINResponseModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return CreateGSTINResponseModel.withError(
        responseCode: error.response.data['response_code'],
      );
    } catch (e) {
      return CreateGSTINResponseModel.withError(
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<CreateGSTINResponseModel> deleteGstinNumber(Map map) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(deleteLeadsGstin_url,
          data: map,
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + map["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        CreateGSTINResponseModel result;
        result = CreateGSTINResponseModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return CreateGSTINResponseModel.withError(
        responseCode: error.response.data['response_code'],
      );
    } catch (e) {
      return CreateGSTINResponseModel.withError(
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<CreateReturnStatusModel> createReturnStatus(Map map) async {
    try {
      // Dio diocall;

      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(creatGst_return_url,
          data: jsonEncode(map),
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + map["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        CreateReturnStatusModel result;
        result = CreateReturnStatusModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return CreateReturnStatusModel.withError(
        msg: error.response.statusMessage.toString(),
        responseCode: error.response.data['response_code'],
      );
    } catch (e) {
      return CreateReturnStatusModel.withError(
        msg: e.response.statusMessage.toString(),
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<ReadGstinDataModel> getReturnStatusTech(Map map) async {
    try {
      // Dio diocall;

      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(readGst_return_url,
          data: map,
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + map["token"], // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        ReadGstinDataModel result;
        result = ReadGstinDataModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return ReadGstinDataModel.withError(
        // msg: error.response.statusMessage.toString(),
        responseCode: error.response.data['response_code'],
      );
    } catch (e) {
      return ReadGstinDataModel.withError(
        // msg: e.response.statusMessage.toString(),
        responseCode: e.response.data["response_code"].toString(),
      );
    }
  }

  @override
  Future<StorageModel> saveToBackend(String token, Map map) async {
    try {
      // Dio diocall;
      print(token);
      print(jsonEncode(map));
      print(baseUrl + store_to_backend_url);
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrl;
      final response = await dio.post(store_to_backend_url,
          data: jsonEncode(map),
          options: Options(headers: {
            "Authorization": BEARER_TOKEN + token, // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        final result = StorageModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return StorageModel.withError(
          responseCode: error.response.statusCode.toString(),
          msg: error.response.data['msg'].toString());
    } catch (e) {
      Logger().e(e.toString());
      return StorageModel.withError(
          responseCode: e.response.statusCode.toString(),
          msg: e.response.data['msg'].toString());
    }
  }

  @override
  Future<ReadStorageModel> readStorage(Map map, String token) async {
//  try {
    // Dio diocall;
    dio.options.extra['removeHeader'] = false;
    dio.options.baseUrl = baseUrl;
    final response = await dio.post(read_from_backend_url,
        data: map,
        options: Options(headers: {
          "Authorization": BEARER_TOKEN + token, // set content-length
        }, contentType: 'application/json'));
    if (response.statusCode == 200 || response.statusCode == 304) {
      Logger().wtf(response.data);
      final result = ReadStorageModel.fromJson(response.data);
      return result;
    }
    // } on DioError catch (error) {
    //   return ReadStorageModel.withError(
    //     responseCode: error.response.statusCode .toString(),
    //   );
    // } catch (e) {
    //   return ReadStorageModel.withError(
    //     responseCode: e.response.statusCode .toString(),
    //   );
    // }
  }

  @override
  Future<HeadIncomeModel> headIncome(Map map, String sinewaveToken) async {
    try {
      // Dio diocall;
      dio.options.extra['removeHeader'] = false;
      dio.options.baseUrl = baseUrlSinewave;
      final response = await dio.post(head_income_url,
          data: map,
          options: Options(headers: {
            "AuthToken": sinewaveToken, // set content-length
          }, contentType: 'application/json'));
      if (response.statusCode == 200 || response.statusCode == 304) {
        final result = HeadIncomeModel.fromJson(response.data);
        return result;
      }
    } on DioError catch (error) {
      return HeadIncomeModel.withError(
          responseCode: error.response.statusCode, msg: error.message);
    } catch (e) {
      return HeadIncomeModel.withError(
          responseCode: e.response.statusCode, msg: e.toString());
    }
  }
}
