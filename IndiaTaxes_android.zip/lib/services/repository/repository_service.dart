import 'dart:io';

import 'package:taxbase_general/models/GstinModel/create_gstin_responseModel.dart';
import 'package:taxbase_general/models/GstinModel/gstin_responseModel.dart';
import 'package:taxbase_general/models/OTP/get_otp_responseModel.dart';
import 'package:taxbase_general/models/OTP/tokenResponse_Model.dart';
import 'package:taxbase_general/models/OTP/updateUserDetailsModel.dart';
import 'package:taxbase_general/models/OTP/verify_otp_responseModel.dart';
import 'package:taxbase_general/models/RequestOtpSineWave/requeset_otp_model.dart';
import 'package:taxbase_general/models/durationModel/durationResponseModel.dart';
import 'package:taxbase_general/models/notificationsModel/notification_response_model.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_responseModel.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_type_responseModel.dart';
import 'package:taxbase_general/models/returnsModel/create_returnStatusModel.dart';
import 'package:taxbase_general/models/returnsModel/read_gstinDataModel.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/view_track_return_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/models/sinewaveModel/calculate_tax_response_model.dart';
import 'package:taxbase_general/models/sinewaveModel/form_16_model.dart';
import 'package:taxbase_general/models/sinewaveModel/get_token_model.dart';
import 'package:taxbase_general/models/sinewaveModel/head_income_model.dart';
import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
import 'package:taxbase_general/models/sinewaveModel/storage_model.dart';

abstract class RepositoryService {
  Future<GetOtpResponseModel> getOtp(Map data);

  Future<VerifyResponseOtpModel> verifyOTP(Map data);

  // Future<TokenResponse> getToken(Map data);

  Future<GetTokenModel> getSinewaveToken(Map map);

  Future<CalculateTaxResponseModel> calculateTax(Map map, String sinewaveToken);

  Future<UpdateUserDetailsModel> updateUser(Map data);

  Future<NotificationSeenResponseModel> createDeviceId(Map data);

  Future<DurationListModel> getDurationList(String data);

  Future<ReminderResponseModel> setReminder(Map data);

  Future<ReminderTypeResponseModel> getType(String token);

  Future<YearModel> getFinancialYears(String token);

  Future<ReturnsModel> getAllReturns(Map request, String token);

  Future<RequestOTPSineWaveModel> requestForOtp(Map map);

  Future<RequestOTPSineWaveModel> requestForVerifyOtp(Map map);
  
  Future<Form16Model>  uploadForm16(File form16file, String sinewaveToken ) ;


  Future<ViewTrackReturnsModel> viewTackReturn(Map map);

  Future<ViewTrackReturnsModel> requestForRefreshToken(Map map);

  Future<GstinResponseModel> getUserGstin(Map map);

  Future<CreateGSTINResponseModel> createGstinUser(Map map);

  Future<CreateGSTINResponseModel> updateGstinNumber(Map map);

  Future<CreateGSTINResponseModel> deleteGstinNumber(Map map);

  Future<CreateReturnStatusModel> createReturnStatus(Map map);

  Future<ReadGstinDataModel> getReturnStatusTech(Map map);

  Future<StorageModel> saveToBackend(String token, Map map) ;

  Future<ReadStorageModel> readStorage(Map map, String token) ;

  Future<HeadIncomeModel> headIncome(Map map, String token) ;

}
