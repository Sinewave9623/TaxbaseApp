abstract class StorageService {
  String get mytoken;
  String get userMobileNo;
  String get transaction_id;
  String get birthDate;
  String get sineWaveToken;
  String get getUserDetails;
  String get getAccessToken;
  
  String get getUserName;
  String get getUserPan;
  String get getUserAddress;
  String get getUserTown;
  String get getUserFlatNo;
  String get getUserPremise;
  String get getUserRoad;
  String get getUserArea;
  String get getUserPin;
  String get getUserState;
  String get getUserCountry;
 
  String get getUserAge;

  String get getGstInNo;
  String get getDate;

  String get getUserBasicDetailsFromApi;

  String get getSineWaveUserName;
  String get getUserBday;
  String get getUserGender;
  bool get getisSalariedYes;

  Future<bool> clearAll();

  Future<bool> saveToken(String access);

  Future<bool> saveUserMobile(String mobileNo);
  Future<bool> saveTransactionId(String transaction_id);

  Future<bool> saveSinewaveToken(String authToken);

  Future<bool> saveUserDetails(String user);

  Future<bool> saveAccessToken(String token);

  Future<bool> saveUserName(String name);

  Future<bool> saveUserPan(String pan);

  Future<bool> saveUserTown(String address);
  Future<bool> saveFlatNo(String address);
  Future<bool> savePremise(String address);
  Future<bool> saveRoad(String address);
  Future<bool> saveArea(String address);
  Future<bool> savePin(String address);
  Future<bool> saveState(String address);
  Future<bool> saveCountry(String address);
  Future<bool> saveUserAddress(String address);
  Future<bool> saveBirthDate(String date);

  Future<bool> saveUserAge(String age);

  Future<bool> saveGstInNo(String gstinNo);

  Future<bool> saveSineWaveusername(String username);

  Future<bool> saveDate(String saveDate);

  Future<bool> saveUserBirthDate(String birthDate);

  Future<bool> saveBasicDetailFromApi(String basicDetailss);

  Future<bool> saveGender(String gender);

  Future<bool> saveIsalaried(bool isSalariedYes);

  Future<bool> saveUserFirstName(String firstName);
  String get getUserFirstName;

  Future<bool> saveUserMiddleName(String middleName);
  String get getUserMiddleName;
  
  Future<bool> saveUserLastName(String lastName);
  String get getUserLastName;

}
