// import 'package:hive/hive.dart';
// part 'hive_storage.g.dart';

// @HiveType(typeId: 2)
// class GstinData extends HiveObject {
//   @HiveField(0)
//   String gstin;

//   @HiveField(1)
//   List<Years> year;

//   GstinData({this.gstin, this.year});
// }

// @HiveType(typeId: 3)
// class Years extends HiveObject {
//   @HiveField(0)
//   String fyear;

//   @HiveField(1)
//   List<FyearData> fyearData;

//   Years({this.fyear, this.fyearData});
// }

// @HiveType(typeId: 4)
// class FyearData extends HiveObject {
//   @HiveField(0)
//   String fdate;

//   FyearData({this.fdate});
// }
