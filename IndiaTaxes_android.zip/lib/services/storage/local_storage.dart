import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:taxbase_general/services/storage/storage_service.dart';

import 'key_provider.dart';

class LocalStorage extends StorageService {
  final SharedPreferences prefs;

  LocalStorage({this.prefs}) : assert(prefs != null);

  @override
  Future<bool> clearAll() {
    return prefs.clear();
  }

  @override
  // TODO: implement mytoken
  String get mytoken {
    if (!prefs.containsKey(MY_TOKEN)) {
      return null;
    }
    final userString = prefs.getString(MY_TOKEN);
    return userString;
  }

  @override
  Future<bool> saveToken(String access) {
    final value = access;
    return prefs.setString(MY_TOKEN, value);
  }

  @override
  Future<bool> saveUserMobile(String mobile) {
    final value = mobile;
    return prefs.setString(USER_MOBILE, value);
  }

  @override
  String get userMobileNo {
    if (!prefs.containsKey(USER_MOBILE)) {
      return null;
    }
    final userString = prefs.getString(USER_MOBILE);
    return userString;
  }

  @override
  // TODO: implement customerId
  String get transaction_id {
    if (!prefs.containsKey(TRANSACTION_ID)) {
      return null;
    }
    final userString = prefs.getString(TRANSACTION_ID);
    return userString;
  }

  @override
  Future<bool> saveTransactionId(String transaction_id) {
    final value = transaction_id;
    return prefs.setString(TRANSACTION_ID, value);
  }

  @override
  Future<bool> saveBirthDate(String birthDate) {
    final value = birthDate;
    return prefs.setString(BIRTH_DATE, value);
  }

  @override
  String get birthDate {
    if (!prefs.containsKey(BIRTH_DATE)) {
      return null;
    }
    final userString = prefs.getString(BIRTH_DATE);
    return userString;
  }

  @override
  Future<bool> saveSinewaveToken(String authToken) {
    final value = authToken;
    return prefs.setString(SINEWAVE_TOKEN, value);
  }

  @override
  String get sineWaveToken {
    if (!prefs.containsKey(SINEWAVE_TOKEN)) {
      return null;
    }
    final userString = prefs.getString(SINEWAVE_TOKEN);
    return userString;
  }

  @override
  String get getUserDetails {
    if (!prefs.containsKey(USER_DETAILS)) {
      return null;
    }
    final String userString = prefs.getString(USER_DETAILS);
    return userString;
  }

  @override
  Future<bool> saveUserDetails(String user) {
    final value = user;
    return prefs.setString(USER_DETAILS, value);
  }

  @override
  String get getAccessToken {
    if (!prefs.containsKey(USER_TOKEN)) {
      return null;
    }
    final String userString = prefs.getString(USER_TOKEN);
    return userString;
  }

  @override
  Future<bool> saveAccessToken(String token) {
    final value = token;
    return prefs.setString(USER_TOKEN, value);
  }

  @override
  String get getUserTown {
    if (!prefs.containsKey(USER_TOWN)) {
      return null;
    }
    final String userString = prefs.getString(USER_TOWN);
    return userString;
  }

  @override
  String get getUserAge {
    if (!prefs.containsKey(USER_AGE)) {
      return null;
    }
    final String userString = prefs.getString(USER_AGE);
    return userString;
  }

  @override
  String get getUserName {
    if (!prefs.containsKey(USER_NAME)) {
      return null;
    }
    final String userString = prefs.getString(USER_NAME);
    return userString;
  }

  @override
  String get getUserPan {
    if (!prefs.containsKey(USER_PAN)) {
      return null;
    }
    final String userString = prefs.getString(USER_PAN);
    return userString;
  }

  @override
  Future<bool> saveUserTown(String town) {
    final value = town;
    return prefs.setString(USER_TOWN, value);
  }

  @override
  Future<bool> saveUserAge(String age) {
    final value = age;
    return prefs.setString(USER_AGE, value);
  }

  @override
  Future<bool> saveUserName(String name) {
    final value = name;
    return prefs.setString(USER_NAME, value);
  }

  @override
  Future<bool> saveUserPan(String pan) {
    final value = pan;
    return prefs.setString(USER_PAN, value);
  }

  @override
  Future<bool> saveGstInNo(String gstinNo) {
    final value = gstinNo;
    return prefs.setString(USER_GSTIN, value);
  }

  @override
  Future<bool> saveSineWaveusername(String username) {
    final value = username;
    return prefs.setString(USER_USERNAME, value);
  }

  @override
  // TODO: implement getGstInNo
  String get getGstInNo {
    if (!prefs.containsKey(USER_GSTIN)) {
      return null;
    }
    final String userString = prefs.getString(USER_GSTIN);
    return userString;
  }

  @override
  String get getSineWaveUserName {
    if (!prefs.containsKey(USER_USERNAME)) {
      return null;
    }
    final String userString = prefs.getString(USER_USERNAME);
    return userString;
  }

  @override
  String get getDate {
    if (!prefs.containsKey(SAVE_DATE)) {
      return null;
    }
    final String userString = prefs.getString(SAVE_DATE);
    return userString;
  }

@override
  // TODO: implement getUserBday
  String get getUserBday {
    if (!prefs.containsKey(USER_BDAY)) {
      return null;
    }
    final String userString = prefs.getString(USER_BDAY);
    return userString;
  }

  @override
  Future<bool> saveDate(String saveDate) {
    final value = saveDate;
    return prefs.setString(SAVE_DATE, value);
  }

  @override
  Future<bool> saveUserBirthDate(String birthDate1) {
    final value = birthDate1;
    return prefs.setString(USER_BDAY, value);
  }

  @override
  // TODO: implement getUserBasicDetailsFromApi
  String get getUserBasicDetailsFromApi {
    if (!prefs.containsKey(USER_BASIC_DETAILS_FROM_API)) {
      return null;
    }
    final String userString = prefs.getString(USER_BASIC_DETAILS_FROM_API);
    return userString;
  }

  @override
  Future<bool> saveBasicDetailFromApi(String basicDetailss) {
    final value = basicDetailss;
    return prefs.setString(USER_BASIC_DETAILS_FROM_API, value);
  }

  @override
  Future<bool> saveGender(String gender) {
    final value = gender;
    return prefs.setString(USER_GENDER, value);
  }

  @override
  // TODO: implement getUserGender
  String get getUserGender {
    if (!prefs.containsKey(USER_GENDER)) {
      return null;
    }
    final String userString = prefs.getString(USER_GENDER);
    return userString;
  }

  @override
  // TODO: implement getisSalariedYes
  bool get getisSalariedYes {
    if (!prefs.containsKey(USER_IS_SALARIED)) {
      return null;
    }
    final bool userString = prefs.getBool(USER_IS_SALARIED);
    return userString;
  }

  @override
  Future<bool> saveIsalaried(bool isSalariedYes) {
    final value = isSalariedYes;
    return prefs.setBool(USER_IS_SALARIED, isSalariedYes);
  }

  @override
  // TODO: implement getUserFlatNo
  String get getUserFlatNo {
    if (!prefs.containsKey(USER_FLAT)) {
      return null;
    }
    final String userString = prefs.getString(USER_FLAT);
    return userString;
  }

  @override
  Future<bool> saveFlatNo(String flat){
    final value = flat;
    return prefs.setString(USER_FLAT, value);
  }

  @override
  // TODO: implement getUserArea
  String get getUserArea {
    if (!prefs.containsKey(USER_AREA)) {
      return null;
    }
    final String userString = prefs.getString(USER_AREA);
    return userString;
  }

  @override
  // TODO: implement getUserCountry
  String get getUserCountry {
    if (!prefs.containsKey(USER_COUNTRY)) {
      return null;
    }
    final String userString = prefs.getString(USER_COUNTRY);
    return userString;
  }

  @override
  // TODO: implement getUserPin
  String get getUserPin {
    if (!prefs.containsKey(USER_PIN)) {
      return null;
    }
    final String userString = prefs.getString(USER_PIN);
    return userString;
  }

  @override
  // TODO: implement getUserPremise
  String get getUserPremise  {
    if (!prefs.containsKey(USER_PREMISE)) {
      return null;
    }
    final String userString = prefs.getString(USER_PREMISE);
    return userString;
  }

  @override
  // TODO: implement getUserRoad
  String get getUserRoad {
    if (!prefs.containsKey(USER_ROAD)) {
      return null;
    }
    final String userString = prefs.getString(USER_ROAD);
    return userString;
  }

  @override
  // TODO: implement getUserState
  String get getUserState {
    if (!prefs.containsKey(USER_STATE)) {
      return null;
    }
    final String userString = prefs.getString(USER_STATE);
    return userString;
  }

  @override
  Future<bool> saveArea(String area) {
    final value = area;
    return prefs.setString(USER_AREA, value);
  }
  
    @override
    Future<bool> saveCountry(String country) {
    final value = country;
    return prefs.setString(USER_COUNTRY, value);
  }
  
    @override
    Future<bool> savePin(String pin) {
    final value = pin;
    return prefs.setString(USER_PIN, value);
  }
  
    @override
    Future<bool> savePremise(String premise) {
    final value = premise;
    return prefs.setString(USER_PREMISE, value);
  }
  
    @override
    Future<bool> saveRoad(String road) {
    final value = road;
    return prefs.setString(USER_ROAD, value);
  }
  
    @override
    Future<bool> saveState(String state) {
    final value = state;
    return prefs.setString(USER_STATE, value);
  }

  @override
  Future<bool> saveUserAddress(String address)  {
    final value = address;
    return prefs.setString(USER_ADDRESS, value);
  }

  @override
  // TODO: implement getUserAddress
  String get getUserAddress {
    if (!prefs.containsKey(USER_ADDRESS)) {
      return null;
    }
    final String userString = prefs.getString(USER_ADDRESS);
    return userString;
  }

  @override
  String get getUserFirstName {
    if (!prefs.containsKey(USER_FIRST_NAME)) {
      return null;
    }
    final String userString = prefs.getString(USER_FIRST_NAME);
    return userString;
  }

  @override
  String get getUserLastName {
    if (!prefs.containsKey(USER_LAST_NAME)) {
      return null;
    }
    final String userString = prefs.getString(USER_LAST_NAME);
    return userString;
  }

  @override
  String get getUserMiddleName {
    if (!prefs.containsKey(USER_MIDDLE_NAME)) {
      return null;
    }
    final String userString = prefs.getString(USER_MIDDLE_NAME);
    return userString;
  }

  @override
  Future<bool> saveUserFirstName(String firstName) {
    final value = firstName;
    return prefs.setString(USER_FIRST_NAME, value);
  }
  
    @override
    Future<bool> saveUserLastName(String lastName) {
    final value = lastName;
    return prefs.setString(USER_LAST_NAME, value);
  }
  
    @override
    Future<bool> saveUserMiddleName(String middleName) {
    final value = middleName;
    return prefs.setString(USER_MIDDLE_NAME, value);
  }

  
}
