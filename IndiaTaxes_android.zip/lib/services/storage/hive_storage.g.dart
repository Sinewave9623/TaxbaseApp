// // GENERATED CODE - DO NOT MODIFY BY HAND

// part of 'hive_storage.dart';

// // **************************************************************************
// // TypeAdapterGenerator
// // **************************************************************************

// class GstinDataAdapter extends TypeAdapter<GstinData> {
//   @override
//   final int typeId = 2;

//   @override
//   GstinData read(BinaryReader reader) {
//     final numOfFields = reader.readByte();
//     final fields = <int, dynamic>{
//       for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
//     };
//     return GstinData(
//       gstin: fields[0] as String,
//       year: (fields[1] as List)?.cast<Years>(),
//     );
//   }

//   @override
//   void write(BinaryWriter writer, GstinData obj) {
//     writer
//       ..writeByte(2)
//       ..writeByte(0)
//       ..write(obj.gstin)
//       ..writeByte(1)
//       ..write(obj.year);
//   }

//   @override
//   int get hashCode => typeId.hashCode;

//   @override
//   bool operator ==(Object other) =>
//       identical(this, other) ||
//       other is GstinDataAdapter &&
//           runtimeType == other.runtimeType &&
//           typeId == other.typeId;
// }

// class YearsAdapter extends TypeAdapter<Years> {
//   @override
//   final int typeId = 3;

//   @override
//   Years read(BinaryReader reader) {
//     final numOfFields = reader.readByte();
//     final fields = <int, dynamic>{
//       for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
//     };
//     return Years()
//       ..fyear = fields[0] as String
//       ..fyearData = (fields[1] as List)?.cast<FyearData>();
//   }

//   @override
//   void write(BinaryWriter writer, Years obj) {
//     writer
//       ..writeByte(2)
//       ..writeByte(0)
//       ..write(obj.fyear)
//       ..writeByte(1)
//       ..write(obj.fyearData);
//   }

//   @override
//   int get hashCode => typeId.hashCode;

//   @override
//   bool operator ==(Object other) =>
//       identical(this, other) ||
//       other is YearsAdapter &&
//           runtimeType == other.runtimeType &&
//           typeId == other.typeId;
// }

// class FyearDataAdapter extends TypeAdapter<FyearData> {
//   @override
//   final int typeId = 4;

//   @override
//   FyearData read(BinaryReader reader) {
//     final numOfFields = reader.readByte();
//     final fields = <int, dynamic>{
//       for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
//     };
//     return FyearData()..fdate = fields[0] as String;
//   }

//   @override
//   void write(BinaryWriter writer, FyearData obj) {
//     writer
//       ..writeByte(1)
//       ..writeByte(0)
//       ..write(obj.fdate);
//   }

//   @override
//   int get hashCode => typeId.hashCode;

//   @override
//   bool operator ==(Object other) =>
//       identical(this, other) ||
//       other is FyearDataAdapter &&
//           runtimeType == other.runtimeType &&
//           typeId == other.typeId;
// }
