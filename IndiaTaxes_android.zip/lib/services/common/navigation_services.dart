import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/generate_otp_screen.dart';

class NavigationService {
  GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  GlobalKey<NavigatorState> get navigationKey => _navigatorKey;

  Future<dynamic> navigateTo(String routeName, {dynamic arguments}) {
    return _navigatorKey.currentState
        .pushNamed(routeName, arguments: arguments);
  }

  Future<dynamic> navigateUntilRemoved(String routeName, {dynamic arguments}) {
    return _navigatorKey.currentState.pushNamedAndRemoveUntil(
      routeName,
      (route) => false,
      arguments: arguments,
    );
  }

  void navigatePopUntilRemoved(String routeName, {dynamic arguments}) {
    return _navigatorKey.currentState.popUntil(ModalRoute.withName(routeName));
  }

  Future<dynamic> navigatePushReplacement(String routeName,
      {dynamic arguments}) {
    return _navigatorKey.currentState
        .pushReplacementNamed(routeName, arguments: arguments);
  }

  Future<dynamic> pushAndRemoveUntil(String routeName,
      {dynamic arguments}) {
    return _navigatorKey.currentState
        .pushAndRemoveUntil(PageRouteBuilder(pageBuilder: (BuildContext context, Animation animation,
          Animation secondaryAnimation) {
        return GenerateOtpScreen();
      }, transitionsBuilder: (BuildContext context, Animation<double> animation,
          Animation<double> secondaryAnimation, Widget child) {
        return new SlideTransition(
          position: new Tween<Offset>(
            begin: const Offset(1.0, 0.0),
            end: Offset.zero,
          ).animate(animation),
          child: child,
        );
      }),
      (Route route) => false);
  }

  void pop() {
    _navigatorKey.currentState.pop();
  }

  void popToExit() {
    SystemChannels.platform.invokeMethod('SystemNavigator.pop');
  }

  void popWithData(dynamic data) {
    _navigatorKey.currentState.pop(data);
  }
}
