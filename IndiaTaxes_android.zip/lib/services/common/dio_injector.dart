import 'package:dio/dio.dart';
import 'package:taxbase_general/constants/app_url/url_provider.dart';

final DioInjector injector = DioInjector();

class DioInjector {
  static final _singleton = DioInjector._internal();

  factory DioInjector() {
    return _singleton;
  }

  DioInjector._internal();

  Dio _dio;

  Dio get dio => _dio;

  init() {
    _dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: 50000,
      receiveTimeout: 30000,
      sendTimeout: 20000,
    ));

    _dio.interceptors
      ..add(InterceptorsWrapper(onRequest: (options) {
        // print(options.contentType);
        // print(options.toString());
      }))
      ..add(LogInterceptor(
          responseBody: true,
          requestBody: true,
          request: false,
          responseHeader: false));
  }
}
