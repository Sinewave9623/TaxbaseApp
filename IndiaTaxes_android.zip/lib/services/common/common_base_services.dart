import 'package:flutter/cupertino.dart';
import 'package:taxbase_general/services/storage/storage_service.dart';
import 'package:taxbase_general/ui/widgets/dialog_layout_widget.dart';
import 'package:taxbase_general/values/values.dart';

import '../../locator.dart';
import 'dialog_service.dart';
import 'navigation_services.dart';

abstract class CommonBaseServices {
  final _navigationService = locator<NavigationService>();
  final _dialogService = locator<DialogService>();
  // final _locationService = locator<LocationService>();
  final _storageService = locator<StorageService>();

  NavigationService get navigationServices => _navigationService;
  DialogService get dialogServices => _dialogService;

  StorageService get storageService => _storageService;

  

  void _showDialog(
      {String title,
      String description,
      VoidCallback onPositiveButtonClick,
      VoidCallback onNegativeButtonClick,
      String positiveButtonLabel,
      String negativeButtonLabel,
      Widget Function() builder}) async {
    await _dialogService.showDialog(
      title: title,
      description: description,
      positiveButtonLabel: positiveButtonLabel,
      negativeButtonLabel: negativeButtonLabel,
      onPositiveButtonClick: onPositiveButtonClick,
      onNegativeButtonClick: onNegativeButtonClick,
      builder: builder,
    );
  }

  void showErrorDialog({
    String title = ErrorTitle,
    String description = ErrorMessage,
    String positiveButtonLabel = OKButtonLabel,
    VoidCallback onPositiveButtonClick,
  }) {
    _showDialog(
      builder: () => DialogLayoutWidget(
        title: title,
        description: description,
        icon: "assets/images/error.png",
        onPositiveButtonClick: onPositiveButtonClick,
        positiveButtonLabel: positiveButtonLabel,
      ),
    );
  }
}
