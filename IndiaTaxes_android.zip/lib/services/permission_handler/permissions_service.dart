import 'package:permission_handler/permission_handler.dart';

Future<bool> requestPermission() async {
  print("Called");
  if (await Permission.contacts.request().isGranted) {
  // Either the permission was already granted before or the user just granted it.
}

// You can request multiple permissions at once.
Map<Permission, PermissionStatus> statuses = await [
  Permission.storage,
].request();
print(statuses[Permission.storage]);
}
