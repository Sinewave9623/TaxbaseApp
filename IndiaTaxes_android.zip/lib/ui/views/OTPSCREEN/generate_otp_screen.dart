import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/ui/viewModels/OTPViewModels/generate_otp_viewModel.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';
import 'package:taxbase_general/values/images.dart';
import 'package:taxbase_general/values/values.dart';

class GenerateOtpScreen extends StatefulWidget {
  @override
  _GenerateOtpScreenState createState() => _GenerateOtpScreenState();
}

class _GenerateOtpScreenState extends State<GenerateOtpScreen> {
  TextEditingController mobileNumberController = TextEditingController();
  TextEditingController panNumberController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GenerateOTPViewModel>.reactive(
        onModelReady: (model) => model.init(),
        builder: (context, model, child) {
          return Scaffold(
            resizeToAvoidBottomInset: true,
            backgroundColor: //Color(0xff1f0098),
                AppColors.whiteColor,
            body: SafeArea(
              child: SingleChildScrollView(
                child: Container(
                  height: screenHeight(context),
                  width: screenWidth(context),
                  child: Column(
                    children: <Widget>[
                      Padding(padding: EdgeInsets.all(20)),
                      Container(
                          // color: AppColors.primaryColor,
                          height: screenHeight(context) * 0.35,
                          width: double.maxFinite,
                          child: Lottie.asset("assets/images/login.json",
                              height: 380, width: 390, animate: true)

                          //  Image.asset(ImagePath.VERIFICATION),
                          ),
                      Padding(padding: EdgeInsets.all(10)),
                      /*  Container(
                        margin:
                            EdgeInsets.only(top: screenHeight(context) * .01),
                        child: Text(
                          MOBILE_VERIFICATION,
                          style: Theme.of(context).textTheme.headline6.copyWith(
                              color: AppColors.primaryColor,
                              fontWeight: FontWeight.w600),
                        ),
                      ),*/
                      /*Text(
                        ENTER_MOBILE,
                        style: Theme.of(context).textTheme.subtitle2.copyWith(
                            color: AppColors.primaryColorLight,
                            fontWeight: FontWeight.w400),
                      ),*/
                      Container(
                        margin:
                            EdgeInsets.only(top: screenHeight(context) * .05),
                        width: screenWidth(context) * 0.62,
                        child: StreamBuilder<String>(
                            stream: model.mobilenumber,
                            builder: (context, snapshot) {
                              return TextFormField(
                                onChanged: model.onMobileNumChange,
                                keyboardType: TextInputType.phone,
                                controller: mobileNumberController,
                                maxLength: 10,
                                inputFormatters: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                decoration: InputDecoration(
                                  counterText: "",
                                  labelText: MOBILE_NUMBER,
                                  hintText: MOBILE_NUMBER,
                                  hintStyle: Theme.of(context)
                                      .textTheme
                                      .bodyText2
                                      .copyWith(color: Colors.black26),
                                ),
                                onFieldSubmitted: (value) {},
                              );
                            }),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: paddingTop(context) * 4),
                        child: StreamBuilder<bool>(
                            stream: model.validateOTPButton,
                            builder: (context, snapshot) {
                              return BusyButton(
                                height: 50,
                                iconImage: Icons.arrow_forward_rounded,
                                busy: model.loading,
                                onPressed: snapshot.hasData
                                    ? () {
                                        model.generateOTP(context);
                                      }
                                    : null,
                              );
                            }),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
        viewModelBuilder: () => GenerateOTPViewModel());
  }
}
