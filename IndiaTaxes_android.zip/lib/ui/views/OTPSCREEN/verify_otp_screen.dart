import 'package:flutter/material.dart';
import 'package:pin_code_text_field/pin_code_text_field.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/ui/viewModels/OTPViewModels/verify_otp_viewModel.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';
import 'package:taxbase_general/values/images.dart';
import 'package:taxbase_general/values/values.dart';
// import 'package:telephony/telephony.dart';

class VerifyOtpScreen extends StatefulWidget {
  final String mobileNumber;

  const VerifyOtpScreen({Key key, this.mobileNumber}) : super(key: key);
  @override
  _VerifyOtpScreenState createState() => _VerifyOtpScreenState();
}

class _VerifyOtpScreenState extends State<VerifyOtpScreen> {
  TextEditingController _otpController = TextEditingController();
  String otp = "";
  // final telephony = Telephony.instance;

  @override
  void initState() {
    super.initState();
    print("listening");
    // telephony.listenIncomingSms(
    //     onNewMessage: (SmsMessage message) {
    //       print(message.body);
    //       // Handle message
    //     },
    //     listenInBackground: false);
  }

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<VerifyOTPViewModel>.reactive(
        onModelReady: (model) => model.init(widget.mobileNumber),
        builder: (context, model, child) {
          return SafeArea(
            child: Scaffold(
              backgroundColor: AppColors.whiteColor,
              body: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: screenHeight(context) * 0.4,
                      width: double.maxFinite,
                      child: Image.asset(ImagePath.VERIFICATION),
                    ),
                    sizedBox(
                      height: screenHeight(context) * 0.05,
                    ),
                    Container(
                      margin: EdgeInsets.only(
                          left: screenWidth(context) * .1,
                          right: screenWidth(context) * .1),
                      child: Text(
                        OTP_VERIFICATION + " " + widget.mobileNumber.toString(),
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.headline6.copyWith(
                            color: Colors.black54, fontWeight: FontWeight.w600),
                      ),
                    ),
                    // Container(
                    //   margin: EdgeInsets.only(top: screenHeight(context) * .02),
                    //   child: Text(
                    //     ENTER_OTP,
                    //     style: Theme.of(context)
                    //         .textTheme
                    //         .subtitle1
                    //         .copyWith(color: Colors.black38),
                    //   ),
                    // ),
                    sizedBox(
                      height: screenHeight(context) * 0.02,
                    ),
                    PinCodeTextField(
                      autofocus: true,
                      controller: _otpController,
                      hideCharacter: false,
                      highlight: true,
                      highlightColor: AppColors.primaryColorDark,
                      defaultBorderColor: AppColors.subtitleColor,
                      hasTextBorderColor: AppColors.primaryColorLight,
                      maxLength: 4,
                      pinBoxHeight: screenHeight(context) * 0.05,
                      pinBoxWidth: screenWidth(context) * 0.1,
                      hasUnderline: false,
                      wrapAlignment: WrapAlignment.center,
                      isCupertino: true,
                      pinTextAnimatedSwitcherDuration:
                          Duration(milliseconds: 300),
                      highlightAnimationBeginColor: Colors.black,
                      highlightAnimationEndColor: Colors.white12,
                      keyboardType: TextInputType.number,
                      errorBorderColor: AppColors.errorColor,
                      pinBoxRadius: 10,
                      onTextChanged: (value) {
                        setState(() {
                          otp = _otpController.text;
                          model.onOTPNumChange(otp);
                        });
                      },
                      pinTextStyle: Theme.of(context)
                          .textTheme
                          .headline6
                          .copyWith(color: AppColors.primaryColorLight),
                    ),
                    sizedBox(
                      height: screenHeight(context) * 0.06,
                    ),
                    Container(
                      margin: EdgeInsets.only(top: paddingTop(context) * 4),
                      child: StreamBuilder<bool>(
                          stream: model.validateVerifyOTPButton,
                          builder: (context, snapshot) {
                            return BusyButton(
                              height: 40,
                              iconImage: Icons.arrow_forward_rounded,
                              busy: model.loading,
                              onPressed: snapshot.hasData
                                  ? () {
                                      model.verifyOTP(context);
                                    }
                                  : null,
                            );
                          }),
                    ),

                    sizedBox(
                      height: screenHeight(context) * 0.05,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        viewModelBuilder: () => VerifyOTPViewModel());
  }
}
