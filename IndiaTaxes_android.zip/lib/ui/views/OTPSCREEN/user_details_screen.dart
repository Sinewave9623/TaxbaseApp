import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/ui/viewModels/OTPViewModels/user_details_viewModel.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';
import 'package:taxbase_general/values/images.dart';
import 'package:taxbase_general/values/values.dart';

class UserDetailScreen extends StatefulWidget {
  final String mobileNumber;

  const UserDetailScreen({Key key, this.mobileNumber}) : super(key: key);
  @override
  _UserDetailScreenState createState() => _UserDetailScreenState();
}

class _UserDetailScreenState extends State<UserDetailScreen> {
  TextEditingController birthDateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: AppColors.whiteColor,
        statusBarIconBrightness: Brightness.dark));
    return ViewModelBuilder<UserDetailViewModel>.reactive(
        onModelReady: (model) => model.init(widget.mobileNumber),
        builder: (context, model, child) {
          return SafeArea(
            child: Scaffold(
              resizeToAvoidBottomInset: true,
              backgroundColor: AppColors.whiteColor,
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                        margin: EdgeInsets.only(top: paddingTop(context)),
                        height: screenHeight(context) * 0.4,
                        width: screenWidth(context) * .8,
                        child: Image.asset(
                          ImagePath.CA_CODE,
                          fit: BoxFit.fill,
                        )),
                    Container(
                      margin: EdgeInsets.only(top: paddingTop(context)),
                      width: double.maxFinite,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            child: Text(
                              ENTER_DETAILS,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                      color: Colors.black54,
                                      fontWeight: FontWeight.w600),
                            ),
                          ),
                          // Container(
                          //   margin: EdgeInsets.all(Sizes.PADDING_10),
                          //   width: screenWidth(context) * 0.62,
                          //   child: StreamBuilder<String>(
                          //       stream: model.userName,
                          //       builder: (context, snapshot) {
                          //         return TextFormField(
                          //           keyboardType: TextInputType.text,
                          //           decoration: InputDecoration(
                          //             hintText: "UserName",
                          //             hintStyle: Theme.of(context)
                          //                 .textTheme
                          //                 .bodyText2
                          //                 .copyWith(
                          //                     color:
                          //                         AppColors.primaryColorLight),
                          //           ),
                          //           onChanged: model.onUserNameChange,
                          //         );
                          //       }),
                          // ),
                          StreamBuilder<dynamic>(
                            stream: model.firstName,
                            builder: (context, snapshot) {
                              return buildTextField(
                                hint: FIRST_NAME,
                                label: FIRST_NAME,
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[a-z,A-Z,  ,]')),
                                ],
                                keyBoardType: TextInputType.text,
                                onChanged: (value) {
                                  if (value.isEmpty) {
                                    model.onFirstNameChanged("");
                                  } else {
                                    model.onFirstNameChanged(value);
                                  }
                                },
                              );
                            },
                          ),
                          StreamBuilder<dynamic>(
                            stream: model.middleName,
                            builder: (context, snapshot) {
                              return buildTextField(
                                hint: MIDDLE_NAME,
                                label: MIDDLE_NAME,
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[a-z,A-Z,  ,]')),
                                ],
                                keyBoardType: TextInputType.text,
                                onChanged: (value) {
                                  if (value.isEmpty) {
                                    model.onMiddleNameChanged("");
                                  } else {
                                    model.onMiddleNameChanged(value);
                                  }
                                },
                              );
                            },
                          ),
                          StreamBuilder<dynamic>(
                            stream: model.lastName,
                            builder: (context, snapshot) {
                              return buildTextField(
                                hint: LAST_NAME,
                                label: LAST_NAME,
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[a-z,A-Z,  ,]')),
                                ],
                                keyBoardType: TextInputType.text,
                                onChanged: (value) {
                                  if (value.isEmpty) {
                                    model.onLastNameChanged("");
                                  } else {
                                    model.onLastNameChanged(value);
                                  }
                                },
                              );
                            },
                          ),
                          Container(
                            child: StreamBuilder<String>(
                              stream: model.employeePan,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: PAN,
                                  label: PAN,
                                  numbersAllowd: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[a-z,A-Z,0-9]')),
                                  ],
                                  textCapitalization:
                                      TextCapitalization.characters,
                                  keyBoardType: TextInputType.text,
                                  maxLength: 10,
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEmployeePanChanged("");
                                    } else {
                                      model.onEmployeePanChanged(value);
                                    }
                                  },
                                );
                              },
                            ),
                          ),

                          Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(
                                  top: 10,
                                  left: screenWidth(context) * .03,
                                  right: screenWidth(context) * .03,
                                ),
                                width: screenWidth(context) * .35,
                                child: StreamBuilder<String>(
                                    stream: model.dob,
                                    builder: (context, snapshot) {
                                      birthDateController.value =
                                          birthDateController.value.copyWith(
                                              text: snapshot.data.toString() !=
                                                      "null"
                                                  ? snapshot.data.toString()
                                                  : "");
                                      return TextFormField(
                                        maxLength: 2,

                                        onTap: () {
                                          FocusNode().unfocus();
                                          model.getBirthDate(context);
                                        },
                                        controller: birthDateController,
                                        // keyboardType: TextInputType.number,
                                        keyboardType: TextInputType.datetime,
                                        decoration: InputDecoration(
                                          hintText: "Date of Birth",
                                          labelText:
                                              snapshot.data.toString() != "null"
                                                  ? snapshot.data.toString()
                                                  : "",
                                          counterText: "",
                                          hintStyle: Theme.of(context)
                                              .textTheme
                                              .bodyText2
                                              .copyWith(
                                                  color: AppColors
                                                      .primaryColorLight),
                                        ),
                                        onChanged: (value) {
                                          model.onDobChanged;
                                        },
                                      );
                                    }),
                              ),
                              Container(
                                  margin: EdgeInsets.all(10),
                                  child: Text(model.age != null
                                      ? "Age: " +
                                          model.age.years.toString() +
                                          " Yrs"
                                      : "Age: ")),
                              Container(
                                  margin: EdgeInsets.all(10),
                                  child: Text(model.age != null
                                      ? model.age.years >= 60
                                          ? "Senior "
                                          : "General"
                                      : "")),
                            ],
                          ),
                          // Container(
                          //   margin: EdgeInsets.all(Sizes.PADDING_10),
                          //   width: screenWidth(context) * 0.62,
                          //   child: StreamBuilder<String>(
                          //       stream: model.userPanNo,
                          //       builder: (context, snapshot) {
                          //         return TextFormField(
                          //           maxLength: 10,
                          //           keyboardType: TextInputType.text,
                          //           textCapitalization:
                          //               TextCapitalization.characters,
                          //           decoration: InputDecoration(
                          //             hintText: "Pan No",
                          //             counterText: "",
                          //             hintStyle: Theme.of(context)
                          //                 .textTheme
                          //                 .bodyText2
                          //                 .copyWith(
                          //                     color:
                          //                         AppColors.primaryColorLight),
                          //           ),
                          //           onChanged: model.onuserPanNoChange,
                          //         );
                          //       }),
                          // ),

                          // Container(
                          //   margin: EdgeInsets.all(Sizes.PADDING_10),
                          //   width: screenWidth(context) * 0.62,
                          //   child: StreamBuilder<String>(
                          //       stream: model.birthDateInString,
                          //       builder: (context, snapshot) {
                          //         birthDateController.value =
                          //             birthDateController.value
                          //                 .copyWith(text: snapshot.data);
                          //         return TextFormField(
                          //           controller: birthDateController,
                          //           maxLength: 2,
                          //           onTap: () {
                          //             FocusNode().unfocus();
                          //             model.getBirthDate(context);
                          //           },
                          //           // keyboardType: TextInputType.number,
                          //           keyboardType: TextInputType.datetime,
                          //           decoration: InputDecoration(
                          //             hintText: "BirthDate",
                          //             counterText: "",
                          //             hintStyle: Theme.of(context)
                          //                 .textTheme
                          //                 .bodyText2
                          //                 .copyWith(
                          //                     color:
                          //                         AppColors.primaryColorLight),
                          //           ),
                          //           onChanged: model.onBirthDateChange,
                          //         );
                          //       }),
                          // ),

                          // Container(
                          //   margin: EdgeInsets.all(Sizes.PADDING_10),
                          //   width: screenWidth(context) * 0.62,
                          //   child: StreamBuilder<String>(
                          //       stream: model.userAddress,
                          //       builder: (context, snapshot) {
                          //         return TextFormField(
                          //           keyboardType: TextInputType.text,
                          //           textCapitalization:
                          //               TextCapitalization.words,
                          //           decoration: InputDecoration(
                          //             hintText: "Address",
                          //             hintStyle: Theme.of(context)
                          //                 .textTheme
                          //                 .bodyText2
                          //                 .copyWith(
                          //                     color:
                          //                         AppColors.primaryColorLight),
                          //           ),
                          //           onChanged: model.onuserAddressChange,
                          //         );
                          //       }),
                          // ),

                          Container(
                            margin: EdgeInsets.only(
                              left: screenWidth(context) * .12,
                            ),
                            child: Text("Gender"),
                          ),
                          Container(
                              width: screenWidth(context),
                              height: screenHeight(context) * .1,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(
                                      left: screenWidth(context) * .08,
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          margin: EdgeInsets.only(
                                            right: screenWidth(context) * .1,
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                child: Transform.scale(
                                                  scale: 1.2,
                                                  child: Checkbox(
                                                    activeColor:
                                                        AppColors.primaryColor,
                                                    autofocus: true,
                                                    checkColor: AppColors
                                                        .primaryColorLight,
                                                    value: model.isMale,
                                                    onChanged: (newValue) {
                                                      setState(() {
                                                        model.genderSelection(
                                                            newValue,
                                                            false,
                                                            false);
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                child: Text(
                                                  "Male",
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Container(
                                                child: Transform.scale(
                                                  scale: 1.2,
                                                  child: Checkbox(
                                                    activeColor:
                                                        AppColors.primaryColor,
                                                    autofocus: true,
                                                    checkColor: AppColors
                                                        .primaryColorLight,
                                                    value: model.isFeMale,
                                                    onChanged: (newValue) {
                                                      setState(() {
                                                        model.genderSelection(
                                                          false,
                                                          newValue,
                                                          false,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                child: Text("Female"),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Container(
                                                child: Transform.scale(
                                                  scale: 1.2,
                                                  child: Checkbox(
                                                    activeColor:
                                                        AppColors.primaryColor,
                                                    autofocus: true,
                                                    checkColor: AppColors
                                                        .primaryColorLight,
                                                    value: model.isOther,
                                                    onChanged: (newValue) {
                                                      setState(() {
                                                        model.genderSelection(
                                                          false,
                                                          false,
                                                          newValue,
                                                        );
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                child: Text("Other"),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              )),

                          Container(
                            child: StreamBuilder<bool>(
                                stream: model.validateUserButton,
                                builder: (context, snapshot) {
                                  return BusyButton(
                                    height: 40,
                                    iconImage: Icons.arrow_forward_rounded,
                                    busy: model.loading,
                                    onPressed: snapshot.hasData
                                        ? () {
                                            model.saveUserDetails();
                                          }
                                        : null,
                                  );
                                }),
                          ),
                          sizedBox(
                            height: screenHeight(context) * 0.06,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        viewModelBuilder: () => UserDetailViewModel());
  }

  Padding buildTextField(
      {String hint,
      String label,
      Function(dynamic p1) onChanged,
      TextInputType keyBoardType,
      List<TextInputFormatter> numbersAllowd,
      TextCapitalization textCapitalization,
      int maxLength,
      String intialValue}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
        inputFormatters: numbersAllowd,
        textCapitalization: textCapitalization ?? TextCapitalization.none,
        maxLength: maxLength,
        decoration: InputDecoration(
          hintText: hint,
          labelText: label,
        ),
        // controller: controller ?? TextEditingController(),
        onChanged: onChanged,
        initialValue: intialValue ?? "",
      ),
    );
  }
}
