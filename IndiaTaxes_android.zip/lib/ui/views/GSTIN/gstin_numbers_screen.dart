import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/GstinModel/gstin_responseModel.dart';
import 'package:taxbase_general/ui/viewModels/GstinNumberViewModel/gstin_number_ViewModel.dart';
import 'package:taxbase_general/values/values.dart';

class GSTINNUMBERSCREEN extends StatefulWidget {
  @override
  _GSTINNUMBERSCREENState createState() => _GSTINNUMBERSCREENState();
}

class _GSTINNUMBERSCREENState extends State<GSTINNUMBERSCREEN> {
  TextEditingController gstInNoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<GstinNumberViewModel>.reactive(
      onModelReady: (model) => model.init(),
      builder: (context, model, child) {
        return Scaffold(
          appBar: AppBar(
            elevation: 0,
            title: Text(
              'GSTIN NUMBERS',
              style: TextStyle(color: Colors.black),
            ),
            leading: InkWell(
              onTap: () => Navigator.of(context).pop(),
              child: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
            ),
            flexibleSpace: Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: <Color>[
                    AppColors.whiteColor,
                    AppColors.whiteColor
                  ])),
            ),
          ),
          body: SingleChildScrollView(
            child: Container(
              height: screenHeight(context),
              child: Column(
                children: [
                  Container(
                      margin: EdgeInsets.only(
                        top: screenHeight(context) * .02,
                        left: screenWidth(context) * .1,
                        right: screenWidth(context) * .1,
                      ),
                      child: TextFormField(
                        keyboardType: TextInputType.text,
                        controller: gstInNoController,
                        textCapitalization: TextCapitalization.characters,
                        decoration: InputDecoration(
                          labelText: GSTIN_NUMBER,
                          hintText: GSTIN_NUMBER,
                          hintStyle: Theme.of(context)
                              .textTheme
                              .bodyText2
                              .copyWith(color: Colors.black26),
                        ),
                        onFieldSubmitted: (value) {},
                      )),
                  RaisedButton(
                    child: Text('Add'),
                    onPressed: () {
                      addItemToList(model);
                    },
                  ),
                  StreamBuilder<bool>(
                      stream: model.isLoading,
                      builder: (context, snapshot) {
                        print(snapshot.data);
                        return snapshot.data == false
                            ? Container(
                                width: screenWidth(context),
                                height: screenHeight(context) * .8,
                                child: StreamBuilder<List<GSTINData>>(
                                    stream: model.gstInData,
                                    builder: (context, snapshot) {
                                      print("----------snapshot.data");
                                      print(snapshot.data);
                                      return snapshot.data.toString() ==
                                              null.toString()
                                          ? Center(
                                              child:
                                                  CircularProgressIndicator(),
                                            )
                                          : snapshot.data.toString() !=
                                                  [].toString()
                                              ? ListView.builder(
                                                  physics:
                                                      NeverScrollableScrollPhysics(),
                                                  itemCount: model.datacount,
                                                  itemBuilder:
                                                      (context, index) {
                                                    return Container(
                                                      width:
                                                          screenWidth(context),
                                                      height: screenHeight(
                                                              context) *
                                                          .1,
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            flex: 3,
                                                            child: Container(
                                                              margin: EdgeInsets
                                                                  .only(
                                                                top: screenHeight(
                                                                        context) *
                                                                    .02,
                                                                left: screenWidth(
                                                                        context) *
                                                                    .1,
                                                              ),
                                                              child:
                                                                  TextFormField(
                                                                initialValue: snapshot
                                                                        .data[
                                                                            index]
                                                                        .gstin ??
                                                                    "0",
                                                                onChanged:
                                                                    (value) {
                                                                  model.updateGstinNumber(
                                                                      snapshot
                                                                          .data[
                                                                              index]
                                                                          .uId,
                                                                      value);
                                                                },
                                                                onFieldSubmitted:
                                                                    (value) {
                                                                  model.updateGstinNumber(
                                                                      snapshot
                                                                          .data[
                                                                              index]
                                                                          .uId,
                                                                      value);
                                                                },
                                                                decoration:
                                                                    InputDecoration(
                                                                  hintText:
                                                                      "Enter Gstin Number",
                                                                ),

                                                                // controller: gstinNumberController[index],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            flex: 1,
                                                            child: InkWell(
                                                              onTap: () {
                                                                model
                                                                    .removeGstin(
                                                                  snapshot
                                                                      .data[
                                                                          index]
                                                                      .uId,
                                                                );
                                                              },
                                                              child: Container(
                                                                margin:
                                                                    EdgeInsets
                                                                        .only(
                                                                  top: screenHeight(
                                                                          context) *
                                                                      .02,
                                                                  right: screenWidth(
                                                                          context) *
                                                                      .05,
                                                                ),
                                                                height: screenHeight(
                                                                        context) *
                                                                    .07,
                                                                child: Icon(
                                                                  Icons.delete,
                                                                  color: Theme.of(
                                                                          context)
                                                                      .primaryColor,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          // Container(
                                                          //
                                                          //
                                                        ],
                                                      ),
                                                    );
                                                  })
                                              : Container(
                                                  margin: EdgeInsets.only(
                                                    left: screenWidth(context) *
                                                        .2,
                                                    right:
                                                        screenWidth(context) *
                                                            .1,
                                                    top: screenHeight(context) *
                                                        .1,
                                                  ),
                                                  child: Text(
                                                      "\t\t\t\t\tNo Gstin Number found\nPlease Add new Gstin Number"),
                                                );
                                    }),
                              )
                            : Center(
                                child: CircularProgressIndicator(),
                              );
                      })
                ],
              ),
            ),
          ),
        );
      },
      viewModelBuilder: () => GstinNumberViewModel(),
    );
  }

  void addItemToList(GstinNumberViewModel model) {
    setState(() {
      var count = model.datacount++;
      model.addTextfield(count, gstInNoController.text.toString());
      // msgCount.insert(0, 0);
    });
  }
}
