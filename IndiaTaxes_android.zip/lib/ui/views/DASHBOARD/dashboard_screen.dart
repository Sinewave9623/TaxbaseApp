import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animator/widgets/animator_widget.dart';
import 'package:flutter_animator/widgets/bouncing_entrances/bounce_in_down.dart';
import 'package:flutter_animator/widgets/bouncing_entrances/bounce_in_right.dart';
import 'package:flutter_animator/widgets/bouncing_entrances/bounce_in_up.dart';
import 'package:flutter_animator/widgets/in_out_animation.dart';
import 'package:flutter_animator/widgets/specials/cross_fade_a_b.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/animations/in_out_animation.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/ui/viewModels/DashboardViewModels/dashboard_viewModel.dart';
import 'package:taxbase_general/ui/widgets/common_widgets.dart';
import 'package:taxbase_general/values/theme.dart';
import 'package:taxbase_general/values/values.dart';

class DashBoardScreen extends StatefulWidget {
  @override
  _DashBoardScreenState createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
  final GlobalKey<CrossFadeABState> crossFadeAnimation =
      GlobalKey<CrossFadeABState>();

  final GlobalKey<AnimatorWidgetState> basicAnimation =
      GlobalKey<AnimatorWidgetState>();

  final GlobalKey<InOutAnimationState> inOutAnimation =
      GlobalKey<InOutAnimationState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: AppColors.whiteColor,
        statusBarIconBrightness: Brightness.dark));
    return ViewModelBuilder<DashboardViewModel>.reactive(
      onModelReady: (model) => model.init(),
      builder: (context, model, child) {
        return Scaffold(
          appBar: AppBar(
            elevation: 0,
            flexibleSpace: Container(
              decoration: BoxDecoration(
                color: Colors.white,
              ),
            ),
            centerTitle: true,
            title: Text(
              AppNameTitle,
              style: myTheme.textTheme.headline6
                  .copyWith(color: AppColors.titleColor),
            ),
            actions: [],
          ),
          drawer: Drawer(
            child: Column(
              children: [
                UserAccountsDrawerHeader(
                  accountEmail: Text(""),
                  decoration: BoxDecoration(color: AppColors.primaryColorDark),
                  accountName: StreamBuilder<String>(
                      stream: model.userName,
                      builder: (context, snapshot) {
                        return Text(
                          snapshot.data.toString(),
                          style: Theme.of(context)
                              .textTheme
                              .subtitle1
                              .copyWith(color: AppColors.whiteColor),
                        );
                      }),
                  currentAccountPicture: CircleAvatar(
                    child: ClipOval(
                      child: CircleAvatar(
                        backgroundColor: Colors.white.withOpacity(0.5),
                        child: Icon(
                          Icons.person,
                          size: 30,
                        ),
                      ),
                    ),
                  ),
                ),
                ListTile(
                    leading: Icon(
                      Icons.verified_user_rounded,
                      color: AppColors.primaryColorDark,
                    ),
                    title: new Text(USER_PROFILE),
                    onTap: () {
                      Navigator.of(context).pop();
                      model.navigateToProfileScreen();
                    }),
                ListTile(
                    leading: Icon(
                      Icons.calculate,
                      color: AppColors.primaryColorDark,
                    ),
                    title: new Text(TAX_CALCULATION),
                    onTap: () {
                      Navigator.of(context).pop();
                      model.navigateToTaxCalculatorScreen();
                    }),
                ListTile(
                    leading: Icon(
                      Icons.phone_iphone_sharp,
                      color: AppColors.primaryColorDark,
                    ),
                    title: new Text(GSTIN_NUMBERS),
                    onTap: () {
                      Navigator.of(context).pop();
                      model.navigateToGSTINNumberScreen();
                    }),
                Expanded(child: SizedBox()),
                Divider(),
                ListTile(
                    leading: Icon(
                      Icons.power_settings_new,
                      color: Colors.redAccent,
                    ),
                    title: new Text("Logout"),
                    onTap: () {
                      model.logoutfun(context);
                    }),
              ],
            ),
          ),
          body: SafeArea(
            child: Container(
              width: screenWidth(context),
              height: screenHeight(context),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.topLeft,
                  colors: <Color>[AppColors.whiteColor, AppColors.whiteColor],
                ),
              ),
              child: Column(
                children: [
                  Expanded(
                    flex: 2,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                            margin: EdgeInsets.only(
                              top: 10,
                            ),
                            height: screenHeight(context) * .20,
                            width: screenWidth(context) * .86,
                            child: Image.asset(
                              "assets/images/appLogo.png",
                            )),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 5,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.bottomLeft,
                            end: Alignment.topRight,
                            colors: <Color>[
                              AppColors.mydocumentBG_COLOR,
                              AppColors.mydocumentBG_COLOR2
                            ]),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(30),
                          topRight: Radius.circular(30),
                        ),
                      ),
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            InOutAnimations(
                              inDefination: BounceInDownAnimation(),
                              outDefination: BounceInRightAnimation(),
                              child: buildTile(
                                Padding(
                                  padding: EdgeInsets.only(
                                    top: screenHeight(context) * .04,
                                    left: screenWidth(context) * .05,
                                    right: screenWidth(context) * .05,
                                    bottom: screenWidth(context) * .1,
                                  ),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              child: Text(GSTREMINDER,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headline6
                                                      .copyWith(
                                                          color: Colors.white)),
                                            ),
                                            sizedBox(height: 10),
                                            Row(
                                              children: [
                                                Container(
                                                  child: Icon(
                                                    Icons.check,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Container(
                                                  child: Text(
                                                    GSTREMINDERMSG,
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .subtitle2
                                                        .copyWith(
                                                            color:
                                                                Colors.white),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            sizedBox(height: 10),
                                          ],
                                        ),
                                        Container(
                                          width: screenWidth(context) * .2,
                                          child: Lottie.asset(
                                            'assets/animations/reminder_animation.json',
                                            height: screenHeight(context) * .1,
                                            fit: BoxFit.fill,
                                          ),
                                        ),
                                      ]),
                                ),
                                context,
                                onTap: () => model.navigateToGSTReminder(),
                              ),
                            ),
                            InOutAnimations(
                              inDefination: BounceInRightAnimation(),
                              outDefination: BounceInRightAnimation(),
                              child: buildTile(
                                  Padding(
                                    padding: EdgeInsets.only(
                                      top: screenHeight(context) * .04,
                                      left: screenWidth(context) * .05,
                                      bottom: screenWidth(context) * .1,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              child: Text(TAXCALCULATIONLABEL,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headline6
                                                      .copyWith(
                                                          color: Colors.white)),
                                            ),
                                            sizedBox(height: 10),
                                            Row(
                                              children: [
                                                Container(
                                                  child: Icon(
                                                    Icons.check,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Container(
                                                  child: Text(TAXCALCULATIONMSG,
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .subtitle2
                                                          .copyWith(
                                                              color: Colors
                                                                  .white)),
                                                ),
                                              ],
                                            ),
                                            sizedBox(height: 10),
                                          ],
                                        ),
                                        Container(
                                          width: screenWidth(context) * .2,
                                          child: Lottie.asset(
                                            'assets/animations/tax_cal_animation.json',
                                            height: screenHeight(context) * .13,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  context, onTap: () {
                                model.navigateToTaxCalculatorScreen();
                              }
                                  // model.navigateToTaxCalculatorScreen(),
                                  ),
                            ),
                            InOutAnimations(
                              inDefination: BounceInRightAnimation(),
                              outDefination: BounceInRightAnimation(),
                              child: buildTile(
                                  Padding(
                                    padding: EdgeInsets.only(
                                      top: screenHeight(context) * .04,
                                      left: screenWidth(context) * .05,
                                      right: screenWidth(context) * .05,
                                      bottom: screenWidth(context) * .1,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              child: Text(RETURNS_LABEL,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headline6
                                                      .copyWith(
                                                          color: Colors.white)),
                                            ),
                                            sizedBox(height: 10),
                                            Row(
                                              children: [
                                                Container(
                                                  child: Icon(
                                                    Icons.check,
                                                    color: Colors.white,
                                                  ),
                                                ),
                                                Container(
                                                  child: Text(RETURNS_MSG,
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .subtitle2
                                                          .copyWith(
                                                              color: Colors
                                                                  .white)),
                                                ),
                                              ],
                                            ),
                                            sizedBox(height: 10),
                                          ],
                                        ),
                                        Container(
                                          width: screenWidth(context) * .2,
                                          child: Lottie.asset(
                                            'assets/animations/tax_cal_animation.json',
                                            height: screenHeight(context) * .13,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  context, onTap: () {
                                model.navigateToViewReturnScreen();
                              }
                                  // model.navigateToTaxCalculatorScreen(),
                                  ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
      viewModelBuilder: () => DashboardViewModel(),
    );
  }
}
