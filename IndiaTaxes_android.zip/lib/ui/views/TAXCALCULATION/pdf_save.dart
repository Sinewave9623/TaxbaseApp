import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
import 'package:taxbase_general/values/images.dart';
import 'package:taxbase_general/values/values.dart';

Future<Uint8List> generateInvoice(
    PdfPageFormat pageFormat, TaxCalculationViewModel model) async {
  final ByteData bytes = await rootBundle.load(ImagePath.LOGO);
  final Uint8List list = bytes.buffer.asUint8List();
  final data = model;

  final invoice = Invoice(
    image: list,
    data: data,
    baseColor: PdfColors.blue,
    accentColor: PdfColors.blue500,
  );

  return await invoice.buildPdf(pageFormat);
}

class Invoice {
  Invoice({
    this.image,
    this.data,
    this.baseColor,
    this.accentColor,
  });

  final Uint8List image;
  final TaxCalculationViewModel data;
  final PdfColor baseColor;
  final PdfColor accentColor;

  static const _darkColor = PdfColors.blueGrey800;
  static const _lightColor = PdfColors.white;

  PdfColor get _baseTextColor =>
      baseColor.luminance < 0.5 ? _lightColor : _darkColor;

  PdfImage pdfImage;

  Future<Uint8List> buildPdf(PdfPageFormat pageFormat) async {
    // Create a PDF document.
    final doc = pw.Document();
    // Add page to the PDF
    const imageProvider = const AssetImage(ImagePath.LOGO);
    pdfImage = await pdfImageFromImageProvider(
        pdf: doc.document, image: imageProvider);
    doc.addPage(
      pw.MultiPage(
        pageFormat: pageFormat,
        margin: pw.EdgeInsets.all(20),
        header: _buildHeader,
        build: (context) => [
          pw.SizedBox(height: 20),
          _contentTable(context),
          pw.SizedBox(height: 20),
        ],
      ),
    );

    // Return the PDF file content
    final output = await getExternalStorageDirectory();
    print(output.path);
    final file = File("${output.path}/calulatedTax.pdf");
    await file.writeAsBytes(doc.save());

    return doc.save();
  }

  pw.Widget _buildHeader(pw.Context context) {
    final pdf = pw.Document();
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.center,
      children: [
        pw.Center(
          child: pw.Image(
            pdfImage,
            width: 250,
            height: 250,
          ),
        ),
        pw.Text(
          'Summary',
          style: pw.TextStyle(fontSize: 25),
        ),
        pw.SizedBox(height: 20),
      ],
    );
  }

  pw.PageTheme _buildTheme(
      PdfPageFormat pageFormat, pw.Font base, pw.Font bold, pw.Font italic) {
    return pw.PageTheme(
      pageFormat: pageFormat,
      theme: pw.ThemeData.withFont(
        base: base,
        bold: bold,
        italic: italic,
      ),
      buildBackground: (context) => pw.FullPage(
        ignoreMargins: true,
        child: pw.Stack(
          children: [
            pw.Positioned(
              bottom: 0,
              left: 0,
              child: pw.Container(
                height: 20,
                width: pageFormat.width / 2,
                decoration: pw.BoxDecoration(
                  gradient: pw.LinearGradient(
                    colors: [
                      baseColor,
                      PdfColors.white,
                    ],
                  ),
                ),
              ),
            ),
            pw.Positioned(
              bottom: 20,
              left: 0,
              child: pw.Container(
                height: 20,
                width: pageFormat.width / 4,
                decoration: pw.BoxDecoration(
                  gradient: pw.LinearGradient(
                    colors: [accentColor, PdfColors.white],
                  ),
                ),
              ),
            ),
            pw.Positioned(
              top: pageFormat.marginTop + 72,
              left: 0,
              right: 0,
              child: pw.Container(
                height: 3,
                color: baseColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  pw.Widget _contentTable(pw.Context context) {
    int index = 0;
    const tableHeaders = [
      'SR. NO.',
      'DISCRIPTION',
      'Value',
    ];

    return pw.Padding(
      padding: pw.EdgeInsets.all(10),
      child:
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        pw.Text(
            "Name:-  " +
                data.firstNameController.value.toString() +
                "" +
                data.middleNameController.value.toString() +
                " " +
                data.lastNameController.value.toString(),
            style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
        data.employerGenderController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text(
                "Gender:-  " + data.employerGenderController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerTanController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text("PAN:-  " + data.employerTanController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerfNoController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text("Phone:-  " + data.employerfNoController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerPremisesNoController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text(
                "Premises:-  " +
                    data.employerPremisesNoController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerStreetNameController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text(
                "Street:-  " +
                    data.employerStreetNameController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerLocalityController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text(
                "Locality:-  " +
                    data.employerLocalityController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerCityController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text("City:-  " + data.employerCityController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerPinController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text("Pin:-  " + data.employerPinController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerStateController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text(
                "State:-  " + data.employerStateController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.employerCountryController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text(
                "Country:-  " + data.employerCountryController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        data.selectedYearController.value == null
            ? pw.SizedBox.shrink()
            : pw.Text("Year:-  " + data.selectedYearController.value.toString(),
                style: pw.TextStyle(
                    fontSize: 14, fontWeight: pw.FontWeight.normal)),
        pw.SizedBox(height: 30),
        pw.Table(
          border: pw.TableBorder.all(),
          columnWidths: {
            0: pw.FixedColumnWidth(50),
            1: pw.FixedColumnWidth(300),
          },
          defaultColumnWidth: pw.FixedColumnWidth(150),
          defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
          children: [
            pw.TableRow(
              decoration: pw.BoxDecoration(border: pw.Border()),
              verticalAlignment: pw.TableCellVerticalAlignment.middle,
              children: [
                pw.Padding(
                  padding: pw.EdgeInsets.all(10),
                  child: pw.Text("SR.No",
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                ),
                pw.Padding(
                  padding: pw.EdgeInsets.all(10),
                  child: pw.Text("Description",
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                ),
                pw.Padding(
                  padding: pw.EdgeInsets.all(10),
                  child: pw.Text("Value",
                      style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                ),
              ],
            ),
            tableRow("1", SALARY, data.totalSalaryController.value.toString()),
            tableRow("2", HOUSE_PROPERTY,
                data.totalHousPartyController.value.toString()),
            tableRow("3", BUSINESS,
                data.totalBusinessIncomeController.value.toString()),
            tableRow("4", CAPITAL_GAIN,
                data.totalCapitalGainController.value.toString()),
            tableRow("5", OTHER_SOURCES,
                data.totalOtherSourcersController.value.toString()),
            tableRow("6", OTHER_SPECIAL_INCOME,
                data.totalDividentController.value.toString()),
            tableRow("7", LOSS_BF_AND_ADJUSTED,
                data.lossBfAdjustedController.value.toString()),
            tableRow("8", GROSS_TOTAL_INCOME,
                data.totalIncomeController.value.toString()),
          ],
        ),
        pw.SizedBox(height: 30),
        pw.Table(
          border: pw.TableBorder.all(),
          columnWidths: {
            0: pw.FixedColumnWidth(50),
            1: pw.FixedColumnWidth(300),
          },
          defaultColumnWidth: pw.FixedColumnWidth(150),
          defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
          children: [
            tableRow("1", DEDUCTIONS,
                data.totalDeductionUnderChapter6.value.toString()),
            tableRow("2", EXEMPT_INCOME,
                data.exemptIncomeController.value.toString()),
            tableRow("3", AGRICULTURE_INCOME,
                data.agroIncomeController.value.toString()),
            tableRow("4", TAXABLE_INCOME,
                data.taxableIncomeController.value.toString()),
          ],
        ),
        pw.SizedBox(height: 30),
        pw.Table(
          border: pw.TableBorder.all(),
          columnWidths: {
            0: pw.FixedColumnWidth(50),
            1: pw.FixedColumnWidth(300),
          },
          defaultColumnWidth: pw.FixedColumnWidth(150),
          defaultVerticalAlignment: pw.TableCellVerticalAlignment.middle,
          children: [
            tableRow("1", TAX_ON_NORMAL_INCOME,
                data.normalTaxController.value.toString()),
            tableRow("2", TAX_ON_SPECIAL_INCOME,
                data.specialTaxController.value.toString()),
            tableRow("3", LESS_REBATE87A,
                data.lessRebate87AController.value.toString()),
            tableRow("4", SURCHARGE, data.surchargeController.value.toString()),
            tableRow("5", EDUCATION_CESS,
                data.educationCessController.value.toString()),
            tableRow("6", TAXWO_SURCHARGE,
                data.taxPayableContrller.value.toString()),
            tableRow(
                "7",
                RELIEF,
                data.reliefController.value == null
                    ? ""
                    : data.reliefController.value.toString()),
            tableRow(
                "8",
                TDS,
                data.tdsController.value == null
                    ? ""
                    : data.tdsController.value.toString()),
            tableRow("9", ADVANCED_TAX,
                data.totalAdvancedTaxController.value.toString()),
            tableRow(
                "10", INTEREST_US_234A, data.t234AController.value.toString()),
            tableRow(
                "11", INTEREST_US_234B, data.t234BController.value.toString()),
            tableRow(
                "12", INTEREST_US_234C, data.t234CController.value.toString()),
            tableRow("13", TOTAL_234, data.total234Controller.value.toString()),
            tableRow("14", SELF_ASSESMENT_TAX,
                data.totalSelfTaxController.value.toString()),
            tableRow("15", TAX_PAYABLE,
                data.taxPayableRefundableController.value.toString()),
            tableRow(
                "16", FILING_DATE, data.filingDateController.value.toString()),
            tableRow("17", DUE_DATE, data.dueDateController.value.toString()),
          ],
        ),
      ]),
    );
  }

  pw.TableRow tableRow(String srNo, String title, String value) {
    return pw.TableRow(
      children: [
        pw.Padding(
          padding: pw.EdgeInsets.only(left: 25),
          child: pw.Text(srNo, textAlign: pw.TextAlign.center),
        ),
        pw.Padding(
          padding: pw.EdgeInsets.only(left: 15),
          child: pw.Text(title),
        ),
        pw.Padding(
            padding: pw.EdgeInsets.only(left: 15), child: pw.Text(value)),
      ],
    );
  }
}
