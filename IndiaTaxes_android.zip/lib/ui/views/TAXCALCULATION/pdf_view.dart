import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
import 'package:taxbase_general/ui/views/TAXCALCULATION/pdf_save.dart';
import 'package:taxbase_general/values/values.dart';

class PdfInvoice extends StatefulWidget {
  final TaxCalculationViewModel model;

  PdfInvoice(this.model);
  @override
  _PdfInvoiceState createState() => _PdfInvoiceState();
}

class _PdfInvoiceState extends State<PdfInvoice> {
  File file;
  int pages = 1;
  bool isReady = false;
  Completer _controller = Completer();

  @override
  void initState() {
    print(widget.model.totalSalaryController.value.toString());
    Timer(Duration(seconds: 2), () {
      getPdf();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.whiteColor,
        title: Text(
          "PDF",
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        actions: [
          // IconButton(
          //     icon: Icon(Icons.share),
          //     onPressed: () async {
          //       var sharePdf = await file.readAsBytes();
          //       await Share.file('esys image', 'Summary.pdf',
          //           sharePdf.buffer.asUint8List(), 'pdf/pdf',
          //           text: 'My optional text.');
          //     })
        ],
      ),
      body: Center(
        child: file != null
            ? PDFView(
                filePath: file.path,
                enableSwipe: true,

                swipeHorizontal: true,
                autoSpacing: true,
                // nightMode: true,
                pageSnap: true,
                pageFling: false,
                onRender: (_pages) {
                  setState(() {
                    pages = _pages;
                    isReady = true;
                  });
                },
                onError: (error) {
                  print(error.toString());
                },
                onPageError: (page, error) {
                  print('$page: ${error.toString()}');
                },
                onViewCreated: (PDFViewController pdfViewController) {
                  _controller.complete(pdfViewController);
                },
                onPageChanged: (int page, int total) {
                  print('page change: $page/$total');
                },
              )
            : Center(child: CircularProgressIndicator()),
      ),
    );
  }

  void getPdf() async {
    Uint8List uint8list = await generateInvoice(PdfPageFormat.a3, widget.model);
    Directory output = await getApplicationDocumentsDirectory();
    file = File(output.path + "/example.pdf");
    setState(() {
      file.writeAsBytes(uint8list);
      print(file.path);
    });
  }
}
