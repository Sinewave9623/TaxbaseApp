import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:logger/logger.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/StateModel/states.dart';
import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';
import 'package:taxbase_general/ui/widgets/gradient_container_widget.dart';
import 'package:taxbase_general/ui/widgets/tax_calculator_dialog.dart';
import 'package:taxbase_general/ui/widgets/tds_detail_dialog.dart';
import 'package:taxbase_general/values/values.dart';
import 'package:taxbase_general/ui/widgets/custom_bottom_bar.dart';

enum ClassType { SENIOR, NOTSENIOR }

class TaxCalculationScreen extends StatefulWidget {
  @override
  _TaxCalculationScreenState createState() => _TaxCalculationScreenState();
}

class _TaxCalculationScreenState extends State<TaxCalculationScreen> {
  var maritalStatus = "";
  List<int> selfAmountList = [];
  List<int> advancedAmountList = [];
  List<String> selfAmountDate = [];
  List<String> advancedAmountDate = [];
  List<String> otherList = ["0"];
  List<int> perquisitesList = [0];
  List<int> lieuList = [0];
  List<int> exemptList = [0];
  List<String> companyNameList = [];
  List<String> companyTanList = [];
  TextEditingController companyNameController = TextEditingController();
  TextEditingController companyTanController = TextEditingController();
  TextEditingController employerController = TextEditingController();
  List<Map<String, String>> tdsSectionList = [];
  List<Map<String, String>> tdsTransactionDateList = [];
  List<Map<String, String>> tdsbookingDateList = [];
  List<Map<String, String>> tdsbookingStatusList = [];
  List<Map<String, String>> tdsremarksList = [];
  List<Map<String, dynamic>> tdspaidAmountList = [];
  List<Map<String, dynamic>> tdstaxDeductedList = [];
  List<Map<String, dynamic>> tdstaxDepositedList = [];

  TextEditingController _name = TextEditingController();
  TextEditingController _primises = TextEditingController();
  TextEditingController _pincode = TextEditingController();
  TextEditingController _city = TextEditingController();
  TextEditingController _state = TextEditingController();
  TextEditingController _age = TextEditingController();
  TextEditingController birthDateController = TextEditingController();

  var selectedTaxMethod = "Normal";
  var selectedResidency = "Resident India";
  var selecedYear = "2021-2022";
  var selectedITR = "01. Individual";
  var selectedDomesticCompany;

  List<String> states = [
    "Andaman and Nicobar Islands",
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chandigarh",
    "Chhattisgarh",
    "Dadra & Nagar Haveli And Daman & Diu",
    "Daman & Diu",
    "Delhi",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu & Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Lakhswadeep",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Orissa",
    "Pondicherry"
        "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamilnadu",
    "Tripura",
    "Uttar Pradesh",
    "West Bengal",
    "Uttaranchal",
    "Uttarakhand",
    "Telangana",
    "Ladakh",
    "(Outside India)",
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: AppColors.whiteColor,
        statusBarIconBrightness: Brightness.dark));
    return ViewModelBuilder<TaxCalculationViewModel>.reactive(
      onModelReady: (model) => model.init(context),
      builder: (context, model, child) {
        return Scaffold(
            resizeToAvoidBottomInset: true,
            appBar: AppBar(
              backgroundColor: AppColors.whiteColor,
              title: Text(
                TAX_CALCULATION,
                style: TextStyle(
                  fontFamily: "D-DIN",
                  color: Colors.black,
                ),
              ),
              centerTitle: true,
              // actions: [
              //   InkWell(
              //       onTap: () {
              //         model.clearStorage();
              //       },
              //       child: Icon(Icons.remove)),
              // ],
            ),
            body: Container(
              height: screenHeight(context) - AppBar().preferredSize.height,
              width: screenWidth(context),
              child: SingleChildScrollView(
                child: model.isLoading
                    ? Container(
                        margin: EdgeInsets.only(top: 50),
                        child: Center(
                          child: CircularProgressIndicator(),
                        ))
                    : Column(
                        children: [
                          // ^ basic details
                          buildStep(
                              leadingIcon: Icons.backup_table,
                              title: BASIC_DETAILS,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                    child: Scaffold(
                                      appBar: AppBar(
                                        title: Text(BASIC_DETAILS),
                                      ),
                                      body: basicDetailsBody(model),
                                      bottomNavigationBar: CustomBotomBar(
                                        onCancelButtonPressed: () {
                                          print("Cancel Pressed");
                                          Navigator.of(context).pop();
                                        },
                                        onSaveButtonPressed: () {
                                          model.saveBasicDetails();
                                          Navigator.of(context).pop();
                                        },
                                      ),
                                    ),
                                  )),
                          // ^ STEP 1 SALARY
                          buildStep(
                              leadingIcon: Icons.account_balance_wallet,
                              title: SALARY,
                              isInputField: true,
                              value: model.totalSalary,
                              onPressed: () {
                                salaryDialog(
                                  context,
                                  perquisitesList,
                                  lieuList,
                                  exemptList,
                                  model,
                                );
                                // model.navigateToSalaryScreen();
                              }),
                          // ^ STEP 2 HOUSE PROPERTY
                          buildStep(
                              leadingIcon: Icons.home_filled,
                              title: HOUSE_PROPERTY,
                              value: model.totalHouseProperty,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                    child: Scaffold(
                                        appBar: AppBar(
                                          title: Text(HOUSE_PROPERTY),
                                        ),
                                        body: housPropertyBody(model),
                                        bottomNavigationBar: CustomBotomBar(
                                          onCancelButtonPressed: () {
                                            print("Cancel Pressed");
                                            Navigator.of(context).pop();
                                          },
                                          onSaveButtonPressed: () {
                                            model.saveHoueProperty();
                                            Navigator.of(context).pop();
                                          },
                                        )),
                                  )),
                          // ^ STEP 3 BUSINESS
                          buildStep(
                              leadingIcon: Icons.business,
                              title: BUSINESS,
                              value: model.totalBusinessIncome,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                      child: Scaffold(
                                          appBar: AppBar(
                                            title: Text(BUSINESS),
                                          ),
                                          body: businessBody(model),
                                          bottomNavigationBar: CustomBotomBar(
                                            onCancelButtonPressed: () {
                                              print("Cancel Pressed");
                                              Navigator.of(context).pop();
                                            },
                                            onSaveButtonPressed: () {
                                              model.saveBusiness();
                                              Navigator.of(context).pop();
                                            },
                                          )))),
                          // ^ STEP 4 CAPITAL GAIN
                          buildStep(
                              leadingIcon: Icons.insert_chart,
                              title: CAPITAL_GAIN,
                              value: model.totalCapitalGain,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                      child: Scaffold(
                                          appBar: AppBar(
                                            title: Text(CAPITAL_GAIN),
                                          ),
                                          body: capitalGainBody(model),
                                          bottomNavigationBar: CustomBotomBar(
                                            onCancelButtonPressed: () {
                                              print("Cancel Pressed");
                                              Navigator.of(context).pop();
                                            },
                                            onSaveButtonPressed: () {
                                              model.saveCapitalGain();
                                              Navigator.of(context).pop();
                                            },
                                          )))),
                          // ^ STEP 5 OTHER SOURCES
                          buildStep(
                              leadingIcon: Icons.source,
                              title: OTHER_SOURCES,
                              value: model.totalOtherSources,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                      child: Scaffold(
                                          appBar: AppBar(
                                            title: Text(OTHER_SOURCES),
                                          ),
                                          body: otherSourcesBody(model),
                                          bottomNavigationBar: CustomBotomBar(
                                            onCancelButtonPressed: () {
                                              print("Cancel Pressed");
                                              Navigator.of(context).pop();
                                            },
                                            onSaveButtonPressed: () {
                                              model.saveOtherSources();
                                              Navigator.of(context).pop();
                                            },
                                          )))),
                          // ^ STEP 6 OTHER SPECIAL INCOME
                          buildStep(
                            leadingIcon: Icons.folder_special,
                            title: OTHER_SPECIAL_INCOME,
                            value: model.totalDivident,
                            isInputField: true,
                            onPressed: () => model.navigateToCalculationScreen(
                                child: Scaffold(
                                    appBar: AppBar(
                                        title: Text(OTHER_SPECIAL_INCOME)),
                                    body: otherSpecialIncomeBody(model),
                                    bottomNavigationBar: CustomBotomBar(
                                      onCancelButtonPressed: () {
                                        print("Cancel Pressed");
                                        Navigator.of(context).pop();
                                      },
                                      onSaveButtonPressed: () {
                                        model.saveOtherSpecial();
                                        Navigator.of(context).pop();
                                      },
                                    ))),
                          ),
                          // ^ STEP 7 LOSS_BF_AND_ADJUSTED
                          buildStep(
                              leadingIcon: Icons.trending_down,
                              title: LOSS_BF_AND_ADJUSTED,
                              value: model.lossbfAdjusted,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                      child: Scaffold(
                                          appBar: AppBar(
                                            title: Text(LOSS_BF_AND_ADJUSTED),
                                          ),
                                          body: loofBfBody(model),
                                          bottomNavigationBar: CustomBotomBar(
                                            onCancelButtonPressed: () {
                                              print("Cancel Pressed");
                                              Navigator.of(context).pop();
                                            },
                                            onSaveButtonPressed: () {
                                              model.saveLoss();
                                              Navigator.of(context).pop();
                                            },
                                          )))),
                          // ^ STEP 8 DEDUCTIONS
                          StreamBuilder<String>(
                              stream: model.taxMethod,
                              builder: (context, methodSnap) {
                                return StreamBuilder<String>(
                                    stream: model.selectedYear,
                                    builder: (context, snapshot) {
                                      return snapshot.data == "2021-2022" &&
                                              methodSnap.data == "R"
                                          ? SizedBox.shrink()
                                          : buildStep(
                                              leadingIcon: Icons.remove_circle,
                                              value:
                                                  model.deductionUnderChaper6,
                                              title: DEDUCTIONS,
                                              isInputField: true,
                                              onPressed: () => model
                                                      .navigateToCalculationScreen(
                                                    child: Scaffold(
                                                        appBar: AppBar(
                                                          title:
                                                              Text(DEDUCTIONS),
                                                        ),
                                                        body: deductionsBody(
                                                            model),
                                                        bottomNavigationBar:
                                                            CustomBotomBar(
                                                          onCancelButtonPressed:
                                                              () {
                                                            print(
                                                                "Cancel Pressed");
                                                            Navigator.of(
                                                                    context)
                                                                .pop();
                                                          },
                                                          onSaveButtonPressed:
                                                              () {
                                                            model
                                                                .saveDeduction();
                                                            Navigator.of(
                                                                    context)
                                                                .pop();
                                                          },
                                                        )),
                                                  ));
                                    });
                              }),
                          // ^ STEP 9 EXEMPT_INCOME
                          buildStep(
                              leadingIcon: Icons.money,
                              title: EXEMPT_INCOME,
                              value: model.totalExemptIncome,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                      child: Scaffold(
                                          appBar: AppBar(
                                            title: Text(EXEMPT_INCOME),
                                          ),
                                          body: exemptIncomeBody(model),
                                          bottomNavigationBar: CustomBotomBar(
                                            onCancelButtonPressed: () {
                                              print("Cancel Pressed");
                                              Navigator.of(context).pop();
                                            },
                                            onSaveButtonPressed: () {
                                              model.saveExemptIncome();
                                              Navigator.of(context).pop();
                                            },
                                          )))),
                          // ^ STEP 10 AGRICULTURE_INCOME
                          buildStep(
                              leadingIcon: Icons.agriculture,
                              title: AGRICULTURE_INCOME,
                              value: model.agroIncome,
                              isInputField: true,
                              onPressed: () =>
                                  model.navigateToCalculationScreen(
                                      child: Scaffold(
                                          appBar: AppBar(
                                            title: Text(AGRICULTURE_INCOME),
                                          ),
                                          body: agroBody(model),
                                          bottomNavigationBar: CustomBotomBar(
                                            onCancelButtonPressed: () {
                                              print("Cancel Pressed");
                                              Navigator.of(context).pop();
                                            },
                                            onSaveButtonPressed: () {
                                              model.saveAgroIncome();
                                              Navigator.of(context).pop();
                                            },
                                          )))),
                          // ^ step 14
                          buildStep(
                              leadingIcon: Icons.request_page,
                              value: model.tds,
                              title: TDS,
                              isInputField: true,
                              onPressed: () {
                                tdsDetailDialog(
                                  context,
                                  model,
                                );
                              }),
                          // ^ step 15
                          buildStep(
                              leadingIcon: Icons.request_quote,
                              title: ADVANCED_TAX,
                              value: model.totalAdvancedTax,
                              isInputField: true,
                              onPressed: () => advancedTaxDialog(
                                    context,
                                    advancedAmountList,
                                    advancedAmountDate,
                                    model,
                                  )),
                          // ^ STEP 16
                          buildStep(
                              leadingIcon: Icons.request_quote,
                              title: SELF_ASSESMENT_TAX,
                              value: model.totalSelfTax,
                              isInputField: true,
                              onPressed: () => selfAssesmentTaxDialog(
                                    context,
                                    selfAmountList,
                                    selfAmountDate,
                                    model,
                                  )),

                          //   ITR INFORMATION
                          // buildStep(
                          //     leadingIcon: Icons.request_quote,
                          //     title: ITR_INFORMATION,
                          //     value: model.itrInformation,
                          //     isInputField: true,
                          //     onPressed: () => selfAssesmentTaxDialog(
                          //           context,
                          //           selfAmountList,
                          //           selfAmountDate,
                          //           model,
                          //         )),
                          buildStep(
                              leadingIcon: Icons.request_quote,
                              title: ITR_INFORMATION,
                              // value: model.totalSelfTax,
                              isInputField: true,
                              onPressed: () => itrInformationDialog(
                                    context,
                                    model,
                                  )),

                          Container(
                            margin: EdgeInsets.only(
                                top: paddingTop(context) * 0.54),
                            child: StreamBuilder<bool>(
                                stream:
                                    model.validateButton.asBroadcastStream(),
                                builder: (context, snapshot) {
                                  return BusyButton(
                                    height: 40,
                                    iconImage: Icons.arrow_forward_rounded,
                                    busy: model.loading,
                                    onPressed: () {
                                      model.taxcalculatorAPI(model: model);
                                    },
                                  );
                                }),
                          ),
                          SizedBox(
                            height: Sizes.HEIGHT_10,
                          )
                        ],
                      ),
              ),
            ));
      },
      viewModelBuilder: () => TaxCalculationViewModel(),
    );
  }

// ^ BASIC DETAILS

  Container basicDetailsBody(TaxCalculationViewModel model) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Year *"),
                  IconButton(
                    icon: Text(
                      "?",
                    ),
                    onPressed: () =>
                        model.alertInfo(context, "Year", YEAR_DESC),
                  ),
                ],
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 1),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  value: model.selectedYearController.value,
                  items: ["2020-2021", "2021-2022"].map((value) {
                    return new DropdownMenuItem<String>(
                      value: value,
                      child: new Text(value, overflow: TextOverflow.ellipsis),
                    );
                  }).toList(),
                  hint: Text("Please choose a  Year"),
                  onChanged: (value) {
                    selecedYear = value;
                    model.onSelectedYearChanged(value);
                    model.basicDetails();
                    model.calculateDeduction();
                    model.calculateSalary();
                    model.calculateHouseProperty();
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Date *"),
                  IconButton(
                    icon: Text(
                      "?",
                    ),
                    onPressed: () =>
                        model.alertInfo(context, "Date ", DATE_DESC),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: Container(
                      height: 50,
                      width: screenWidth(context),
                      child: DateTimePicker(
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                        dateLabelText: 'Filling Date',
                        dateMask: 'dd-MM-yyyy',
                        controller: TextEditingController()
                          ..text = model.filingDateController.value.toString(),
                        onChanged: (value) {
                          model.onfilingDateChanged(value);
                          model.basicDetails();
                        },
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Container(
                      height: 50,
                      width: screenWidth(context),
                      child: DateTimePicker(
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                        dateLabelText: 'Due Date',
                        dateMask: 'dd-MM-yyyy',
                        controller: TextEditingController()
                          ..text = model.dueDateController.value.toString(),
                        onChanged: (value) {
                          model.ondueDateChanged(value);
                          model.basicDetails();
                        },
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Tax Method"),
                  IconButton(
                    icon: Text(
                      "?",
                    ),
                    onPressed: () =>
                        model.alertInfo(context, "Tax Method", TAX_DESC),
                  ),
                ],
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 1),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  value: model.taxMethodController.value.toString() == "N"
                      ? "Normal"
                      : model.taxMethodController.value.toString() == "M"
                          ? "MMR"
                          : model.taxMethodController.value.toString() == "R"
                              ? "New Regime"
                              : model.taxMethodController.value.toString() ==
                                      "I"
                                  ? "NIL"
                                  : "Normal",
                  items: ["Normal", "MMR", "NIL", "New Regime"].map((value) {
                    return new DropdownMenuItem<String>(
                      value: value,
                      child: new Text(value, overflow: TextOverflow.ellipsis),
                    );
                  }).toList(),
                  hint: Text("Please choose a  Tax Method"),
                  onChanged: (value) {
                    selectedTaxMethod = value;
                    value == "Normal"
                        ? model.ontaxMethodChanged("N")
                        : value == "MMR"
                            ? model.ontaxMethodChanged("M")
                            : value == "NIL"
                                ? model.ontaxMethodChanged("I")
                                : value == "New Regime"
                                    ? model.ontaxMethodChanged("R")
                                    : model.ontaxMethodChanged(null);

                    model.basicDetails();
                    model.calculateDeduction();
                    model.calculateSalary();
                    model.calculateHouseProperty();
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Resident"),
                  // IconButton(
                  //   icon: Text(
                  //     "?",
                  //   ),
                  //   onPressed: () => model.alertInfo(
                  //       context, "Resident", "Resident Info"),
                  // ),
                ],
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 1),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  value: model.residencyStatusController.value == "NR"
                      ? "NRI"
                      : model.residencyStatusController.value == "R"
                          ? "Resident India"
                          : model.residencyStatusController.value == "OR"
                              ? "Non Ordinarily Resident"
                              : "Resident India",
                  items: ["NRI", "Resident India", "Non Ordinarily Resident"]
                      .map((value) {
                    return new DropdownMenuItem<String>(
                      value: value,
                      child: new Text(value, overflow: TextOverflow.ellipsis),
                    );
                  }).toList(),
                  hint: Text("Please choose a  Residency"),
                  onChanged: (value) {
                    selectedResidency = value;
                    value == "NRI"
                        ? model.onresidencyStatusChanged("NR")
                        : value == "Resident India"
                            ? model.onresidencyStatusChanged("R")
                            : value == "Non Ordinarily Resident"
                                ? model.onresidencyStatusChanged("OR")
                                : model.onresidencyStatusChanged(null);

                    model.basicDetails();
                    model.calculateDeduction();
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("ITR Status *"),
                  IconButton(
                    icon: Text(
                      "?",
                    ),
                    onPressed: () =>
                        model.alertInfo(context, "ITR Status ", ITR_DESC),
                  ),
                ],
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 1),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  value: model.selectedITRController.value == "01"
                      ? "01. Individual"
                      : model.selectedITRController.value == "03"
                          ? "03. Hindu Undivided Family"
                          : model.selectedITRController.value == "05"
                              ? "05. Registered Partnership (Business)"
                              : model.selectedITRController.value == "06"
                                  ? "06. Registered Partnership (Professional) "
                                  : model.selectedITRController.value == "07"
                                      ? "07. Association of persons "
                                      : model.selectedITRController.value ==
                                              "08"
                                          ? "08. Association of persons (Trust) "
                                          : model.selectedITRController.value ==
                                                  "09"
                                              ? "09. Body of Individuals "
                                              : model.selectedITRController
                                                          .value ==
                                                      "10"
                                                  ? "10. Artificial Juridical person "
                                                  : model.selectedITRController
                                                              .value ==
                                                          "11"
                                                      ? "11. Co-operative Societies "
                                                      : model.selectedITRController
                                                                  .value ==
                                                              "12"
                                                          ? "12. A domestic Company - Public Substantially Interested "
                                                          : model.selectedITRController
                                                                      .value ==
                                                                  "13"
                                                              ? "13. A domestic Company - Public Not Substantially Interested "
                                                              : model.selectedITRController
                                                                          .value ==
                                                                      "14"
                                                                  ? "14. Trdg/Inv Co. Public not Subst. Interested "
                                                                  : model.selectedITRController
                                                                              .value ==
                                                                          "15"
                                                                      ? "15. Company other than domestic company "
                                                                      : "01. Individual",
                  items: [
                    "01. Individual",
                    "03. Hindu Undivided Family",
                    "05. Registered Partnership (Business)",
                    "06. Registered Partnership (Professional) ",
                    "07. Association of persons ",
                    "08. Association of persons (Trust) ",
                    "09. Body of Individuals ",
                    "10. Artificial Juridical person ",
                    "11. Co-operative Societies ",
                    "12. A domestic Company - Public Substantially Interested ",
                    "13. A domestic Company - Public Not Substantially Interested ",
                    "14. Trdg/Inv Co. Public not Subst. Interested ",
                    "15. Company other than domestic company "
                  ].map((value) {
                    return new DropdownMenuItem<String>(
                      value: value,
                      child: new Text(value, overflow: TextOverflow.ellipsis),
                    );
                  }).toList(),
                  hint: Text("Please choose a  ITR Status"),
                  onChanged: (value) {
                    selectedITR = value;
                    print(value.toString().substring(0, 2));
                    switch (value.substring(0, 2)) {
                      case "01":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "03":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "05":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "06":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "07":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "08":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "09":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "10":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "11":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "12":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "13":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "14":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;
                      case "15":
                        model.onSelectedITRChanged(value.substring(0, 2));
                        model.basicDetails();
                        break;

                      default:
                        model.onSelectedITRChanged(null);
                        break;
                    }

                    model.basicDetails();
                  },
                ),
              ),
              StreamBuilder<String>(
                  stream: model.selectedITR,
                  builder: (context, snapshot) {
                    return snapshot.data.toString() == "12" ||
                            snapshot.data.toString() == "13"
                        ? Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 1),
                            child: DropdownButtonFormField(
                              isExpanded: true,
                              value: model.selectedDomesticCompanyController
                                          .value ==
                                      "BA"
                                  ? "115BA"
                                  : model.selectedDomesticCompanyController
                                              .value ==
                                          "BAA"
                                      ? "115BAA"
                                      : model.selectedDomesticCompanyController
                                                  .value ==
                                              "BAB"
                                          ? "115BAB"
                                          : "115BA",
                              items: ["115BA", "115BAA", "115BAB"].map((value) {
                                return new DropdownMenuItem<String>(
                                  value: value,
                                  child: new Text(value,
                                      overflow: TextOverflow.ellipsis),
                                );
                              }).toList(),
                              hint: Text("Please choose a  Domestic Company"),
                              onChanged: (value) {
                                selectedDomesticCompany = value;
                                value == "115BA"
                                    ? model
                                        .onSelectedDomesticCompanyChanged("BA")
                                    : value == "115BAA"
                                        ? model
                                            .onSelectedDomesticCompanyChanged(
                                                "BAA")
                                        : value == "115BAB"
                                            ? model
                                                .onSelectedDomesticCompanyChanged(
                                                    "BAB")
                                            : model
                                                .onSelectedDomesticCompanyChanged(
                                                    null);

                                model.basicDetails();
                              },
                            ),
                          )
                        : SizedBox.shrink();
                  }),
              StreamBuilder<dynamic>(
                stream: model.firstName,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: FIRST_NAME,
                    label: FIRST_NAME,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.firstNameController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onFirstNameChanged("");
                      } else {
                        model.onFirstNameChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.middleName,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: MIDDLE_NAME,
                    label: MIDDLE_NAME,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.middleNameController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onMiddleNameChanged("");
                      } else {
                        model.onMiddleNameChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.lastName,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: LAST_NAME,
                    label: LAST_NAME,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.lastNameController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onLastNameChanged("");
                      } else {
                        model.onLastNameChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.gender,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: GENDERS,
                    label: GENDERS,
                    keyBoardType: TextInputType.text,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'[a-z,A-Z]')),
                    ],
                    intialValue: model.genderController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onGenderChanged("");
                      } else {
                        model.onGenderChanged(value);
                      }
                    },
                  );
                },
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: StreamBuilder<String>(
                  stream: model.dob,
                  builder: (context, snapshot) {
                    birthDateController.value = birthDateController.value
                        .copyWith(text: snapshot.data ?? "");
                    return TextFormField(
                      controller: birthDateController,
                      maxLength: 2,
                      onTap: () {
                        FocusNode().unfocus();
                        model.getBirthDate(context);
                      },
                      // keyboardType: TextInputType.number,
                      keyboardType: TextInputType.datetime,
                      decoration: InputDecoration(
                        hintText: "BirthDate",
                        counterText: "",
                        hintStyle: Theme.of(context)
                            .textTheme
                            .bodyText2
                            .copyWith(color: AppColors.primaryColorLight),
                      ),
                      onChanged: model.onDobChanged,
                    );
                  },
                ),
              ),
              StreamBuilder<dynamic>(
                stream: model.employeePan,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: PAN,
                    label: PAN,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,0-9]')),
                    ],
                    textCapitalization: TextCapitalization.characters,
                    keyBoardType: TextInputType.text,
                    intialValue: model.employeePanController.value.toString(),
                    maxLength: 10,
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onEmployeePanChanged("");
                      } else {
                        model.onEmployeePanChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.fatherName,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: FATHER_NAME,
                    label: FATHER_NAME,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.fatherNameController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onFatherNameChanged("");
                      } else {
                        model.onFatherNameChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.flatNumber,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: FLAT_NUMBER,
                    label: FLAT_NUMBER,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z, 0-9,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.flatNumberController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onFlatNumberChanged("");
                      } else {
                        model.onFlatNumberChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.premiseName,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: PREMISE_NAME,
                    label: PREMISE_NAME,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,0-9,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.premiseNameController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onPremiseNameChanged("");
                      } else {
                        model.onPremiseNameChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.streetName,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: STREET_NAME,
                    label: STREET_NAME,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,0-9,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.streetNameController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onStreetNameChanged("");
                      } else {
                        model.onStreetNameChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.area,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: AREA,
                    label: AREA,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,0-9,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.areaController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onareaChanged("");
                      } else {
                        model.onareaChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.town,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: TOWN,
                    label: TOWN,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z,  ,]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.townController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onTownChanged("");
                      } else {
                        model.onTownChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.pin,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: PIN,
                    label: PIN,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                    ],
                    intialValue: model.pinController.value.toString(),
                    maxLength: 6,
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onPinChanged("");
                      } else {
                        model.onPinChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<List<StateList>>(
                  stream: model.stateDropdown,
                  builder: (context, snapshot) {
                    Logger().e(snapshot.data);
                    return snapshot.data == null
                        ? SizedBox.shrink()
                        : Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: new DropdownButtonFormField(
                              isExpanded: true,
                              items: snapshot.data.map((StateList value) {
                                return new DropdownMenuItem<String>(
                                  value: value.stateId.toString(),
                                  child: new Text(value.stateName,
                                      overflow: TextOverflow.ellipsis),
                                );
                              }).toList(),
                              hint: Text("Please choose State "),
                              value: model.selectedStateController.value
                                  .toString(),
                              onChanged: (value) {
                                setState(() {
                                  if (value !=
                                      model.selectedStateController.value
                                          .toString()) {
                                    model.selectedStateController.value = value;
                                  }
                                  model.onStateStringChanged;
                                });

                                setState(() {});
                              },
                            ),
                          );
                  }),

              // StreamBuilder<dynamic>(
              //   stream: model.state,
              //   builder: (context, snapshot) {
              //     return buildTextField(
              //       hint: STATE,
              //       label: STATE,
              //       numbersAllowd: <TextInputFormatter>[
              //         FilteringTextInputFormatter.allow(
              //             RegExp(r'[a-z,A-Z,  ,]')),
              //       ],
              //       keyBoardType: TextInputType.text,
              //       intialValue: model.stateController.value.toString(),
              //       onChanged: (value) {
              //         if (value.isEmpty) {
              //           model.onStateChanged("");
              //         } else {
              //           model.onStateChanged(value);
              //         }
              //       },
              //     );
              //   },
              // ),
              StreamBuilder<dynamic>(
                stream: model.country,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: COUNTRY,
                    label: COUNTRY,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'[a-z,A-Z]')),
                    ],
                    keyBoardType: TextInputType.text,
                    intialValue: model.countryController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onCountryChanged("");
                      } else {
                        model.onCountryChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.mobile,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: MOBILE,
                    label: MOBILE,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                    ],
                    intialValue: model.mobileController.value.toString(),
                    maxLength: 10,
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onMobileChanged("");
                      } else {
                        model.onMobileChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.aadhar,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: AADHAR,
                    label: AADHAR,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                    ],
                    intialValue: model.aadharController.value.toString(),
                    maxLength: 12,
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onAadharChanged("");
                      } else {
                        model.onAadharChanged(value);
                      }
                    },
                  );
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.email,
                builder: (context, snapshot) {
                  return buildTextField(
                    hint: EMAIL,
                    label: EMAIL,
                    numbersAllowd: <TextInputFormatter>[
                      FilteringTextInputFormatter.allow(
                          RegExp(r'[a-z,A-Z, 0-9,@,_., ,]')),
                    ],
                    keyBoardType: TextInputType.emailAddress,
                    intialValue: model.emailController.value.toString(),
                    onChanged: (value) {
                      if (value.isEmpty) {
                        model.onEmailChanged("");
                      } else {
                        model.onEmailChanged(value);
                      }
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ^ step 2 HOUSE PROPERTY
  Container housPropertyBody(TaxCalculationViewModel model) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 1),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  value: model.housePropertyTypeController.value,
                  items: ["Self Occupied", "Let Out", "Deemed Let out"]
                      .map((value) {
                    return new DropdownMenuItem<String>(
                      value: value,
                      child: new Text(value, overflow: TextOverflow.ellipsis),
                    );
                  }).toList(),
                  hint: Text("Please choose a House Property Type"),
                  onChanged: (value) {
                    model.onHousPropertyTypeChanged(value);
                    model.calculateHouseProperty();
                  },
                ),
              ),
              StreamBuilder<dynamic>(
                stream: model.rentReceived,
                builder: (context, snapshot) {
                  return buildTextField(
                      hint: RENT_RECEIVED,
                      label: RENT_RECEIVED,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.rendtReceivedHPController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onRentedReceivedChanged(0);
                          model.calculateHouseProperty();
                        } else {
                          model.onRentedReceivedChanged(value);
                          model.calculateHouseProperty();
                        }
                      });
                },
              ),
              StreamBuilder<dynamic>(
                stream: model.municpalTax,
                builder: (context, snapshot) {
                  return buildTextField(
                      hint: MUNCIPLE_TAX,
                      label: MUNCIPLE_TAX,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.muncipalTaxController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onMunicpalTaxChanged(0);
                          model.calculateHouseProperty();
                        } else {
                          model.onMunicpalTaxChanged(int.parse(value));
                          model.calculateHouseProperty();
                        }
                      });
                },
              ),
              Text("Deductions"),
              StreamBuilder<dynamic>(
                  stream: model.interestPaid,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: INTREST_PAID,
                      label: INTREST_PAID,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.interestPaidHPController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onInterestPaidChanged(0);
                          model.calculateHouseProperty();
                        } else {
                          model.onInterestPaidChanged(value);
                          model.calculateHouseProperty();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                stream: model.realisedRent,
                builder: (context, snapshot) {
                  return buildTextField(
                      hint: UNREALISED,
                      label: UNREALISED,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.inrealisedRentController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onRealisedRentChanged(0);
                          model.calculateHouseProperty();
                        } else {
                          model.onRealisedRentChanged(int.parse(value));
                          model.calculateHouseProperty();
                        }
                      });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ^ STEP 3 BUSINESS
  Container businessBody(TaxCalculationViewModel model) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(INCOME_FROM_FIRMS,
                  style: Theme.of(context).textTheme.headline6),
              StreamBuilder<dynamic>(
                  stream: model.profitFromFirm,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: PROFIT,
                      label: PROFIT,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.profitFromFirmController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onProfitFromFirmChanged(0);
                          model.calculateBusiness();
                        } else {
                          model.onProfitFromFirmChanged(value);
                          model.calculateBusiness();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.remunerationFromFirm,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: REMUNERATION,
                        label: REMUNERATION,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue: model.remunerationFromFirmController.value
                            .toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onRemunerationFromFirmChanged(0);
                            model.calculateBusiness();
                          } else {
                            model.onRemunerationFromFirmChanged(value);
                            model.calculateBusiness();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.interestFromFirm,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: INTEREST,
                        label: INTEREST,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.interestFromFirmController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onInterestFromFirmChanged(0);
                            model.calculateBusiness();
                          } else {
                            model.onInterestFromFirmChanged(value);
                            model.calculateBusiness();
                          }
                        });
                  }),
              Text(BUSINESS, style: Theme.of(context).textTheme.headline6),
              StreamBuilder<String>(
                  stream: model.businessName,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: NAME_OF_BUSINESS,
                        label: NAME_OF_BUSINESS,
                        intialValue: model.nameOfBusinessController.value,
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onBusinessNameChange("");
                            model.calculateBusiness();
                          } else {
                            model.onBusinessNameChange(value);
                            model.calculateBusiness();
                          }
                        },
                        keyBoardType: TextInputType.text);
                  }),
              StreamBuilder<dynamic>(
                  stream: model.profitFromBusiness,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: PROFIT,
                        label: PROFIT,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.profitFromBusinessController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onProfitFromBusinessChanged(0);
                            model.calculateBusiness();
                          } else {
                            model.onProfitFromBusinessChanged(value);
                            model.calculateBusiness();
                          }
                        });
                  }),
            ],
          ),
        ),
      ),
    );
  }

// ^ STEP 4 CAPITAL GAIN
  SingleChildScrollView capitalGainBody(TaxCalculationViewModel model) {
    return SingleChildScrollView(
      child: Container(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(STCG_NORMAL, style: Theme.of(context).textTheme.headline6),
              StreamBuilder<dynamic>(
                  stream: model.stcgNormal1506,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: F15_06,
                      label: F15_06,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.stcgNormal1506Controller.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onStcgNormal1506Change(0);
                          model.calculateCapitalGain();
                        } else {
                          model.onStcgNormal1506Change(value);
                          model.calculateCapitalGain();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcgNormal1509,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: F15_09,
                      label: F15_09,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.stcgNormal1509Controller.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onStcgNormal1509Change(0);
                          model.calculateCapitalGain();
                        } else {
                          model.onStcgNormal1509Change(value);
                          model.calculateCapitalGain();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcgNormal1512,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_12,
                        label: F15_12,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.stcgNormal1512Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onStcgNormal1512Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onStcgNormal1512Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcgNormal1503,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_03,
                        label: F15_03,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.stcgNormal1503Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onStcgNormal1503Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onStcgNormal1503Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcgNormal3103,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F31_3,
                        label: F31_3,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.stcgNormal3103Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onStcgNormal3103Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onStcgNormal3103Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              GradientContainerWidget(
                title: STCG_NORMAL,
                model: model.totalStcgNormal,
              ),
              Text(STCG_111A, style: Theme.of(context).textTheme.headline6),
              StreamBuilder<dynamic>(
                  stream: model.stcg111A1506,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: F15_06,
                      label: F15_06,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.stcg111A1506Controller.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onStcg111A1506Change(0);
                          model.calculateCapitalGain();
                        } else {
                          model.onStcg111A1506Change(value);
                          model.calculateCapitalGain();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcg111A1509,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_09,
                        label: F15_09,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.stcg111A1509Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onStcg111A1509Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onStcg111A1509Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcg111A1512,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_12,
                        label: F15_12,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.stcg111A1512Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onStcg111A1512Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onStcg111A1512Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcg111A1503,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_03,
                        label: F15_03,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.stcg111A1503Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onStcg111A1503Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onStcg111A1503Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.stcg111A3103,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F31_3,
                        label: F31_3,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.stcg111A3103Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onStcg111A3103Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onStcg111A3103Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              GradientContainerWidget(
                  title: STCG_111A, model: model.totalStcg111A),
              Text(LTCG_112A, style: Theme.of(context).textTheme.headline6),
              StreamBuilder<dynamic>(
                  stream: model.ltcg112A1506,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_06,
                        label: F15_06,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg112A1506Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg112A1506Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg112A1506Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg112A1509,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_09,
                        label: F15_09,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg112A1509Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg112A1509Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg112A1509Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg112A1512,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_12,
                        label: F15_12,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg112A1512Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg112A1512Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg112A1512Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg112A1503,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_03,
                        label: F15_03,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg112A1503Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg112A1503Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg112A1503Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg112A3103,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F31_3,
                        label: F31_3,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg112A3103Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg112A3103Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg112A3103Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              GradientContainerWidget(
                  title: LTCG_112A, model: model.totalLtcg112A),
              Text(LTCG_10, style: Theme.of(context).textTheme.headline6),
              StreamBuilder<dynamic>(
                  stream: model.ltcg101506,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_06,
                        label: F15_06,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg101506Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg101506Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg101506Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg101509,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_09,
                        label: F15_09,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg101509Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg101509Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg101509Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg101512,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_12,
                        label: F15_12,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg101512Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg101512Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg101512Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg101503,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_03,
                        label: F15_03,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg101503Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg101503Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg101503Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg103103,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F31_3,
                        label: F31_3,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg103103Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg103103Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg103103Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              GradientContainerWidget(title: LTCG_10, model: model.totalLtcg10),
              Text(LTCG_20, style: Theme.of(context).textTheme.headline6),
              StreamBuilder<dynamic>(
                  stream: model.ltcg201506,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_06,
                        label: F15_06,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg201506Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg201506Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg201506Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg201509,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_09,
                        label: F15_09,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg201509Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg201509Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg201509Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg201512,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_12,
                        label: F15_12,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg201512Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg201512Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg201512Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg201503,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_03,
                        label: F15_03,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.ltcg201503Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLtcg201503Change(0);
                            model.calculateCapitalGain();
                          } else {
                            model.onLtcg201503Change(value);
                            model.calculateCapitalGain();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.ltcg203103,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: F31_3,
                      label: F31_3,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.ltcg203103Controller.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onLtcg203103Change(0);
                          model.calculateCapitalGain();
                        } else {
                          model.onLtcg203103Change(value);
                          model.calculateCapitalGain();
                        }
                      },
                    );
                  }),
              GradientContainerWidget(title: LTCG_20, model: model.totalLtcg20),
            ],
          ),
        ),
      ),
    );
  }

// ^ STEP 5 OTHER SOURCES
  SingleChildScrollView otherSourcesBody(TaxCalculationViewModel model) {
    List<Widget> _getOtherSourceIncome(Function setState) {
      List<Widget> otherTextFields = [];
      if (model.otherIncomeController.value != null) {
        for (int i = 0; i < model.otherIncomeController.value.length; i++) {
          otherTextFields.add(Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              model.otherIncomeController.value.toString() != [].toString() ||
                      model.otherIncomeController.value.length > 0
                  ? Card(
                      elevation: 5,
                      color: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        height: screenHeight(context) / 3.5,
                        width: screenWidth(context),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Scaffold(
                          appBar: AppBar(
                            leading: Text(""),
                            title: Text(OTHER),
                            centerTitle: true,
                            flexibleSpace: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.topRight,
                                    end: Alignment.bottomLeft,
                                    colors: <Color>[
                                      AppColors.mydocumentBG_COLOR,
                                      AppColors.mydocumentBG_COLOR2
                                    ]),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20),
                                ),
                              ),
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          body: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                StreamBuilder<dynamic>(
                                    stream: model.otherIncome,
                                    builder: (context, snapshot) {
                                      return buildTextField(
                                          hint: OTHER_INCOME,
                                          label: OTHER_INCOME,
                                          numbersAllowd: <TextInputFormatter>[
                                            FilteringTextInputFormatter.allow(
                                                RegExp(r'[0-9]')),
                                          ],
                                          intialValue: model
                                              .otherIncomeController.value[i]
                                              .toString(),
                                          onChanged: (value) {
                                            if (value.toString().isEmpty) {
                                              model.otherIncomeController
                                                  .value[i] = 0;
                                              model.onEmployerOtherChange;
                                              model.calculateOtherSources();
                                            } else {
                                              model.otherIncomeController
                                                      .value[i] =
                                                  double.parse(value).round();
                                              model.onEmployerOtherChange;
                                              model.calculateOtherSources();
                                            }
                                          });
                                    }),
                                IconButton(
                                  icon: Icon(Icons.delete),
                                  onPressed: () {
                                    print(i);
                                    setState(() {
                                      model.otherIncomeController.value
                                          .removeAt(i);
                                    });
                                    setState(() {});
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                  : Container(
                      child: Text(
                      'hiii',
                    ))
            ],
          ));
        }
      }
      return otherTextFields;
    }

    return SingleChildScrollView(
      child: StatefulBuilder(
        builder: (context, setState) {
          return Container(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  StreamBuilder<dynamic>(
                      stream: model.interestFromBank,
                      builder: (context, snapshot) {
                        return buildTextField(
                            hint: INTEREST_FROM_BANK_DEPOSITS,
                            label: INTEREST_FROM_BANK_DEPOSITS,
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            intialValue: model
                                .interestFromBankDepositController.value
                                .toString(),
                            onChanged: (value) {
                              if (value.isEmpty) {
                                model.onInterestFromBankChanged(0);
                                model.calculateOtherSources();
                              } else {
                                model.onInterestFromBankChanged(value);
                                model.calculateOtherSources();
                              }
                            });
                      }),
                  StreamBuilder<dynamic>(
                      stream: model.interestFromSaving,
                      builder: (context, snapshot) {
                        return buildTextField(
                            hint: INTEREST_FROM_BANK_SAVINGS,
                            label: INTEREST_FROM_BANK_SAVINGS,
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            intialValue: model
                                .interestFromSavingController.value
                                .toString(),
                            onChanged: (value) {
                              if (value.isEmpty) {
                                model.onInterestFromSavingChanged(0);
                                model.calculateOtherSources();
                              } else {
                                model.onInterestFromSavingChanged(value);
                                model.calculateOtherSources();
                              }
                            });
                      }),
                  StreamBuilder<dynamic>(
                      stream: model.interestTaxIncome,
                      builder: (context, snapshot) {
                        return buildTextField(
                            hint: INTEREST_FROM_INCOME_TAX_REFUND,
                            label: INTEREST_FROM_INCOME_TAX_REFUND,
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            intialValue: model.interestTaxIncomeController.value
                                .toString(),
                            onChanged: (value) {
                              if (value.isEmpty) {
                                model.onInterestTaxIncomeChanged(0);
                                model.calculateOtherSources();
                              } else {
                                model.onInterestTaxIncomeChanged(value);
                                model.calculateOtherSources();
                              }
                            });
                      }),
                  Text("Family pension"),
                  StreamBuilder<dynamic>(
                      stream: model.pensionReceived,
                      builder: (context, snapshot) {
                        return buildTextField(
                            hint: PENSION_RECEIVED,
                            label: PENSION_RECEIVED,
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            intialValue: model.pensionReceivedController.value
                                .toString(),
                            onChanged: (value) {
                              if (value.isEmpty) {
                                model.onPensionReceivedChanged(0);
                                model.calculateOtherSources();
                              } else {
                                model
                                    .onPensionReceivedChanged(int.parse(value));
                                model.calculateOtherSources();
                              }
                            });
                      }),
                  StreamBuilder<dynamic>(
                      stream: model.otherSourceDeduction57,
                      builder: (context, snapshot) {
                        return buildTextField(
                            hint: DEDUCTION_57,
                            label: DEDUCTION_57,
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            intialValue: model
                                .otherSourceDeduction57Controller.value
                                .toString(),
                            onChanged: (value) {
                              if (value.isEmpty) {
                                model.onOtherSourceDeduction57Changed(0);
                                model.calculateOtherSources();
                              } else {
                                model.onOtherSourceDeduction57Changed(
                                    int.parse(value));
                                model.calculateOtherSources();
                              }
                            });
                      }),
                  ..._getOtherSourceIncome(setState),
                  FloatingActionButton(
                      mini: true,
                      child: Icon(Icons.add),
                      onPressed: () {
                        setState(() {
                          model.otherIncomeController.value.insert(
                              model.otherIncomeController.value.length, 0);
                          // model.calculateOther(otherList);
                          model.calculateOtherSources();
                          model.onEmployerOtherChange;
                        });
                      }),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

// ^ STEP 6 OTHER SPECIAL INCOME
  SingleChildScrollView otherSpecialIncomeBody(TaxCalculationViewModel model) {
    return SingleChildScrollView(
      child: Container(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              StreamBuilder<dynamic>(
                  stream: model.divident1506,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: DIVIDEND_1506,
                        label: DIVIDEND_1506,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.divident1506Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onDivident1506Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onDivident1506Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.divident1509,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: DIVIDEND_1509,
                        label: DIVIDEND_1509,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.divident1509Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onDivident1509Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onDivident1509Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.divident1512,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: DIVIDEND_1512,
                        label: DIVIDEND_1512,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.divident1512Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onDivident1512Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onDivident1512Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.divident1503,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: DIVIDEND_1503,
                        label: DIVIDEND_1503,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.divident1503Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onDivident1503Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onDivident1503Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.divident3103,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: DIVIDEND_3103,
                        label: DIVIDEND_3103,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.divident3103Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onDivident3103Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onDivident3103Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              Text(LOTTERY, style: Theme.of(context).textTheme.headline6),
              StreamBuilder<dynamic>(
                  stream: model.lottery1506,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_06,
                        label: F15_06,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.lottery1506Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLottery1506Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onLottery1506Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.lottery1509,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_09,
                        label: F15_09,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.lottery1509Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLottery1509Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onLottery1509Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.lottery1512,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_12,
                        label: F15_12,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.lottery1512Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLottery1512Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onLottery1512Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.lottery1503,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F15_03,
                        label: F15_03,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.lottery1503Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLottery1503Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onLottery1503Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.lottery3103,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: F31_3,
                        label: F31_3,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.lottery3103Controller.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onLottery3103Changed(0);
                            model.calculateOtherSpecialIncome();
                          } else {
                            model.onLottery3103Changed(value);
                            model.calculateOtherSpecialIncome();
                          }
                        });
                  }),
              GradientContainerWidget(
                title: OTHER_SPECIAL_INCOME,
                model: model.totalDivident,
              ),
            ],
          ),
        ),
      ),
    );
  }

// ^ STEP 7 LOSS B/F
  SingleChildScrollView loofBfBody(TaxCalculationViewModel model) {
    return SingleChildScrollView(
      child: Container(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              StreamBuilder<dynamic>(
                  stream: model.lossbfAdjusted,
                  builder: (context, snapshot) {
                    return StreamBuilder<String>(
                        stream: model.lossbfAdjusted,
                        builder: (context, snapshot) {
                          return buildTextField(
                            hint: LOSS_BF_AND_ADJUSTED,
                            label: LOSS_BF_AND_ADJUSTED,
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            intialValue: model.lossBfAdjustedController.value,
                            onChanged: (value) {
                              if (value.isEmpty) {
                                model.onLossBfAdjustedChanged("0");
                                model.calculateLossBfAdjusted();
                              } else {
                                model.onLossBfAdjustedChanged("-" + value);
                                model.calculateLossBfAdjusted();
                              }
                            },
                          );
                        });
                  }),
            ],
          ),
        ),
      ),
    );
  }

// ^ STEP 8 DEDUCTIONS
  SingleChildScrollView deductionsBody(TaxCalculationViewModel model) {
    List<Widget> _certain100Dynamic(Function setState) {
      List<Widget> certain100Fields = [];
      if (model.certain100doneeNameController.value != null) {
        for (int i = 0;
            i < model.certain100doneeNameController.value.length;
            i++) {
          certain100Fields.add(Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              model.certain100doneeNameController.value.toString() !=
                          [].toString() ||
                      model.certain100doneeNameController.value.length > 0
                  ? Card(
                      elevation: 5,
                      color: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        height: screenHeight(context) / 3.5,
                        width: screenWidth(context),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Scaffold(
                          appBar: AppBar(
                            leading: Text(""),
                            title: Text(
                              "Donations to Certain Funds 100",
                              style: TextStyle(fontSize: 14),
                            ),
                            centerTitle: true,
                            flexibleSpace: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.topRight,
                                    end: Alignment.bottomLeft,
                                    colors: <Color>[
                                      AppColors.mydocumentBG_COLOR,
                                      AppColors.mydocumentBG_COLOR2
                                    ]),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20),
                                ),
                              ),
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            actions: [
                              IconButton(
                                icon: Icon(Icons.delete),
                                onPressed: () {
                                  print(i);
                                  setState(() {
                                    model.certain100doneeNameController.value
                                        .removeAt(i);
                                    model.certain100AddressController.value
                                        .removeAt(i);
                                    model.certain100CityController.value
                                        .removeAt(i);
                                    model.certain100StateController.value
                                        .removeAt(i);
                                    model.certain100PincodeController.value
                                        .removeAt(i);
                                    model.certain100doneePanController.value
                                        .removeAt(i);
                                    model.certain100donationCashController.value
                                        .removeAt(i);
                                    model
                                        .certain100donationOtherController.value
                                        .removeAt(i);
                                  });
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                          body: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  StreamBuilder<dynamic>(
                                      stream: model.certain100doneeName,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee Name",
                                            label: "Donee Name",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain100doneeNameController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain100doneeNameController
                                                    .value[i] = "";
                                                model
                                                    .onCertain100doneeNameChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain100doneeNameController
                                                    .value[i] = value;
                                                model
                                                    .onCertain100doneeNameChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain100Address,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee Address",
                                            label: "Donee Address",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain100AddressController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain100AddressController
                                                    .value[i] = "";
                                                model
                                                    .onCertain100AddressChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain100AddressController
                                                    .value[i] = value;
                                                model
                                                    .onCertain100AddressChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain100City,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee City",
                                            label: "Donee City",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain100CityController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model.certain100CityController
                                                    .value[i] = "";
                                                model.onCertain100CityChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model.certain100CityController
                                                    .value[i] = value;
                                                model.onCertain100CityChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 1),
                                    child: DropdownButtonFormField(
                                      isExpanded: true,
                                      value: model
                                          .certain100StateController.value[i],
                                      items: states.map((value) {
                                        return new DropdownMenuItem<String>(
                                          value: value,
                                          child: new Text(value,
                                              overflow: TextOverflow.ellipsis),
                                        );
                                      }).toList(),
                                      hint: Text("Please choose a State"),
                                      onChanged: (value) {
                                        model.onCertain100StateChanged(value);
                                        model.calculateDeduction();
                                      },
                                    ),
                                  ),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain100Pincode,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Pincode",
                                            label: "Pincode",
                                            intialValue: model
                                                .certain100PincodeController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            maxLength: 6,
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain100PincodeController
                                                    .value[i] = 0;
                                                model
                                                    .onCertain100PincodeChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain100PincodeController
                                                    .value[i] = int.parse(value);
                                                model
                                                    .onCertain100PincodeChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain100doneePan,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee PAN",
                                            label: "Donee PAN",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain100doneePanController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9,A-Z]')),
                                            ],
                                            maxLength: 10,
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain100doneePanController
                                                    .value[i] = "";
                                                model
                                                    .onCertain100doneePanChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain100doneePanController
                                                    .value[i] = value;
                                                model
                                                    .onCertain100doneePanChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain100donationCash,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donation Cash",
                                            label: "Donation Cash",
                                            intialValue: model
                                                .certain100donationCashController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain100donationCashController
                                                    .value[i] = "";
                                                model
                                                    .onCertain100donationCashChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain100donationCashController
                                                    .value[i] = value;
                                                model
                                                    .onCertain100donationCashChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain100donationOther,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donation in Other Mode",
                                            label: "Donation in Other Mode",
                                            intialValue: model
                                                .certain100donationOtherController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain100donationOtherController
                                                    .value[i] = "";
                                                model
                                                    .onCertain100donationOtherChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain100donationOtherController
                                                    .value[i] = value;
                                                model
                                                    .onCertain100donationOtherChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    )
                  : Container(
                      child: Text(
                      'hiii',
                    ))
            ],
          ));
        }
      }
      return certain100Fields;
    }

    List<Widget> _certain50Dynamic(Function setState) {
      List<Widget> certain50Fields = [];
      if (model.certain50doneeNameController.value != null) {
        for (int i = 0;
            i < model.certain50doneeNameController.value.length;
            i++) {
          certain50Fields.add(Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              model.certain50doneeNameController.value.toString() !=
                          [].toString() ||
                      model.certain50doneeNameController.value.length > 0
                  ? Card(
                      elevation: 5,
                      color: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        height: screenHeight(context) / 3.5,
                        width: screenWidth(context),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Scaffold(
                          appBar: AppBar(
                            leading: Text(""),
                            title: Text(
                              "Donations to Certain Funds 50",
                              style: TextStyle(fontSize: 14),
                            ),
                            centerTitle: true,
                            flexibleSpace: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.topRight,
                                    end: Alignment.bottomLeft,
                                    colors: <Color>[
                                      AppColors.mydocumentBG_COLOR,
                                      AppColors.mydocumentBG_COLOR2
                                    ]),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20),
                                ),
                              ),
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            actions: [
                              IconButton(
                                icon: Icon(Icons.delete),
                                onPressed: () {
                                  print(i);
                                  setState(() {
                                    model.certain50doneeNameController.value
                                        .removeAt(i);
                                    model.certain50AddressController.value
                                        .removeAt(i);
                                    model.certain50CityController.value
                                        .removeAt(i);
                                    model.certain50StateController.value
                                        .removeAt(i);
                                    model.certain50PincodeController.value
                                        .removeAt(i);
                                    model.certain50doneePanController.value
                                        .removeAt(i);
                                    model.certain50donationCashController.value
                                        .removeAt(i);
                                    model.certain50donationOtherController.value
                                        .removeAt(i);
                                  });
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                          body: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  StreamBuilder<dynamic>(
                                      stream: model.certain50doneeName,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee Name",
                                            label: "Donee Name",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain50doneeNameController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain50doneeNameController
                                                    .value[i] = "";
                                                model
                                                    .onCertain50doneeNameChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain50doneeNameController
                                                    .value[i] = value;
                                                model
                                                    .onCertain50doneeNameChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain50Address,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee Address",
                                            label: "Donee Address",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain50AddressController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model.certain50AddressController
                                                    .value[i] = "";
                                                model.onCertain50AddressChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model.certain50AddressController
                                                    .value[i] = value;
                                                model.onCertain50AddressChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain50City,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee City",
                                            label: "Donee City",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain50CityController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model.certain50CityController
                                                    .value[i] = "";
                                                model.onCertain50CityChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model.certain50CityController
                                                    .value[i] = value;
                                                model.onCertain50CityChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 1),
                                    child: DropdownButtonFormField(
                                      isExpanded: true,
                                      value: model
                                          .certain50StateController.value[i],
                                      items: states.map((value) {
                                        return new DropdownMenuItem<String>(
                                          value: value,
                                          child: new Text(value,
                                              overflow: TextOverflow.ellipsis),
                                        );
                                      }).toList(),
                                      hint: Text("Please choose a State"),
                                      onChanged: (value) {
                                        model.onCertain50StateChanged(value);
                                        model.calculateDeduction();
                                      },
                                    ),
                                  ),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain50Pincode,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Pincode",
                                            label: "Pincode",
                                            intialValue: model
                                                .certain50PincodeController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            maxLength: 6,
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model.certain50PincodeController
                                                    .value[i] = 0;
                                                model.onCertain50PincodeChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model.certain50PincodeController
                                                        .value[i] =
                                                    int.parse(value);
                                                model.onCertain50PincodeChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain50doneePan,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee PAN",
                                            label: "Donee PAN",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .certain50doneePanController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9, A-Z]')),
                                            ],
                                            maxLength: 10,
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain50doneePanController
                                                    .value[i] = "";
                                                model
                                                    .onCertain50doneePanChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain50doneePanController
                                                    .value[i] = value;
                                                model
                                                    .onCertain50doneePanChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain50donationCash,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donation Cash",
                                            label: "Donation Cash",
                                            intialValue: model
                                                .certain50donationCashController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain50donationCashController
                                                    .value[i] = 0;
                                                model
                                                    .onCertain50donationCashChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model.certain50donationCashController
                                                        .value[i] =
                                                    double.parse(value);
                                                model
                                                    .onCertain50donationCashChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.certain50donationOther,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donation in Other Mode",
                                            label: "Donation in Other Mode",
                                            intialValue: model
                                                .certain50donationOtherController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .certain50donationOtherController
                                                    .value[i] = "";
                                                model
                                                    .onCertain50donationOtherChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .certain50donationOtherController
                                                    .value[i] = value;
                                                model
                                                    .onCertain50donationOtherChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    )
                  : Container(
                      child: Text(
                      'hiii',
                    ))
            ],
          ));
        }
      }
      return certain50Fields;
    }

    List<Widget> _scientificDynamic(Function setState) {
      List<Widget> scientificFields = [];
      if (model.scientificdoneeNameController.value != null) {
        for (int i = 0;
            i < model.scientificdoneeNameController.value.length;
            i++) {
          scientificFields.add(Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              model.scientificdoneeNameController.value.toString() !=
                          [].toString() ||
                      model.scientificdoneeNameController.value.length > 0
                  ? Card(
                      elevation: 5,
                      color: Colors.green,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        height: screenHeight(context) / 3.5,
                        width: screenWidth(context),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Scaffold(
                          appBar: AppBar(
                            leading: Text(""),
                            title: Text("Scientific Donation"),
                            centerTitle: true,
                            flexibleSpace: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                    begin: Alignment.topRight,
                                    end: Alignment.bottomLeft,
                                    colors: <Color>[
                                      AppColors.mydocumentBG_COLOR,
                                      AppColors.mydocumentBG_COLOR2
                                    ]),
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20),
                                ),
                              ),
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            actions: [
                              IconButton(
                                icon: Icon(Icons.delete),
                                onPressed: () {
                                  print(i);
                                  setState(() {
                                    model.scientificdoneeNameController.value
                                        .removeAt(i);
                                    model.scientificAddressController.value
                                        .removeAt(i);
                                    model.scientificCityController.value
                                        .removeAt(i);
                                    model.scientificStateController.value
                                        .removeAt(i);
                                    model.scientificPincodeController.value
                                        .removeAt(i);
                                    model.scientificdoneePanController.value
                                        .removeAt(i);
                                    model.scientificdonationCashController.value
                                        .removeAt(i);
                                    model
                                        .scientificdonationOtherController.value
                                        .removeAt(i);
                                    model.scientificDateController.value
                                        .removeAt(i);
                                  });
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                          body: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  StreamBuilder<dynamic>(
                                      stream: model.scientificdoneeName,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee Name",
                                            label: "Donee Name",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .scientificdoneeNameController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .scientificdoneeNameController
                                                    .value[i] = "";
                                                model
                                                    .onScientificdoneeNameChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .scientificdoneeNameController
                                                    .value[i] = value;
                                                model
                                                    .onScientificdoneeNameChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.scientificAddress,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee Address",
                                            label: "Donee Address",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .scientificAddressController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .scientificAddressController
                                                    .value[i] = "";
                                                model
                                                    .onScientificAddressChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .scientificAddressController
                                                    .value[i] = value;
                                                model
                                                    .onScientificAddressChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.scientificCity,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee City",
                                            label: "Donee City",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .scientificCityController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[a-z,A-Z,  ,]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model.scientificCityController
                                                    .value[i] = "";
                                                model.onScientificCityChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model.scientificCityController
                                                    .value[i] = value;
                                                model.onScientificCityChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 1),
                                    child: DropdownButtonFormField(
                                      isExpanded: true,
                                      value: model
                                          .scientificStateController.value[i],
                                      items: states.map((value) {
                                        return new DropdownMenuItem<String>(
                                          value: value,
                                          child: new Text(value,
                                              overflow: TextOverflow.ellipsis),
                                        );
                                      }).toList(),
                                      hint: Text("Please choose a State"),
                                      onChanged: (value) {
                                        model.onScientificStateChanged(value);
                                        model.calculateDeduction();
                                      },
                                    ),
                                  ),
                                  StreamBuilder<dynamic>(
                                      stream: model.scientificPincode,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Pincode",
                                            label: "Pincode",
                                            intialValue: model
                                                .scientificPincodeController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            maxLength: 6,
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .scientificPincodeController
                                                    .value[i] = 0;
                                                model
                                                    .onScientificPincodeChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .scientificPincodeController
                                                    .value[i] = int.parse(value);
                                                model
                                                    .onScientificPincodeChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.scientificdoneePan,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donee PAN",
                                            label: "Donee PAN",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .scientificdoneePanController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9, A-Z]')),
                                            ],
                                            maxLength: 10,
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .scientificdoneePanController
                                                    .value[i] = "";
                                                model
                                                    .onScientificdoneePanChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .scientificdoneePanController
                                                    .value[i] = value;
                                                model
                                                    .onScientificdoneePanChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  Container(
                                    height: 50,
                                    width: screenWidth(context),
                                    child: DateTimePicker(
                                      firstDate: DateTime(2020, 01, 01),
                                      lastDate: DateTime(2100),
                                      dateLabelText: 'Date',
                                      dateMask: 'dd-MMM-yyyy',
                                      controller: TextEditingController()
                                        ..text = model
                                            .scientificDateController.value[i]
                                            .toString(),
                                      onChanged: (value) {
                                        model.scientificDateController
                                                .value[i] =
                                            value.toString().substring(0, 10);
                                        model.onScientificDateChanged;
                                      },
                                    ),
                                  ),
                                  StreamBuilder<dynamic>(
                                      stream: model.scientificdonationCash,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donation Cash",
                                            label: "Donation Cash",
                                            keyBoardType: TextInputType.text,
                                            intialValue: model
                                                .scientificdonationCashController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .scientificdonationCashController
                                                    .value[i] = "";
                                                model
                                                    .onScientificdonationCashChanged;
                                                model.calculateDeduction();
                                              } else {
                                                if (double.parse(value) >
                                                    10000) {
                                                  model
                                                      .scientificdonationCashController
                                                      .value[i] = "10000";
                                                }
                                                model
                                                    .onScientificdonationCashChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                  StreamBuilder<dynamic>(
                                      stream: model.scientificdonationOther,
                                      builder: (context, snapshot) {
                                        return buildTextField(
                                            hint: "Donation in Other Mode",
                                            label: "Donation in Other Mode",
                                            intialValue: model
                                                .scientificdonationOtherController
                                                .value[i]
                                                .toString(),
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .scientificdonationOtherController
                                                    .value[i] = "";
                                                model
                                                    .onScientificdonationOtherChanged;
                                                model.calculateDeduction();
                                              } else {
                                                model
                                                    .scientificdonationOtherController
                                                    .value[i] = value;
                                                model
                                                    .onScientificdonationOtherChanged;
                                                model.calculateDeduction();
                                              }
                                            });
                                      }),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    )
                  : Container(
                      child: Text(
                      'hiii',
                    ))
            ],
          ));
        }
      }
      return scientificFields;
    }

    return SingleChildScrollView(child: StatefulBuilder(
      builder: (context, setState) {
        return Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        LIC,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.lic,
                        builder: (context, snapshot) {
                          print("------model.lic---------");
                          print(snapshot.data);
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue:
                                  model.licDeductionController.value.toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onLicChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  setState(() {
                                    model.onLicChanged(value);
                                    model.calculateDeduction();
                                  });
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.licLimit,
                        builder: (context, snapshot) {
                          print("------model.licLimit---------");
                          print(snapshot.data);
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onLicChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onLicChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        PF,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.pf,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue:
                                  model.pfDeductionController.value.toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onPfChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onPfChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.pf,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue:
                              //     model.pfDeductionController.value.toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onPfChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onPfChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        HL,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.hl,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue:
                                  model.hlDeductionController.value.toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onHlChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onHlChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.hl,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue:
                              //     model.hlDeductionController.value.toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onHlChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onHlChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        PUBLIC_PF,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.publicPf,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .publicPfDeductionController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onPublicPfChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onPublicPfChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.publicPf,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model
                              //     .publicPfDeductionController.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onPublicPfChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onPublicPfChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        NSC_ACCURED_INTEREST,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                      width: screenWidth(context) / 3,
                      child: StreamBuilder<dynamic>(
                          stream: model.nscInterest,
                          builder: (context, snapshot) {
                            return buildTextField(
                                hint: ACTUAL_AMT_TITLE,
                                label: ACTUAL_AMT_TITLE,
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                intialValue: model
                                    .nscInterestDeductionController.value
                                    .toString(),
                                onChanged: (value) {
                                  if (value.isEmpty) {
                                    model.onNscInterestChanged(0);
                                    model.calculateDeduction();
                                  } else {
                                    model.onNscInterestChanged(value);
                                    model.calculateDeduction();
                                  }
                                });
                          })),
                  Container(
                      width: screenWidth(context) / 3,
                      child: StreamBuilder<dynamic>(
                          stream: model.nscInterest,
                          builder: (context, snapshot) {
                            return buildTextField(
                                enabled: false,
                                hint: snapshot.data.toString(),
                                label: snapshot.data.toString(),
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                // intialValue: model
                                //     .nscInterestDeductionController.value
                                //     .toString(),
                                onChanged: (value) {
                                  if (value.isEmpty) {
                                    model.onNscInterestChanged(0);
                                    model.calculateDeduction();
                                  } else {
                                    model.onNscInterestChanged(value);
                                    model.calculateDeduction();
                                  }
                                });
                          })),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        NSC_NEW_DEPOSITS,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.nscDeposits,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .nscDepositsDeductionController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onNscDepositsChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onNscDepositsChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.nscDeposits,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model
                              //     .nscDepositsDeductionController.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onNscDepositsChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onNscDepositsChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        EDUCATION_EXPENSES,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.educationalExpenses,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .educationExpensesDeductionController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onEducationalExpensesChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onEducationalExpensesChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.educationalExpenses,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model
                              //     .educationExpensesDeductionController.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onEducationalExpensesChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onEducationalExpensesChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        PUBLIC_PF,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.certainFunds,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .certainFundsDeductionController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onCertainFundsChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onCertainFundsChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.certainFunds,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model
                              //     .certainFundsDeductionController.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onCertainFundsChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onCertainFundsChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        GROUP_INSURANCE,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.groupInsurance,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .groupInsuranceDeductionController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.ongroupInsuranceChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.ongroupInsuranceChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.groupInsurance,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model
                              //     .groupInsuranceDeductionController.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.ongroupInsuranceChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.ongroupInsuranceChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        MUTUAL_FUNDS,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.mutualFunds,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: ACTUAL_AMT_TITLE,
                              label: ACTUAL_AMT_TITLE,
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .mutualFundsDeductionController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onmutualFundsChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onmutualFundsChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.mutualFunds,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model
                              //     .mutualFundsDeductionController.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onmutualFundsChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onmutualFundsChanged(value);
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 5,
                ),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Container(
                    height: screenHeight(context) * 0.10,
                    width: screenWidth(context),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      leading: Text(
                        "80C",
                        style: Theme.of(context).textTheme.headline6.copyWith(
                              color: Colors.white,
                              fontFamily: 'D-DIN',
                            ),
                      ),
                      title: StreamBuilder<String>(
                          stream: model.usertotalDeductionT80c,
                          builder: (context, snapshot) {
                            return Text(
                              snapshot.data ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            );
                          }),
                      // trailing: StreamBuilder<String>(
                      //     stream: model.totalDeductionT80c,
                      //     builder: (context, snapshot) {
                      //       var item = int.parse(snapshot.data);
                      //       int total = 0;
                      //       if (item > 150000) {
                      //         total = 150000;
                      //       } else {
                      //         total = item;
                      //       }
                      //       return Text(
                      //         "Limit: " + total.toString() ?? "",
                      //         style: Theme.of(context)
                      //             .textTheme
                      //             .headline6
                      //             .copyWith(
                      //               color: Colors.white,
                      //               fontFamily: 'D-DIN',
                      //             ),
                      //       );
                      //     }),
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        "80CCC",
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccc,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "80CCC",
                              label: "80CCC",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model.deduction80cccController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80cccChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80cccChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccc,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model.deduction80ccd1Controller.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80cccChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80cccChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 5,
                ),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Container(
                    height: screenHeight(context) * 0.10,
                    width: screenWidth(context),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      leading: Text(
                        "80CCC",
                        style: Theme.of(context).textTheme.headline6.copyWith(
                              color: Colors.white,
                              fontFamily: 'D-DIN',
                            ),
                      ),
                      trailing: StreamBuilder<dynamic>(
                          stream: model.deduction80ccc,
                          builder: (context, snapshot) {
                            return Text(
                              snapshot.data.toString() ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            );
                          }),
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        "80CCD(1)",
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccd1,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "80CCD(1)",
                              label: "80CCD(1)",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model.deduction80ccd1Controller.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80ccd1Changed(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80ccd1Changed(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccd1,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model.deduction80ccd1Controller.value
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80ccd1Changed(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80ccd1Changed(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 5,
                ),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Container(
                    height: screenHeight(context) * 0.10,
                    width: screenWidth(context),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      leading: Container(
                        alignment: Alignment.centerLeft,
                        width: screenWidth(context) / 2,
                        child: Row(
                          children: [
                            Text(
                              "Total:  ",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            ),
                            StreamBuilder<dynamic>(
                                stream: model.deductionTotalof80,
                                builder: (context, snapshot) {
                                  return Text(
                                    snapshot.data.toString() ?? "",
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6
                                        .copyWith(
                                          color: Colors.white,
                                          fontFamily: 'D-DIN',
                                        ),
                                  );
                                }),
                          ],
                        ),
                      ),
                      trailing: Container(
                        alignment: Alignment.centerRight,
                        width: screenWidth(context) / 3,
                        child: Row(
                          children: [
                            Text(
                              "Limit: ",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            ),
                            Text(
                              "150000",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        "80CCD(1B)",
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccd1b,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "80CCD(1B)",
                              label: "80CCD(1B)",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .deduction80ccd1bController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80ccd1bChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80ccd1bChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccd1b,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: model
                              //     .deduction80ccd1bController.value
                              // .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80ccd1bChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80ccd1bChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 5,
                ),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Container(
                    height: screenHeight(context) * 0.10,
                    width: screenWidth(context),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      leading: Text(
                        "80CCD(1B)",
                        style: Theme.of(context).textTheme.headline6.copyWith(
                              color: Colors.white,
                              fontFamily: 'D-DIN',
                            ),
                      ),
                      trailing: StreamBuilder<dynamic>(
                          stream: model.deduction80ccd1b,
                          builder: (context, snapshot) {
                            return Text(
                              snapshot.data.toString() ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            );
                          }),
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  Container(
                      width: screenWidth(context) / 4,
                      child: Text(
                        "80CCD(2)",
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccd2,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "80CCD(2)",
                              label: "80CCD(2)",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model.deduction80ccd2Controller.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80ccd2Changed(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80ccd2Changed(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80ccd2,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString(),
                              label: snapshot.data.toString(),
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue:
                              //     model.deduction80ccd2Controller.value.toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80ccd2Changed(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80ccd2Changed(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 5,
                ),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Container(
                    height: screenHeight(context) * 0.10,
                    width: screenWidth(context),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      leading: Text(
                        "80CCD(2)",
                        style: Theme.of(context).textTheme.headline6.copyWith(
                              color: Colors.white,
                              fontFamily: 'D-DIN',
                            ),
                      ),
                      trailing: StreamBuilder<dynamic>(
                          stream: model.deduction80ccd2,
                          builder: (context, snapshot) {
                            return Text(
                              snapshot.data.toString() ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            );
                          }),
                    ),
                  ),
                ),
              ),
              Text(
                DEDUCTION_IN_MEDI_INSURANCE + " Self",
                style: Theme.of(context).textTheme.headline6,
              ),
              // Container(
              //   child: Row(
              //     mainAxisAlignment: MainAxisAlignment.start,
              //     children: [
              //       StreamBuilder<bool>(
              //           stream: model.self,
              //           builder: (context, snapshot) {
              //             return Checkbox(
              //                 tristate: true,
              //                 value: snapshot.data ?? false,
              //                 onChanged: (value) {
              //                   model.onSelfChanged(value ?? false);
              //                   model.calculateDeduction();
              //                 });
              //           }),
              //       Text(SELF + " (SR.Citizen)"),
              //     ],
              //   ),
              // ),
              StreamBuilder<dynamic>(
                  stream: model.selfMediclaim,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: "Mediclaim",
                        label: "Mediclaim",
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.selfMediclaimController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onSelfMediclaimChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onSelfMediclaimChanged(int.parse(value));
                            model.calculateDeduction();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.selfHealthchekup,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: "Preventive Health checkup",
                        label: "Preventive Health checkup",
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.selfHealthcheckupController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onSelfHealthcheckupChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onSelfHealthcheckupChanged(int.parse(value));
                            model.calculateDeduction();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.medicalInsurance,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: "Medical expenditure",
                        label: "Medical expenditure",
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.medicalInsuranceController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onMedicalInsuranceChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onMedicalInsuranceChanged(value);
                            model.calculateDeduction();
                          }
                        });
                  }),
              Text(
                DEDUCTION_IN_MEDI_INSURANCE + " Parent",
                style: Theme.of(context).textTheme.headline6,
              ),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    StreamBuilder<bool>(
                        stream: model.parent,
                        builder: (context, snapshot) {
                          return Checkbox(
                              tristate: true,
                              value: snapshot.data ?? false,
                              onChanged: (value) {
                                model.onParentChanged(value ?? false);
                                model.calculateDeduction();
                              });
                        }),
                    Text(PARENT + " (SR.Citizen)"),
                  ],
                ),
              ),
              StreamBuilder<dynamic>(
                  stream: model.parentMediclaim,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: "Mediclaim",
                        label: "Mediclaim",
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.parentMediclaimController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onParentMediclaimChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onParentMediclaimChanged(int.parse(value));
                            model.calculateDeduction();
                          }
                        });
                  }),
              StreamBuilder<dynamic>(
                stream: model.parentHealthchekup,
                builder: (context, snapshot) {
                  return buildTextField(
                      hint: "Preventive Health checkup",
                      label: "Preventive Health checkup",
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue:
                          model.parentHealthcheckupController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onParentHealthcheckupChanged(0);
                          model.calculateDeduction();
                        } else {
                          model.onParentHealthcheckupChanged(int.parse(value));
                          model.calculateDeduction();
                        }
                      });
                },
              ),
              // StreamBuilder<bool>(
              //   stream: model.parent,
              //   builder: (context, snapshot) {
              //     return snapshot.data ?? false
              //         ? StreamBuilder<dynamic>(
              //             stream: model.parentMedicalExpenditure,
              //             builder: (context, snapshot) {
              //               return buildTextField(
              //                   hint: "Medical expenditure",
              //                   label: "Medical expenditure",
              //                   numbersAllowd: <TextInputFormatter>[
              //                     FilteringTextInputFormatter.allow(
              //                         RegExp(r'[0-9]')),
              //                   ],
              //                   intialValue: model
              //                       .parentMedicalExpenditureController.value
              //                       .toString(),
              //                   onChanged: (value) {
              //                     if (value.isEmpty) {
              //                       model.onParentMedicalExpenditureChanged(0);
              //                       model.calculateDeduction();
              //                     } else {
              //                       model.onParentMedicalExpenditureChanged(
              //                           int.parse(value));
              //                       model.calculateDeduction();
              //                     }
              //                   });
              //             },
              //           )
              //         : SizedBox.shrink();
              //   },
              // ),
              StreamBuilder<dynamic>(
                  stream: model.parentMedicalInsurance,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: "Medical expenditure",
                        label: "Medical expenditure",
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue: model
                            .parentMedicalInsuranceController.value
                            .toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onParentMedicalInsuranceChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onParentMedicalInsuranceChanged(value);
                            model.calculateDeduction();
                          }
                        });
                  }),
              Row(
                children: [
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80TTA,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "80TTA",
                              label: "80TTA",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model.deduction80TTAController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80TTAChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80TTAChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80TTA,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString() ?? "",
                              label: snapshot.data.toString() ?? "",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              // intialValue: snapshot.data
                              //     .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80TTAChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80TTAChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),

              Row(
                children: [
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80TTB,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "80TTB",
                              label: "80TTB",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model.deduction80TTBController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80TTBChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80TTBChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 3,
                    child: StreamBuilder<dynamic>(
                        stream: model.deduction80TTB,
                        builder: (context, snapshot) {
                          return buildTextField(
                              enabled: false,
                              hint: snapshot.data.toString() ?? "",
                              label: snapshot.data.toString() ?? "",
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onDeduction80TTBChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onDeduction80TTBChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                ],
              ),
              Container(
                width: screenWidth(context),
                child: StreamBuilder<bool>(
                    stream: model.handicapped,
                    builder: (context, snapshot) {
                      return ListTile(
                        contentPadding: EdgeInsets.all(0),
                        leading: Checkbox(
                          // tristate: true,
                          value: snapshot.data ?? false,
                          onChanged: model.onHandicapChanged,
                        ),
                        title: Text(HANDICAP),
                      );
                    }),
              ),
              StreamBuilder<bool>(
                  stream: model.handicapped,
                  builder: (context, snapshotHandiCapped) {
                    return snapshotHandiCapped.data == true
                        ? Container(
                            width: screenWidth(context),
                            child: StreamBuilder<bool>(
                                stream: model.severe,
                                builder: (context, snapshot) {
                                  return ListTile(
                                    contentPadding: EdgeInsets.all(0),
                                    leading: Checkbox(
                                        // tristate: true,
                                        value: snapshot.data ?? false,
                                        onChanged: (value) {
                                          model.onSevereChanged(value);
                                          model.calculateDeduction();
                                        }),
                                    title: Text(SEVERE),
                                    trailing: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        snapshot.data == null
                                            ? NON_SEVERE_AMOUNT
                                            : snapshot.data
                                                ? SEVERE_AMOUNT
                                                : NON_SEVERE_AMOUNT,
                                      ),
                                    ),
                                  );
                                }),
                          )
                        : SizedBox.shrink();
                  }),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    StreamBuilder<bool>(
                        stream: model.senior80ddb,
                        builder: (context, snapshot) {
                          return Checkbox(
                              tristate: true,
                              value: snapshot.data ?? false,
                              onChanged: (value) {
                                model.onSenior80ddbChanged(value ?? false);
                                model.calculateDeduction();
                              });
                        }),
                    Text(SENIOR_CITIZEN_TITLE),
                  ],
                ),
              ),
              StreamBuilder<dynamic>(
                  stream: model.medical80ddb,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: "Medical Treatment Of Specified Disease",
                        label: "Medical Treatment Of Specified Disease",
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.medical80ddbController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onMedical80ddbChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onMedical80ddbChanged(int.parse(value));
                            model.calculateDeduction();
                          }
                        });
                  }),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    StreamBuilder<bool>(
                        stream: model.first80EE,
                        builder: (context, snapshot) {
                          return Checkbox(
                              tristate: true,
                              value: snapshot.data ?? false,
                              onChanged: (value) {
                                model.onFirst80EEChanged(value ?? false);
                                model.calculateDeduction();
                              });
                        }),
                    Text("First Time"),
                  ],
                ),
              ),
              Row(
                children: [
                  Container(
                    width: screenWidth(context) / 2.5,
                    child: StreamBuilder<dynamic>(
                        stream: model.houseProperty80EE,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "House Property- 80EE",
                              label: "House Property- 80EE",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .houseProperty80EEController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onHouseProperty80EEChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onHouseProperty80EEChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 2.5,
                    child: StreamBuilder<dynamic>(
                        stream: model.houseProperty80EE,
                        builder: (context, snapshot) {
                          return buildTextField(
                            enabled: false,
                            hint: snapshot.data.toString(),
                            label: snapshot.data.toString(),
                          );
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                    width: screenWidth(context) / 2.5,
                    child: StreamBuilder<dynamic>(
                        stream: model.houseProperty80EEA,
                        builder: (context, snapshot) {
                          print("----houseProperty80EEA---");
                          print(snapshot.data);
                          return buildTextField(
                              hint: "House Property- 80EEA",
                              label: "House Property- 80EEA",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .houseProperty80EEAController.value
                                  .toString(),
                              onChanged: (value) {
                                print("---------value");
                                print(value);
                                if (value.isEmpty) {
                                  model.onHouseProperty80EEAChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onHouseProperty80EEAChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 2.5,
                    child: StreamBuilder<dynamic>(
                        stream: model.houseProperty80EEA,
                        builder: (context, snapshot) {
                          print("-----snapshot.data--------");
                          print(snapshot.data);

                          return buildTextField(
                            enabled: false,
                            hint: snapshot.data.toString(),
                            label: snapshot.data.toString(),
                          );
                        }),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                    width: screenWidth(context) / 2.5,
                    child: StreamBuilder<dynamic>(
                        stream: model.houseProperty80EEB,
                        builder: (context, snapshot) {
                          return buildTextField(
                              hint: "electric vehicle- 80EEB",
                              label: "electric vehicle- 80EEB",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              intialValue: model
                                  .houseProperty80EEBController.value
                                  .toString(),
                              onChanged: (value) {
                                if (value.isEmpty) {
                                  model.onHouseProperty80EEBChanged(0);
                                  model.calculateDeduction();
                                } else {
                                  model.onHouseProperty80EEBChanged(
                                      int.parse(value));
                                  model.calculateDeduction();
                                }
                              });
                        }),
                  ),
                  Container(
                    width: screenWidth(context) / 2.5,
                    child: StreamBuilder<dynamic>(
                        stream: model.houseProperty80EEB,
                        builder: (context, snapshot) {
                          return buildTextField(
                            enabled: false,
                            hint: snapshot.data.toString(),
                            label: snapshot.data.toString(),
                          );
                        }),
                  ),
                ],
              ),
              StreamBuilder<dynamic>(
                  stream: model.interestForHigherEdu,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: INTREST_HIGHER_EDU_LOAN,
                        label: INTREST_HIGHER_EDU_LOAN,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue: model.interestForHigherEduController.value
                            .toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onInterestForHigherEduChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onInterestForHigherEduChanged(value);
                            model.calculateDeduction();
                          }
                        });
                  }),
              StreamBuilder(
                  stream: model.employerHRA,
                  builder: (context, snapshot) {
                    return model.employerhra == 0 ||
                            model.employerhra == 0.00 ||
                            model.employerhra == ""
                        ? SizedBox.shrink()
                        : StreamBuilder<dynamic>(
                            stream: model.rentPaid,
                            builder: (context, snapshot) {
                              return buildTextField(
                                  hint: RENT_PAID,
                                  label: RENT_PAID,
                                  numbersAllowd: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[0-9]')),
                                  ],
                                  intialValue:
                                      model.rentPaidController.value.toString(),
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onRentpaidChanged("0");
                                      model.calculateDeduction();
                                    } else {
                                      model.onRentpaidChanged(value);
                                      model.calculateDeduction();
                                    }
                                  });
                            });
                  }),
              Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        StreamBuilder<bool>(
                            stream: model.withoutLimit,
                            builder: (context, snapshot) {
                              return Checkbox(
                                  tristate: true,
                                  value: snapshot.data ?? false,
                                  onChanged: (value) {
                                    setState(() {
                                      model.onWithoutLimitChanged(
                                          value ?? false);
                                      model.calculateDeduction();
                                    });
                                  });
                            }),
                        Text("With Limit"),
                      ],
                    ),
                    model.withoutLimitController.value
                        ? Container(
                            margin: EdgeInsets.only(left: 15),
                            child: Text(
                                "Limit is ${model.donationLimit.toStringAsFixed(0)}"),
                          )
                        : SizedBox.shrink(),
                  ],
                ),
              ),
              ..._certain100Dynamic(setState),
              FloatingActionButton(
                  mini: true,
                  child: Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      model.certain100doneeNameController.value.insert(
                          model.certain100doneeNameController.value.length, "");
                      model.certain100AddressController.value.insert(
                          model.certain100AddressController.value.length, "");
                      model.certain100CityController.value.insert(
                          model.certain100CityController.value.length, "");
                      model.certain100StateController.value.insert(
                          model.certain100StateController.value.length,
                          "Maharashtra");
                      model.certain100PincodeController.value.insert(
                          model.certain100PincodeController.value.length, 0);
                      model.certain100doneePanController.value.insert(
                          model.certain100doneePanController.value.length, "");
                      model.certain100donationCashController.value.insert(
                          model.certain100donationCashController.value.length,
                          "");
                      model.certain100donationOtherController.value.insert(
                          model.certain100donationOtherController.value.length,
                          "");
                      model.certain100TotalController.close();

                      model.calculateDeduction();
                    });
                  }),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 5,
                ),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Container(
                    height: screenHeight(context) * 0.10,
                    width: screenWidth(context),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      leading: Text(
                        "Donation 100 %",
                        style: Theme.of(context).textTheme.headline6.copyWith(
                              color: Colors.white,
                              fontFamily: 'D-DIN',
                            ),
                      ),
                      trailing: StreamBuilder<dynamic>(
                          stream: model.donation100,
                          builder: (context, snapshot) {
                            return Text(
                              snapshot.data.toString() ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            );
                          }),
                    ),
                  ),
                ),
              ),
              ..._certain50Dynamic(setState),
              FloatingActionButton(
                  mini: true,
                  child: Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      model.certain50doneeNameController.value.insert(
                          model.certain50doneeNameController.value.length, "");
                      model.certain50AddressController.value.insert(
                          model.certain50AddressController.value.length, "");
                      model.certain50CityController.value.insert(
                          model.certain50CityController.value.length, "");
                      model.certain50StateController.value.insert(
                          model.certain50StateController.value.length,
                          "Maharashtra");
                      model.certain50PincodeController.value.insert(
                          model.certain50PincodeController.value.length, 0);
                      model.certain50doneePanController.value.insert(
                          model.certain50doneePanController.value.length, "");
                      model.certain50donationCashController.value.insert(
                          model.certain50donationCashController.value.length,
                          "");
                      model.certain50donationOtherController.value.insert(
                          model.certain50donationOtherController.value.length,
                          "");
                      model.calculateDeduction();
                    });
                  }),
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8.0,
                  vertical: 5,
                ),
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Container(
                    height: screenHeight(context) * 0.10,
                    width: screenWidth(context),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.all(
                        Radius.circular(20),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: ListTile(
                      leading: Text(
                        "Donation 50 %",
                        style: Theme.of(context).textTheme.headline6.copyWith(
                              color: Colors.white,
                              fontFamily: 'D-DIN',
                            ),
                      ),
                      trailing: StreamBuilder<dynamic>(
                          stream: model.donation50,
                          builder: (context, snapshot) {
                            return Text(
                              snapshot.data.toString() ?? "",
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                    color: Colors.white,
                                    fontFamily: 'D-DIN',
                                  ),
                            );
                          }),
                    ),
                  ),
                ),
              ),
              ..._scientificDynamic(setState),
              FloatingActionButton(
                  mini: true,
                  child: Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      model.scientificdoneeNameController.value.insert(
                          model.scientificdoneeNameController.value.length, "");
                      model.scientificAddressController.value.insert(
                          model.scientificAddressController.value.length, "");
                      model.scientificCityController.value.insert(
                          model.scientificCityController.value.length, "");
                      model.scientificStateController.value.insert(
                          model.scientificStateController.value.length,
                          "Maharashtra");
                      model.scientificPincodeController.value.insert(
                          model.scientificPincodeController.value.length, 0);
                      model.scientificdoneePanController.value.insert(
                          model.scientificdoneePanController.value.length, "");
                      model.scientificdonationCashController.value.insert(
                          model.scientificdonationCashController.value.length,
                          "");
                      model.scientificdonationOtherController.value.insert(
                          model.scientificdonationOtherController.value.length,
                          "");
                      model.scientificDateController.value.insert(
                          model.scientificDateController.value.length, "");
                      model.calculateDeduction();
                    });
                  }),
              StreamBuilder<dynamic>(
                  stream: model.political80GGC,
                  builder: (context, snapshot) {
                    return buildTextField(
                        hint: "Political Party",
                        label: "Political Party",
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                        ],
                        intialValue:
                            model.political80GGCController.value.toString(),
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onPolitical80GGCChanged(0);
                            model.calculateDeduction();
                          } else {
                            model.onPolitical80GGCChanged(int.parse(value));
                            model.calculateDeduction();
                          }
                        });
                  }),
            ],
          ),
        );
      },
    ));
  }

// ^ STEP 9 EXEMPT INCOME
  SingleChildScrollView exemptIncomeBody(TaxCalculationViewModel model) {
    return SingleChildScrollView(
      child: Container(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              StreamBuilder<dynamic>(
                  stream: model.exemptIncome,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: INCOME_CLAIMED_EXEMPT,
                      label: INCOME_CLAIMED_EXEMPT,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.exemptIncomeController.value,
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onExemptIncomeChanged("0");
                          model.calculateExemptIncome();
                        } else {
                          model.onExemptIncomeChanged(value);
                          model.calculateExemptIncome();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.exemptIncomeDescription,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: "Description",
                      label: "Description",
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z,A-Z,  ,]')),
                      ],
                      maxLength: 75,
                      intialValue:
                          model.exemptIncomeDescriptionController.value,
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onExemptIncomeDescriptionChanged("0");
                          model.calculateExemptIncome();
                        } else {
                          model.onExemptIncomeDescriptionChanged(value);
                          model.calculateExemptIncome();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.insurancePolicy1010d,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: "Insurance Policy",
                      label: "Insurance Policy",
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.insurancePolicy1010dController.value,
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onInsurancePolicy1010dChanged("0");
                          model.calculateExemptIncome();
                        } else {
                          model.onInsurancePolicy1010dChanged(value);
                          model.calculateExemptIncome();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.statutoryPF,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: "Statutory PF",
                      label: "Statutory PF",
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.statutoryPFController.value,
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onStatutoryPFChanged("0");
                          model.calculateExemptIncome();
                        } else {
                          model.onStatutoryPFChanged(value);
                          model.calculateExemptIncome();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.recognisedPF,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: "Recognised PF",
                      label: "Recognised PF",
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.recognisedPFController.value,
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onRecognisedPFChanged("0");
                          model.calculateExemptIncome();
                        } else {
                          model.onRecognisedPFChanged(value);
                          model.calculateExemptIncome();
                        }
                      },
                    );
                  }),
              StreamBuilder<dynamic>(
                  stream: model.exemptDividend,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: "Exempt dividend",
                      label: "Exempt dividend",
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.exemptDividendController.value,
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onExemptDividendChanged("0");
                          model.calculateExemptIncome();
                        } else {
                          model.onExemptDividendChanged(value);
                          model.calculateExemptIncome();
                        }
                      },
                    );
                  }),
            ],
          ),
        ),
      ),
    );
  }

// ^ STEP 10 AGRO INCOME
  SingleChildScrollView agroBody(TaxCalculationViewModel model) {
    return SingleChildScrollView(
      child: Container(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: StreamBuilder<dynamic>(
              stream: model.agroIncome,
              builder: (context, snapshot) {
                return buildTextField(
                  hint: AGRICULTURE_INCOME,
                  label: AGRICULTURE_INCOME,
                  numbersAllowd: <TextInputFormatter>[
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                  ],
                  intialValue: model.agroIncomeController.value,
                  onChanged: (value) {
                    if (value.isEmpty) {
                      model.onAgroIncomeChanged("0");
                      model.calculateAgro();
                    } else {
                      model.onAgroIncomeChanged(value);
                      model.calculateAgro();
                    }
                  },
                );
              }),
        ),
      ),
    );
  }

  Padding buildTextField(
      {bool enabled,
      String hint,
      String label,
      Function(dynamic p1) onChanged,
      TextInputType keyBoardType,
      List<TextInputFormatter> numbersAllowd,
      TextCapitalization textCapitalization,
      int maxLength,
      TextEditingController textEditingController,
      String intialValue}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        controller: textEditingController,
        enabled: enabled,
        keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
        inputFormatters: numbersAllowd,
        textCapitalization: textCapitalization ?? TextCapitalization.none,
        maxLength: maxLength,
        decoration: InputDecoration(
          hintText: hint,
          labelText: label,
        ),
        // controller: controller ?? TextEditingController(),
        onChanged: onChanged,
        initialValue: intialValue ?? "",
      ),
    );
  }

  Padding buildStep(
      {IconData leadingIcon,
      String title,
      Stream<String> value,
      Function onPressed,
      bool isInputField}) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 8.0,
        vertical: 5,
      ),
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(20),
          ),
        ),
        child: Container(
          height: screenHeight(context) * 0.10,
          width: screenWidth(context),
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: <Color>[
                  AppColors.mydocumentBG_COLOR,
                  AppColors.mydocumentBG_COLOR2
                ]),
            borderRadius: BorderRadius.all(
              Radius.circular(20),
            ),
          ),
          alignment: Alignment.center,
          child: ListTile(
              leading: Icon(
                leadingIcon,
                color: Colors.white,
                size: Sizes.ICON_SIZE_32,
              ),
              title: Text(
                title,
                style: Theme.of(context).textTheme.headline6.copyWith(
                      color: Colors.white,
                      fontFamily: 'D-DIN',
                    ),
              ),
              subtitle: StreamBuilder<String>(
                  stream: value,
                  builder: (context, snapshot) {
                    return Text(
                      snapshot.data ?? "",
                      style: Theme.of(context).textTheme.subtitle1.copyWith(
                            color: Colors.white70,
                            fontFamily: 'D-DIN',
                          ),
                    );
                  }),
              trailing: isInputField
                  ? IconButton(
                      icon: Icon(
                        Icons.arrow_forward_ios,
                        color: Colors.white70,
                      ),
                      onPressed: onPressed,
                    )
                  : SizedBox.shrink()),
        ),
      ),
    );
  }
}
