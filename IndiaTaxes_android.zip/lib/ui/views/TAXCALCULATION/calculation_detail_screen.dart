


import 'package:flutter/material.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';


class CalculationDetailScreen extends StatefulWidget {

  final  Widget child;


  const CalculationDetailScreen({Key key, this.child}) : super(key: key);
  @override
  _CalculationDetailScreenState createState() => _CalculationDetailScreenState();
}

class _CalculationDetailScreenState extends State<CalculationDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return  Container(
        height: screenHeight(context),
        width: screenWidth(context),
        child: widget.child,
      );
  }
}