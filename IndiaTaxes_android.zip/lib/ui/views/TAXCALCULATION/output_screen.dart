import 'package:flutter/material.dart';
import 'package:flutter_json_widget/flutter_json_widget.dart';
import 'package:scroll_to_index/scroll_to_index.dart';
import 'package:taxbase_general/constants/custom_icon_icons.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
import 'package:taxbase_general/ui/views/TAXCALCULATION/pdf_view.dart';
import 'package:taxbase_general/values/values.dart';

class OutputScreen extends StatefulWidget {
  final TaxCalculationViewModel model;

  const OutputScreen({Key key, this.model}) : super(key: key);

  @override
  _OutputScreenState createState() => _OutputScreenState();
}

class _OutputScreenState extends State<OutputScreen> {
  final scrollDirection = Axis.vertical;
  int _selectedIndex = 0;
  int counter = -1;

  AutoScrollController controller;

  @override
  void initState() {
    super.initState();
    controller = AutoScrollController(
        viewportBoundaryGetter: () =>
            Rect.fromLTRB(0, 0, 0, MediaQuery.of(context).padding.bottom),
        axis: scrollDirection);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(OUTPUT_TITLE),
        actions: [
          InkWell(
            onTap: () {
              widget.model.generateJson(context);
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(Icons.done, color: Colors.white),
            ),
          )
        ],
      ),
      drawer: Container(
        width: screenWidth(context) * .3,
        child: Drawer(
          child: Container(
            margin: EdgeInsets.only(top: screenHeight(context) * .05),
            width: 10,
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: 20),
                child: IntrinsicHeight(
                  child: NavigationRail(
                    backgroundColor: Theme.of(context).scaffoldBackgroundColor,
                    selectedIndex: _selectedIndex,
                    onDestinationSelected: (int index) {
                      setState(() {
                        _selectedIndex = index;
                        print(_selectedIndex);
                        if (_selectedIndex == 0) {
                          controller.scrollToIndex(0,
                              preferPosition: AutoScrollPosition.begin);
                          controller.highlight(0);
                        } else if (_selectedIndex == 1) {
                          controller.scrollToIndex(8,
                              preferPosition: AutoScrollPosition.begin);
                          controller.highlight(8);
                        } else if (_selectedIndex == 2) {
                          controller.scrollToIndex(12,
                              preferPosition: AutoScrollPosition.begin);
                          controller.highlight(12);
                        } else if (_selectedIndex == 3) {
                          controller.scrollToIndex(26,
                              preferPosition: AutoScrollPosition.begin);
                          controller.highlight(26);
                        }
                      });
                      Navigator.pop(context);
                      setState(() {});
                    },
                    labelType: NavigationRailLabelType.selected,
                    destinations: [
                      NavigationRailDestination(
                        icon: Icon(CustomIcon.wallet__1_),
                        selectedIcon: Icon(
                          CustomIcon.wallet__1_,
                          color: Theme.of(context).primaryColor,
                        ),
                        label: Text(SALARY),
                      ),
                      NavigationRailDestination(
                        icon: Icon(
                          CustomIcon.tax,
                        ),
                        selectedIcon: Icon(
                          CustomIcon.tax,
                          color: Theme.of(context).primaryColor,
                        ),
                        label: Text(DEDUCTIONS),
                      ),
                      NavigationRailDestination(
                        icon: Icon(CustomIcon.receipt),
                        selectedIcon: Icon(
                          CustomIcon.receipt,
                          color: Theme.of(context).primaryColor,
                        ),
                        label: Text(TAX_ON_NORMAL_INCOME),
                      ),
                      NavigationRailDestination(
                        icon: Icon(CustomIcon.bf7a66e6bd374ef0a70334fab04a2647),
                        selectedIcon: Icon(
                          CustomIcon.bf7a66e6bd374ef0a70334fab04a2647,
                          color: Theme.of(context).primaryColor,
                        ),
                        label: Text(FILING_DATE),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
      body: Container(
        height: screenHeight(context),
        width: screenWidth(context),
        child: Column(
          children: [
            headerCard(),
            Container(
              height: screenHeight(context) * .65,
              child: ListView(
                controller: controller,
                children: [
                  outputCard(
                    index: 0,
                    leadingIcon: Icons.account_balance_wallet,
                    value: widget.model.totalSalary,
                    title: SALARY,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 1,
                    leadingIcon: Icons.home_filled,
                    title: HOUSE_PROPERTY,
                    value: widget.model.totalHouseProperty,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 2,
                    leadingIcon: Icons.business,
                    title: BUSINESS,
                    value: widget.model.totalBusinessIncome,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 3,
                    leadingIcon: Icons.insert_chart,
                    title: CAPITAL_GAIN,
                    value: widget.model.totalCapitalGain,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 4,
                    leadingIcon: Icons.source,
                    title: OTHER_SOURCES,
                    value: widget.model.totalOtherSources,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 5,
                    leadingIcon: Icons.folder_special,
                    title: OTHER_SPECIAL_INCOME,
                    value: widget.model.totalDivident,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 6,
                    leadingIcon: Icons.trending_down,
                    title: LOSS_BF_AND_ADJUSTED,
                    value: widget.model.lossbfAdjusted,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 7,
                    leadingIcon: Icons.app_registration,
                    value: widget.model.totalIncome,
                    title: GROSS_TOTAL_INCOME,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 8,
                    leadingIcon: Icons.remove_circle,
                    value: widget.model.deductionUnderChaper6,
                    title: DEDUCTIONS,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 9,
                    leadingIcon: Icons.money,
                    title: EXEMPT_INCOME,
                    value: widget.model.exemptIncome,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 10,
                    leadingIcon: Icons.agriculture,
                    title: AGRICULTURE_INCOME,
                    value: widget.model.agroIncome,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 11,
                    leadingIcon: Icons.app_registration,
                    value: widget.model.taxableIncome,
                    title: TAXABLE_INCOME,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 12,
                    leadingIcon: Icons.money_off,
                    value: widget.model.normalTax,
                    title: TAX_ON_NORMAL_INCOME,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 13,
                    leadingIcon: Icons.money_off,
                    value: widget.model.specialTax,
                    title: TAX_ON_SPECIAL_INCOME,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 14,
                    leadingIcon: Icons.money_off,
                    value: widget.model.lessRebate,
                    title: LESS_REBATE87A,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 15,
                    leadingIcon: Icons.money_off,
                    value: widget.model.surCharge,
                    title: SURCHARGE,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 16,
                    leadingIcon: Icons.money_off,
                    value: widget.model.educationCess,
                    title: EDUCATION_CESS,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 17,
                    leadingIcon: Icons.money_off,
                    value: widget.model.taxPayable,
                    title: TAXWO_SURCHARGE,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 18,
                    leadingIcon: Icons.app_registration,
                    value: widget.model.relieF,
                    title: RELIEF,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 19,
                    leadingIcon: Icons.request_page,
                    value: widget.model.tds,
                    title: TDS,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 20,
                    leadingIcon: Icons.request_quote,
                    title: ADVANCED_TAX,
                    value: widget.model.totalAdvancedTax,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 21,
                    leadingIcon: Icons.batch_prediction,
                    value: widget.model.t234A,
                    title: INTEREST_US_234A,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 22,
                    leadingIcon: Icons.batch_prediction,
                    value: widget.model.t234B,
                    title: INTEREST_US_234B,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 23,
                    leadingIcon: Icons.batch_prediction,
                    value: widget.model.t234C,
                    title: INTEREST_US_234C,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 24,
                    leadingIcon: Icons.batch_prediction,
                    value: widget.model.total_234,
                    title: TOTAL_234,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 25,
                    leadingIcon: Icons.request_quote,
                    title: SELF_ASSESMENT_TAX,
                    value: widget.model.totalSelfTax,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 3,
                    leadingIcon: Icons.money_off,
                    title: TAX_PAYABLE,
                    value: widget.model.taxPayableRefundable,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 26,
                    leadingIcon: Icons.date_range,
                    title: FILING_DATE,
                    value: widget.model.filingDate,
                  ),
                  Divider(
                    indent: 20,
                    endIndent: 20,
                  ),
                  outputCard(
                    index: 27,
                    leadingIcon: Icons.date_range,
                    title: DUE_DATE,
                    value: widget.model.dueDate,
                  ),
                  SizedBox(
                    height: 60,
                  ),
                  FlatButton.icon(
                      icon: Icon(Icons.picture_as_pdf_rounded,
                          color: Colors.white),
                      minWidth: 150,
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => PdfInvoice(widget.model)));
                      },
                      label: Text("View",
                          style: TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 16.0,
                          )),
                      color: Theme.of(context).primaryColorDark),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  headerCard() {
    return Container(
        margin: EdgeInsets.all(screenWidth(context) * .03),
        decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                AppColors.mydocumentBG_COLOR,
                AppColors.mydocumentBG_COLOR2
              ],
            ),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10.0),
              topRight: Radius.circular(10.0),
              bottomLeft: Radius.circular(10.0),
              bottomRight: Radius.circular(10.0),
            )),
        padding: EdgeInsets.all(5.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: 35.0),
            Text(BALANCE_PAYABLE,
                style: TextStyle(color: Colors.white, fontSize: 20.0)),
            SizedBox(height: 10.0),
            Center(
              child: Padding(
                padding: EdgeInsets.all(5.0),
                child: StreamBuilder<String>(
                    stream: widget.model.taxPayableRefundable,
                    builder: (context, snapshot) {
                      return Text("\u20B9 " + snapshot.data.toString(),
                          style:
                              TextStyle(color: Colors.white, fontSize: 24.0));
                    }),
              ),
            ),
            SizedBox(height: 35.0),
          ],
        ));
  }

  outputCard(
      {IconData leadingIcon, String title, Stream<String> value, int index}) {
    return _wrapScrollTag(
      index: index,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 8.0,
          vertical: 5,
        ),
        child: ListTile(
          leading: Icon(
            leadingIcon,
            color: Theme.of(context).primaryColorDark,
            size: Sizes.ICON_SIZE_32,
          ),
          title: Text(
            title,
            style: Theme.of(context).textTheme.headline6.copyWith(
                  color: Theme.of(context).primaryColor,
                  fontFamily: 'D-DIN',
                ),
          ),
          trailing: StreamBuilder<String>(
              stream: value,
              builder: (context, snapshot) {
                return Text(
                  snapshot.data ?? "",
                  style: Theme.of(context).textTheme.subtitle1.copyWith(
                        color: Colors.black45,
                        fontFamily: 'D-DIN',
                      ),
                );
              }),
        ),
      ),
    );
  }

  Widget _wrapScrollTag({int index, Widget child}) => AutoScrollTag(
        key: ValueKey(index),
        controller: controller,
        index: index,
        child: child,
        highlightColor: Colors.black.withOpacity(0.1),
      );
}
