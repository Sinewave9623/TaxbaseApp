import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/values/images.dart';

Future<Uint8List> generateGstPdf(PdfPageFormat pageFormat) async {
  final ByteData bytes = await rootBundle.load(ImagePath.LOGO);
  final Uint8List list = bytes.buffer.asUint8List();

  final invoice = Invoice(
    image: list,
    baseColor: PdfColors.blue,
    accentColor: PdfColors.blue500,
  );

  return await invoice.buildPdf(pageFormat);
}

class Invoice {
  Invoice({
    this.image,
    this.baseColor,
    this.accentColor,
  });

  final Uint8List image;
  final PdfColor baseColor;
  final PdfColor accentColor;

  static const _darkColor = PdfColors.blueGrey800;
  static const _lightColor = PdfColors.white;

  PdfColor get _baseTextColor =>
      baseColor.luminance < 0.5 ? _lightColor : _darkColor;

  PdfImage pdfImage;

  Future<Uint8List> buildPdf(PdfPageFormat pageFormat) async {
    // Create a PDF document.
    final doc = pw.Document();
    // Add page to the PDF
    const imageProvider = const AssetImage(ImagePath.LOGO);
    pdfImage = await pdfImageFromImageProvider(
        pdf: doc.document, image: imageProvider);
    doc.addPage(
      pw.MultiPage(
        pageFormat: pageFormat,
        margin: pw.EdgeInsets.all(20),
        header: _buildHeader,
        build: (context) => [
          pw.SizedBox(height: 20),
          _contentTable(context),
          pw.SizedBox(height: 20),
        ],
      ),
    );

    // Return the PDF file content
    final output = await getExternalStorageDirectory();
    print(output.path);
    final file = File("${output.path}/calulatedTax.pdf");
    await file.writeAsBytes(doc.save());

    return doc.save();
  }

  pw.Widget _buildHeader(pw.Context context) {
    final pdf = pw.Document();
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.center,
      children: [
        pw.Center(
          child: pw.Image(
            pdfImage,
            width: 100,
            height: 100,
          ),
        ),
        pw.Text(
          'GST Returns',
          style: pw.TextStyle(fontSize: 25),
        ),
        pw.SizedBox(height: 20),
      ],
    );
  }

  pw.Widget _contentTable(pw.Context context) {
    int index = 0;
    const tableHeaders = [
      'SR. NO.',
      'Id',
      'Uid',
      'Financial year',
      'tax Period',
      'Month',
      'Return Type',
      'Filing Date',
      'Filing Status',
      'ARN',
    ];

    return pw.Table.fromTextArray(
      border: pw.TableBorder.all(),
      cellAlignment: pw.Alignment.centerLeft,
      headerDecoration: pw.BoxDecoration(
        color: baseColor,
      ),
      headerHeight: 25,
      cellHeight: 40,
      cellAlignments: {
        0: pw.Alignment.center,
        1: pw.Alignment.center,
        2: pw.Alignment.center,
        3: pw.Alignment.center,
        4: pw.Alignment.center,
        5: pw.Alignment.center,
        6: pw.Alignment.center,
        7: pw.Alignment.center,
        8: pw.Alignment.center,
        9: pw.Alignment.center,
      },
      headerStyle: pw.TextStyle(
        color: _baseTextColor,
        fontSize: 8,
        fontWeight: pw.FontWeight.bold,
      ),
      cellStyle: const pw.TextStyle(
        color: _darkColor,
        fontSize: 8,
      ),
      rowDecoration: pw.BoxDecoration(
        border: pw.BoxBorder(
          bottom: true,
          color: accentColor,
          width: .3,
        ),
      ),
      headers: List<String>.generate(
        tableHeaders.length,
        (col) => tableHeaders[col],
      ),
    );
  }
}
