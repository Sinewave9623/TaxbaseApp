import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:logger/logger.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/returnsModel/all_returns_model.dart';
import 'package:taxbase_general/models/returnsModel/read_gstinDataModel.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/ui/viewModels/ViewReturns/view_track_return_viewModel.dart';
import 'package:taxbase_general/values/values.dart';
import 'package:supercharged/supercharged.dart';

class ViewTrackReturns extends StatefulWidget {
  final String gstinNo;

  const ViewTrackReturns({Key key, this.gstinNo}) : super(key: key);
  @override
  _ViewTrackReturnsState createState() => _ViewTrackReturnsState();
}

class _ViewTrackReturnsState extends State<ViewTrackReturns> {
  var selectedYear = "";
  var selectedType = "All";

  final GlobalKey _menuKey = new GlobalKey();

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: AppColors.primaryColor,
        statusBarIconBrightness: Brightness.dark));
    return ViewModelBuilder<ViewTrackReturnsViewModel>.reactive(
      onModelReady: (model) => model.init(context),
      builder: (context, model, child) {
        final button = new PopupMenuButton(
            key: _menuKey,
            itemBuilder: (_) => <PopupMenuItem<String>>[
                  new PopupMenuItem<String>(
                      child: const Text('GSTR1'), value: 'GSTR1'),
                  new PopupMenuItem<String>(
                      child: const Text('GSTR3B'), value: 'GSTR3B'),
                  new PopupMenuItem<String>(
                      child: const Text('GSTR9'), value: 'GSTR9'),
                  new PopupMenuItem<String>(
                      child: const Text('All'), value: 'All'),
                ],
            onSelected: (newValue) {
              selectedType = newValue;
              if (newValue == "All") {
                if (!model.isGovernData) {
                  model.filteredData1 =
                      model.readGstinDataModel.readGstData[0].gstdata;
                } else {
                  model.filteredData = model.allReturnsModel.efiledlist;
                }
                Logger().e(model.filteredData);
              } else if (newValue == "GSTR1") {
                if (!model.isGovernData) {
                  model.filteredData1 = model
                      .readGstinDataModel.readGstData[0].gstdata
                      .filter((element) => element.rtntype == selectedType)
                      .toList();
                } else {
                  model.filteredData = model.allReturnsModel.efiledlist
                      .filter((element) => element.rtntype == selectedType)
                      .toList();
                  Logger().e(model.filteredData);
                }
              } else if (newValue == "GSTR3B") {
                if (!model.isGovernData) {
                  model.filteredData1 = model
                      .readGstinDataModel.readGstData[0].gstdata
                      .filter((element) => element.rtntype == selectedType)
                      .toList();
                } else {
                  model.filteredData = model.allReturnsModel.efiledlist
                      .filter((element) => element.rtntype == selectedType)
                      .toList();
                }

                Logger().e(model.filteredData);
              } else if (newValue == "GSTR9") {
                if (!model.isGovernData) {
                  model.filteredData1 = model
                      .readGstinDataModel.readGstData[0].gstdata
                      .filter((element) => element.rtntype == selectedType)
                      .toList();
                } else {
                  model.filteredData = model.allReturnsModel.efiledlist
                      .filter((element) => element.rtntype == selectedType)
                      .toList();
                  Logger().e(model.filteredData);
                }
              } else {
                if (!model.isGovernData) {
                  model.filteredData1 =
                      model.readGstinDataModel.readGstData[0].gstdata;
                } else {
                  model.filteredData = model.allReturnsModel.efiledlist;
                  Logger().e(model.filteredData);
                }
              }

              setState(() {});
            });
        return Scaffold(
          appBar: AppBar(
            title: Text("GST Returns"),
            centerTitle: true,
          ),
          body: Container(
            height: screenHeight(context),
            width: screenWidth(context),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: screenHeight(context) * .08,
                  width: screenWidth(context),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.2),
                    borderRadius: new BorderRadius.circular(5.0),
                  ),
                  margin: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  child: StreamBuilder<YearModel>(
                      stream: model.yearModel,
                      builder: (context, snapshot) {
                        print("=========YearModel");
                        print(snapshot.data);
                        return snapshot.data != null
                            ? DropdownButtonFormField(
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    disabledBorder: InputBorder.none,
                                    enabledBorder: InputBorder.none,
                                    errorBorder: InputBorder.none,
                                    focusedBorder: InputBorder.none,
                                    suffixIcon: button),
                                items: snapshot.data.year.map((value) {
                                  return new DropdownMenuItem<Year>(
                                    value: value,
                                    child: new Text(value.year,
                                        overflow: TextOverflow.ellipsis),
                                  );
                                }).toList(),
                                hint: Text("Please choose a  Year"),
                                onChanged: (value) {
                                  selectedYear = value.year;
                                  print("========selectedYear");
                                  print(selectedYear);
                                  model.getGSTReturnStatus(selectedYear);
                                  // model.getTrackReturns(selectedYear);
                                },
                              )
                            : SizedBox.shrink();
                      }),
                ),
                Container(
                  margin: EdgeInsets.only(left: screenWidth(context) * .08),
                  child: StreamBuilder<String>(
                      stream: model.gstinNo,
                      builder: (context, snapshot) {
                        return Text(
                          "GstinNo: " + snapshot.data.toString(),
                        );
                      }),
                ),
                model.isGovernData
                    ? StreamBuilder<int>(
                        stream: model.isGovLoaded,
                        builder: (context, snapshot) {
                          return snapshot.data == 1
                              ? model.viewTrackReturnsModel.message
                                          .toString() !=
                                      ""
                                  ? model.allReturnsModel.toString() ==
                                          null.toString()
                                      ? SizedBox.shrink()
                                      : model.filteredData.toString() !=
                                              [].toString()
                                          ? Container(
                                              height:
                                                  screenHeight(context) * .76,
                                              width: screenWidth(context),
                                              child: ListView.builder(
                                                // itemCount: model
                                                //     .allReturnsModel.efiledlist.length,
                                                itemCount:
                                                    model.filteredData.length,
                                                itemBuilder: (context, index) {
                                                  // var filedList = model.allReturnsModel
                                                  //     .efiledlist[index];
                                                  var filedList =
                                                      model.filteredData[index];
                                                  return headerCardGov(
                                                      filedList);
                                                },
                                              ),
                                            )
                                          : Center(
                                              child: Text("No Data Found"),
                                            )
                                  : Center(
                                      child: CircularProgressIndicator(),
                                    )
                              : snapshot.data == 2
                                  ? Center(
                                      child: Text("No Data Found"),
                                    )
                                  : Center(
                                      child: CircularProgressIndicator(),
                                    );
                        })
                    : StreamBuilder(
                        stream: model.isLoaded,
                        builder: (context, snapshot) {
                          return snapshot.data == 0
                              ? model.filteredData1.toString() != [].toString()
                                  ? Container(
                                      height: screenHeight(context) * .76,
                                      width: screenWidth(context),
                                      child: ListView.builder(
                                        // itemCount: model
                                        //     .allReturnsModel.efiledlist.length,
                                        itemCount: model.filteredData1.length,
                                        itemBuilder: (context, index) {
                                          // var filedList = model.allReturnsModel
                                          //     .efiledlist[index];
                                          var filedList =
                                              model.filteredData1[index];
                                          Logger().e(filedList.toJson());
                                          // print(model.filteredData1.length);
                                          return headerCard(filedList);
                                        },
                                      ),
                                    )
                                  : Center(
                                      child: Text("No Data Found"),
                                    )
                              : Center(
                                  child: CircularProgressIndicator(),
                                );
                        })
              ],
            ),
          ),
        );
      },
      viewModelBuilder: () => ViewTrackReturnsViewModel(),
    );
  }

  ExpansionTile headerCard(Gstdata filedList) {
    return ExpansionTile(
      title: ListTile(
          title: buildText(Theme.of(context).textTheme.bodyText2,
              "Return Type: " + filedList.rtntype),
          subtitle: buildText(
              Theme.of(context).textTheme.bodyText2,
              "Return Month: " +
                  monthsInYear(filedList.retPrd.toString().substring(0, 2))
                      .toString() +
                  "-" +
                  filedList.retPrd.toString().substring(2)),
          trailing: Container(
            width: screenWidth(context) * .2,
            child: Text(filedList.dof.toString(),
                style: Theme.of(context).textTheme.button),
          )),
      children: [
        ListTile(
          title: Container(
            padding: EdgeInsets.only(left: 15),
            child: buildText(Theme.of(context).textTheme.bodyText2,
                "ARN: " + filedList.arn.toString()),
          ),
          subtitle: Container(
            padding: EdgeInsets.only(left: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                buildText(
                    Theme.of(context).textTheme.bodyText2,
                    "Date of Filing: " +
                        // monthsInYear(
                        //         filedList.retPrd.toString().substring(0, 2))
                        //     .toString() +
                        // "-" +
                        // filedList.retPrd.toString().substring(2),
                        filedList.dof.toString()),
                buildText(Theme.of(context).textTheme.bodyText2,
                    "Method of Filing: " + filedList.mof),
              ],
            ),
          ),
          trailing: Container(
            padding: EdgeInsets.only(right: 50),
            child: Text("Valid: " + filedList.valid.toString(),
                style: Theme.of(context).textTheme.button),
          ),
        )
      ],
    );
  }

  ExpansionTile headerCardGov(Efiledlist filedList) {
    return ExpansionTile(
      title: ListTile(
          title: buildText(Theme.of(context).textTheme.bodyText2,
              "Return Type: " + filedList.rtntype),
          subtitle: buildText(
              Theme.of(context).textTheme.bodyText2,
              "Return Month: " +
                  monthsInYear(filedList.retPrd.toString().substring(0, 2))
                      .toString() +
                  "-" +
                  filedList.retPrd.toString().substring(2)),
          trailing: Container(
            width: screenWidth(context) * .2,
            child: Text(filedList.dof.toString(),
                style: Theme.of(context).textTheme.button),
          )),
      children: [
        ListTile(
          title: Container(
            padding: EdgeInsets.only(left: 15),
            child: buildText(Theme.of(context).textTheme.bodyText2,
                "ARN: " + filedList.arn.toString()),
          ),
          subtitle: Container(
            padding: EdgeInsets.only(left: 15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                buildText(
                    Theme.of(context).textTheme.bodyText2,
                    "Date of Filing: " +
                        // monthsInYear(
                        //         filedList.retPrd.toString().substring(0, 2))
                        //     .toString() +
                        // "-" +
                        // filedList.retPrd.toString().substring(2),
                        filedList.dof.toString()),
                buildText(Theme.of(context).textTheme.bodyText2,
                    "Method of Filing: " + filedList.mof),
              ],
            ),
          ),
          trailing: Container(
            padding: EdgeInsets.only(right: 50),
            child: Text("Valid: " + filedList.valid.toString(),
                style: Theme.of(context).textTheme.button),
          ),
        )
      ],
    );
  }

  Divider divider() => Divider(
        color: Colors.black26,
        indent: 30,
        endIndent: 30,
      );

  Padding buildText(TextStyle style, String title) => Padding(
        padding: const EdgeInsets.all(2.0),
        child: Text(title, style: style),
      );
}

monthsInYear(String substring) {
  print(substring);
  switch (substring) {
    case "01":
      return "Jan";
      break;
    case "02":
      return "Feb";
      break;
    case "03":
      return "Mar";
      break;
    case "04":
      return "Apr";
      break;
    case "05":
      return "May";
      break;
    case "06":
      return "Jun";
      break;
    case "07":
      return "Jul";
      break;
    case "08":
      return "Aug";
      break;
    case "09":
      return "Sep";
      break;
    case "10":
      return "Oct";
      break;
    case "11":
      return "Nov";
      break;
    case "12":
      return "Dec";
      break;
    default:
  }
}
