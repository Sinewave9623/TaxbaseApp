import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:logger/logger.dart';
import 'package:lottie/lottie.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/GstinModel/gstin_responseModel.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:supercharged/supercharged.dart';
import 'package:taxbase_general/ui/viewModels/ViewReturns/view_returns_viewModel.dart';
import 'package:taxbase_general/ui/views/RETURNS/gst_pdf_view_screen.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';
import 'package:taxbase_general/values/values.dart';
import 'package:url_launcher/url_launcher.dart';

class ViewReturnsScreen extends StatefulWidget {
  final YearModel years;

  const ViewReturnsScreen({Key key, this.years}) : super(key: key);
  @override
  _ViewReturnsScreenState createState() => _ViewReturnsScreenState();
}

class _ViewReturnsScreenState extends State<ViewReturnsScreen> {
  final GlobalKey _menuKey = new GlobalKey();
  TextEditingController gstinNoController =
      TextEditingController(text: "27AAECG6794Q1ZM");
  TextEditingController userNameController = TextEditingController(text: "");
  TextEditingController userOTPController = TextEditingController();
  Logger logger = Logger();

  var selectedGstin = "";
  var selectedType = "All";
  List<GSTdata> filteredData = [];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: AppColors.primaryColor,
        statusBarIconBrightness: Brightness.light));

    return ViewModelBuilder<ViewReturnsViewModel>.reactive(
      onModelReady: (model) => model.init(),
      builder: (context, model, child) {
        return SafeArea(
          child: Scaffold(
            appBar: AppBar(
              title: Text("Authentication"),
              centerTitle: true,
            ),
            // floatingActionButton: FloatingActionButton(
            //   child: Icon(Icons.picture_as_pdf),
            //   onPressed: () => Navigator.of(context)
            //       .push(MaterialPageRoute(builder: (context) => GstPdf())),
            // ),
            body: SingleChildScrollView(
              child: Container(
                  height: screenHeight(context),
                  width: screenWidth(context),
                  margin: EdgeInsets.only(top: 15),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.only(
                          left: 20.0,
                          right: 20.0,
                          top: 20,
                          bottom: 20,
                        ),
                        child: StreamBuilder<GstinResponseModel>(
                            stream: model.gstInData,
                            builder: (context, snapshot) {
                              print("===================");
                              return snapshot.data != null
                                  ? DropdownButtonFormField(
                                      decoration: InputDecoration(
                                        border: InputBorder.none,
                                        disabledBorder: InputBorder.none,
                                        enabledBorder: InputBorder.none,
                                        errorBorder: InputBorder.none,
                                        focusedBorder: InputBorder.none,
                                      ),
                                      items: snapshot.data.data.map((value) {
                                        print("=====================");
                                        print(value.gstin);
                                        return new DropdownMenuItem<GSTINData>(
                                          value: value,
                                          child: new Text(
                                              value.gstin.toString(),
                                              overflow: TextOverflow.ellipsis),
                                        );
                                      }).toList(),
                                      hint:
                                          Text("Please choose a  GstinNumber"),
                                      onChanged: (value) {
                                        selectedGstin = value.gstin;
                                        // model.getSelectedData(selectedGstin);
                                        setState(() {
                                          
                                        });
                                        print("========selectedGstin");
                                        print(selectedGstin);
                                      },
                                    )
                                  : SizedBox.shrink();
                            }),
                      ),
                      Container(
                        padding: const EdgeInsets.only(
                          left: 20.0,
                          right: 20.0,
                          bottom: 20,
                        ),
                        child: StreamBuilder<String>(
                            stream: model.userName,
                            builder: (context, snapshot) {
                              return TextFormField(
                                onChanged: model.onUserNameChange,
                                keyboardType: TextInputType.text,
                                // textCapitalization:
                                //     TextCapitalization.characters,
                                controller: userNameController,
                                decoration: InputDecoration(
                                  labelText: USER_NAME,
                                  hintText: USER_NAME,
                                  hintStyle: Theme.of(context)
                                      .textTheme
                                      .bodyText2
                                      .copyWith(color: Colors.black26),
                                ),
                                onFieldSubmitted: (value) {},
                              );
                            }),
                      ),
                      Container(
                        padding: const EdgeInsets.only(
                          left: 20.0,
                          right: 20.0,
                          bottom: 20,
                        ),
                        child: model.isEanbled
                            ? StreamBuilder<String>(
                                stream: model.userOTP,
                                builder: (context, snapshot) {
                                  return TextFormField(
                                    onChanged: model.onUserOTPChange,
                                    keyboardType: TextInputType.text,
                                    textCapitalization:
                                        TextCapitalization.characters,
                                    controller: userOTPController,
                                    decoration: InputDecoration(
                                      labelText: USER_OTP,
                                      hintText: USER_OTP,
                                      hintStyle: Theme.of(context)
                                          .textTheme
                                          .bodyText2
                                          .copyWith(color: Colors.black26),
                                    ),
                                    onFieldSubmitted: (value) {},
                                  );
                                })
                            : SizedBox.shrink(),
                      ),
                      Container(
                          child: !model.isEanbled
                              ? StreamBuilder<bool>(
                                  stream: model.generateOTPButton,
                                  builder: (context, snapshot) {
                                    return BusyButton(
                                      height: 50,
                                      iconImage: Icons.arrow_forward_rounded,
                                      busy: model.loading,
                                      onPressed: snapshot.hasData
                                          ? () {
                                              model
                                                  .requestForOtp(selectedGstin);
                                            }
                                          : null,
                                    );
                                  })
                              : StreamBuilder<bool>(
                                  stream: model.validateOTPButton,
                                  builder: (context, snapshot) {
                                    return BusyButton(
                                      height: 50,
                                      iconImage: Icons.arrow_forward_rounded,
                                      busy: model.loading,
                                      onPressed: snapshot.hasData
                                          ? () {
                                              model.verifyOtp(selectedGstin);
                                            }
                                          : null,
                                    );
                                  })),
                    ],
                  )),
            ),
          ),
        );
      },
      viewModelBuilder: () => ViewReturnsViewModel(),
    );
  }

  _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  ExpansionTile headerCard(GSTdata gstDetails) {
    return ExpansionTile(
      title: ListTile(
          title: buildText(Theme.of(context).textTheme.bodyText2,
              "Return Type: " + gstDetails.returnType),
          subtitle: buildText(Theme.of(context).textTheme.bodyText2,
              "Month: " + gstDetails.month),
          trailing: Text(gstDetails.dateOfFiling,
              style: Theme.of(context).textTheme.button)),
      children: [
        SizedBox(height: 10.0),
        ListTile(
            title: buildText(Theme.of(context).textTheme.bodyText2, "Year"),
            trailing:
                Text(gstDetails.fy, style: Theme.of(context).textTheme.button)),
        divider(),
        // ListTile(
        //     title:
        //         buildText(Theme.of(context).textTheme.bodyText2, "Tax Period "),
        //     trailing: Text(gstDetails.month,
        //         style: Theme.of(context).textTheme.button)),
        // divider(),
        ListTile(
            title: buildText(
                Theme.of(context).textTheme.bodyText2, "Return Type "),
            trailing: Text(gstDetails.returnType,
                style: Theme.of(context).textTheme.button)),
        divider(),
        ListTile(
            title: buildText(
                Theme.of(context).textTheme.bodyText2, "Filing Status"),
            trailing: Text(gstDetails.filingStatus,
                style: Theme.of(context).textTheme.button)),
        divider(),
        ListTile(
            title: buildText(Theme.of(context).textTheme.bodyText2, "ARN"),
            trailing: Text(gstDetails.aRN ?? "",
                style: Theme.of(context).textTheme.button)),
        gstDetails.fileUrls.length > 0
            ? Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Attachments",
                    style: Theme.of(context).textTheme.headline6,
                  ),
                ],
              )
            : SizedBox.shrink(),
        gstDetails.fileUrls.length > 0
            ? Container(
                height: gstDetails.fileUrls.length > 2
                    ? screenHeight(context) / 3
                    : screenHeight(context) / 5,
                child: ListView.separated(
                  itemCount: gstDetails.fileUrls.length,
                  separatorBuilder: (context, index) {
                    return divider();
                  },
                  itemBuilder: (context, i) {
                    return ListTile(
                      leading: Icon(Icons.file_copy,
                          color: Theme.of(context).primaryColor),
                      title: Text(gstDetails.fileUrls[i].filename ?? "",
                          style: Theme.of(context).textTheme.button),
                      onTap: () {
                        _launchURL(gstDetails.fileUrls[i].fileurl);
                      },
                    );
                  },
                ),
              )
            : SizedBox.shrink()
      ],
    );
  }

  Divider divider() => Divider(
        color: Colors.black26,
        indent: 30,
        endIndent: 30,
      );

  Padding buildText(TextStyle style, String title) => Padding(
        padding: const EdgeInsets.all(2.0),
        child: Text(title, style: style),
      );
}
