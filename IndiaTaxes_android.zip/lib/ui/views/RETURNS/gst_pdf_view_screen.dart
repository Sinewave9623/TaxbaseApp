import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:taxbase_general/ui/views/RETURNS/save_gst_pdf.dart';

class GstPdf extends StatefulWidget {

  @override
  _GstPdfState createState() => _GstPdfState();
}

class _GstPdfState extends State<GstPdf> {
  File file;
  int pages = 1;
  bool isReady = false;
  Completer _controller = Completer();

  @override
  void initState() {
    Timer(Duration(seconds: 2), () {
      getPdf();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("PDF"),
        actions: [
          // IconButton(
          //     icon: Icon(Icons.share),
          //     onPressed: ()async {
          //       var sharePdf = await file.readAsBytes();
          //       await Share.file('esys image', 'GstReturn.pdf', sharePdf.buffer.asUint8List(), 'pdf/pdf', text: 'My optional text.');
          //     })
        ],
      ),
      body: Center(
        child: file != null
            ? PDFView(
                filePath: file.path,
                enableSwipe: true,

                swipeHorizontal: true,
                autoSpacing: true,
                // nightMode: true,
                pageSnap: true,
                pageFling: false,
                onRender: (_pages) {
                  setState(() {
                    pages = _pages;
                    isReady = true;
                  });
                },
                onError: (error) {
                  print(error.toString());
                },
                onPageError: (page, error) {
                  print('$page: ${error.toString()}');
                },
                onViewCreated: (PDFViewController pdfViewController) {
                  _controller.complete(pdfViewController);
                },
                onPageChanged: (int page, int total) {
                  print('page change: $page/$total');
                },
              )
            : Center(child: CircularProgressIndicator()),
      ),
    );
  }

  void getPdf() async {
    
    Uint8List uint8list = await generateGstPdf(PdfPageFormat.a3);
    Directory output = await getApplicationDocumentsDirectory();
    file = File(output.path + "/example.pdf");
    setState(() {
      file.writeAsBytes(uint8list);
      print(file.path);
    });
  }
}
