import 'package:flutter/material.dart';
import 'package:flutter_json_widget/flutter_json_widget.dart';

class ViewJsonScreen extends StatefulWidget {
  final Map<String, dynamic> json;

  const ViewJsonScreen({Key key, this.json}) : super(key: key);

  @override
  _ViewJsonScreenState createState() => _ViewJsonScreenState();
}

class _ViewJsonScreenState extends State<ViewJsonScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      padding: EdgeInsets.all(10),
      margin: EdgeInsets.only(
        top: 50,
      ),
      child: SingleChildScrollView(child: JsonViewerWidget(widget.json)),
    ));
  }
}
