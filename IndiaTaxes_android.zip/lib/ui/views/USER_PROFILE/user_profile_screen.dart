import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/ui/views/USER_PROFILE/user_profile_viewModel.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';
import 'package:taxbase_general/values/theme.dart';
import 'package:taxbase_general/values/values.dart';

class UserProfileScreen extends StatefulWidget {
  @override
  _UserProfileScreenState createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  TextEditingController birthDateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<UserProfileViewModel>.reactive(
      viewModelBuilder: () => UserProfileViewModel(),
      onModelReady: (model) => model.init(),
      builder: (context, model, child) {
        return Scaffold(
          backgroundColor: Colors.white,
          resizeToAvoidBottomInset: true,
          appBar: AppBar(
            elevation: 0,
            flexibleSpace: Container(
              decoration: BoxDecoration(
                color: Colors.white,
              ),
            ),
            centerTitle: true,
            title: Text(
              "Profile",
              style: myTheme.textTheme.headline6
                  .copyWith(color: AppColors.titleColor),
            ),
            actions: [],
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Divider(),
                Container(
                  margin: EdgeInsets.only(
                    left: screenWidth(context) * .12,
                  ),
                  child: Text("Salaried ?"),
                ),
                Container(
                    width: screenWidth(context),
                    height: screenHeight(context) * .1,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                            left: screenWidth(context) * .08,
                          ),
                          child: Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(
                                  right: screenWidth(context) * .1,
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      child: Transform.scale(
                                        scale: 1.2,
                                        child: Checkbox(
                                          activeColor: AppColors.primaryColor,
                                          autofocus: true,
                                          checkColor:
                                              AppColors.primaryColorLight,
                                          value: model.isSalariedYes,
                                          onChanged: (newValue) {
                                            setState(() {
                                              model.experience(newValue, false);
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                    Container(
                                      child: Text(
                                        "Yes",
                                      ),
                                    ),
                                    SizedBox(
                                      width: 50,
                                    ),
                                    Container(
                                      child: Transform.scale(
                                        scale: 1.2,
                                        child: Checkbox(
                                          activeColor: AppColors.primaryColor,
                                          autofocus: true,
                                          checkColor:
                                              AppColors.primaryColorLight,
                                          value: model.isSalariedNo,
                                          onChanged: (newValue) {
                                            setState(() {
                                              model.experience(
                                                false,
                                                newValue,
                                              );
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                    Container(
                                      child: Text("No"),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    )),
                Divider(),
                StreamBuilder<dynamic>(
                  stream: model.flatNumber,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: FLAT_NUMBER,
                      label: FLAT_NUMBER,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z,A-Z, 0-9,  ,]')),
                      ],
                      keyBoardType: TextInputType.text,
                      intialValue: model.flatNumberController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onFlatNumberChanged("");
                        } else {
                          print(value);
                          model.onFlatNumberChanged(value);
                        }
                      },
                    );
                  },
                ),
                StreamBuilder<dynamic>(
                  stream: model.premiseName,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: PREMISE_NAME,
                      label: PREMISE_NAME,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z,A-Z,0-9,  ,]')),
                      ],
                      keyBoardType: TextInputType.text,
                      intialValue: model.premiseNameController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onPremiseNameChanged("");
                        } else {
                          model.onPremiseNameChanged(value);
                        }
                      },
                    );
                  },
                ),
                StreamBuilder<dynamic>(
                  stream: model.streetName,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: STREET_NAME,
                      label: STREET_NAME,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z,A-Z,0-9,  ,]')),
                      ],
                      keyBoardType: TextInputType.text,
                      intialValue: model.streetNameController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onStreetNameChanged("");
                        } else {
                          model.onStreetNameChanged(value);
                        }
                      },
                    );
                  },
                ),
                StreamBuilder<dynamic>(
                  stream: model.area,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: AREA,
                      label: AREA,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z,A-Z,0-9,  ,]')),
                      ],
                      keyBoardType: TextInputType.text,
                      intialValue: model.areaController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onareaChanged("");
                        } else {
                          model.onareaChanged(value);
                        }
                      },
                    );
                  },
                ),
                StreamBuilder<dynamic>(
                  stream: model.town,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: TOWN,
                      label: TOWN,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z,A-Z,  ,]')),
                      ],
                      keyBoardType: TextInputType.text,
                      intialValue: model.townController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onTownChanged("");
                        } else {
                          model.onTownChanged(value);
                        }
                      },
                    );
                  },
                ),
                StreamBuilder<dynamic>(
                  stream: model.pin,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: PIN,
                      label: PIN,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      ],
                      intialValue: model.pinController.value.toString(),
                      maxLength: 6,
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onPinChanged("");
                        } else {
                          model.onPinChanged(value);
                        }
                      },
                    );
                  },
                ),
                StreamBuilder<dynamic>(
                  stream: model.state,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: STATE,
                      label: STATE,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(
                            RegExp(r'[a-z,A-Z,  ,]')),
                      ],
                      keyBoardType: TextInputType.text,
                      intialValue: model.stateController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onStateChanged("");
                        } else {
                          model.onStateChanged(value);
                        }
                      },
                    );
                  },
                ),
                StreamBuilder<dynamic>(
                  stream: model.country,
                  builder: (context, snapshot) {
                    return buildTextField(
                      hint: COUNTRY,
                      label: COUNTRY,
                      numbersAllowd: <TextInputFormatter>[
                        FilteringTextInputFormatter.allow(RegExp(r'[a-z,A-Z]')),
                      ],
                      keyBoardType: TextInputType.text,
                      intialValue: model.countryController.value.toString(),
                      onChanged: (value) {
                        if (value.isEmpty) {
                          model.onCountryChanged("");
                        } else {
                          model.onCountryChanged(value);
                        }
                      },
                    );
                  },
                ),
                Divider(),
                Container(
                  margin: EdgeInsets.only(
                    left: screenWidth(context) * .12,
                  ),
                  child: Text("Gender"),
                ),
                Container(
                    width: screenWidth(context),
                    height: screenHeight(context) * .1,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          margin: EdgeInsets.only(
                            left: screenWidth(context) * .08,
                          ),
                          child: Row(
                            children: [
                              Container(
                                margin: EdgeInsets.only(
                                  right: screenWidth(context) * .1,
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      child: Transform.scale(
                                        scale: 1.2,
                                        child: Checkbox(
                                          activeColor: AppColors.primaryColor,
                                          autofocus: true,
                                          checkColor:
                                              AppColors.primaryColorLight,
                                          value: model.isMale,
                                          onChanged: (newValue) {
                                            setState(() {
                                              model.gender(
                                                  newValue, false, false);
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                    Container(
                                      child: Text(
                                        "Male",
                                      ),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Container(
                                      child: Transform.scale(
                                        scale: 1.2,
                                        child: Checkbox(
                                          activeColor: AppColors.primaryColor,
                                          autofocus: true,
                                          checkColor:
                                              AppColors.primaryColorLight,
                                          value: model.isFeMale,
                                          onChanged: (newValue) {
                                            setState(() {
                                              model.gender(
                                                false,
                                                newValue,
                                                false,
                                              );
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                    Container(
                                      child: Text("Female"),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Container(
                                      child: Transform.scale(
                                        scale: 1.2,
                                        child: Checkbox(
                                          activeColor: AppColors.primaryColor,
                                          autofocus: true,
                                          checkColor:
                                              AppColors.primaryColorLight,
                                          value: model.isOther,
                                          onChanged: (newValue) {
                                            setState(() {
                                              model.gender(
                                                false,
                                                false,
                                                newValue,
                                              );
                                            });
                                          },
                                        ),
                                      ),
                                    ),
                                    Container(
                                      child: Text("Other"),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    )),
                Divider(),
                Container(
                  margin: EdgeInsets.only(
                    left: screenWidth(context) * .12,
                  ),
                  child: Text("Date of Birth"),
                ),
                Row(
                  children: [
                    Container(
                      margin: EdgeInsets.only(
                        top: 10,
                        left: screenWidth(context) * .12,
                      ),
                      width: screenWidth(context) * 0.3,
                      child: StreamBuilder<String>(
                          stream: model.birthDateInString,
                          builder: (context, snapshot) {
                            birthDateController.value = birthDateController
                                .value
                                .copyWith(text: snapshot.data);
                            return TextFormField(
                              controller: birthDateController,
                              maxLength: 2,
                              onTap: () {
                                FocusNode().unfocus();
                                model.getBirthDate(context);
                              },
                              // keyboardType: TextInputType.number,
                              keyboardType: TextInputType.datetime,
                              decoration: InputDecoration(
                                hintText: "BirthDate",
                                counterText: "",
                                hintStyle: Theme.of(context)
                                    .textTheme
                                    .bodyText2
                                    .copyWith(
                                        color: AppColors.primaryColorLight),
                              ),
                              onChanged: model.onBirthDateChange,
                            );
                          }),
                    ),
                    Container(
                        margin: EdgeInsets.all(10),
                        child: Text(model.age != null
                            ? "Age: " + model.age.years.toString() + " Yrs"
                            : "Age: ")),
                    Container(
                        margin: EdgeInsets.all(10),
                        child: Text(model.age != null
                            ? model.age.years >= 60
                                ? "Senior "
                                : "General"
                            : "")),
                  ],
                ),
                Divider(),
                Container(
                  margin: EdgeInsets.only(
                    left: screenWidth(context) * .1,
                    right: screenWidth(context) * .1,
                  ),
                  child: StreamBuilder<String>(
                    stream: model.employeePan,
                    builder: (context, snapshot) {
                      return buildTextField(
                        hint: PAN,
                        label: PAN,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[a-z,A-Z,0-9]')),
                        ],
                        textCapitalization: TextCapitalization.characters,
                        keyBoardType: TextInputType.text,
                        intialValue:
                            model.employeePanController.value.toString(),
                        maxLength: 10,
                        onChanged: (value) {
                          if (value.isEmpty) {
                            model.onEmployeePanChanged("");
                          } else {
                            model.onEmployeePanChanged(value);
                          }
                        },
                      );
                    },
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(top: 10),
                  child: Center(
                    child: BusyButton(
                      width: screenWidth(context),
                      busy: model.loading,
                      iconImage: Icons.arrow_forward_rounded,
                      onPressed: () {
                        model.saveValues(context);
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Padding buildTextField(
      {String hint,
      String label,
      Function(dynamic p1) onChanged,
      TextInputType keyBoardType,
      List<TextInputFormatter> numbersAllowd,
      TextCapitalization textCapitalization,
      int maxLength,
      String intialValue}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
        inputFormatters: numbersAllowd,
        textCapitalization: textCapitalization ?? TextCapitalization.none,
        maxLength: maxLength,
        decoration: InputDecoration(
          hintText: hint,
          labelText: label,
        ),
        // controller: controller ?? TextEditingController(),
        onChanged: onChanged,
        initialValue: intialValue ?? "",
      ),
    );
  }
}
