import 'dart:convert';

import 'package:age/age.dart';
import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:rxdart/rxdart.dart';
import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';

class UserProfileViewModel extends BaseViewModel {
  final _services = AuthenticationServices();
  bool isSalariedYes = false;
  bool isSalariedNo = true;

  bool isMale = true;
  bool isFeMale = false;
  bool isOther = false;

  DateTime birthDate;
  AgeDuration age;

  final birthDateController = BehaviorSubject<String>();
  Stream<String> get birthDateInString => birthDateController.stream;
  Function(String) get onBirthDateChange => birthDateController.sink.add;

  final addreessController = BehaviorSubject<String>();
  Stream<String> get address => addreessController.stream;
  Function(String) get onAddressChange => addreessController.sink.add;

  final employeePanController = BehaviorSubject<String>();
  Stream<String> get employeePan => employeePanController.stream;
  Function(String) get onEmployeePanChanged => employeePanController.sink.add;

  final townController = BehaviorSubject<String>();
  Stream<String> get town => townController.stream;
  Function(String) get onTownChanged => townController.sink.add;

  final flatNumberController = BehaviorSubject<String>();
  Stream<String> get flatNumber => flatNumberController.stream;
  Function(String) get onFlatNumberChanged => flatNumberController.sink.add;

  final premiseNameController = BehaviorSubject<String>();
  Stream<String> get premiseName => premiseNameController.stream;
  Function(String) get onPremiseNameChanged => premiseNameController.sink.add;

  final streetNameController = BehaviorSubject<String>();
  Stream<String> get streetName => streetNameController.stream;
  Function(String) get onStreetNameChanged => streetNameController.sink.add;

  final areaController = BehaviorSubject<String>();
  Stream<String> get area => areaController.stream;
  Function(String) get onareaChanged => areaController.sink.add;

  final pinController = BehaviorSubject<String>();
  Stream<String> get pin => pinController.stream;
  Function(String) get onPinChanged => pinController.sink.add;

  final stateController = BehaviorSubject<String>();
  Stream<String> get state => stateController.stream;
  Function(String) get onStateChanged => stateController.sink.add;

  final countryController = BehaviorSubject<String>();
  Stream<String> get country => countryController.stream;
  Function(String) get onCountryChanged => countryController.sink.add;

  init() {
    String employeePan = _services.getUserPan;
    String town = _services.getUserAddress;
    // String flatNo = _services.getUserFlatNo;
    // String userPremise = _services.getUserPremise;
    // String userRoad = _services.getUserRoad;
    // String userArea = _services.getUserArea;
    // String userPincode = _services.getUserPin;
    // String state = _services.getUserState;
    // String country = _services.getUserCountry;

    // String age = _services.getUserAge;

    // flatNumberController.add(flatNo);
    // premiseNameController.add(userPremise);
    // streetNameController.add(userRoad);
    // areaController.add(userArea);
    // pinController.add(userPincode);
    // stateController.add(state);
    // countryController.add(country);
    // birthDateController.add(age);
    Logger().wtf(town);
    townController.add(town.toString() != "null" ? town : "");

    String mobile = _services.user;
    String userName = _services.getUserName;
    String userGender = _services.getUserGender;
    String flat = _services.getUserFlatNo;
    String premiseName = _services.getUserPremise;
    String getUserRoad = _services.getUserRoad;
    String getUserArea = _services.getUserArea;
    String getUserPin = _services.getUserPin;
    String getUserState = _services.getUserState;
    String getUserCountry = _services.getUserCountry;
    String getUserDOB = _services.getUserDOB;

    // addreessController.add();
    Logger().e(flat);
    birthDateController.add(getUserDOB);
    flatNumberController.add(flat ?? "");
    premiseNameController.add(premiseName ?? "");
    streetNameController.add(getUserRoad ?? "");
    areaController.add(getUserArea ?? "");
    // townController.add("");
    pinController.add(getUserPin ?? "");
    stateController.add(getUserState ?? "");
    countryController.add(getUserCountry ?? "");
    employeePanController.add(employeePan);

    notifyListeners();
  }

  void experience(bool _isOther, bool _isUnskilled) {
    if (_isOther) {
      isSalariedYes = _isOther;
      isSalariedNo = false;
      notifyListeners();
    }
    if (_isUnskilled) {
      isSalariedYes = false;
      isSalariedNo = _isUnskilled;
      notifyListeners();
    }
  }

  void gender(bool _isMale, bool _isFemale, bool _isOther) {
    if (_isMale) {
      isMale = _isMale;
      isFeMale = false;
      isOther = false;
      notifyListeners();
    }
    if (_isFemale) {
      isMale = false;
      isFeMale = _isFemale;
      isOther = false;

      notifyListeners();
    }
    if (_isOther) {
      isMale = false;
      isFeMale = false;
      isOther = _isOther;
      notifyListeners();
    }
  }

  Future<void> getBirthDate(BuildContext context) async {
    final datePick = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime(1900),
        lastDate: new DateTime(2025));
    if (datePick != null && datePick != birthDate) {
      birthDate = datePick;
      var birthDate2 = DateFormat("yyyy-MM-dd").format(birthDate);
      print(birthDate2.toString());
      birthDateController
          .add(birthDate2.toString());
      print("birthDateController");
      print(birthDateController.value.toString());
      age = Age.dateDifference(
          fromDate: birthDate, toDate: DateTime.now(), includeToDate: false);
      print(age.years.toString());
      notifyListeners();
    }
  }

  void saveValues(BuildContext context) {
    setBusy(true);
    _services.saveUserPan(employeePanController.value.toString());
    _services.saveFlatNo(flatNumberController.value.toString());
    _services.savepremiseName(premiseNameController.value.toString());
    _services.saveStreetName(streetNameController.value.toString());
    _services.saveArea(areaController.value.toString());
    _services.saveUserTown(townController.value.toString());
    _services.saveUserPin(pinController.value.toString());
    _services.saveUserState(stateController.value.toString());
    _services.saveUserCountry(countryController.value.toString());

    _services.saveIsalaried(isSalariedYes);

    if (isMale) {
      _services.saveGender("Male");
    } else if (isFeMale) {
      _services.saveGender("FeMale");
    } else {
      _services.saveGender("Other");
    }

    setBusy(false);
    Navigator.of(context).pop();
    // _services.saveUserMobile(mobileNumber.toString());
  }
}
