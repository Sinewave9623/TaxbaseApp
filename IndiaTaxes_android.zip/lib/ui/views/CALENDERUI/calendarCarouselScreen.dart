import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:logger/logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stacked/stacked.dart';

import 'package:table_calendar/table_calendar.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/durationModel/durationResponseModel.dart';
import 'package:taxbase_general/ui/viewModels/CalendarViewModel/CalendarCarouselViewModel.dart';
import 'package:taxbase_general/values/values.dart';
import 'package:autocomplete_textfield/autocomplete_textfield.dart';

class CalendarCarouselScreen extends StatefulWidget {
  @override
  _CalendarCarouselScreenState createState() => _CalendarCarouselScreenState();
}

class _CalendarCarouselScreenState extends State<CalendarCarouselScreen> {
  CalendarController _controller;
  Map<DateTime, List<dynamic>> _events;
  List<dynamic> _selectedEvents;
  List<dynamic> _myselectedEvents;
  TextEditingController _eventController;
  TextEditingController _durationController;
  SharedPreferences prefs;
  List<String> tags = [];
  AutoCompleteTextField durationSearchField;
  GlobalKey<AutoCompleteTextFieldState<DurationList>> key = new GlobalKey();

  SimpleAutoCompleteTextField textField;
  // GlobalKey<AutoCompleteTextFieldState<String>> key = new GlobalKey();
  String currentText = "";
  List<String> added = [];
  String currentDuration = "";
  String selectedValue = "2020-2021";
  String selectedDurationValue = "";

  @override
  void initState() {
    super.initState();
    _controller = CalendarController();
    _eventController = TextEditingController();
    _events = {};
    _selectedEvents = [];
    _myselectedEvents = [];

    // SchedulerBinding.instance.addPostFrameCallback((_) {
    //   _controller.setFocusedDay(
    //       DateTime.parse(today.substring(0, 10) + " 12:00:00.000Z"));
    // });
    prefsData();
  }

  void _onDaySelected(DateTime day, List events, List holidays) {
    print("=====================");
    print('CALLBACK: _onDaySelected');
    print(day);
    print("=====================");
    setState(() {
      _selectedEvents = events;
    });
  }

  void _onCalendarCreated(
      DateTime first, DateTime last, CalendarFormat format) {
    print("=====================");
    print('CALLBACK: _onCalendarCreated');
    print(first);
    print(last);
    print("=====================");
    // _controller.setFocusedDay(first);
    // _onVisibleDaysChanged(first, first, format);
  }

  void _onVisibleDaysChanged(
      DateTime first, DateTime last, CalendarFormat format) {
    print("=====================");
    print('CALLBACK: _onVisibleDaysChanged');
    print(first);
    print(last);
    print("=====================");
  }

  prefsData() async {
    prefs = await SharedPreferences.getInstance();

    setState(() {
      _events = Map<DateTime, List<dynamic>>.from(
          decodeMap(jsonDecode(prefs.getString("events") ?? "{}")));
      var values = _events.map((key, value) {
        print("==--0==");
        var today = DateTime.now().toString() + "Z";
        _myselectedEvents = value.toList();
        print(_myselectedEvents);
        _onDaySelected(
            DateTime.parse(today.substring(0, 10) + " 12:00:00.000Z"),
            _myselectedEvents,
            _selectedEvents);
        print("==--0==");
      });
    });
  }

  Map<String, dynamic> encodeMap(Map<DateTime, dynamic> map) {
    Map<String, dynamic> newMap = {};
    map.forEach((key, value) {
      newMap[key.toString()] = map[key];
    });
    return newMap;
  }

  Map<DateTime, dynamic> decodeMap(Map<String, dynamic> map) {
    Map<DateTime, dynamic> newMap = {};
    map.forEach((key, value) {
      newMap[DateTime.parse(key)] = map[key];
    });
    return newMap;
  }

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<CalendarCarouselViewModel>.reactive(
      onModelReady: (model) => model.init(),
      builder: (context, model, child) {
        return Scaffold(
          backgroundColor: Colors.grey[100],
          appBar: AppBar(
            elevation: 0,
            title: Text(
              'GST Reminder',
              style: TextStyle(color: Colors.black),
            ),
            leading: InkWell(
              onTap: () => Navigator.of(context).pop(),
              child: Icon(
                Icons.arrow_back,
                color: Colors.black,
              ),
            ),
            flexibleSpace: Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                      colors: <Color>[
                    AppColors.whiteColor,
                    AppColors.whiteColor
                  ])),
            ),
          ),
          body: Container(
            width: screenWidth(context),
            height: screenHeight(context),
            decoration: BoxDecoration(color: Colors.white),
            child: Stack(
              // crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(color: Colors.white),
                  child: TableCalendar(
                    events: _events,
                    initialSelectedDay: DateTime.now(),
                    initialCalendarFormat: CalendarFormat.month,
                    daysOfWeekStyle: DaysOfWeekStyle(
                      weekdayStyle: TextStyle(color: Colors.black),
                      weekendStyle: TextStyle(color: Colors.black),
                    ),
                    calendarStyle: CalendarStyle(
                        markersColor: AppColors.mydocumentBG_COLOR,
                        holidayStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0,
                            color: Colors.black),
                        weekendStyle: TextStyle(color: Colors.black),
                        outsideStyle: TextStyle(color: Colors.black),
                        weekdayStyle: TextStyle(color: Colors.black),
                        eventDayStyle: TextStyle(color: Colors.black),
                        selectedStyle: TextStyle(color: Colors.black),
                        outsideHolidayStyle: TextStyle(color: Colors.black),
                        unavailableStyle: TextStyle(color: Colors.black),
                        outsideWeekendStyle: TextStyle(color: Colors.black),
                        outsideDaysVisible: false,
                        canEventMarkersOverflow: true,
                        todayColor: Colors.black38,
                        selectedColor: Colors.black38,
                        todayStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18.0,
                            color: Colors.black)),
                    headerStyle: HeaderStyle(
                      rightChevronVisible: false,
                      leftChevronVisible: false,
                      titleTextStyle: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                      ),
                      centerHeaderTitle: true,
                      formatButtonShowsNext: false,
                      formatButtonVisible: false,
                    ),
                    startingDayOfWeek: StartingDayOfWeek.monday,
                    onCalendarCreated: _onCalendarCreated,
                    onDaySelected: _onDaySelected,
                    onVisibleDaysChanged: _onVisibleDaysChanged,
                    builders: CalendarBuilders(
                      weekendDayBuilder: (context, date, events) => Container(
                          margin: const EdgeInsets.all(4.0),
                          alignment: Alignment.center,
                          child: Text(
                            date.day.toString(),
                            style: TextStyle(color: Colors.black),
                          )),
                      unavailableDayBuilder: (context, date, events) =>
                          Container(
                              margin: const EdgeInsets.all(4.0),
                              alignment: Alignment.center,
                              child: Text(
                                date.day.toString(),
                                style: TextStyle(color: Colors.black),
                              )),
                      dayBuilder: (context, date, events) => Container(
                          margin: const EdgeInsets.all(4.0),
                          alignment: Alignment.center,
                          child: Text(
                            date.day.toString(),
                            style: TextStyle(color: Colors.black),
                          )),
                      selectedDayBuilder: (context, date, events) => Container(
                          margin: const EdgeInsets.all(4.0),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: AppColors.onDateSelectedColor),

                              // color: AppColors.mydocumentBG_COLOR2,
                              borderRadius: BorderRadius.circular(10.0)),
                          child: Text(
                            date.day.toString(),
                            style:
                                TextStyle(color: AppColors.onDateSelectedColor),
                          )),
                      todayDayBuilder: (context, date, events) => Container(
                          margin: const EdgeInsets.all(4.0),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: AppColors.mydocumentBG_COLOR),

                              // color: AppColors.mydocumentBG_COLOR2,
                              borderRadius: BorderRadius.circular(10.0)),
                          child: Text(
                            date.day.toString(),
                            style: TextStyle(color: Colors.black),
                          )),
                    ),
                    calendarController: _controller,
                  ),
                ),
                Positioned(
                  top: screenHeight(context) * .4,
                  child: Container(
                    width: screenWidth(context),
                    height: screenHeight(context) / 2,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: <Color>[
                            AppColors.mydocumentBG_COLOR,
                            AppColors.mydocumentBG_COLOR2
                          ]),
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                      ),
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          _selectedEvents.toString() == [].toString()
                              ? Center(
                                  child: Container(
                                    margin: EdgeInsets.only(
                                      top: screenHeight(context) * .2,
                                    ),
                                    child: Text(
                                      "Please Add Reminder",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 22,
                                          color: Colors.white),
                                    ),
                                  ),
                                )
                              : SizedBox.shrink(),
                          ..._selectedEvents.map((event) => Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height:
                                      MediaQuery.of(context).size.height * .07,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(30),
                                      color: Colors.white,
                                      border: Border.all(
                                          color: AppColors.mydocumentBG_COLOR)),
                                  child: Center(
                                      child: Text(
                                    event,
                                    style: TextStyle(
                                        color: Theme.of(context).accentColor,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16),
                                  )),
                                ),
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          floatingActionButton: FloatingActionButton(
            backgroundColor: Colors.white,
            child: Icon(
              Icons.add,
              color: Theme.of(context).accentColor,
            ),
            onPressed: () {
              setState(() {
                _showAddDialog(model);
              });
            },
          ),
        );
      },
      viewModelBuilder: () => CalendarCarouselViewModel(),
    );
  }

  void _showAddDialog(CalendarCarouselViewModel model) async {
    await showDialog(
        useRootNavigator: false,
        context: context,
        builder: (context) => AlertDialog(
              title: Text("Add Reminders"),
              content: Container(
                height: screenHeight(context) * .30,
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: screenHeight(context) * .03),
                      child: DropdownButtonFormField(
                        isExpanded: true,
                        items: model.gst_types.map((value) {
                          return new DropdownMenuItem<String>(
                            value: value.reminderType,
                            child: new Text(value.reminderType.toString(),
                                overflow: TextOverflow.ellipsis),
                          );
                        }).toList(),
                        hint: Text("Please Select Type"),
                        onChanged: (value) {
                          selectedValue = value;
                          print("=====selectedValue");
                          print(selectedValue);
                        },
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: screenHeight(context) * .03),
                      child: TextField(
                        controller: _eventController,
                        decoration: InputDecoration(
                          hintText: "Title",
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: screenHeight(context) * .03),
                      child: DropdownButtonFormField(
                        isExpanded: true,
                        items: model.options.map((value) {
                          return new DropdownMenuItem<String>(
                            value: value.uId,
                            child: new Text(value.frequencyType.toString(),
                                overflow: TextOverflow.ellipsis),
                          );
                        }).toList(),
                        hint: Text("Please Select Duration"),
                        onChanged: (value) {
                          selectedDurationValue = value;
                          print("=====selectedDurationValue");
                          print(selectedDurationValue);
                        },
                      ),
                    )
                  ],
                ),
              ),
              actions: [
                FlatButton(
                  child: Text(
                    "Add",
                    style: TextStyle(
                        color: Colors.red, fontWeight: FontWeight.bold),
                  ),
                  onPressed: () {
                    if (_eventController.text.isEmpty) return;
                    setState(() async {
                      if (_events[_controller.selectedDay] != null) {
                        print("IF");
                        _events[_controller.selectedDay]
                            .add(_eventController.text);
                        setState(() {
                          print(_events);
                          var values = _events.forEach((key, value) {
                            if (key.toString() ==
                                _controller.selectedDay.toString()) {
                              _myselectedEvents = value.toList();
                              _onDaySelected(_controller.selectedDay,
                                  _myselectedEvents, _selectedEvents);
                            }
                          });
                        });
                      } else {
                        print("ELSE");
                        _events[_controller.selectedDay] = [];
                        _events[_controller.selectedDay]
                            .add(_eventController.text);

                        setState(() {
                          print(_events);
                          var values = _events.forEach((key, value) {
                            if (key.toString() ==
                                _controller.selectedDay.toString()) {
                              _myselectedEvents = value.toList();
                              _onDaySelected(_controller.selectedDay,
                                  _myselectedEvents, _selectedEvents);
                            }
                          });
                        });
                      }

                      model.setReminder(
                          _eventController.text,
                          selectedDurationValue,
                          _controller.selectedDay,
                          selectedValue);
                      prefs.setString(
                          "events", jsonEncode(encodeMap(_events)));
                      prefs = await SharedPreferences.getInstance();

                      _eventController.clear();

                      Navigator.pop(context);
                    });
                  },
                )
              ],
            ));
  }

  Widget row(DurationList cutlotLst) {
    return ListTile(
      title: Text(
        cutlotLst.frequencyType,
        style: TextStyle(
          color: Colors.black,
        ),
      ),
      subtitle: Text(cutlotLst.uId),
    );
  }
}
