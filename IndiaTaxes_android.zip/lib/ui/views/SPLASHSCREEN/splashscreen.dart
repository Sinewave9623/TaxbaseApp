import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';

class SplashScreen extends StatefulWidget {
  // String data;
  // SplashScreen({Key key, this.data}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final _storage = AuthenticationServices();
  @override
  void initState() {
    // print(widget.data);
    super.initState();
    //FocusScope.of(context).unfocus();
    Timer(Duration(seconds: 8), () {
      _storage.navigateToLoginScreen();
    });
    //_storage.navigateToCallOpenScreen(widget.data["channel"]));

    /*Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => HomeScreen())));*/
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height / 8)),

            /*Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.only(top: 100),
                child: Center(
                  child: Container(
                    height: 500,
                    width: 500,
                    child: DecoratedBox(
                        decoration: BoxDecoration(
                      image: DecorationImage(
                        image: AssetImage("assets/images/background.jpg"),
                        fit: BoxFit.cover,
                      ),
                    )),
                  ),
                ),
              ),
            ),*/
            /* Align(
          alignment: Alignment.bottomCenter,
          child: Center(
              child: Text("3Cube Communicator",
                  style: Theme.of(context).textTheme.headline4)),
        ),*/
            Container(
              //  margin: EdgeInsets.only(top: 50, left: 20, right: 20),
              child: Center(
                  child: Lottie.asset("assets/images/finance-blue.json",
                      height: 200, width: 220, animate: true)
                  /*   Image.asset(
                  'assets/images/splash_trans.gif',
                  height: 80,
                  width: 80,
                ),*/
                  ),
            ),
            Text("Attain Tax Nirvana",
                style: Theme.of(context).textTheme.headline4),

            // Padding(padding: EdgeInsets.only(top: 10)),
            //Text("Communicator", style: Theme.of(context).textTheme.headline4),
            Padding(
                padding: EdgeInsets.only(top: 20),
                child: Center(
                    child: Image.asset(
                  'assets/images/appLogo.png',
                  height: 175,
                  width: 250,
                ))),
          ],
        ),
      ),
    );
  }
}
