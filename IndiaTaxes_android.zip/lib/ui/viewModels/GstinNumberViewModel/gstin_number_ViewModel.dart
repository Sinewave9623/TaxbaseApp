import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:taxbase_general/models/GstinModel/create_gstin_responseModel.dart';
import 'package:taxbase_general/models/GstinModel/gstin_responseModel.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/generate_otp_screen.dart';
import 'package:taxbase_general/values/values.dart';

class GstinNumberViewModel extends BaseViewModel {
  //Services
  final _services = AuthenticationServices();

  var datacount = 0;

  //  init controllers
  final gstinDataController = BehaviorSubject<List<GSTINData>>();
  final isLoadingController = BehaviorSubject<bool>();
  //  Streams
  Stream<List<GSTINData>> get gstInData => gstinDataController.stream;
  Stream<bool> get isLoading => isLoadingController.stream;

  // on change
  Function(List<GSTINData>) get onGstInCountChange =>
      gstinDataController.sink.add;
  init() {
    setBusy(true);
    isLoadingController.add(false);
    print("------gstinDataController.value");
    print(gstinDataController.value);
    if (gstinDataController.value.toString() == null.toString()) {
      gstinDataController.add([]);
      print("IF");
    }

    getUserGstin();
    notifyListeners();
    setBusy(false);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    gstinDataController.close();
    super.dispose();
  }

  Future<void> getUserGstin() async {
    setBusy(true);
    isLoadingController.add(true);
    String userMobile = _services.user;
    String userToken = _services.getAccessToken;
    Map gstinMap = {"mobileno": userMobile, "token": userToken};
    GstinResponseModel result = await _services.getUserGstin(gstinMap);
    if (result.responseCode.toString() == "200") {
      datacount = result.data.length;

      gstinDataController.add(result.data);
      isLoadingController.add(false);
      notifyListeners();
      setBusy(false);
    } else {
      isLoadingController.add(false);
    }
    isLoadingController.add(false);
    print(userToken);
    notifyListeners();
    setBusy(false);
  }

  Future<void> updateGstinNumber(String uId, String gstinNumber) async {
    print(uId);
    print(gstinNumber);
    String userToken = _services.getAccessToken;
    Map gstinMap = {"uId": uId, "token": userToken, "gstin": gstinNumber};
    CreateGSTINResponseModel result =
        await _services.updateGstinNumber(gstinMap);
    if (result.responseCode.toString() == "200") {
    } else {}
  }

  Future<void> addTextfield(int count, String gstinNumber) async {
    setBusy(true);
    String userMobile = _services.user;
    String userToken = _services.getAccessToken;

    Map gstinMap = {
      "mobileno": userMobile,
      "token": userToken,
      "gstin": gstinNumber
    };
    GSTINData gstinData =
        GSTINData(gstin: gstinNumber.toString(), id: 0, mobileno: "", uId: "");
    gstinDataController.value.add(gstinData);
    CreateGSTINResponseModel result = await _services.createGstinUser(gstinMap);
    if (result.responseCode.toString() == "200") {
      getUserGstin();
    } else {}
  }

  Future<void> removeGstin(String uId) async {
     String userToken = _services.getAccessToken;
    Map gstinMap = {"uId": uId, "token": userToken};
    CreateGSTINResponseModel result =
        await _services.deleteGstinNumber(gstinMap);
    if (result.responseCode.toString() == "200") {
      getUserGstin();
    } else {}
  }
}
