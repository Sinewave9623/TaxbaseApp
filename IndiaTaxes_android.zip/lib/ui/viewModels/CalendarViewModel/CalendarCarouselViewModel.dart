import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/subjects.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:taxbase_general/models/durationModel/durationResponseModel.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_responseModel.dart';
import 'package:taxbase_general/models/notificationsModel/reminder_type_responseModel.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/generate_otp_screen.dart';

class CalendarCarouselViewModel extends BaseViewModel {
  //Services
  final _services = AuthenticationServices();

  //  init controllers
  final _titleController = BehaviorSubject<String>();
  final _descriptionController = BehaviorSubject<String>();
  //  Streams
  Stream<String> get title => _titleController.stream;
  Stream<String> get description => _descriptionController.stream;

  // on change
  Function(String) get onTitleChange => _titleController.sink.add;
  Function(String) get onDescriptionChange => _descriptionController.sink.add;

  // List<DurationList> options = [];
  List<DurationList> options = new List<DurationList>();
  List<ReminderTypeData> gst_types = new List<ReminderTypeData>();

  init() {
    setBusy(true);
    getDurationList();
    notifyListeners();
    setBusy(false);
  }

  @override
  void dispose() {
    _titleController.close();
    super.dispose();
  }

  void logoutfun(BuildContext context) {
    _services.clearAll;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => GenerateOtpScreen()),
    );
  }

  Future<void> setReminder(String event, String currentDuration,
      DateTime selectedDay, String selectedType) async {
    setBusy(true);

    String mobileNumber = _services.user;
    String date = DateFormat("yyyy-MM-dd").format(selectedDay).toString();
    String userToken = _services.getUserToken;
    print("setReminder");
    print(event);
    print(currentDuration);
    print(selectedType);
    print(DateFormat("yyyy-MM-dd").format(selectedDay));
    print("setReminder========");
    Map map = {
      "mobileno": mobileNumber.toString(),
      "type": selectedType,
      "date": date,
      "frequency": currentDuration.toString(),
      "token": userToken
    };
    ReminderResponseModel result = await _services.setReminder(map);
    if (result.responseCode.toString() == "200") {
      // _services.showErrorDialog(title: 'Success!', description: result.msg);
      notifyListeners();
      setBusy(false);
    } else {
      _services.showErrorDialog(title: 'Failed!', description: result.msg);
      notifyListeners();
      setBusy(false);
    }
    notifyListeners();
    setBusy(false);
  }

  void getDurationList() async {
    setBusy(true);
    String userToken = _services.getUserToken;

    DurationListModel result = await _services.getDurationList(userToken);
    if (result.responseCode.toString() == "200") {
      options.addAll(result.data);
      notifyListeners();
      setBusy(false);
    }

    ReminderTypeResponseModel result2 = await _services.getType(userToken);

    if (result2.responseCode.toString() == "200") {
      gst_types.addAll(result2.data);
      notifyListeners();
      setBusy(false);
    }

    setBusy(false);
  }
}
