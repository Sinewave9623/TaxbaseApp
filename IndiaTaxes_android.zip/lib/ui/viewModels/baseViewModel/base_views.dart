import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/dialog/dialog_model.dart';
import 'package:taxbase_general/services/common/connectivity_service.dart';
import 'package:taxbase_general/services/common/dialog_service.dart';
import 'package:taxbase_general/ui/widgets/error_widget.dart';
import 'package:taxbase_general/values/values.dart';

import '../../../locator.dart';

class BaseView extends StatefulWidget {
  const BaseView({Key key, this.child})
      : assert(child != null),
        super(key: key);

  final Widget child;

  @override
  _BaseViewState createState() => _BaseViewState();
}

class _BaseViewState extends State<BaseView> {
  final _dialogService = locator<DialogService>();
  final GlobalKey<ScaffoldState> _scaffoldState = GlobalKey();

  @override
  void initState() {
    _dialogService.registerDialogListener(_showDialog);
    _dialogService.registerSnackbarListener(_showSnackBar);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var connectionStatus = Provider.of<ConnectivityStatus>(context);
    if (connectionStatus == ConnectivityStatus.Offline) {
      return ErrorPopupView(
        title: "assets/images/no_internet.png",
        message: NO_INTERNET_CONNECTION_MESSAGE,
//        buttonLabel: EnableWifiLabel,
        showButton: false,
      );
    }
    return Scaffold(
      backgroundColor: Colors.white,
      key: _scaffoldState,
      body: widget.child,
    );
  }

  void _showDialog(DialogRequest request) {
    var isConfirmationDialog = request.onNegativeButtonClick != null;
    showDialog(
      context: context,
      builder: (context) => request.builder != null
          ? request.builder()
          : AlertDialog(
              title: Text(
                "${(request.title) ?? request.title}",
                style: GoogleFonts.lato(
                  fontWeight: FontWeight.w600,
                  fontSize: 20,
                  color: AppColors.primaryColorDark,
                ),
              ),
              content: Text(
                "${(request.description) ?? request.description}",
                style: GoogleFonts.lato(
                  fontWeight: FontWeight.w400,
                  fontSize: 16,
                  color: AppColors.primaryColor,
                ),
              ),
              actions: <Widget>[
                if (isConfirmationDialog)
                  FlatButton(
                    splashColor: AppColors.primaryColorDark,
                    onPressed: () {
                      if (request.onNegativeButtonClick != null) {
                        request.onNegativeButtonClick();
                      }
                      _dialogService.dialogComplete(
                        DialogResponse(confirmed: false),
                      );
                    },
                    child: Text(
                      "${(request.negativeButtonLabel).toUpperCase()}",
                      style: errorButtonStyle,
                    ),
                  ),
                FlatButton(
                  splashColor: AppColors.primaryColorDark,
                  onPressed: () {
                    if (request.onPositiveButtonClick != null) {
                      request.onPositiveButtonClick();
                    }
                    _dialogService
                        .dialogComplete(DialogResponse(confirmed: true));
                  },
                  child: Text(
                    "${(request.positiveButtonLabel).toUpperCase()}",
                    style: errorButtonStyle,
                  ),
                )
              ],
            ),
    );
  }

  _showSnackBar(String message) {
    onWidgetDidBuild(() {
      _scaffoldState.currentState.showSnackBar(
        SnackBar(
          content: Text(
            "${(message) ?? message}",
            style: GoogleFonts.lato(
              fontSize: 14.0,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
          backgroundColor: Colors.black,
        ),
      );
    });
  }
}
