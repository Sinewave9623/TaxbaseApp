import 'package:flutter/foundation.dart';

class BaseViewModel extends ChangeNotifier {
  bool _loading = false;

  bool get loading => _loading;

  bool _mounted = false;

  bool get mounted => _mounted;

  void setBusy(bool value) {
    _loading = value;
    notifyListeners();
  }

  @override
  void dispose() {
    super.dispose();
    _mounted = true;
  }
}
