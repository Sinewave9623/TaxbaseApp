import 'dart:async';

import 'package:rxdart/rxdart.dart';
import 'package:taxbase_general/constants/extensions/validators.dart';
import 'package:taxbase_general/models/OTP/get_otp_responseModel.dart';
import 'package:taxbase_general/models/OTP/tokenResponse_Model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/values/values.dart';

class GenerateOTPViewModel extends BaseViewModel {
  //  Services
  final _services = AuthenticationServices();

  // Init Controller
  final _mobilenumController = BehaviorSubject<String>();

  // Streams
  Stream<String> get mobilenumber =>
      _mobilenumController.stream.transform(mobileValidator);

  // OnChange
  Function(String) get onMobileNumChange => _mobilenumController.sink.add;

  // Button Validates
  Stream<bool> get validateOTPButton =>
      CombineLatestStream([mobilenumber], (data) => true);

  @override
  void dispose() {
    // TODO: implement dispose
    _mobilenumController.close();
    super.dispose();
  }

  init() {
    setBusy(true);
    notifyListeners();
    setBusy(false);
  }

  getTokenApi() async {
    setBusy(true);

    setBusy(false);
  }

  generateOTP(context) async {
    setBusy(true);
    String mobileNumb = _mobilenumController.value;
    if (mobileNumb != null || mobileNumb != "") {
      Map map = {
        "username": mobileNumb.toString(),
        "password": mobileNumb.toString()
      };
     
          Map otpmap = {"mobileno": mobileNumb};
          GetOtpResponseModel result = await _services.getOtp(otpmap);
          if (result.responseCode == "200") {
            _services.saveTransactionId(result.transactionId.toString());
            _services.saveAccessToken(result.access.toString());
            _services.navigateToVerifyOTPScreen(mobileNumb.toString());
          } else if (result.responseCode == "400") {
            _services.showErrorDialog(
                title: 'Failed!', description: result.msg);
          }
      } else {
        _services.showErrorDialog(
            title: 'Failed!',
            description: "Please Enter Mobile Number");
      }
      // print(result.toJson().toString());
    setBusy(false);

    }
}

