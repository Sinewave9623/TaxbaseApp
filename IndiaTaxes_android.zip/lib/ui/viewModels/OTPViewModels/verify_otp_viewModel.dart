import 'dart:convert';

import 'package:flutter/src/widgets/framework.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:rxdart/subjects.dart';
import 'package:taxbase_general/constants/extensions/validators.dart';
import 'package:taxbase_general/models/OTP/verify_otp_responseModel.dart';
import 'package:taxbase_general/models/notificationsModel/send_device_id_response_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/values/values.dart';
import 'dart:async';
// import 'package:telephony/telephony.dart';

class VerifyOTPViewModel extends BaseViewModel {
  //---- Services
  final _services = AuthenticationServices();

  //---- Init controller
  final _otpController = BehaviorSubject<String>();
  // final telephony = Telephony.instance;

  // List<SmsMessage> messages;

  // ---- STREAMS
  Stream<String> get otpnumber => _otpController.stream.transform(otpValidator);

  String auto_otpnumber = '';

  void getOTP() async {
    // messages = await telephony.getInboxSms(
    //     columns: [SmsColumn.ADDRESS, SmsColumn.BODY],
    //     filter: SmsFilter.where(SmsColumn.ADDRESS).equals("BP-TAXBAS"),
    //     sortOrder: [
    //       OrderBy(SmsColumn.ADDRESS, sort: Sort.ASC),
    //       OrderBy(SmsColumn.BODY)
    //     ]);

    // print(messages);
  }

  // --- OnChange
  Function(String) get onOTPNumChange => _otpController.sink.add;

  // BUTTON  Validates
  Stream<bool> get validateVerifyOTPButton =>
      CombineLatestStream([otpnumber], (data) => true);

  var mobileNumber;

  @override
  void dispose() {
    // TODO: implement dispose
    _otpController.close();
    super.dispose();
  }

  void printsms(String message) {
    print(message);
  }

  init(String mob) {
    // telephony.listenIncomingSms(
    //     onNewMessage: (SmsMessage message) {
    //       printsms(message.toString());
    //       // Handle message
    //     },
    //     listenInBackground: false);

    setBusy(true);
    mobileNumber = mob;
    notifyListeners();
    setBusy(false);
  }

  void verifyOTP(BuildContext context) async {
    setBusy(true);
    OneSignal.shared.setAppId(
      OPEN_SIGNAL_APP_ID,
    );
    var playerId;
    var status = await OneSignal.shared
        .getDeviceState()
        .then((value) => (playerId = value.userId));

    if (playerId != null) {
      Map notimap = {
        "mobile_no": mobileNumber.toString(),
        "device_id": playerId,
      };
      var result = await _services.createDeviceId(notimap);
    }

    String otp = _otpController.value;
    // String mobileNumber = _services.user;
    String transaction_id = _services.trans_id;
    if (otp.toString() != null) {
      Map map = {
        "mobileNumber": mobileNumber.toString(),
        "otpNumber": otp,
        "transaction_id": transaction_id,
      };
      print(map.toString());
      VerifyResponseOtpModel result = await _services.verifyOTP(map);
      if (result.responseCode == "200") {
        // _services.savePanNo(result.pan.toString());

        if (result.pan.toString() != "") {
          _services.saveUserName(result.name.toString());
          _services.saveUserPan(result.pan.toString());
          _services.saveUserAddress(result.address.toString());
          _services.saveUserAge(result.age.toString());
          _services.saveUserMobile(mobileNumber.toString());

          _services.navigateToDashboardScreen();
        } else {
          _services.navigateToUserDetailScreen(mobileNumber.toString());
        }
      } else if (result.responseCode == "404") {
        _services.showErrorDialog(title: 'Failed!', description: result.result);
      } else if (result.responseCode == "500") {
        _services.showErrorDialog(title: 'Failed!', description: result.result);
      }
      print(result.toJson().toString());
    }
    setBusy(false);
  }
}
