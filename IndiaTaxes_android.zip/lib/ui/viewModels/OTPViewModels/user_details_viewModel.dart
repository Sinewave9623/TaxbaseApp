import 'package:age/age.dart';
import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:logger/logger.dart';
import 'package:rxdart/rxdart.dart';
import 'package:rxdart/subjects.dart';
import 'package:taxbase_general/constants/extensions/validators.dart';
import 'package:taxbase_general/models/OTP/updateUserDetailsModel.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:localstorage/localstorage.dart' as local;

class UserDetailViewModel extends BaseViewModel {
  //---- Services
  final _services = AuthenticationServices();

  DateTime birthDate;
  bool isMale = true;
  bool isFeMale = false;
  bool isOther = false;

  //---- Init controller
  final userNameController = BehaviorSubject<String>();
  final birthDateController = BehaviorSubject<String>();
  final userPanNoController = BehaviorSubject<String>();
  final userAddressController = BehaviorSubject<String>();

  // ---- STREAMS
  Stream<String> get userName => userNameController.stream;
  Stream<String> get birthDateInString => birthDateController.stream;
  Stream<String> get userPanNo =>
      userPanNoController.stream.transform(validateTan);
  Stream<String> get userAddress => userAddressController.stream;

  // --- OnChange
  Function(String) get onUserNameChange => userNameController.sink.add;
  Function(String) get onBirthDateChange => birthDateController.sink.add;
  Function(String) get onuserPanNoChange => userPanNoController.sink.add;
  Function(String) get onuserAddressChange => userAddressController.sink.add;

  // BUTTON  Validates
  Stream<bool> get validateUserButton => CombineLatestStream(
      [firstName, middleName, lastName, employeePan], (data) => true);

  final firstNameController = BehaviorSubject<String>();
  Stream<String> get firstName => firstNameController.stream;
  Function(String) get onFirstNameChanged => firstNameController.sink.add;

  final middleNameController = BehaviorSubject<String>();
  Stream<String> get middleName => middleNameController.stream;
  Function(String) get onMiddleNameChanged => middleNameController.sink.add;

  final lastNameController = BehaviorSubject<String>();
  Stream<String> get lastName => lastNameController.stream;
  Function(String) get onLastNameChanged => lastNameController.sink.add;

  final genderController = BehaviorSubject<String>();
  Stream<String> get gender => genderController.stream;
  Function(String) get onGenderChanged => genderController.sink.add;

  final dobController = BehaviorSubject<String>();
  Stream<String> get dob => dobController.stream;
  Function(String) get onDobChanged => dobController.sink.add;

  final employeePanController = BehaviorSubject<String>();
  Stream<String> get employeePan => employeePanController.stream;
  Function(String) get onEmployeePanChanged => employeePanController.sink.add;

  var mobileNumber;
  AgeDuration age;

  final local.LocalStorage storageUserdetails =
      local.LocalStorage('Userdetails');
  @override
  void dispose() {
    // TODO: implement dispose
    userNameController.close();
    birthDateController.close();
    userPanNoController.close();
    userAddressController.close();
    super.dispose();
  }

  init(String mob) {
    setBusy(true);
    mobileNumber = mob;
    notifyListeners();
    setBusy(false);
  }

  void genderSelection(bool _isMale, bool _isFemale, bool _isOther) {
    if (_isMale) {
      isMale = _isMale;
      isFeMale = false;
      isOther = false;
      notifyListeners();
    }
    if (_isFemale) {
      isMale = false;
      isFeMale = _isFemale;
      isOther = false;

      notifyListeners();
    }
    if (_isOther) {
      isMale = false;
      isFeMale = false;
      isOther = _isOther;
      notifyListeners();
    }
  }

  Future<void> saveUserDetails() async {
    setBusy(true);
    String userToken = _services.getUserToken;
    String userName = firstNameController.value.toString() +
        " " +
        middleNameController.value.toString() +
        " " +
        lastNameController.value.toString();
    String userAddress = userAddressController.value.toString();
    String userPanNo = employeePanController.value.toString();
    String userBirthDate = dobController.value.toString();

    Map map = {
      "mobileNumber": mobileNumber.toString(),
      "address": userAddress ?? "",
      "pan": userPanNo,
      "name": userName,
      "age": userBirthDate,
      "token": "Bearer " + userToken
    };
    if (userName.toString() != "" &&
        userName.toString() != null &&
        userAddress.toString() != "" &&
        userAddress.toString() != null &&
        userPanNo.toString() != "" &&
        userPanNo.toString() != null &&
        age.toString() != "" &&
        age.toString() != null) {
      UpdateUserDetailsModel result = await _services.updateUser(map);
      if (result.responseCode == "200") {
        setBusy(false);

        if (isMale) {
          _services.saveGender("Male");
        } else if (isFeMale) {
          _services.saveGender("FeMale");
        } else {
          _services.saveGender("Other");
        }
        // _services.savePanNo(result.pan.toString());
        _services.saveUserName(userName.toString());
        _services.saveUserFirstName(firstNameController.value.toString());
        _services.saveUserMiddleName(middleNameController.value.toString());
        _services.saveUserLastName(lastNameController.value.toString());
        _services.saveUserPan(userPanNo.toString());
        _services.saveUserAddress(userAddress.toString());
        _services.saveUserAge(age.toString());
        _services.saveUserBirthDate(userBirthDate.toString());
        _services.saveUserMobile(mobileNumber.toString());
      } else if (result.responseCode == "500") {
        setBusy(false);
        _services.showErrorDialog(title: 'Failed!', description: result.msg);
      }
      print(result.toJson().toString());
      setBusy(false);

      // final details = UserDetailsModel(
      //   userName: userNameController.value.toString(),
      //   userPanNo: userPanNoController.value.toString(),
      //   userAge: ageController.value.toString(),
      //   userAddress: userAddressController.value.toString(),
      // );
      _services.saveUserMobile(mobileNumber.toString());

      // storageUserdetails.setItem("Userdetails", details.toJSONEncodable());
      _services.navigateToDashboardScreen();
    } else {
      setBusy(false);
      _services.showErrorDialog(
          title: 'Failed!', description: "Please Fill The Details");
    }
  }

  Future<void> getBirthDate(BuildContext context) async {
    final datePick = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime(1900),
        lastDate: new DateTime(2025));
    if (datePick != null && datePick != birthDate) {
      birthDate = datePick;
      Logger().wtf(birthDate);
      var date = DateFormat('yyyy-MM-dd').format(birthDate);
      Logger().e(date);
      dobController.add(((date)));
      age = Age.dateDifference(
          fromDate: birthDate, toDate: DateTime.now(), includeToDate: false);
      print(age.years.toString());
      notifyListeners();
    }
  }
}
