import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:taxbase_general/models/GstinModel/gstin_responseModel.dart';
import 'package:taxbase_general/models/RequestOtpSineWave/requeset_otp_model.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/generate_otp_screen.dart';
import 'package:taxbase_general/values/values.dart';

class ViewReturnsViewModel extends BaseViewModel {
  //Services
  final _services = AuthenticationServices();

  // Init Controller
  final _gstinNoController = BehaviorSubject<String>();
  final _userNameController = BehaviorSubject<String>();
  final _userOTPController = BehaviorSubject<String>();
  final isLoadingController = BehaviorSubject<bool>();
  final gstinDataController = BehaviorSubject<GstinResponseModel>();
  final gstinDataListController = BehaviorSubject<List<GSTINData>>();
  // Streams
  Stream<String> get gstinNo => _gstinNoController.stream;
  Stream<String> get userName => _userNameController.stream;
  Stream<String> get userOTP => _userOTPController.stream;
  Stream<bool> get isLoading => isLoadingController.stream;
  Stream<GstinResponseModel> get gstInData => gstinDataController.stream;
  Stream<List<GSTINData>> get gstList => gstinDataListController.stream;
  // OnChange
  Function(String) get onGstInNoChange => _gstinNoController.sink.add;
  Function(String) get onUserNameChange => _userNameController.sink.add;
  Function(String) get onUserOTPChange => _userOTPController.sink.add;

  // Button Validates
  Stream<bool> get generateOTPButton =>
      CombineLatestStream([gstinNo, userName], (data) => true);

  Stream<bool> get validateOTPButton =>
      CombineLatestStream([userOTP], (data) => true);

  bool isEanbled = false;

  init() {
    setBusy(true);
    isLoadingController.add(false);
    _gstinNoController.add("27AAGCS3463G1Z9");
    _userNameController.add("SRS_27820016472");
    print("GST  AUTH SCREEE*/EE*****n*******");
    getGstinNumbers();
    notifyListeners();
    setBusy(false);
  }

  @override
  void dispose() {
    gstinDataListController.close();
    super.dispose();
  }

  Future<void> requestForOtp(String selectedGstin) async {
    setBusy(true);
    Map map = {
      "gstin": selectedGstin.toString(),
      "username": _userNameController.value.toString(),
      "customer_id": CUSTOMER_ID,
      "ip_address": "",
      "hkey": HKEY,
      "lkey": LKEY,
    };
    print(map);
    RequestOTPSineWaveModel result = await _services.requestForOtp(map);
    print("result========================================");
    print(result);

    if (result.statusCd == "1") {
      isEanbled = true;
    } else if (result.statusCd == "0") {
      isEanbled = false;
      _services.showErrorDialog(
          title: 'Failed!', description: "Failed To Send OTP");
      setBusy(false);
    } else {
      isEanbled = false;
      // _services.clearAll;
      // _services.navigateToLoginScreen();
      setBusy(false);
    }
    setBusy(false);
    notifyListeners();
  }

  Future<void> verifyOtp(String selectedGstin) async {
    setBusy(true);

    String gstinNo = selectedGstin.toString();
    String username = _userNameController.value.toString();
    Map map = {
      "gstin": gstinNo,
      "username": username,
      "customer_id": CUSTOMER_ID,
      "ip_address": "",
      "hkey": HKEY,
      "lkey": LKEY,
      "otp": _userOTPController.value.toString(),
    };
    print(map);
    RequestOTPSineWaveModel result = await _services.requestForVerifyOtp(map);
    if (result.statusCd == "1") {
      _services.saveGstInNo(gstinNo);
      _services.saveSineWaveusername(username);
      _services.navigateToViewTrackReturnsAfterOTP(gstinNo);
      setBusy(false);
    } else if (result.statusCd == "0") {
      isEanbled = false;
      _services.showErrorDialog(
          title: 'Failed!', description: "Failed To Send OTP");
      setBusy(false);
    } else {
      isEanbled = false;
      // _services.clearAll;
      // _services.navigateToLoginScreen();
      setBusy(false);
    }
    setBusy(false);
    notifyListeners();
  }

  Future<void> getGstinNumbers() async {
    setBusy(true);
    isLoadingController.add(true);
    String userMobile = _services.user;
    String userToken = _services.getAccessToken;
    Map gstinMap = {"mobileno": userMobile, "token": userToken};
    GstinResponseModel result = await _services.getUserGstin(gstinMap);
    if (result.responseCode.toString() == "200") {
      gstinDataController.add(result);
      gstinDataListController.add(result.data);
      isLoadingController.add(false);
      notifyListeners();
      setBusy(false);
    } else {
      isLoadingController.add(false);
    }
    isLoadingController.add(false);
    print(userToken);
    notifyListeners();
    setBusy(false);
  }
}
