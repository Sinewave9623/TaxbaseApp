import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:rxdart/rxdart.dart';
import 'package:taxbase_general/models/returnsModel/all_returns_model.dart';
import 'package:taxbase_general/models/returnsModel/create_returnStatusModel.dart';
import 'package:taxbase_general/models/returnsModel/read_gstinDataModel.dart';
import 'package:taxbase_general/models/returnsModel/view_track_return_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/values/values.dart';

class ViewTrackReturnsViewModel extends BaseViewModel {
  //Services
  final _services = AuthenticationServices();
  AllReturnsModel allReturnsModel;
  AllReturnsModel saveToAPiReturnsModel;
  ReadGstinDataModel readGstinDataModel;
  ViewTrackReturnsModel viewTrackReturnsModel;

  List<Efiledlist> filteredData = [];
  List<Gstdata> filteredData1 = [];
  List<Efiledlist> saveToAPi = [];

  bool isGovernData = false;

  var ret_period = DateTime.now().toString().substring(0, 4);
  var now = DateTime.now();
  var minus = 0;
  var currentYear;

  // Init Controller
  final _isLoadedGovController = BehaviorSubject<int>();
  final _isLoadedController = BehaviorSubject<int>();
  final _yearsController = BehaviorSubject<YearModel>();
  final _gstinNoController = BehaviorSubject<String>();
  // Streams
  Stream<int> get isGovLoaded => _isLoadedGovController.stream;
  Stream<int> get isLoaded => _isLoadedController.stream;
  Stream<YearModel> get yearModel => _yearsController.stream;
  Stream<String> get gstinNo => _gstinNoController.stream;

  // OnChange

  // Button Validates

  // Stream<bool> get validateOTPButton =>
  //     CombineLatestStream([userOTP], (data) => true);

  bool isEanbled = false;
  BuildContext ctx;
  init( context) {
    setBusy(true);

    ctx = context;
    _isLoadedGovController.add(0);
    if (now.month <= 3) {
      minus = 1;
    }
    currentYear = DateTime(DateTime.now().year - minus);
    getFinancialYear();
    var final_period = currentYear.year.toString() + "-" + ret_period;
    getGSTReturnStatus(final_period);
    notifyListeners();
    setBusy(false);
  }

  @override
  void dispose() {
    super.dispose();
  }

  getFinancialYear() async {
    String token = _services.getUserToken;
    Logger().e(token);
    YearModel result = await _services.getFinancialYears(token);
    if (result.responseCode == "200") {
      _yearsController.add(result);
      print("result======");
      print(result);
    } else if (result.responseCode == "401") {
      _services.clearAll;
      _services.navigateToLoginScreen();
    } else {
      _services.showErrorDialog(
          title: 'Failed!', description: "Not able load Financial Years");
    }
  }

  Future<void> getTrackReturns(String selectedYear) async {
    setBusy(true);
    String token = _services.getAccessToken;
    _isLoadedGovController.add(0);
    filteredData.clear();
    String gstinNo = _services.getGstInNo;
    String userName = _services.getSineWaveUserName;
    _gstinNoController.add(_services.getGstInNo);
    print("===========getTrackReturns=============selectedYear");
    var ret_year = selectedYear.split('-');
    var new_selectedYear = ret_year[0] + "-" + ret_year[1].substring(2, 4);
    print(new_selectedYear);

    Map map = {
      "gstin": gstinNo.toString(),
      "username": userName.toString(),
      "customer_id": CUSTOMER_ID,
      "ip_address": "",
      "hkey": HKEY,
      "lkey": LKEY,
      "ret_period": new_selectedYear
    };
    ViewTrackReturnsModel result = await _services.viewTackReturn(map);
    if (result.statusCd.toString() == "1") {
      var saveDate = DateTime.now().toString().substring(0,10);
       _services.saveDate(saveDate);
      Map b = jsonDecode((result.message));
      viewTrackReturnsModel = result;
      allReturnsModel = AllReturnsModel.fromJson(b);
      filteredData.addAll(allReturnsModel.efiledlist);
      Logger().wtf(allReturnsModel.efiledlist.toList());
      saveToAPi.addAll(allReturnsModel.efiledlist);

      // saveToAPiReturnsModel = AllReturnsModel(
      //   gstin: gstinNo,
      //   retPeriod: new_selectedYear,
      //   efiledlist: saveToAPi,
      // );
      // Logger().e(saveToAPiReturnsModel.toJson());

      Map map = {
        "gstin": gstinNo,
        "year": new_selectedYear,
        "data": saveToAPi,
        "token": token,
      };
      CreateReturnStatusModel createResult =
          await _services.createReturnStatus(map);

      _isLoadedGovController.add(1);

    } else if (result.statusCd.toString() == "0") {
      Map refreshMap = {
        "gstin": gstinNo.toString(),
        "username": userName.toString(),
        "customer_id": CUSTOMER_ID,
        "hkey": HKEY,
        "lkey": LKEY,
      };
      ViewTrackReturnsModel refreshResult =
          await _services.requestForRefreshToken(refreshMap);
      if (refreshResult.statusCd.toString() == "1") {
        ViewTrackReturnsModel result = await _services.viewTackReturn(map);
        if (result.statusCd.toString() == "1") {
          var saveDate = DateTime.now().toString().substring(0,10);
       _services.saveDate(saveDate);
          Map b = jsonDecode((result.message));
          viewTrackReturnsModel = result;
          allReturnsModel = AllReturnsModel.fromJson(b);
          Logger().wtf(allReturnsModel.toJson());

          saveToAPi.addAll(allReturnsModel.efiledlist);

          // saveToAPiReturnsModel = AllReturnsModel(
          //   gstin: gstinNo,
          //   retPeriod: new_selectedYear,
          //   efiledlist: saveToAPi,
          // );

          // Logger().e(saveToAPiReturnsModel.toJson());

          Map map = {
            "gstin": gstinNo,
            "year": new_selectedYear,
            "data": saveToAPi,
            "token": token,
          };

          CreateReturnStatusModel createResult =
              await _services.createReturnStatus(map);

          filteredData.addAll(allReturnsModel.efiledlist);
          _isLoadedGovController.add(1);
        } else if (result.statusCd.toString() == "0") {
          viewTrackReturnsModel = result;
          _isLoadedGovController.add(2);
        }
      } else if (refreshResult.isAuth.toString() == "false") {
        print("========+++++++ FALSE");
        _isLoadedGovController.add(2);
        _services.navigateToViewReturnScreen();
      }
    }
    notifyListeners();
    setBusy(false);
  }

  getGSTReturnStatus(String final_period) async {
    setBusy(true);
    filteredData1.clear();
    String gstin = _services.getGstInNo;

    print("gstin");
    print(gstin);
    String year = final_period;
    String token = _services.getAccessToken;
    _gstinNoController.add(gstin);
     var ret_year = final_period.split('-');
    var new_selectedYear = ret_year[0] + "-" + ret_year[1].substring(2, 4);

    if (gstin.toString() != "null") {
          Map map = {
      "gstin": gstin.toString(),
      "year": new_selectedYear.toString(),
      "token": token,
    };

    var savedDate = _services.getDate;
    if(savedDate.toString() == DateTime.now().toString().substring(0,10) ){
        ReadGstinDataModel result = await _services.getReturnStatusTech(map);
      if (result.responseCode == "200") {
        isGovernData = false;
        var saveDate = DateTime.now().toString().substring(0,10);
          _services.saveDate(saveDate);
         
        _isLoadedController.add(0);
        readGstinDataModel = result;
        Logger().e(result.readGstData);
        for (int i = 0; i < result.readGstData[0].gstdata.length; i++) {
          filteredData1.add(result.readGstData[0].gstdata[i]);
        }
        Logger().wtf(filteredData1);
      } else if (result.responseCode == "400") {
        getTrackReturns(final_period);
      }
    }else{

       getTrackReturns(final_period);


    }
      
    } else {
      Timer(Duration(seconds: 0), (){

      _services.navigateToViewReturnScreen();
      });
    }


    notifyListeners();
    setBusy(true);
  }
}
