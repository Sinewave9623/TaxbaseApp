import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:rxdart/rxdart.dart';
import 'package:taxbase_general/models/returnsModel/returns_model.dart';
import 'package:taxbase_general/models/returnsModel/year_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/ui/views/OTPSCREEN/generate_otp_screen.dart';
import 'package:taxbase_general/values/values.dart';

class DashboardViewModel extends BaseViewModel {
  //Services
  final _services = AuthenticationServices();


  //  init controllers
  final userNameController = BehaviorSubject<String>();
  final _yearsController = BehaviorSubject<YearModel>();
  final _gstReturnController = BehaviorSubject<List<GSTdata>>();
  //  Streams
  Stream<String> get userName => userNameController.stream;
  Stream<List<GSTdata>> get gstReturn => _gstReturnController.stream;
  Stream<YearModel> get yearModel => _yearsController.stream;

  // on change
  Function(String) get onUserNameChange => userNameController.sink.add;
  init() async {
  

    setBusy(true);
    notifyListeners();
    getUserDetails();
    // getCustomerReturn();
    getFinancialYear();
    setBusy(false);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    userNameController.close();
    super.dispose();
  }

  void logoutfun(BuildContext context) {
    _services.clearAll;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => GenerateOtpScreen()),
    );
  }

  getFinancialYear() async {
    String token = _services.getUserToken;
    Logger().e(token);
    var result = await _services.getFinancialYears(token);
    Logger().wtf(result.responseCode);
    if (result.responseCode == "200") {
      _yearsController.add(result);
    } else if (result.responseCode.toString() == "401") {
      _services.clearAll;
      _services.navigateToLoginScreen();
      notifyListeners();
      setBusy(false);
    } else {
      _services.showErrorDialog(
          title: 'Failed!', description: "Not able load Financial Years");
    }
  }

  getCustomerReturn() async {
    setBusy(true);
    String panNumber = _services.getUserPan;
    String token = _services.getAccessToken;
    Map request = {"pan": panNumber.toString()};
    Logger().i(request);
    ReturnsModel result = await _services.getAllReturns(request, token);
    if (result.responseCode == "200") {
      if (result.gSTdata.isEmpty &&
          result.tDSdata.isEmpty &&
          result.iTRdata.isEmpty) {
      } else {}

      _gstReturnController.add(result.gSTdata);
    } else if (result.responseCode.toString() == "401") {
      _services.showErrorDialog(
          title: 'Failed!',
          description: "Session Expired",
          onPositiveButtonClick: () {
            _services.clearAll;
            _services.navigateToLoginScreen();
          });
    } else {
      // _services.showErrorDialog(
      //     title: "Failed!",
      //     description: result.msg,
      //     onPositiveButtonClick: () {
      //       // _services.clearAll;
      //       // _services.navigateToLoginScreen();
      //     });
    }
  }

  navigateToGSTReminder() {
    _services.navigateToGstReminderScreen();
  }

  void navigateToTaxCalculatorScreen() {
    _services.navigateToTaxCalculationScreen();
  }

  void navigateToProfileScreen() {
    _services.navigateToProfileScreen();
  }

  void navigateToViewReturnScreen() {
    print("navigateToViewReturnScreen");
    print(_yearsController.value.toString());
    _services.navigateToViewTrackReturns();
    // _services.navigateToViewReturnnoScreen();
    // _services.navigateToViewReturnScreen(
    //     _yearsController.value, _gstReturnController.value);
  }

  Future<void> getUserDetails() async {
    OneSignal.shared.setAppId(
      OPEN_SIGNAL_APP_ID,
    );
    var playerId;
    var status = await OneSignal.shared
        .getDeviceState()
        .then((value) => (playerId = value.userId));

    String name = _services.getUserName;
    String age = _services.getUserAge;
    String address = _services.getUserAddress;
    String pan = _services.getUserPan;
    String mobile = _services.user;
    userNameController.add(name.toUpperCase());
    if (playerId != null) {
      Map notimap = {
        "mobile_no": mobile.toString(),
        "device_id": playerId,
      };
      var result = await _services.createDeviceId(notimap);
      Logger().e(result.responseCode);
      if (result.responseCode == "200") {
      } else if (result.responseCode.toString() == "401") {
        _services.clearAll;
        _services.navigateToLoginScreen();
      }
    }
  }

  void navigateToGSTINNumberScreen() {
    _services.navigateToGSTINNUMBERScreen();
  }
}
