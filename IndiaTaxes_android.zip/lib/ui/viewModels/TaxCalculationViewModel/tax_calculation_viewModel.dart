import 'dart:async';
import 'dart:convert';
import 'dart:core';
import 'dart:io';

import 'package:age/age.dart';
import 'package:date_time_picker/date_time_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_json_widget/flutter_json_widget.dart';
import 'package:logger/logger.dart';
import 'package:rxdart/rxdart.dart';
import 'package:taxbase_general/constants/extensions/validators.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/ITR_Information_model/itr_information_model.dart';
import 'package:taxbase_general/models/StateModel/states.dart';
import 'package:taxbase_general/models/jsonModel/jsonModel.dart';
import 'package:taxbase_general/models/sinewaveModel/calculate_tax_response_model.dart';
import 'package:taxbase_general/models/sinewaveModel/form_16_model.dart';
import 'package:taxbase_general/models/sinewaveModel/get_heads_model.dart';
import 'package:taxbase_general/models/sinewaveModel/get_token_model.dart';
import 'package:taxbase_general/models/sinewaveModel/head_income_model.dart';
import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
import 'package:taxbase_general/services/auth_services/auth_services.dart';
import 'package:taxbase_general/ui/viewModels/baseViewModel/baseviewModel.dart';
import 'package:taxbase_general/models/sinewaveModel/storage_model.dart';
import 'package:taxbase_general/ui/views/ViewJson/viewJsonScreen.dart';
import 'package:taxbase_general/ui/widgets/tax_calculator_dialog.dart';
import 'package:taxbase_general/values/values.dart';

class TaxCalculationViewModel extends BaseViewModel {
  //!Services
  final _services = AuthenticationServices();
  Logger logger = Logger();
  File document;
  final _grossTotalIncomeController = BehaviorSubject<String>();
  var grosstotalincome;
  int age;
  AgeDuration age1;
  BuildContext ctx;
  String userDob;
  //! Init Controller

  final _t80coutController = BehaviorSubject<String>();
  final taxSurchargeController = BehaviorSubject<String>();
  final lessRebate87AController = BehaviorSubject<String>();
  final surchargeController = BehaviorSubject<String>();
  final educationCessController = BehaviorSubject<String>();
  final taxPayableContrller = BehaviorSubject<String>();
  final balancePayableController = BehaviorSubject<String>();
  final taxPayableRefundableController = BehaviorSubject<String>();
  final _incomeTaxController = BehaviorSubject<String>();
  final t234AController = BehaviorSubject<String>();
  final t234BController = BehaviorSubject<String>();
  final t234CController = BehaviorSubject<String>();
  final total234Controller = BehaviorSubject<String>();
  final normalTaxController = BehaviorSubject<String>();
  final specialTaxController = BehaviorSubject<String>();
  final taxableIncomeController = BehaviorSubject<String>();
  final totalIncomeController = BehaviorSubject<String>();

// ^ basic details
  final filingDateController = BehaviorSubject<String>();
  final dueDateController = BehaviorSubject<String>();
  final taxMethodController = BehaviorSubject<String>();
  final residencyStatusController = BehaviorSubject<String>();
  final selectedYearController = BehaviorSubject<String>();
  final selectedITRController = BehaviorSubject<String>();
  final selectedDomesticCompanyController = BehaviorSubject<String>();
  var filingdate;
  var duedate;
  var taxmethod;
  var residencystatus;
  var selectedyear;
  var selecteditr;
  var selecteddomesticcompany;

  final firstNameController = BehaviorSubject<String>();
  final middleNameController = BehaviorSubject<String>();
  final lastNameController = BehaviorSubject<String>();
  final genderController = BehaviorSubject<String>();
  final dobController = BehaviorSubject<String>();
  final employeePanController = BehaviorSubject<String>();
  final fatherNameController = BehaviorSubject<String>();
  final flatNumberController = BehaviorSubject<String>();
  final premiseNameController = BehaviorSubject<String>();
  final streetNameController = BehaviorSubject<String>();
  final areaController = BehaviorSubject<String>();
  final townController = BehaviorSubject<String>();
  final pinController = BehaviorSubject<String>();
  final stateController = BehaviorSubject<String>();
  final countryController = BehaviorSubject<String>();
  final mobileController = BehaviorSubject<String>();
  final aadharController = BehaviorSubject<String>();
  final emailController = BehaviorSubject<String>();

  // ^ step 1 salary step
  final employerNameController = BehaviorSubject<String>();
  final employerGenderController = BehaviorSubject<String>();
  final employerfNoController = BehaviorSubject<String>();
  final employerPremisesNoController = BehaviorSubject<String>();
  final employerStreetNameController = BehaviorSubject<String>();
  final employerLocalityController = BehaviorSubject<String>();
  final employerCityController = BehaviorSubject<String>();
  final employerPinController = BehaviorSubject<String>();
  final employerStateController = BehaviorSubject<String>();
  final employerCountryController = BehaviorSubject<String>();
  final employerTanController = BehaviorSubject<String>();
  final employerTypeController = BehaviorSubject<String>();
  final employerSalaryBy17Controller = BehaviorSubject<String>();
  final employerBasicController = BehaviorSubject<dynamic>();
  final employerHRAController = BehaviorSubject<dynamic>();
  final employerLATAController = BehaviorSubject<dynamic>();
  final employerAllowancePerquisitesController = BehaviorSubject<dynamic>();
  final employerTanDeducterController = BehaviorSubject<String>();
  final employerPanDeducterController = BehaviorSubject<String>();

  final employerOtherController = BehaviorSubject<List<int>>();
  final employerPerquistesController = BehaviorSubject<List<int>>();
  final employerProfitInLieuController = BehaviorSubject<List<int>>();
  final employerExemptAllowancesController = BehaviorSubject<List<int>>();
  final employerExemptAllowancesDescriptionController =
      BehaviorSubject<List<String>>();

  final _employerBalanceController = BehaviorSubject<String>();
  final employerEntertainementController = BehaviorSubject<String>();
  final _employerStdDeductionController = BehaviorSubject<String>();
  final employerProfTaxController = BehaviorSubject<dynamic>.seeded(0);
  final totalSalaryController = BehaviorSubject<String>.seeded("0");

  final _otherDropdownController = BehaviorSubject<List<Others>>();
  final _perquisitesDropdownController = BehaviorSubject<List<Perquisites>>();
  final _lieuDropdownController = BehaviorSubject<List<Lieu>>();
  final _exemptAllwnropdownController = BehaviorSubject<List<ExemptAllwn>>();
  final _form16DataController = BehaviorSubject<Form16Model>();
  final fileController = BehaviorSubject<File>();
  final reliefController = BehaviorSubject<String>();
  final isAnyOtherController = BehaviorSubject<List<bool>>();

  final employerOtherStringController = BehaviorSubject<List<dynamic>>();
  final employerValueOfPerquisitesStringController =
      BehaviorSubject<List<dynamic>>();
  final employeLieuStringController = BehaviorSubject<List<dynamic>>();
  final employeExemptAllwnStringController = BehaviorSubject<List<dynamic>>();
  final employerExemptAllowanceStringController =
      BehaviorSubject<List<dynamic>>();

  var employername;
  var employertan;
  var employercategory;
  var employerbasic;
  var employerhra;
  var employerlata;
  var employerallowanceperquisites;
  var employerprofessionaltax;
  var relief;

  // ^ step 2 house property
  final interestPaidHPController = BehaviorSubject<dynamic>();
  final rendtReceivedHPController = BehaviorSubject<dynamic>();
  final housePropertyTypeController = BehaviorSubject<String>();
  final muncipalTaxController = BehaviorSubject<dynamic>();
  final inrealisedRentController = BehaviorSubject<dynamic>();
  final anualValueController = BehaviorSubject<dynamic>();
  final totalHousPartyController = BehaviorSubject<String>.seeded("0");

  // ^ step 3  Business
  final profitFromFirmController = BehaviorSubject<dynamic>();
  final remunerationFromFirmController = BehaviorSubject<dynamic>();
  final interestFromFirmController = BehaviorSubject<dynamic>();
  final profitFromBusinessController = BehaviorSubject<dynamic>();
  final nameOfBusinessController = BehaviorSubject<String>();
  final totalBusinessIncomeController = BehaviorSubject<String>.seeded("0");

  // ^step 4 Capital Gain
  final totalCapitalGainController = BehaviorSubject<String>.seeded("0");

  // ! STCG NORMAL
  final stcgNormal1506Controller = BehaviorSubject<dynamic>();
  final stcgNormal1509Controller = BehaviorSubject<dynamic>();
  final stcgNormal1512Controller = BehaviorSubject<dynamic>();
  final stcgNormal1503Controller = BehaviorSubject<dynamic>();
  final stcgNormal3103Controller = BehaviorSubject<dynamic>();
  final _totalStcgNormalController = BehaviorSubject<String>();

  var stcgnormal1506;
  var stcgnormal1509;
  var stcgnormal1512;
  var stcgnormal1503;
  var stcgnormal3103;

  // ! STCG 111A
  final stcg111A1506Controller = BehaviorSubject<dynamic>();
  final stcg111A1509Controller = BehaviorSubject<dynamic>();
  final stcg111A1512Controller = BehaviorSubject<dynamic>();
  final stcg111A1503Controller = BehaviorSubject<dynamic>();
  final stcg111A3103Controller = BehaviorSubject<dynamic>();
  final _totalStcg111AController = BehaviorSubject<String>();

  var stcg111a1506;
  var stcg111a1509;
  var stcg111a1512;
  var stcg111a1503;
  var stcg111a3103;

  // ! LTCG 112A
  final ltcg112A1506Controller = BehaviorSubject<dynamic>();
  final ltcg112A1509Controller = BehaviorSubject<dynamic>();
  final ltcg112A1512Controller = BehaviorSubject<dynamic>();
  final ltcg112A1503Controller = BehaviorSubject<dynamic>();
  final ltcg112A3103Controller = BehaviorSubject<dynamic>();
  final totalLtcg112AController = BehaviorSubject<String>();

  var ltcg112a1506;
  var ltcg112a1509;
  var ltcg112a1512;
  var ltcg112a1503;
  var ltcg112a3103;

  // ! LTCG 10
  final ltcg101506Controller = BehaviorSubject<dynamic>();
  final ltcg101509Controller = BehaviorSubject<dynamic>();
  final ltcg101512Controller = BehaviorSubject<dynamic>();
  final ltcg101503Controller = BehaviorSubject<dynamic>();
  final ltcg103103Controller = BehaviorSubject<dynamic>();
  final totalLtcg10Controller = BehaviorSubject<String>();

  var ltcg10_1506;
  var ltcg10_1509;
  var ltcg10_1512;
  var ltcg10_1503;
  var ltcg10_3103;

  // ! LTCG 20
  final ltcg201506Controller = BehaviorSubject<dynamic>();
  final ltcg201509Controller = BehaviorSubject<dynamic>();
  final ltcg201512Controller = BehaviorSubject<dynamic>();
  final ltcg201503Controller = BehaviorSubject<dynamic>();
  final ltcg203103Controller = BehaviorSubject<dynamic>();
  final _totalLtcg20Controller = BehaviorSubject<String>();

  var ltcg20_1506;
  var ltcg20_1509;
  var ltcg20_1512;
  var ltcg20_1503;
  var ltcg20_3103;

  // ^ step 5 other Sources
  final interestFromBankDepositController = BehaviorSubject<dynamic>();
  final interestFromSavingController = BehaviorSubject<dynamic>();
  final otherIncomeController = BehaviorSubject<List<dynamic>>();

  final interestTaxIncomeController = BehaviorSubject<dynamic>();
  final pensionReceivedController = BehaviorSubject<dynamic>();
  final otherSourceDeduction57Controller = BehaviorSubject<dynamic>();
  final totalOtherSourcersController = BehaviorSubject<String>.seeded("0");

  var interestfrombank;
  var interestfromsaving;
  var otherincome;
  var lottery_1506;
  var lottery_1509;
  var lottery_1512;
  var lottery_1503;
  var lottery_3103;

  // ^ step 6 special income
  final divident1506Controller = BehaviorSubject<dynamic>();
  final divident1509Controller = BehaviorSubject<dynamic>();
  final divident1512Controller = BehaviorSubject<dynamic>();
  final divident1503Controller = BehaviorSubject<dynamic>();
  final divident3103Controller = BehaviorSubject<dynamic>();
  final lottery1506Controller = BehaviorSubject<dynamic>();
  final lottery1509Controller = BehaviorSubject<dynamic>();
  final lottery1512Controller = BehaviorSubject<dynamic>();
  final lottery1503Controller = BehaviorSubject<dynamic>();
  final lottery3103Controller = BehaviorSubject<dynamic>();
  final _totalLotteryController = BehaviorSubject<String>();
  final totalDividentController = BehaviorSubject<String>.seeded("0");

  var divident_1506;
  var divident_1509;
  var divident_1512;
  var divident_1503;
  var divident_3103;
  // ^ step 7 loss and bf
  final lossBfAdjustedController = BehaviorSubject<String>.seeded("0");

  var lossBfAdjusted;

  // ^ step 8 deductions
  final licDeductionController = BehaviorSubject<dynamic>();
  final licLimitDeductionController = BehaviorSubject<dynamic>();
  final pfDeductionController = BehaviorSubject<dynamic>();
  final hlDeductionController = BehaviorSubject<dynamic>();
  final publicPfDeductionController = BehaviorSubject<dynamic>();
  final nscInterestDeductionController = BehaviorSubject<dynamic>();
  final nscDepositsDeductionController = BehaviorSubject<dynamic>();
  final educationExpensesDeductionController = BehaviorSubject<dynamic>();
  final certainFundsDeductionController = BehaviorSubject<dynamic>();
  final groupInsuranceDeductionController = BehaviorSubject<dynamic>();
  final mutualFundsDeductionController = BehaviorSubject<dynamic>();
  final totalDeductionT80Controller = BehaviorSubject<String>();
  final usertotalDeductionT80Controller = BehaviorSubject<String>();
  final selfController = BehaviorSubject<bool>();
  final parentController = BehaviorSubject<bool>();
  final parentAgeController = BehaviorSubject<bool>();
  final severeController = BehaviorSubject<bool>();
  final handicapController = BehaviorSubject<bool>();
  final interestForHigherEduController = BehaviorSubject<dynamic>();
  final donation100Controller = BehaviorSubject<dynamic>();
  final donation50Controller = BehaviorSubject<dynamic>();
  final _adjustedGtiController = BehaviorSubject<String>();
  final _qualifyingAmountController = BehaviorSubject<String>();
  final rentPaidController = BehaviorSubject<String>();
  final _80GController = BehaviorSubject<String>();
  final totalDeductionUnderChapter6 = BehaviorSubject<String>();

  final deduction80ccd1Controller = BehaviorSubject<dynamic>();
  final deduction80cccController = BehaviorSubject<dynamic>();
  final deductionTotalof80Controller = BehaviorSubject<dynamic>();
  final deduction80ccd1bController = BehaviorSubject<dynamic>();
  final deduction80ccd2Controller = BehaviorSubject<dynamic>();

  final selfMediclaimController = BehaviorSubject<dynamic>();
  final selfHealthcheckupController = BehaviorSubject<dynamic>();
  final selfMedicalExpenditureController = BehaviorSubject<dynamic>();
  final medicalInsuranceController = BehaviorSubject<dynamic>();

  final parentMediclaimController = BehaviorSubject<dynamic>();
  final parentHealthcheckupController = BehaviorSubject<dynamic>();
  final parentMedicalExpenditureController = BehaviorSubject<dynamic>();
  final parentMedicalInsuranceController = BehaviorSubject<dynamic>();

  final senior80ddbController = BehaviorSubject<bool>();
  final medical80ddbController = BehaviorSubject<dynamic>();

  final first80EEController = BehaviorSubject<bool>();
  final withoutLimitController = BehaviorSubject<bool>();
  final houseProperty80EEController = BehaviorSubject<dynamic>();
  final houseProperty80EEAController = BehaviorSubject<dynamic>();
  final houseProperty80EEBController = BehaviorSubject<dynamic>();
  final political80GGCController = BehaviorSubject<dynamic>();
  final deduction80TTAController = BehaviorSubject<dynamic>();
  final deduction80TTBController = BehaviorSubject<dynamic>();

  final certain100doneeNameController = BehaviorSubject<List<dynamic>>();
  final certain100AddressController = BehaviorSubject<List<dynamic>>();
  final certain100CityController = BehaviorSubject<List<dynamic>>();
  final certain100StateController = BehaviorSubject<List<dynamic>>();
  final certain100PincodeController = BehaviorSubject<List<int>>();
  final certain100doneePanController = BehaviorSubject<List<dynamic>>();
  final certain100donationCashController = BehaviorSubject<List<dynamic>>();
  final certain100donationOtherController = BehaviorSubject<List<dynamic>>();
  final certain100TotalController = BehaviorSubject<List<int>>();

  final certain50doneeNameController = BehaviorSubject<List<dynamic>>();
  final certain50AddressController = BehaviorSubject<List<dynamic>>();
  final certain50CityController = BehaviorSubject<List<dynamic>>();
  final certain50StateController = BehaviorSubject<List<dynamic>>();
  final certain50PincodeController = BehaviorSubject<List<int>>();
  final certain50doneePanController = BehaviorSubject<List<dynamic>>();
  final certain50donationCashController = BehaviorSubject<List<dynamic>>();
  final certain50donationOtherController = BehaviorSubject<List<dynamic>>();
  final certain50TotalController = BehaviorSubject<List<int>>();

  final scientificdoneeNameController = BehaviorSubject<List<dynamic>>();
  final scientificAddressController = BehaviorSubject<List<dynamic>>();
  final scientificCityController = BehaviorSubject<List<dynamic>>();
  final scientificStateController = BehaviorSubject<List<dynamic>>();
  final scientificPincodeController = BehaviorSubject<List<int>>();
  final scientificdoneePanController = BehaviorSubject<List<dynamic>>();
  final scientificdonationCashController = BehaviorSubject<List<dynamic>>();
  final scientificdonationOtherController = BehaviorSubject<List<dynamic>>();
  final scientificTotalController = BehaviorSubject<List<int>>();
  final scientificDateController = BehaviorSubject<List<dynamic>>();

  var licdeduction;
  var pfdeduction;
  var hldeduction;
  var publicpfdeduction;
  var nscinterestdeduction;
  var nscdepositdeduction;
  var eduexpensesdeduction;
  var certainfundsdeduction;
  var grpinsurancededuction;
  var mutualfunddeduction;
  var medialinsurancededuction;
  var interesthigheredu;
  var donation_100;
  var donation_50;
  var adjustedgti;
  var rentpaid;
  var sec80g;

  // ^ step 9  exempt  income
  final exemptIncomeController = BehaviorSubject<String>();
  final totalExemptIncomeController = BehaviorSubject<String>();
  final insurancePolicy1010dController = BehaviorSubject<String>();
  final statutoryPFController = BehaviorSubject<String>();
  final recognisedPFController = BehaviorSubject<String>();
  final exemptDividendController = BehaviorSubject<String>();
  final exemptIncomeDescriptionController = BehaviorSubject<String>();

  var exemptincome;
  // ^ step 10  agro income
  final agroIncomeController = BehaviorSubject<String>();

  var agroincome;

  // ^ step 14 TDS
  final tdsController = BehaviorSubject<String>();
  final tdsListController = BehaviorSubject<List<TdsDetails>>();
  final headIncomeListController = BehaviorSubject<List<HeadOfIncome>>();
  final sectionListController = BehaviorSubject<List<HeadOfIncome>>();

  // ^ step 15  advancedTax
  final advancedTaxDateController = BehaviorSubject<List<String>>();
  final advancedTaxAmountController = BehaviorSubject<List<int>>();
  final _advancedFirstInstallationController = BehaviorSubject<List<int>>();
  final _advancedSecondInstallationController = BehaviorSubject<List<int>>();
  final _advancedThirdInstallationController = BehaviorSubject<List<int>>();
  final _advancedFourthInstallationController = BehaviorSubject<List<int>>();
  final _advancedFifthInstallationController = BehaviorSubject<List<int>>();
  final totalAdvancedTaxController = BehaviorSubject<String>();
  final advanceTaxCINController = BehaviorSubject<List<int>>();
  final advanceTaxBSRController = BehaviorSubject<List<int>>();
  List<int> advancedtax = [];
  List<String> advancedtaxDate = [];

  // ^ step 16  advancedTax
  final selfTaxDateController = BehaviorSubject<List<String>>();
  final selfTaxAmountController = BehaviorSubject<List<int>>();
  final _selfFirstInstallationController = BehaviorSubject<List<int>>();
  final _selfSecondInstallationController = BehaviorSubject<List<int>>();
  final _selfThirdInstallationController = BehaviorSubject<List<int>>();
  final _selfFourthInstallationController = BehaviorSubject<List<int>>();
  final totalSelfTaxController = BehaviorSubject<String>();

  final selfTaxCINController = BehaviorSubject<List<int>>();
  final selfTaxBSRController = BehaviorSubject<List<int>>();

  List<int> selftax = [];
  List<String> selftaxDate = [];
  // !Streams
  Stream<String> get grossTotalIncome => _grossTotalIncomeController.stream;

  Stream<String> get taxableIncome => taxableIncomeController.stream;
  Stream<String> get totalIncome => totalIncomeController.stream;
  Stream<String> get t80Cout => _t80coutController.stream;
  Stream<String> get taxSurcharge => taxSurchargeController.stream;
  Stream<String> get lessRebate => lessRebate87AController.stream;
  Stream<String> get surCharge => surchargeController.stream;
  Stream<String> get educationCess => educationCessController.stream;
  Stream<String> get taxPayable => taxPayableContrller.stream;
  Stream<String> get balancePayable => balancePayableController.stream;
  Stream<String> get taxPayableRefundable =>
      taxPayableRefundableController.stream;
  Stream<String> get incomeTax => _incomeTaxController.stream;
  Stream<String> get t234A => t234AController.stream;
  Stream<String> get t234B => t234BController.stream;
  Stream<String> get t234C => t234CController.stream;
  Stream<String> get total_234 => total234Controller.stream;
  Stream<String> get normalTax => normalTaxController.stream;
  Stream<String> get specialTax => specialTaxController.stream;

// ^ basic details
  Stream<String> get filingDate => filingDateController.stream;
  Stream<String> get dueDate => dueDateController.stream;
  Stream<String> get taxMethod => taxMethodController.stream;
  Stream<String> get residencyStatus => residencyStatusController.stream;
  Stream<String> get selectedYear => selectedYearController.stream;
  Stream<String> get selectedITR => selectedITRController.stream;
  Stream<String> get selectedDomesticCompany =>
      selectedDomesticCompanyController.stream;
  Stream<String> get firstName => firstNameController.stream;
  Stream<String> get middleName => middleNameController.stream;
  Stream<String> get lastName => lastNameController.stream;
  Stream<String> get gender => genderController.stream;
  Stream<String> get dob => dobController.stream;
  Stream<String> get employeePan => employeePanController.stream;
  Stream<String> get fatherName => fatherNameController.stream;
  Stream<String> get flatNumber => flatNumberController.stream;
  Stream<String> get premiseName => premiseNameController.stream;
  Stream<String> get streetName => streetNameController.stream;
  Stream<String> get area => areaController.stream;
  Stream<String> get town => townController.stream;
  Stream<String> get pin => pinController.stream;
  Stream<String> get state => stateController.stream;
  Stream<String> get country => countryController.stream;
  Stream<String> get mobile => mobileController.stream;
  Stream<String> get aadhar => aadharController.stream;
  Stream<String> get email => emailController.stream;

  // ^ step 1 salary step
  Stream<String> get tanDeducter => employerTanDeducterController.stream;
  Stream<String> get panDeducter => employerPanDeducterController.stream;
  Stream<String> get employerName =>
      employerNameController.stream.asBroadcastStream();
  Stream<String> get employerTan =>
      employerTanController.stream.transform(validateTan);
  Stream<String> get employerType => employerTypeController.stream;
  Stream<String> get employerSalaryBy17 => employerSalaryBy17Controller.stream;
  Stream<dynamic> get employerBasic => employerBasicController.stream;
  Stream<dynamic> get employerHRA => employerHRAController.stream;
  Stream<dynamic> get employerLATA => employerLATAController.stream;
  Stream<dynamic> get employerAllowancePerquisites =>
      employerAllowancePerquisitesController.stream;
  Stream<List<int>> get employerOther => employerOtherController.stream;
  Stream<List<int>> get employerPerquistes =>
      employerPerquistesController.stream;
  Stream<List<int>> get employerProfitInLieu =>
      employerProfitInLieuController.stream;
  Stream<List<int>> get employerExemptAllowances =>
      employerExemptAllowancesController.stream;
  Stream<List<String>> get employerExemptAllowancesDescription =>
      employerExemptAllowancesDescriptionController.stream;
  Stream<String> get employerBalance => _employerBalanceController.stream;
  Stream<String> get employerStdDeduction =>
      _employerStdDeductionController.stream;
  Stream<dynamic> get employerProfTax => employerProfTaxController.stream;
  Stream<String> get totalSalary => totalSalaryController.stream;
  Stream<String> get entertainment => employerEntertainementController.stream;
  Stream<List<Others>> get otherDropdown => _otherDropdownController.stream;
  Stream<List<Perquisites>> get perquisitesDropdown =>
      _perquisitesDropdownController.stream;
  Stream<List<Lieu>> get lieuDropdown => _lieuDropdownController.stream;
  Stream<List<ExemptAllwn>> get exemptAllwnropdown =>
      _exemptAllwnropdownController.stream;
  Stream<List<bool>> get isAnyOther => isAnyOtherController.stream;

  Stream<File> get file => fileController.stream;
  Stream<Form16Model> get form16Data => _form16DataController.stream;
  Stream<String> get relieF => reliefController.stream;

  Stream<List<dynamic>> get employerOtherString =>
      employerOtherStringController.stream;
  Stream<List<dynamic>> get employerValueOfPerquisitesString =>
      employerValueOfPerquisitesStringController.stream;
  Stream<List<dynamic>> get employeLieuString =>
      employeLieuStringController.stream;
  Stream<List<dynamic>> get employerExemptAllowanceString =>
      employerExemptAllowanceStringController.stream;

  // ^ step 2  house property
  Stream<dynamic> get interestPaid => interestPaidHPController.stream;
  Stream<dynamic> get rentReceived => rendtReceivedHPController.stream;
  Stream<String> get totalHouseProperty => totalHousPartyController.stream;
  Stream<String> get housePropertyType => housePropertyTypeController.stream;
  Stream<dynamic> get municpalTax => muncipalTaxController.stream;
  Stream<dynamic> get realisedRent => inrealisedRentController.stream;
  Stream<dynamic> get anualValue => anualValueController.stream;

  // ^ step 3  Business
  Stream<dynamic> get profitFromFirm => profitFromFirmController.stream;
  Stream<dynamic> get remunerationFromFirm =>
      remunerationFromFirmController.stream;
  Stream<dynamic> get interestFromFirm => interestFromFirmController.stream;
  Stream<String> get businessName => nameOfBusinessController.stream;
  Stream<dynamic> get profitFromBusiness => profitFromBusinessController.stream;
  Stream<String> get totalBusinessIncome =>
      totalBusinessIncomeController.stream;

  // ^ step 4 Capital Gain

  Stream<String> get totalCapitalGain => totalCapitalGainController.stream;
  // ! STCG NORMAL
  Stream<dynamic> get stcgNormal1506 => stcgNormal1506Controller.stream;
  Stream<dynamic> get stcgNormal1509 => stcgNormal1509Controller.stream;
  Stream<dynamic> get stcgNormal1512 => stcgNormal1512Controller.stream;
  Stream<dynamic> get stcgNormal1503 => stcgNormal1503Controller.stream;
  Stream<dynamic> get stcgNormal3103 => stcgNormal3103Controller.stream;
  Stream<dynamic> get totalStcgNormal => _totalStcgNormalController.stream;

  // ! STCG 111A
  Stream<dynamic> get stcg111A1506 => stcg111A1506Controller.stream;
  Stream<dynamic> get stcg111A1509 => stcg111A1509Controller.stream;
  Stream<dynamic> get stcg111A1512 => stcg111A1512Controller.stream;
  Stream<dynamic> get stcg111A1503 => stcg111A1503Controller.stream;
  Stream<dynamic> get stcg111A3103 => stcg111A3103Controller.stream;
  Stream<dynamic> get totalStcg111A => _totalStcg111AController.stream;

  // ! LTCG 112A
  Stream<dynamic> get ltcg112A1506 => ltcg112A1506Controller.stream;
  Stream<dynamic> get ltcg112A1509 => ltcg112A1509Controller.stream;
  Stream<dynamic> get ltcg112A1512 => ltcg112A1512Controller.stream;
  Stream<dynamic> get ltcg112A1503 => ltcg112A1503Controller.stream;
  Stream<dynamic> get ltcg112A3103 => ltcg112A3103Controller.stream;
  Stream<dynamic> get totalLtcg112A => totalLtcg112AController.stream;

  // ! LTCG 10
  Stream<dynamic> get ltcg101506 => ltcg101506Controller.stream;
  Stream<dynamic> get ltcg101509 => ltcg101509Controller.stream;
  Stream<dynamic> get ltcg101512 => ltcg101512Controller.stream;
  Stream<dynamic> get ltcg101503 => ltcg101503Controller.stream;
  Stream<dynamic> get ltcg103103 => ltcg103103Controller.stream;
  Stream<dynamic> get totalLtcg10 => totalLtcg10Controller.stream;

  // ! LTCG 20
  Stream<dynamic> get ltcg201506 => ltcg201506Controller.stream;
  Stream<dynamic> get ltcg201509 => ltcg201509Controller.stream;
  Stream<dynamic> get ltcg201512 => ltcg201512Controller.stream;
  Stream<dynamic> get ltcg201503 => ltcg201503Controller.stream;
  Stream<dynamic> get ltcg203103 => ltcg203103Controller.stream;
  Stream<dynamic> get totalLtcg20 => _totalLtcg20Controller.stream;

  // ^ step 5  other Sources
  Stream<dynamic> get interestFromBank =>
      interestFromBankDepositController.stream;
  Stream<dynamic> get interestFromSaving => interestFromSavingController.stream;
  Stream<List<dynamic>> get otherIncome => otherIncomeController.stream;
  Stream<dynamic> get interestTaxIncome => interestTaxIncomeController.stream;
  Stream<dynamic> get pensionReceived => pensionReceivedController.stream;
  Stream<dynamic> get otherSourceDeduction57 =>
      otherSourceDeduction57Controller.stream;

  Stream<dynamic> get lottery1506 => interestFromBankDepositController.stream;
  Stream<dynamic> get lottery1509 => interestFromBankDepositController.stream;
  Stream<dynamic> get lottery1512 => interestFromBankDepositController.stream;
  Stream<dynamic> get lottery1503 => interestFromBankDepositController.stream;
  Stream<dynamic> get lottery3103 => interestFromBankDepositController.stream;
  Stream<String> get totalLottery => _totalLotteryController.stream;
  Stream<String> get totalOtherSources => totalOtherSourcersController.stream;

  // ^ step 6 special income
  Stream<dynamic> get divident1506 => divident1506Controller.stream;
  Stream<dynamic> get divident1509 => divident1509Controller.stream;
  Stream<dynamic> get divident1512 => divident1512Controller.stream;
  Stream<dynamic> get divident1503 => divident1503Controller.stream;
  Stream<dynamic> get divident3103 => divident3103Controller.stream;
  Stream<String> get totalDivident => totalDividentController.stream;

  // ^ step 7 loss and bf
  Stream<String> get lossbfAdjusted => lossBfAdjustedController.stream;

  // ^ step 8 deductions
  Stream<dynamic> get lic => licDeductionController.stream;
  Stream<dynamic> get licLimit => licLimitDeductionController.stream;
  Stream<dynamic> get pf => pfDeductionController.stream;
  Stream<dynamic> get hl => hlDeductionController.stream;
  Stream<dynamic> get publicPf => publicPfDeductionController.stream;
  Stream<dynamic> get nscInterest => nscInterestDeductionController.stream;
  Stream<dynamic> get nscDeposits => nscDepositsDeductionController.stream;
  Stream<dynamic> get educationalExpenses =>
      educationExpensesDeductionController.stream;
  Stream<dynamic> get certainFunds => certainFundsDeductionController.stream;
  Stream<dynamic> get groupInsurance =>
      groupInsuranceDeductionController.stream;
  Stream<dynamic> get mutualFunds => mutualFundsDeductionController.stream;
  Stream<String> get totalDeductionT80c => totalDeductionT80Controller.stream;
  Stream<String> get usertotalDeductionT80c =>
      usertotalDeductionT80Controller.stream;
  Stream<bool> get self => selfController.stream;
  Stream<bool> get parent => parentController.stream;
  Stream<bool> get parentAge => parentAgeController.stream;
  Stream<dynamic> get medicalInsurance => medicalInsuranceController.stream;
  Stream<dynamic> get parentMedicalInsurance =>
      parentMedicalInsuranceController.stream;

  Stream<bool> get severe => severeController.stream;
  Stream<bool> get handicapped => handicapController.stream;
  Stream<dynamic> get interestForHigherEdu =>
      interestForHigherEduController.stream;
  Stream<dynamic> get donation100 => donation100Controller.stream;
  Stream<dynamic> get donation50 => donation50Controller.stream;
  Stream<dynamic> get adjustedGti => _adjustedGtiController.stream;
  Stream<String> get qualifyingLimit => _qualifyingAmountController.stream;
  Stream<String> get rentPaid => rentPaidController.stream;
  Stream<String> get sec80G => _80GController.stream;
  Stream<String> get deductionUnderChaper6 =>
      totalDeductionUnderChapter6.stream;

  Stream<dynamic> get deduction80ccd1 => deduction80ccd1Controller.stream;
  Stream<dynamic> get deduction80ccc => deduction80cccController.stream;
  Stream<dynamic> get deductionTotalof80 => deductionTotalof80Controller.stream;
  Stream<dynamic> get deduction80ccd1b => deduction80ccd1bController.stream;
  Stream<dynamic> get deduction80ccd2 => deduction80ccd2Controller.stream;

  Stream<dynamic> get selfMediclaim => selfMediclaimController.stream;
  Stream<dynamic> get selfHealthchekup => selfHealthcheckupController.stream;
  Stream<dynamic> get selfMedicalExpenditure =>
      selfMedicalExpenditureController.stream;

  Stream<dynamic> get parentMediclaim => parentMediclaimController.stream;
  Stream<dynamic> get parentHealthchekup =>
      parentHealthcheckupController.stream;
  Stream<dynamic> get parentMedicalExpenditure =>
      parentMedicalExpenditureController.stream;

  Stream<bool> get senior80ddb => senior80ddbController.stream;
  Stream<dynamic> get medical80ddb => medical80ddbController.stream;

  Stream<bool> get first80EE => first80EEController.stream;
  Stream<bool> get withoutLimit => withoutLimitController.stream;
  Stream<dynamic> get houseProperty80EE => houseProperty80EEController.stream;
  Stream<dynamic> get houseProperty80EEA => houseProperty80EEAController.stream;
  Stream<dynamic> get houseProperty80EEB => houseProperty80EEBController.stream;
  Stream<dynamic> get political80GGC => political80GGCController.stream;
  Stream<dynamic> get deduction80TTA => deduction80TTAController.stream;
  Stream<dynamic> get deduction80TTB => deduction80TTBController.stream;

  Stream<List<dynamic>> get certain100doneeName =>
      certain100doneeNameController.stream;
  Stream<List<dynamic>> get certain100Address =>
      certain100AddressController.stream;
  Stream<List<dynamic>> get certain100City => certain100CityController.stream;
  Stream<List<dynamic>> get certain100State => certain100StateController.stream;
  Stream<List<int>> get certain100Pincode => certain100PincodeController.stream;
  Stream<List<dynamic>> get certain100doneePan =>
      certain100doneePanController.stream;
  Stream<List<dynamic>> get certain100donationCash =>
      certain100donationCashController.stream;
  Stream<List<dynamic>> get certain100donationOther =>
      certain100donationOtherController.stream;
  Stream<List<int>> get certain100Total => certain100TotalController.stream;

  Stream<List<dynamic>> get certain50doneeName =>
      certain50doneeNameController.stream;
  Stream<List<dynamic>> get certain50Address =>
      certain50AddressController.stream;
  Stream<List<dynamic>> get certain50City => certain50CityController.stream;
  Stream<List<dynamic>> get certain50State => certain50StateController.stream;
  Stream<List<int>> get certain50Pincode => certain50PincodeController.stream;
  Stream<List<dynamic>> get certain50doneePan =>
      certain50doneePanController.stream;
  Stream<List<dynamic>> get certain50donationCash =>
      certain50donationCashController.stream;
  Stream<List<dynamic>> get certain50donationOther =>
      certain50donationOtherController.stream;
  Stream<List<int>> get certain50Total => certain50TotalController.stream;

  Stream<List<dynamic>> get scientificdoneeName =>
      scientificdoneeNameController.stream;
  Stream<List<dynamic>> get scientificAddress =>
      scientificAddressController.stream;
  Stream<List<dynamic>> get scientificCity => scientificCityController.stream;
  Stream<List<dynamic>> get scientificState => scientificStateController.stream;
  Stream<List<int>> get scientificPincode => scientificPincodeController.stream;
  Stream<List<dynamic>> get scientificdoneePan =>
      scientificdoneePanController.stream;
  Stream<List<dynamic>> get scientificdonationCash =>
      scientificdonationCashController.stream;
  Stream<List<dynamic>> get scientificdonationOther =>
      scientificdonationOtherController.stream;
  Stream<List<int>> get scientificTotal => scientificTotalController.stream;
  Stream<List<dynamic>> get scientificDate => scientificDateController.stream;

// ^ step 9 exempt  income
  Stream<String> get exemptIncome => exemptIncomeController.stream;
  Stream<String> get totalExemptIncome => totalExemptIncomeController.stream;

  Stream<String> get insurancePolicy1010d =>
      insurancePolicy1010dController.stream;
  Stream<String> get statutoryPF => statutoryPFController.stream;
  Stream<String> get recognisedPF => recognisedPFController.stream;
  Stream<String> get exemptDividend => exemptDividendController.stream;
  Stream<String> get exemptIncomeDescription =>
      exemptIncomeDescriptionController.stream;
// ^ step 10 agro income
  Stream<String> get agroIncome => agroIncomeController.stream;

// ^ step 14 TDS
  Stream<String> get tds => tdsController.stream;
  Stream<List<TdsDetails>> get tdsList => tdsListController.stream;

  Stream<List<HeadOfIncome>> get headIncomeList =>
      headIncomeListController.stream;
  Stream<List<HeadOfIncome>> get sectionsList => sectionListController.stream;

// ^ step 15 advacnde tax
  Stream<List<int>> get advancedTaxAmount => advancedTaxAmountController.stream;
  Stream<List<int>> get advanceTaxCIN => advanceTaxCINController.stream;
  Stream<List<int>> get advanceTaxBSR => advanceTaxBSRController.stream;

  Stream<List<String>> get advancedTaxDate => advancedTaxDateController.stream;
  Stream<List<int>> get firstInstallmentAdvanced =>
      _advancedFirstInstallationController.stream;
  Stream<List<int>> get secondInstallmentAdvanced =>
      _advancedSecondInstallationController.stream;
  Stream<List<int>> get thirdInstallmentAdvanced =>
      _advancedThirdInstallationController.stream;
  Stream<List<int>> get fourthInstallmentAdvanced =>
      _advancedFourthInstallationController.stream;
  Stream<String> get totalAdvancedTax => totalAdvancedTaxController.stream;

// ^ step 16 self tax
  Stream<List<int>> get selfTaxAmount => selfTaxAmountController.stream;
  Stream<List<int>> get selfTaxCIN => selfTaxCINController.stream;
  Stream<List<int>> get selfTaxBSR => selfTaxBSRController.stream;
  Stream<List<String>> get selfTaxDate => selfTaxDateController.stream;
  Stream<List<int>> get firstInstallmentSelf =>
      _selfFirstInstallationController.stream;
  Stream<List<int>> get secondInstallmentSelf =>
      _selfSecondInstallationController.stream;
  Stream<List<int>> get thirdInstallmentSelf =>
      _selfThirdInstallationController.stream;
  Stream<List<int>> get fourthInstallmentSelf =>
      _selfFourthInstallationController.stream;
  Stream<String> get totalSelfTax => totalSelfTaxController.stream;

  // !OnChange

//  ^ basic details
  Function(String) get onfilingDateChanged => filingDateController.sink.add;
  Function(String) get ondueDateChanged => dueDateController.sink.add;
  Function(String) get ontaxMethodChanged => taxMethodController.sink.add;
  Function(String) get onresidencyStatusChanged =>
      residencyStatusController.sink.add;
  Function(String) get onSelectedYearChanged => selectedYearController.sink.add;
  Function(String) get onSelectedITRChanged => selectedITRController.sink.add;
  Function(String) get onSelectedDomesticCompanyChanged =>
      selectedDomesticCompanyController.sink.add;
  Function(String) get onFirstNameChanged => firstNameController.sink.add;
  Function(String) get onMiddleNameChanged => middleNameController.sink.add;
  Function(String) get onLastNameChanged => lastNameController.sink.add;
  Function(String) get onGenderChanged => genderController.sink.add;
  Function(String) get onDobChanged => dobController.sink.add;
  Function(String) get onEmployeePanChanged => employeePanController.sink.add;
  Function(String) get onFatherNameChanged => fatherNameController.sink.add;
  Function(String) get onFlatNumberChanged => flatNumberController.sink.add;
  Function(String) get onPremiseNameChanged => premiseNameController.sink.add;
  Function(String) get onStreetNameChanged => streetNameController.sink.add;
  Function(String) get onareaChanged => areaController.sink.add;
  Function(String) get onTownChanged => townController.sink.add;
  Function(String) get onPinChanged => pinController.sink.add;
  Function(String) get onStateChanged => stateController.sink.add;
  Function(String) get onCountryChanged => countryController.sink.add;
  Function(String) get onMobileChanged => mobileController.sink.add;
  Function(String) get onAadharChanged => aadharController.sink.add;
  Function(String) get onEmailChanged => emailController.sink.add;
  Function(String) get onEntertainmentChanged =>
      employerEntertainementController.sink.add;
  // ^ step 1 salary step
  Function(String) get onEmployerNameChange => employerNameController.sink.add;
  Function(String) get onEmployerTanChange => employerTanController.sink.add;
  Function(String) get onEmployerTanDeducterChange =>
      employerTanDeducterController.sink.add;
  Function(String) get onEmployerPanDeducterChange =>
      employerPanDeducterController.sink.add;
  Function(String) get onEmployerTypeChange => employerTypeController.sink.add;
  Function(dynamic) get onEmployerSalaryBy17Change =>
      employerSalaryBy17Controller.sink.add;
  Function(dynamic) get onEmployerBasicChange =>
      employerBasicController.sink.add;
  Function(dynamic) get onEmployerHRAChange => employerHRAController.sink.add;
  Function(dynamic) get onEmployerLATAChange => employerLATAController.sink.add;
  Function(dynamic) get onEmployerAllowancePerquisites =>
      employerAllowancePerquisitesController.sink.add;

  Function(List<int>) get onEmployerOtherChange =>
      employerOtherController.sink.add;
  Function(List<int>) get onEmployerPerquistesChange =>
      employerPerquistesController.sink.add;
  Function(List<int>) get onEmployerProfitInLieuChange =>
      employerProfitInLieuController.sink.add;
  Function(List<int>) get onEmployerExemptAllowancesChange =>
      employerExemptAllowancesController.sink.add;
  Function(List<String>) get onEmployerExemptAllowancesDescriptionChange =>
      employerExemptAllowancesDescriptionController.sink.add;
  Function(dynamic) get onEmployerBalanceChange =>
      _employerBalanceController.sink.add;
  Function(dynamic) get onEmployerProfTaxChange =>
      employerProfTaxController.sink.add;
  Function(dynamic) get onReleifChanged => reliefController.sink.add;

  Function(List<dynamic>) get onEmployerOtherStrinChanged =>
      employerOtherStringController.sink.add;
  Function(List<dynamic>) get onEmployerValueOfPerquisitesStringChanged =>
      employerValueOfPerquisitesStringController.sink.add;
  Function(List<dynamic>) get onEmployeLieuStringChanged =>
      employeLieuStringController.sink.add;
  Function(List<dynamic>) get onEmployeExemptAllwncStringChanged =>
      employeExemptAllwnStringController.sink.add;
  Function(List<dynamic>) get onEmployerExemptAllowanceStringChanged =>
      employerExemptAllowanceStringController.sink.add;

  // ^ step 2  house property
  Function(dynamic) get onInterestPaidChanged =>
      interestPaidHPController.sink.add;
  Function(dynamic) get onRentedReceivedChanged =>
      rendtReceivedHPController.sink.add;
  Function(dynamic) get onHousPropertyTypeChanged =>
      housePropertyTypeController.sink.add;
  Function(dynamic) get onMunicpalTaxChanged => muncipalTaxController.sink.add;
  Function(dynamic) get onRealisedRentChanged =>
      inrealisedRentController.sink.add;
  Function(dynamic) get onAnualValuChanged => anualValueController.sink.add;

// ^ step 3 Business
  Function(dynamic) get onProfitFromFirmChanged =>
      profitFromFirmController.sink.add;
  Function(dynamic) get onRemunerationFromFirmChanged =>
      remunerationFromFirmController.sink.add;
  Function(dynamic) get onInterestFromFirmChanged =>
      interestFromFirmController.sink.add;
  Function(dynamic) get onProfitFromBusinessChanged =>
      profitFromBusinessController.sink.add;
  Function(String) get onBusinessNameChange =>
      nameOfBusinessController.sink.add;

  // ^ step 4 Capital Gain
  // ! STCG NORMAL
  Function(dynamic) get onStcgNormal1506Change =>
      stcgNormal1506Controller.sink.add;
  Function(dynamic) get onStcgNormal1509Change =>
      stcgNormal1509Controller.sink.add;
  Function(dynamic) get onStcgNormal1512Change =>
      stcgNormal1512Controller.sink.add;
  Function(dynamic) get onStcgNormal1503Change =>
      stcgNormal1503Controller.sink.add;
  Function(dynamic) get onStcgNormal3103Change =>
      stcgNormal3103Controller.sink.add;
  // ! STCG 111A
  Function(dynamic) get onStcg111A1506Change => stcg111A1506Controller.sink.add;
  Function(dynamic) get onStcg111A1509Change => stcg111A1509Controller.sink.add;
  Function(dynamic) get onStcg111A1512Change => stcg111A1512Controller.sink.add;
  Function(dynamic) get onStcg111A1503Change => stcg111A1503Controller.sink.add;
  Function(dynamic) get onStcg111A3103Change => stcg111A3103Controller.sink.add;
  // ! LTCG 112A
  Function(dynamic) get onLtcg112A1506Change => ltcg112A1506Controller.sink.add;
  Function(dynamic) get onLtcg112A1509Change => ltcg112A1509Controller.sink.add;
  Function(dynamic) get onLtcg112A1512Change => ltcg112A1512Controller.sink.add;
  Function(dynamic) get onLtcg112A1503Change => ltcg112A1503Controller.sink.add;
  Function(dynamic) get onLtcg112A3103Change => ltcg112A3103Controller.sink.add;
  // ! LTCG 10
  Function(dynamic) get onLtcg101506Change => ltcg101506Controller.sink.add;
  Function(dynamic) get onLtcg101509Change => ltcg101509Controller.sink.add;
  Function(dynamic) get onLtcg101512Change => ltcg101512Controller.sink.add;
  Function(dynamic) get onLtcg101503Change => ltcg101503Controller.sink.add;
  Function(dynamic) get onLtcg103103Change => ltcg103103Controller.sink.add;
  // ! LTCG 20
  Function(dynamic) get onLtcg201506Change => ltcg201506Controller.sink.add;
  Function(dynamic) get onLtcg201509Change => ltcg201509Controller.sink.add;
  Function(dynamic) get onLtcg201512Change => ltcg201512Controller.sink.add;
  Function(dynamic) get onLtcg201503Change => ltcg201503Controller.sink.add;
  Function(dynamic) get onLtcg203103Change => ltcg203103Controller.sink.add;

  // ^ step 5  other Sources
  Function(dynamic) get onInterestFromBankChanged =>
      interestFromBankDepositController.sink.add;
  Function(dynamic) get onInterestFromSavingChanged =>
      interestFromSavingController.sink.add;
  Function(List<dynamic>) get onOtherIncomeChanged =>
      otherIncomeController.sink.add;
  Function(dynamic) get onInterestTaxIncomeChanged =>
      interestTaxIncomeController.sink.add;
  Function(dynamic) get onPensionReceivedChanged =>
      pensionReceivedController.sink.add;
  Function(dynamic) get onOtherSourceDeduction57Changed =>
      otherSourceDeduction57Controller.sink.add;

  Function(dynamic) get onLottery1506Changed => lottery1506Controller.sink.add;
  Function(dynamic) get onLottery1509Changed => lottery1509Controller.sink.add;
  Function(dynamic) get onLottery1512Changed => lottery1512Controller.sink.add;
  Function(dynamic) get onLottery1503Changed => lottery1503Controller.sink.add;
  Function(dynamic) get onLottery3103Changed => lottery3103Controller.sink.add;

  // ^ step 6 special income
  Function(dynamic) get onDivident1506Changed =>
      divident1506Controller.sink.add;
  Function(dynamic) get onDivident1509Changed =>
      divident1509Controller.sink.add;
  Function(dynamic) get onDivident1512Changed =>
      divident1512Controller.sink.add;
  Function(dynamic) get onDivident1503Changed =>
      divident1503Controller.sink.add;
  Function(dynamic) get onDivident3103Changed =>
      divident3103Controller.sink.add;

  // ^ step 7 loss and bf
  Function(String) get onLossBfAdjustedChanged =>
      lossBfAdjustedController.sink.add;
  // ^ step 8 deductions
  Function(dynamic) get onLicChanged => licDeductionController.sink.add;
  Function(dynamic) get onLicLimitChanged => licLimitDeductionController.sink.add;
  Function(dynamic) get onPfChanged => pfDeductionController.sink.add;
  Function(dynamic) get onHlChanged => hlDeductionController.sink.add;
  Function(dynamic) get onPublicPfChanged =>
      publicPfDeductionController.sink.add;
  Function(dynamic) get onNscInterestChanged =>
      nscInterestDeductionController.sink.add;
  Function(dynamic) get onNscDepositsChanged =>
      nscDepositsDeductionController.sink.add;
  Function(dynamic) get onEducationalExpensesChanged =>
      educationExpensesDeductionController.sink.add;
  Function(dynamic) get onCertainFundsChanged =>
      certainFundsDeductionController.sink.add;
  Function(dynamic) get ongroupInsuranceChanged =>
      groupInsuranceDeductionController.sink.add;
  Function(dynamic) get onmutualFundsChanged =>
      mutualFundsDeductionController.sink.add;
  Function(bool) get onSelfChanged => selfController.sink.add;
  Function(bool) get onParentChanged => parentController.sink.add;
  Function(bool) get onParentAgeChanged => parentAgeController.sink.add;
  Function(dynamic) get onMedicalInsuranceChanged =>
      medicalInsuranceController.sink.add;
  Function(dynamic) get onParentMedicalInsuranceChanged =>
      parentMedicalInsuranceController.sink.add;

  Function(bool) get onSevereChanged => severeController.sink.add;
  Function(bool) get onHandicapChanged => handicapController.sink.add;
  Function(dynamic) get onInterestForHigherEduChanged =>
      interestForHigherEduController.sink.add;
  Function(dynamic) get onDonation100Changed => donation100Controller.sink.add;
  Function(dynamic) get onDonation50Changed => donation50Controller.sink.add;
  Function(dynamic) get onRentpaidChanged => rentPaidController.sink.add;
  Function(String) get onDeductionUnderChapter6Changed =>
      totalDeductionUnderChapter6.sink.add;
  Function(dynamic) get onDeduction80ccd1Changed =>
      deduction80ccd1Controller.sink.add;
  Function(dynamic) get onDeduction80cccChanged =>
      deduction80cccController.sink.add;
  Function(dynamic) get onDeductionTotalof80Changed =>
      deductionTotalof80Controller.sink.add;
  Function(dynamic) get onDeduction80ccd1bChanged =>
      deduction80ccd1bController.sink.add;
  Function(dynamic) get onDeduction80ccd2Changed =>
      deduction80ccd2Controller.sink.add;

  Function(dynamic) get onSelfMediclaimChanged =>
      selfMediclaimController.sink.add;
  Function(dynamic) get onSelfHealthcheckupChanged =>
      selfHealthcheckupController.sink.add;
  Function(dynamic) get onSelfMedicalExpenditureChanged =>
      selfMedicalExpenditureController.sink.add;

  Function(dynamic) get onParentMediclaimChanged =>
      parentMediclaimController.sink.add;
  Function(dynamic) get onParentHealthcheckupChanged =>
      parentHealthcheckupController.sink.add;
  Function(dynamic) get onParentMedicalExpenditureChanged =>
      parentMedicalExpenditureController.sink.add;

  Function(bool) get onSenior80ddbChanged => senior80ddbController.sink.add;
  Function(dynamic) get onMedical80ddbChanged =>
      medical80ddbController.sink.add;

  Function(bool) get onFirst80EEChanged => first80EEController.sink.add;
  Function(bool) get onWithoutLimitChanged => withoutLimitController.sink.add;
  Function(dynamic) get onHouseProperty80EEChanged =>
      houseProperty80EEController.sink.add;
  Function(dynamic) get onHouseProperty80EEAChanged =>
      houseProperty80EEAController.sink.add;
  Function(dynamic) get onHouseProperty80EEBChanged =>
      houseProperty80EEBController.sink.add;
  Function(dynamic) get onPolitical80GGCChanged =>
      political80GGCController.sink.add;

  Function(dynamic) get onDeduction80TTAChanged =>
      deduction80TTAController.sink.add;

  Function(dynamic) get onDeduction80TTBChanged =>
      deduction80TTBController.sink.add;

  Function(List<dynamic>) get onCertain100doneeNameChanged =>
      certain100doneeNameController.sink.add;
  Function(List<dynamic>) get onCertain100AddressChanged =>
      certain100AddressController.sink.add;
  Function(List<dynamic>) get onCertain100CityChanged =>
      certain100CityController.sink.add;
  Function(List<dynamic>) get onCertain100StateChanged =>
      certain100StateController.sink.add;
  Function(List<int>) get onCertain100PincodeChanged =>
      certain100PincodeController.sink.add;
  Function(List<dynamic>) get onCertain100doneePanChanged =>
      certain100doneePanController.sink.add;
  Function(List<dynamic>) get onCertain100donationCashChanged =>
      certain100donationCashController.sink.add;
  Function(List<dynamic>) get onCertain100donationOtherChanged =>
      certain100donationOtherController.sink.add;
  Function(List<int>) get onCertain100TotalChanged =>
      certain100TotalController.sink.add;

  Function(List<dynamic>) get onCertain50doneeNameChanged =>
      certain50doneeNameController.sink.add;
  Function(List<dynamic>) get onCertain50AddressChanged =>
      certain50AddressController.sink.add;
  Function(List<dynamic>) get onCertain50CityChanged =>
      certain50CityController.sink.add;
  Function(List<dynamic>) get onCertain50StateChanged =>
      certain50StateController.sink.add;
  Function(List<int>) get onCertain50PincodeChanged =>
      certain50PincodeController.sink.add;
  Function(List<dynamic>) get onCertain50doneePanChanged =>
      certain50doneePanController.sink.add;
  Function(List<dynamic>) get onCertain50donationCashChanged =>
      certain50donationCashController.sink.add;
  Function(List<dynamic>) get onCertain50donationOtherChanged =>
      certain50donationOtherController.sink.add;
  Function(List<int>) get onCertain50TotalChanged =>
      certain50TotalController.sink.add;

  Function(List<dynamic>) get onScientificdoneeNameChanged =>
      scientificdoneeNameController.sink.add;
  Function(List<dynamic>) get onScientificAddressChanged =>
      scientificAddressController.sink.add;
  Function(List<dynamic>) get onScientificCityChanged =>
      scientificCityController.sink.add;
  Function(List<dynamic>) get onScientificStateChanged =>
      scientificStateController.sink.add;
  Function(List<int>) get onScientificPincodeChanged =>
      scientificPincodeController.sink.add;
  Function(List<dynamic>) get onScientificdoneePanChanged =>
      scientificdoneePanController.sink.add;
  Function(List<dynamic>) get onScientificdonationCashChanged =>
      scientificdonationCashController.sink.add;
  Function(List<dynamic>) get onScientificdonationOtherChanged =>
      scientificdonationOtherController.sink.add;
  Function(List<int>) get onScientificTotalChanged =>
      scientificTotalController.sink.add;
  Function(List<dynamic>) get onScientificDateChanged =>
      scientificDateController.sink.add;
  // ^ step 9 exempt  income
  Function(String) get onExemptIncomeChanged => exemptIncomeController.sink.add;

  Function(String) get onInsurancePolicy1010dChanged =>
      insurancePolicy1010dController.sink.add;
  Function(String) get onStatutoryPFChanged => statutoryPFController.sink.add;
  Function(String) get onRecognisedPFChanged => recognisedPFController.sink.add;
  Function(String) get onExemptDividendChanged =>
      exemptDividendController.sink.add;
  Function(String) get onExemptIncomeDescriptionChanged =>
      exemptIncomeDescriptionController.sink.add;
  // ^ step 10 agro income
  Function(String) get onAgroIncomeChanged => agroIncomeController.sink.add;

  // ^ step 14 TDS
  Function(String) get onTdsChanged => tdsController.sink.add;

  // ^ step 15 advanced tax
  Function(List<String>) get onAdvancedTaxDateChanged =>
      advancedTaxDateController.sink.add;
  Function(List<int>) get onAdvancedTaxAmountChanged =>
      advancedTaxAmountController.sink.add;
  Function(List<int>) get onAdvanceTaxCINChanged =>
      advanceTaxCINController.sink.add;
  Function(List<int>) get onAdvanceTaxBSRChanged =>
      advanceTaxBSRController.sink.add;

  // ^ step 16 self tax
  Function(List<String>) get onSelfTaxDateChanged =>
      selfTaxDateController.sink.add;
  Function(List<int>) get onSelfTaxCINChanged => selfTaxCINController.sink.add;
  Function(List<int>) get onSelfTaxBSRChanged => selfTaxBSRController.sink.add;
  Function(List<int>) get onSelfTaxAmountChanged =>
      selfTaxAmountController.sink.add;

  //! Button Validates
  Stream<bool> get validateButton =>
      CombineLatestStream([file], (data) => true);

  List<Others> otherList = [
    Others(nameOfOther: "Dearness Allowance "),
    Others(nameOfOther: "Conveyance Allowance "),
    Others(nameOfOther: "Children Education Allowance "),
    Others(nameOfOther: "Other Allowance "),
    Others(
        nameOfOther: "Contribution made by employer towards pension schemes"),
    Others(
        nameOfOther:
            "Amount deemed to be income under rule 11 of Fourth schedule "),
    Others(
        nameOfOther:
            "Amount deemed to be income under rule 6 of fourth schedule "),
    Others(nameOfOther: "Annuity or pension "),
    Others(nameOfOther: "Commuted Pension"),
    Others(nameOfOther: "Gratuity"),
    Others(nameOfOther: "Fees or commission"),
    Others(nameOfOther: "Advance of salary "),
    Others(nameOfOther: "Leave encashment"),
    Others(nameOfOther: "Other ")
  ];

  List<Perquisites> perquisitesList = [
    Perquisites(nameOfPerquisites: "Accommodation"),
    Perquisites(nameOfPerquisites: "Cars or other automobiles "),
    Perquisites(
        nameOfPerquisites: "Sweeper, Gardener, Watchman or other attendant "),
    Perquisites(nameOfPerquisites: "Gas, electricity, water"),
    Perquisites(nameOfPerquisites: "Interest free or concessional loan"),
    Perquisites(nameOfPerquisites: "Holiday expenses"),
    Perquisites(nameOfPerquisites: "Free or concessional travel "),
    Perquisites(nameOfPerquisites: "Free Meals"),
    Perquisites(nameOfPerquisites: "Free education"),
    Perquisites(nameOfPerquisites: "Gifts, vouchers etc."),
    Perquisites(nameOfPerquisites: "Credit card expenses"),
    Perquisites(nameOfPerquisites: "Club expenses"),
    Perquisites(nameOfPerquisites: "Use of movable assets by employee"),
    Perquisites(nameOfPerquisites: "Transfer of assets to employee"),
    Perquisites(
        nameOfPerquisites:
            "Value of any other benefit, amenity, service, privilege"),
    Perquisites(nameOfPerquisites: "Stock options (non-qualified options)"),
    Perquisites(
        nameOfPerquisites: "Tax paid by employer on non-monetary perquisite "),
    Perquisites(nameOfPerquisites: "Other benefits or amenities ")
  ];

  List<Lieu> lieuList = [
    Lieu(nameOfLieu: "Compensation dues from employer or former employer  "),
    Lieu(nameOfLieu: "Any Payment received from employer or former employer "),
    Lieu(
        nameOfLieu:
            "Any amount due/ received from any other person before joining ")
  ];

  List<ExemptAllwn> exemptAllwnList_newRegime = [
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(6) - Remuneration received as an official, by whatever name called, of an embassy. high commission etc."),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(7) - Allowances or perquisites paid or allowed as such outside India by the Government to a citizen of India for rendering service Outside India"),
    ExemptAllwn(
        nameOfExemptAllwn: "Sec 10(10)-Death-cum-retirement gratuity received"),
    ExemptAllwn(
        nameOfExemptAllwn: "Sec 10(10A)- Commuted value of pension received"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(10AA)-Earned leave encashment on Retirement"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "10(10B) First proviso- Compensation limit notified by CG in the Official Gezette"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "10(10B) Second proviso – Compensation under scheme approved by the central government"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(10C)- Amount received/receivable on voluntary retirement or termination of service"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(10CC)- Tax paid by employer on non-monetary perquisite"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Section 10(14)(ii) – Transport allowance granted to certain physically handicapped assessee"),
    ExemptAllwn(nameOfExemptAllwn: "Any Other"),
  ];

  List<ExemptAllwn> exemptAllwnList_oldRegime = [
    ExemptAllwn(
        nameOfExemptAllwn: "Sec 10(5) - Leave Travel Concession/Assistance"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(6) - Remuneration received as an official, by whatever name called, of an embassy. high commission etc"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(7)-Allowances or perquisites paid or allowed as such outside India by the Government to a citizen of India for rendering service outside India"),
    ExemptAllwn(
        nameOfExemptAllwn: "Sec 10(10)-Death-cum-retirement gratuity received"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Dec 10(10AA)-Earned leave encashment on Retirement"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "10(10B) First proviso- Compensation limit notified by CG in the Official Gezette"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "10(10B) Second proviso – Compensation under scheme approved by the central government"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(10C)- Amount received/receivable on voluntary retirement or termination of service"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(10CC)- Tax paid by employer on non-monetary perquisite"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(13A)- Allowance to meet expenditure incurred on House Rent"),
    ExemptAllwn(
        nameOfExemptAllwn:
            "Sec 10(14)(i)- Prescribed Allowances or benefits (not in a nature of perquisite) specifically granted to meet expenses wholly, necessarily and exclusively and to the extent actually incurred, in performance of duties of office or employment"),
    ExemptAllwn(nameOfExemptAllwn: "Any Other"),
  ];
  List<StateList> stateDropwDown = [
    StateList(stateName: "Andaman and Nicobar islands", stateId: 01),
    StateList(stateName: "Andhra Pradesh", stateId: 02),
    StateList(stateName: "Arunachal Pradesh", stateId: 03),
    StateList(stateName: "Assam", stateId: 04),
    StateList(stateName: "Bihar", stateId: 05),
    StateList(stateName: "Chandigarh", stateId: 06),
    StateList(stateName: "Dadra Nagar and Haveli", stateId: 07),
    StateList(stateName: "Daman and Diu", stateId: 08),
    StateList(stateName: "Delhi", stateId: 09),
    StateList(stateName: "Goa", stateId: 10),
    StateList(stateId: 11, stateName: "Gujarat"),
    StateList(stateId: 12, stateName: "Haryana"),
    StateList(stateId: 13, stateName: "Himachal Pradesh"),
    StateList(stateId: 14, stateName: "Jammu and Kashmir"),
    StateList(stateId: 15, stateName: "Karnataka"),
    StateList(stateId: 16, stateName: "Kerala"),
    StateList(stateId: 17, stateName: "Lakshadweep"),
    StateList(stateId: 18, stateName: "Madhya Pradesh"),
    StateList(stateId: 19, stateName: "Maharashtra"),
    StateList(stateId: 20, stateName: "Manipur"),
    StateList(stateId: 21, stateName: "meghalaya"),
    StateList(stateId: 22, stateName: "Mizoram"),
    StateList(stateId: 23, stateName: "Nagaland"),
    StateList(stateId: 24, stateName: "Odisha"),
    StateList(stateId: 25, stateName: "Puducherry"),
    StateList(stateId: 26, stateName: "Punjab"),
    StateList(stateId: 27, stateName: "Rajasthan"),
    StateList(stateId: 28, stateName: "Sikkim"),
    StateList(stateId: 29, stateName: "Tamil Nadu"),
    StateList(stateId: 30, stateName: "Tripura"),
    StateList(stateId: 31, stateName: "Uttar Pradesh"),
    StateList(stateId: 32, stateName: "West Bengal"),
    StateList(stateId: 33, stateName: "Chhattisgarh"),
    StateList(stateId: 34, stateName: "Uttarakhand"),
    StateList(stateId: 35, stateName: "Jharkhand"),
    StateList(stateId: 36, stateName: "Telangana"),
    StateList(stateId: 37, stateName: "Ladakh"),
    StateList(stateId: 99, stateName: "Foreign"),
  ];
  final stateDropDownController = BehaviorSubject<List<StateList>>();
  Stream<List<StateList>> get stateDropdown => stateDropDownController.stream;
  Function(List<StateList>) get onStateDropdownChanged =>
      stateDropDownController.sink.add;

  final itrDropdownController = BehaviorSubject<List<ItrDropDown>>();
  Stream<List<ItrDropDown>> get itrDropdown => itrDropdownController.stream;
  Function(List<ItrDropDown>) get onItrDropdownChanged =>
      itrDropdownController.sink.add;

  final itrDropdownStringController = BehaviorSubject<dynamic>();
  Function(dynamic) get onitrDropdownStringChanged =>
      itrDropdownStringController.sink.add;

  final selectedStateController = BehaviorSubject<dynamic>();
  Function(dynamic) get onStateStringChanged =>
      selectedStateController.sink.add;

  final isShowUniqDocController = BehaviorSubject<bool>();
  Stream<bool> get isShowUniqDoc => isShowUniqDocController.stream;
  Function(bool) get onisShowUniqDocChanged => isShowUniqDocController.sink.add;

  final isShowReceiptNoController = BehaviorSubject<bool>();
  Stream<bool> get isShowReceiptNo => isShowReceiptNoController.stream;
  Function(bool) get onisShowReceiptNoChanged =>
      isShowReceiptNoController.sink.add;

  final uniqDocController = BehaviorSubject<dynamic>();
  Stream<dynamic> get uniqDocNo => uniqDocController.stream;
  Function(dynamic) get onUniqDocChanged => uniqDocController.sink.add;

  final receiptNoController = BehaviorSubject<dynamic>();
  Stream<dynamic> get receiptNo => receiptNoController.stream;
  Function(dynamic) get onReceiptNoChanged => receiptNoController.sink.add;

  final depositeAmtExceedController = BehaviorSubject<dynamic>();
  Stream<dynamic> get depositeAmtExceed => depositeAmtExceedController.stream;
  Function(dynamic) get onDepositeAmtExceedChanged =>
      depositeAmtExceedController.sink.add;

  final foreignTravelExpensesController = BehaviorSubject<dynamic>();
  Stream<dynamic> get foreignTravelExpenses =>
      foreignTravelExpensesController.stream;
  Function(dynamic) get onforeignTravelExpensesChanged =>
      foreignTravelExpensesController.sink.add;

  final electricitybillsExceedingController = BehaviorSubject<dynamic>();
  Stream<dynamic> get electricitybillsExceeding =>
      electricitybillsExceedingController.stream;
  Function(dynamic) get onElectricitybillsExceedingControllerChanged =>
      electricitybillsExceedingController.sink.add;

  final dateOfNoticeController = BehaviorSubject<DateTime>();
  Stream<DateTime> get dateofNotice => dateOfNoticeController.stream;
  Function(DateTime) get onDateofNoticeChanged =>
      dateOfNoticeController.sink.add;

  final dateOfITRController = BehaviorSubject<DateTime>();
  Stream<DateTime> get dateofITR => dateOfITRController.stream;
  Function(DateTime) get onDateofITRChanged => dateOfITRController.sink.add;

  final dateOfFilingController = BehaviorSubject<DateTime>();
  Stream<DateTime> get dateOfFiling => dateOfFilingController.stream;
  Function(DateTime) get onDateOfFilingChanged =>
      dateOfFilingController.sink.add;

  List<ItrDropDown> itrDropDownsList = [
    ItrDropDown(itrDropDwnName: "139(1)"),
    ItrDropDown(itrDropDwnName: "139(4)"),
    ItrDropDown(itrDropDwnName: "139(5)"),
    ItrDropDown(itrDropDwnName: "119(2)(b)"),
    ItrDropDown(itrDropDwnName: "139(9)"),
    ItrDropDown(itrDropDwnName: "142(1)"),
    ItrDropDown(itrDropDwnName: "148"),
    ItrDropDown(itrDropDwnName: "153A"),
    ItrDropDown(itrDropDwnName: "153C"),
  ];

  // Group Value for Radio Button.
  int radioValue1 = -1;

  List<bool> refundCreditCheckbox = [false];

  bool isLoading = false;

  GenerateJsonModel generateJsonModel;

  double donationLimit;

  final bankListController = BehaviorSubject<List<BankDetails>>();
  final bankListStringController = BehaviorSubject<List<dynamic>>();
  final ifscCodeController = BehaviorSubject<List<String>>();
  final nameOfBankController = BehaviorSubject<List<String>>();
  final accountNoController = BehaviorSubject<List<String>>();

  @override
  void dispose() {
    headIncomeListController.close();
    sectionListController.close();
    _grossTotalIncomeController.close();
    taxableIncomeController.close();
    totalIncomeController.close();
    _t80coutController.close();
    taxSurchargeController.close();
    lessRebate87AController.close();
    surchargeController.close();
    educationCessController.close();
    taxPayableContrller.close();
    balancePayableController.close();
    taxPayableRefundableController.close();
    _incomeTaxController.close();
    t234AController.close();
    t234BController.close();
    t234CController.close();
    total234Controller.close();

    normalTaxController.close();
    specialTaxController.close();

    // ^ basic Details

    filingDateController.close();
    dueDateController.close();
    taxMethodController.close();
    residencyStatusController.close();
    selectedYearController.close();
    selectedITRController.close();
    selectedDomesticCompanyController.close();

    firstNameController.close();
    middleNameController.close();
    lastNameController.close();
    genderController.close();
    dobController.close();
    employeePanController.close();
    fatherNameController.close();
    flatNumberController.close();
    premiseNameController.close();
    streetNameController.close();
    areaController.close();
    townController.close();
    pinController.close();
    stateController.close();
    countryController.close();
    mobileController.close();
    aadharController.close();
    emailController.close();
    // ^ step 1 salary step

    employerNameController.close();
    employerTanController.close();
    employerTypeController.close();
    employerSalaryBy17Controller.close();
    employerBasicController.close();
    employerAllowancePerquisitesController.close();
    employerOtherController.close();
    employerHRAController.close();
    employerLATAController.close();
    employerPerquistesController.close();
    employerProfitInLieuController.close();
    employerExemptAllowancesController.close();
    employerExemptAllowancesDescriptionController.close();
    _employerBalanceController.close();
    _employerStdDeductionController.close();
    employerProfTaxController.close();
    totalSalaryController.close();
    fileController.close();
    _form16DataController.close();
    reliefController.close();

    employerOtherStringController.close();
    employerValueOfPerquisitesStringController.close();
    employeLieuStringController.close();
    employerExemptAllowanceStringController.close();

    // ^ step 2  house property
    interestPaidHPController.close();
    rendtReceivedHPController.close();
    totalHousPartyController.close();
    muncipalTaxController.close();
    inrealisedRentController.close();
    housePropertyTypeController.close();
    anualValueController.close();
    //^ step 3 Business
    profitFromFirmController.close();
    remunerationFromFirmController.close();
    interestFromFirmController.close();
    nameOfBusinessController.close();
    profitFromBusinessController.close();
    totalBusinessIncomeController.close();

    // ^ step 4 Capital Gain
    totalCapitalGainController.close();
    // ! STCG NORMAL
    stcgNormal1509Controller.close();
    stcgNormal1512Controller.close();
    stcgNormal1503Controller.close();
    stcgNormal1506Controller.close();
    stcgNormal3103Controller.close();
    _totalStcgNormalController.close();

    // ! STCG 111A
    stcg111A1506Controller.close();
    stcg111A1509Controller.close();
    stcg111A1512Controller.close();
    stcg111A1503Controller.close();
    stcg111A3103Controller.close();
    _totalStcg111AController.close();

    // ! LTCG 112A
    ltcg112A1506Controller.close();
    ltcg112A1509Controller.close();
    ltcg112A1512Controller.close();
    ltcg112A1503Controller.close();
    ltcg112A3103Controller.close();
    totalLtcg112AController.close();

    // ! LTCG 10
    ltcg101506Controller.close();
    ltcg101509Controller.close();
    ltcg101512Controller.close();
    ltcg101503Controller.close();
    ltcg103103Controller.close();
    totalLtcg10Controller.close();

    // ! LTCG 20

    ltcg201506Controller.close();
    ltcg201509Controller.close();
    ltcg201512Controller.close();
    ltcg201503Controller.close();
    ltcg203103Controller.close();
    _totalLtcg20Controller.close();

    // ^ step 5  other Sources
    interestFromBankDepositController.close();
    interestFromSavingController.close();
    interestTaxIncomeController.close();
    pensionReceivedController.close();
    otherSourceDeduction57Controller.close();
    otherIncomeController.close();
    lottery1506Controller.close();
    lottery1509Controller.close();
    lottery1512Controller.close();
    lottery1503Controller.close();
    lottery3103Controller.close();
    _totalLotteryController.close();
    totalOtherSourcersController.close();

    // ^ step 6 special income
    divident1506Controller.close();
    divident1509Controller.close();
    divident1512Controller.close();
    divident1503Controller.close();
    divident3103Controller.close();
    totalDividentController.close();

    // ^ step 7 loss and bf
    lossBfAdjustedController.close();

    // ^ step 8 deductions
    licDeductionController.close();
    licLimitDeductionController.close();
    pfDeductionController.close();
    hlDeductionController.close();
    publicPfDeductionController.close();
    nscInterestDeductionController.close();
    nscDepositsDeductionController.close();
    educationExpensesDeductionController.close();
    certainFundsDeductionController.close();
    groupInsuranceDeductionController.close();
    mutualFundsDeductionController.close();
    totalDeductionT80Controller.close();
    usertotalDeductionT80Controller.close();
    selfController.close();
    parentController.close();
    parentAgeController.close();
    medicalInsuranceController.close();
    severeController.close();
    handicapController.close();
    interestForHigherEduController.close();
    donation100Controller.close();
    donation50Controller.close();
    _adjustedGtiController.close();
    _qualifyingAmountController.close();
    rentPaidController.close();
    _80GController.close();
    totalDeductionUnderChapter6.close();
    deduction80ccd1Controller.close();
    deduction80ccd1bController.close();
    deduction80ccd2Controller.close();
    selfMediclaimController.close();
    selfHealthcheckupController.close();
    selfMedicalExpenditureController.close();
    parentMediclaimController.close();
    parentHealthcheckupController.close();
    parentMedicalExpenditureController.close();
    senior80ddbController.close();
    medical80ddbController.close();
    parentMedicalInsuranceController.close();
    first80EEController.close();
    withoutLimitController.close();
    houseProperty80EEController.close();
    houseProperty80EEAController.close();
    houseProperty80EEBController.close();
    political80GGCController.close();
    deduction80TTAController.close();
    deduction80TTBController.close();

    certain100doneeNameController.close();
    certain100AddressController.close();
    certain100CityController.close();
    certain100StateController.close();
    certain100PincodeController.close();
    certain100doneePanController.close();
    certain100donationCashController.close();
    certain100donationOtherController.close();
    certain100TotalController.close();
    certain50doneeNameController.close();
    certain50AddressController.close();
    certain50CityController.close();
    certain50StateController.close();
    certain50PincodeController.close();
    certain50doneePanController.close();
    certain50donationCashController.close();
    certain50donationOtherController.close();
    certain50TotalController.close();
    scientificdoneeNameController.close();
    scientificAddressController.close();
    scientificCityController.close();
    scientificStateController.close();
    scientificPincodeController.close();
    scientificdoneePanController.close();
    scientificdonationCashController.close();
    scientificdonationOtherController.close();
    scientificTotalController.close();
    scientificDateController.close();

    // ^ step 9  exempt  income
    exemptIncomeController.close();
    insurancePolicy1010dController.close();
    statutoryPFController.close();
    recognisedPFController.close();
    exemptDividendController.close();
    exemptIncomeDescriptionController.close();
    totalExemptIncomeController.close();

    // ^ step 10 agro income
    agroIncomeController.close();

    // ^ step 14 TDS
    tdsController.close();
    tdsListController.close();

    // ^ step 15 advanced tax
    advancedTaxDateController.close();
    advancedTaxAmountController.close();
    _advancedFirstInstallationController.close();
    _advancedSecondInstallationController.close();
    _advancedThirdInstallationController.close();
    _advancedFourthInstallationController.close();
    totalAdvancedTaxController.close();
    advanceTaxCINController.close();
    advanceTaxBSRController.close();
    advancedtax.clear();
    advancedtaxDate.clear();

    // ^ step 16 self tax
    selfTaxDateController.close();
    selfTaxAmountController.close();
    _selfFirstInstallationController.close();
    _selfSecondInstallationController.close();
    _selfThirdInstallationController.close();
    _selfFourthInstallationController.close();
    totalAdvancedTaxController.close();
    totalSelfTaxController.close();
    selfTaxCINController.close();
    selfTaxBSRController.close();
    selftax.clear();
    selftaxDate.clear();
    super.dispose();
  }

  init(BuildContext context) {
    setBusy(true);
    isLoading = true;
    ctx = context;
    _grossTotalIncomeController.add("0");
    userDob = _services.getUserBday;
    bankListController.add([]);
    ifscCodeController.add([""]);
    nameOfBankController.add([""]);
    accountNoController.add([""]);
    String userName = _services.getUserName;
    String userPan = _services.getUserPan;
    String mobileNo = _services.user;
    String gender = _services.getUserGender;
    String flat = _services.getUserFlatNo;
    String premiseName = _services.getUserPremise;
    String getUserRoad = _services.getUserRoad;
    String getUserArea = _services.getUserArea;
    String getUserPin = _services.getUserPin;
    String getUserState = _services.getUserState;
    String getUserCountry = _services.getUserCountry;
    String town = _services.getUserAddress;
    String firstName = _services.getUserFirstName;
    String middleName = _services.getUserMiddleName;
    String lastName = _services.getUserLastName;
    String getUserDOB = _services.getUserDOB;

    Logger().e(userDob);
    Logger().e(taxMethodController.value.toString());
    Logger().wtf((getUserDOB));
    dobController.value = (userDob ?? "");
    onDobChanged("${userDob}");
    firstNameController.add(firstName ?? "");
    employeePanController.add(userPan ?? "");
    mobileController.add(mobileNo ?? "");
    middleNameController.add(middleName ?? "");
    lastNameController.add(lastName ?? "");
    genderController.add(gender ?? "");
    dobController.add(getUserDOB ?? "");
    // dobController.add("");
    employeePanController.add(userPan ?? "");
    fatherNameController.add("");
    flatNumberController.add(flat ?? "");
    premiseNameController.add(premiseName ?? "");
    streetNameController.add(getUserRoad ?? "");
    areaController.add(getUserArea ?? "");
    townController.add(town ?? "");

    pinController.add(getUserPin ?? "");
    selectedStateController.add(getUserState ?? 1);
    countryController.add(getUserCountry ?? "");
    mobileController.add(mobileNo ?? "");
    aadharController.add("");
    emailController.add("");
    // age = int.parse(userDob);
    _otherDropdownController.add(otherList);
    _perquisitesDropdownController.add(perquisitesList);
    _lieuDropdownController.add(lieuList);
    isAnyOtherController.add([false]);
    // otherList.add(otherList);
    stateDropDownController.add(stateDropwDown);
    selectedStateController.add(1);

    itrDropdownController.add(itrDropDownsList);
    isShowUniqDocController.add(false);
    isShowReceiptNoController.add(false);
    getAuthToken();
    deduction80cccController.add(0);
    deductionTotalof80Controller.add(0);
    notifyListeners();
    setBusy(false);
  }

  void handleRadioValueChange1(int value) {
    radioValue1 = value;
    notifyListeners();
  }

  Future<void> getNoticeDate(BuildContext context) async {
    var noticeDate;
    final datePick = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime(1900),
        lastDate: new DateTime(2025));
    if (datePick != null && datePick != noticeDate) {
      noticeDate = datePick;

      dateOfNoticeController.add(noticeDate);

      onDateofNoticeChanged(noticeDate);

      Logger().e(dateOfNoticeController.value.toString());

      notifyListeners();
    }
  }

  Future<void> setITRDate(BuildContext context) async {
    var noticeDate;
    final datePick = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime(1900),
        lastDate: new DateTime(2025));
    if (datePick != null && datePick != noticeDate) {
      noticeDate = datePick;

      dateOfITRController.add(noticeDate);

      onDateofITRChanged(noticeDate);

      Logger().e(dateOfITRController.value.toString());

      notifyListeners();
    }
  }

  Future<void> getFilingDate(BuildContext context) async {
    var noticeDate;
    final datePick = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime(1900),
        lastDate: new DateTime(2025));
    if (datePick != null && datePick != noticeDate) {
      noticeDate = datePick;

      dateOfFilingController.add(noticeDate);

      onDateOfFilingChanged(noticeDate);

      Logger().e(dateOfFilingController.value.toString());

      notifyListeners();
    }
  }

  Future<void> getBirthDate(BuildContext context) async {
    var birthDate;
    final datePick = await showDatePicker(
        context: context,
        initialDate: new DateTime.now(),
        firstDate: new DateTime(1900),
        lastDate: new DateTime(2025));
    if (datePick != null && datePick != birthDate) {
      birthDate = datePick;
      var birthDate2 = DateFormat("yyyy-MM-dd").format(birthDate);
      print(birthDate2);
      dobController.add(birthDate2.toString());
      print("birthDateController");
      onDobChanged(birthDate2.toString());
      print(dobController.value.toString());
      Logger().e(dobController.value.toString());
      var age2 = Age.dateDifference(
          fromDate: birthDate, toDate: DateTime.now(), includeToDate: false);
      print(age2.years.toString());
      notifyListeners();
    }
  }

  Future<HeadIncomeModel> getHeadIncome() async {
    setBusy(true);
    var sinewaveToken = _services.sinewaveToken;
    Map map = {"fy": selectedYearController.value.toString()};
    logger.wtf(map);
    var result = await _services.headIncome(sinewaveToken, map);
    if (result.statusCode == 200) {
      headIncomeListController.sink.add(result.headOfIncome);
      sectionListController.sink.add(result.sectionOfIncome);
      isLoading = false;
    }
    print(result);
    setBusy(false);
  }

  readBackendData() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {"leads": mobile.toString()};

    ReadStorageModel result = await _services.readStorage(map, token);

    if (result.responseCode == "200") {
      Logger().e(result.data.toJson());
      BasicDetails basicDetailss = result.data.basicDetails;

      SalaryModel salary = result.data.salary;
      HouseProperty houseProperty = result.data.houseProperty;
      Business business = result.data.business;
      CapitalGain capitalGain = result.data.capitalGain;
      OtherSources otherSources = result.data.otherSources;
      OtherSpecialIncome otherSpecialIncome = result.data.otherSpecialIncome;
      Deductions deductions = result.data.deductions;
      Tds tds = result.data.tds;
      AdvanceTax advanceTax = result.data.advanceTax;
      AdvanceTax selfTax = result.data.selfAssesmentTax;
      Exempt exempt = result.data.exemptIncome;
      ITRInformation itr_information = result.data.itr_information;
      if (basicDetailss == null) {
        initBasicDetails();
        basicDetails();
        getHeadIncome();
      } else {
        selectedYearController.add(basicDetailss.year ?? "2021-2022");
        filingDateController.add(basicDetailss.filingDate ?? "");
        dueDateController.add(basicDetailss.dueDate ?? "");
        taxMethodController.add(basicDetailss.taxMethod ?? "N");
        bool isNewRegime =
            taxMethodController.value.toString() == "R" ? true : false;
        _exemptAllwnropdownController.add(isNewRegime
            ? exemptAllwnList_newRegime
            : exemptAllwnList_oldRegime);

        residencyStatusController.add(basicDetailss.residency ?? "R");
        selectedITRController.add(basicDetailss.itrStatus ?? "01");
        selectedDomesticCompanyController
            .add(basicDetailss.domesticCompany ?? "");
        firstNameController.add(basicDetailss.firstName ?? "");
        middleNameController.add(basicDetailss.middleName ?? "");
        Logger().d(basicDetailss.middleName);
        Logger().d(middleNameController.value);
        lastNameController.add(basicDetailss.lastName ?? "");
        genderController.add(basicDetailss.gender ?? "");
        dobController.add(basicDetailss.dob ?? userDob);
        if (basicDetailss.dob != null) {
          _services.saveBirthDate(basicDetailss.dob);
        }
        employeePanController.add(basicDetailss.pan ?? "");
        fatherNameController.add(basicDetailss.fatherName ?? "");
        flatNumberController.add(basicDetailss.flatNumber ?? "");
        premiseNameController.add(basicDetailss.premiseName ?? "");
        streetNameController.add(basicDetailss.streetName ?? "");
        areaController.add(basicDetailss.area ?? "");
        townController.add(basicDetailss.town ?? "");
        pinController.add(basicDetailss.pin ?? "");
        selectedStateController.add(basicDetailss.state ?? 1);
        countryController.add(basicDetailss.country ?? "");
        mobileController.add(basicDetailss.mobileNumber ?? "");
        aadharController.add(basicDetailss.aadharNumber ?? "");
        emailController.add(basicDetailss.emailId ?? "");
        // selectedStateController.add(basicDetailss.state ?? "");
        basicDetails();
        getHeadIncome();
      }

      if (salary == null) {
        initSalary();
      } else {
        employerTanController.add(salary.employerPan ?? "");
        employerNameController.add(salary.employerName ?? "");
        employerPanDeducterController.add(salary.panDeducter ?? "");
        employerTanDeducterController.add(salary.tanDeducter ?? "");
        employerTypeController.add(salary.employerCategory ?? "");
        employerBasicController.add(salary.employerBasic ?? 0);
        employerHRAController.add(salary.employerHra ?? 0);
        employerLATAController.add(salary.lta ?? 0);
        employerAllowancePerquisitesController
            .add(salary.employerAllowancePerquisites ?? 0);
        employerOtherController.add(salary.other ?? []);
        employerPerquistesController.add(salary.perquisites ?? []);
        employerProfitInLieuController.add(salary.lieu ?? []);
        employerExemptAllowancesController.add(salary.exemptAllowance ?? []);
        employerExemptAllowancesDescriptionController.add([""]);
        Logger().e(salary.exemptAllowance);
        Logger().e(salary.exemptAllowanceString);
        salary.exemptAllowanceString.forEach((element) {
          if (element.contains("Any Other")) {
            isAnyOtherController.add([true]);
            employerExemptAllowancesDescriptionController.add([""]);
          } else {
            isAnyOtherController.value.add(false);
            employerExemptAllowancesDescriptionController.add([""]);
          }
        });
        if (salary.exemptAllowance.toString() == [].toString()) {
          isAnyOtherController.add([false]);
          employerExemptAllowancesDescriptionController.add([""]);
          Logger().d("---------[-------]-----------");
        } else {
          if (salary.exemptAllowance.toString() == [].toString()) {
            isAnyOtherController.add([false]);
            Logger().d("---------[-------]-----------");
          }
          print(salary.exemptAllowance);
          salary.exemptAllowance.forEach((element) {
            if (element == 0) {
              print("element");
              Logger().wtf(element);
              isAnyOtherController.value.add(true);
            } else {
              isAnyOtherController.value.add(false);
            }
          });

          Logger().d("---------[else]-----------");
        }
        // employeExemptAllwnStringController.add([])
        // ;
        employerExemptAllowanceStringController
            .add(salary.exemptAllowanceString ?? []);
        employerOtherStringController.add(salary.otherString ?? []);
        employerValueOfPerquisitesStringController
            .add(salary.perquisitesString ?? []);
        employeLieuStringController.add(salary.lieuString ?? []);

        employeExemptAllwnStringController
            .add(salary.exemptAllowanceString ?? []);

        // employerExemptAllowancesController.add(salary.exemptAllowance ?? []);
        employerProfTaxController.add(salary.profTax ?? "");
        employerEntertainementController.add(salary.entertainment ?? "0");
        calculateSalary();
      }

      if (houseProperty == null) {
        initHouseProperty();
      } else {
        interestPaidHPController.add(houseProperty.self);
        rendtReceivedHPController.add(houseProperty.rented);
        muncipalTaxController.add(houseProperty.muncipalTax ?? 0);
        inrealisedRentController.add(houseProperty.inrealisedRent ?? 0);
        housePropertyTypeController.add(houseProperty.housePropertyType ?? "");
        calculateHouseProperty();
      }

      if (business == null) {
        initBusiness();
      } else {
        profitFromFirmController.add(business.firmProfit);
        remunerationFromFirmController.add(business.remuneration);
        interestFromFirmController.add(business.interest);
        nameOfBusinessController.add(business.businessName);
        profitFromBusinessController.add(business.businessProfit);
        calculateBusiness();
      }

      if (capitalGain == null) {
        initCapitalGain();
      } else {
        // ! STCG NORMAL
        stcgNormal1509Controller.add(capitalGain.stcgNormal1509);
        stcgNormal1512Controller.add(capitalGain.stcgNormal1512);
        stcgNormal1503Controller.add(capitalGain.stcgNormal1503);
        stcgNormal1506Controller.add(capitalGain.stcgNormal1506);
        stcgNormal3103Controller.add(capitalGain.stcgNormal3103);
        // ! STCG 111A
        stcg111A1506Controller.add(capitalGain.stcg111A1506);
        stcg111A1509Controller.add(capitalGain.stcg111A1509);
        stcg111A1512Controller.add(capitalGain.stcg111A1512);
        stcg111A1503Controller.add(capitalGain.stcg111A1503);
        stcg111A3103Controller.add(capitalGain.stcg111A3103);
        // ! LTCG 112A
        ltcg112A1506Controller.add(capitalGain.ltcg112A1506);
        ltcg112A1509Controller.add(capitalGain.ltcg112A1509);
        ltcg112A1512Controller.add(capitalGain.ltcg112A1512);
        ltcg112A1503Controller.add(capitalGain.ltcg112A1503);
        ltcg112A3103Controller.add(capitalGain.ltcg112A3103);
        // ! LTCG 10
        ltcg101506Controller.add(capitalGain.ltcg101506);
        ltcg101509Controller.add(capitalGain.ltcg101509);
        ltcg101512Controller.add(capitalGain.ltcg101512);
        ltcg101503Controller.add(capitalGain.ltcg101503);
        ltcg103103Controller.add(capitalGain.ltcg103103);
        // ! LTCG 20
        ltcg201506Controller.add(capitalGain.ltcg201506);
        ltcg201509Controller.add(capitalGain.ltcg201509);
        ltcg201512Controller.add(capitalGain.ltcg201512);
        ltcg201503Controller.add(capitalGain.ltcg201503);
        ltcg203103Controller.add(capitalGain.ltcg203103);

        calculateCapitalGain();
      }

      if (otherSources == null) {
        initOtherSources();
      } else {
        interestFromBankDepositController.add(otherSources.interestBank);
        interestFromSavingController.add(otherSources.interestSaving);
        otherIncomeController.add(otherSources.otherIncome ?? [0]);
        interestTaxIncomeController.add(otherSources.interestTaxIncome ?? 0);
        pensionReceivedController.add(otherSources.pensionReceived ?? 0);
        otherSourceDeduction57Controller
            .add(otherSources.otherSourceDeduction57 ?? 0);
        calculateOtherSources();
      }

      if (otherSpecialIncome == null) {
        initOtherSpecialIncome();
      } else {
        divident1506Controller.add(otherSpecialIncome.divident1506);
        divident1509Controller.add(otherSpecialIncome.divident1509);
        divident1512Controller.add(otherSpecialIncome.divident1512);
        divident1503Controller.add(otherSpecialIncome.divident1503);
        divident3103Controller.add(otherSpecialIncome.divident3103);
        lottery1506Controller.add(otherSpecialIncome.lottery1506);
        lottery1509Controller.add(otherSpecialIncome.lottery1509);
        lottery1512Controller.add(otherSpecialIncome.lottery1512);
        lottery1503Controller.add(otherSpecialIncome.lottery1503);
        lottery3103Controller.add(otherSpecialIncome.lottery3103);
        calculateOtherSpecialIncome();
      }

      if (result.data.lossBfAdjusted == null) {
        initLossBfAdjusted();
      } else {
        lossBfAdjustedController.add(result.data.lossBfAdjusted);
        calculateLossBfAdjusted();
      }

      if (deductions == null) {
        initDeduction();
      } else {
        licDeductionController.sink.add(deductions.lic ?? 0);
        licLimitDeductionController.sink.add(deductions.licLimit ?? 0);
        pfDeductionController.sink.add(deductions.pf ?? 0);
        hlDeductionController.sink.add(deductions.hl ?? 0);
        publicPfDeductionController.sink.add(deductions.publicPf ?? 0);
        nscInterestDeductionController.sink.add(deductions.nscInterest ?? 0);
        nscDepositsDeductionController.sink.add(deductions.nscDeposit ?? 0);
        educationExpensesDeductionController.sink
            .add(deductions.educationExpenses ?? 0);
        certainFundsDeductionController.sink.add(deductions.certainFunds ?? 0);
        groupInsuranceDeductionController.sink
            .add(deductions.groupInsurance ?? 0);
        mutualFundsDeductionController.sink.add(deductions.mf ?? 0);
        if (age == null) {
          String getUserDOB = _services.getUserDOB;
          // String birthDate = _services.birthDate;

          print(getUserDOB);
          if (getUserDOB == null) {
            var dateOfBirth = _services.birthDate;
            print(dateOfBirth);
            // int year = int.parse(dateOfBirth.substring(6, 10));
            // int month = int.parse(dateOfBirth.substring(3, 5));
            // int day = int.parse(dateOfBirth.substring(0, 2));
            int year = int.parse(dateOfBirth.substring(0, 4));
            int month = int.parse(dateOfBirth.substring(5, 7));
            int day = int.parse(dateOfBirth.substring(8, 10));
            print(day);
            print(month);
            print(year);

            DateTime birthday = DateTime(year, month, day);
            DateTime today = DateTime.now();

            age1 = Age.dateDifference(
                fromDate: birthday, toDate: today, includeToDate: false);

            // var dateTime2 = DateFormat('MM/dd/yyyy ')
            //     .parse(birthDate.toString().replaceAll('-', '/'));
            // // var dateTime3 =
            // //     DateFormat('yyyy/mm/dd').parse(dateTime2.toString());
            // Logger().e(dateTime2);
            // Logger().e(dateTime3);
            // var date = (birthDate.toString().substring(0, 1));
            // print("Date: " + date.toString());

            // var month = birthDate.toString().substring(2, 3);
            // print("month: " + month.toString());

            // var year = birthDate.toString().substring(4, 8);
            // print(year.toString());
            // DateTime newBday = DateTime(
            //   int.parse(year),
            //   int.parse(month),
            //   int.parse(date),
            // );

            // Logger().e(newBday);
            // age1 = Age.dateDifference(
            //     fromDate: newBday,
            //     toDate: DateTime.now(),
            //     includeToDate: false);
            Logger().e(age1);
            if (age1.years >= 60) {
              selfController.add(true);
            } else {
              selfController.add(true);
            }
          } else {
            DateTime newBday = DateTime.parse(getUserDOB.toString());

            Logger().e(getUserDOB);
            age1 = Age.dateDifference(
                fromDate: newBday,
                toDate: DateTime.now(),
                includeToDate: false);
            Logger().e(age1);
            if (age1.years >= 60) {
              selfController.add(true);
            } else {
              selfController.add(false);
            }
          }
        }

        parentController
            .add(deductions.parent == null ? false : deductions.parent);
        parentAgeController
            .add(deductions.parentAge == null ? false : deductions.parentAge);
        medicalInsuranceController.sink.add(deductions.medicalInsurance ?? 0);
        interestForHigherEduController.add(deductions.higherEducation ?? 0);
        donation100Controller.add(deductions.donation100 ?? 0);
        donation50Controller.add(deductions.donation50 ?? 0);
        handicapController.add(deductions.handicap ?? false);
        severeController.add(deductions.severe ?? false);
        rentPaidController.add(deductions.rent ?? "0");

        deduction80ccd1Controller.add(deductions.deduction80ccd1 ?? 0);
        deduction80ccd1bController.add(deductions.deduction80ccd1b ?? 0);
        deduction80ccd2Controller.add(deductions.deduction80ccd2 ?? 0);
        selfMediclaimController.add(deductions.selfMediclaim ?? 0);
        selfHealthcheckupController.add(deductions.selfHealthcheckup ?? 0);
        selfMedicalExpenditureController
            .add(deductions.selfMedicalExpenditure ?? 0);
        parentMediclaimController.add(deductions.parentMediclaim ?? 0);
        parentHealthcheckupController.add(deductions.parentHealthcheckup ?? 0);
        parentMedicalExpenditureController
            .add(deductions.parentMedicalExpenditure ?? 0);
        senior80ddbController.add(deductions.senior80ddb ?? "false");
        medical80ddbController.add(deductions.medical80ddb ?? 0);
        parentMedicalInsuranceController
            .add(deductions.parentMedicalInsurance ?? 0);
        first80EEController.add(deductions.first80EE ?? false);
        withoutLimitController.add(false);
        houseProperty80EEController.add(deductions.houseProperty80EE ?? 0);
        houseProperty80EEAController.add(deductions.houseProperty80EEA ?? 0);
        houseProperty80EEBController.add(deductions.houseProperty80EEB ?? 0);
        political80GGCController.add(deductions.political80GGC ?? 0);
        deduction80TTAController.add(deductions.deduction80TTA ?? 0);
        deduction80TTBController.add(deductions.deduction80TTB ?? 0);

        certain100doneeNameController
            .add(deductions.certain100doneeName.toList() ?? []);
        certain100AddressController
            .add(deductions.certain100Address.toList() ?? []);
        certain100CityController.add(deductions.certain100City.toList() ?? []);
        certain100StateController.add(deductions.certain100State ?? []);
        certain100PincodeController.add(deductions.certain100Pincode ?? []);
        certain100doneePanController.add(deductions.certain100doneePan ?? []);
        certain100donationCashController
            .add(deductions.certain100donationCash ?? [0]);
        certain100donationOtherController
            .add(deductions.certain100donationOther ?? [0]);
        certain100TotalController.add(deductions.certain100Total ?? []);

        certain50doneeNameController.add(deductions.certain50doneeName ?? []);
        certain50AddressController.add(deductions.certain50Address ?? []);
        certain50CityController.add(deductions.certain50City ?? []);
        certain50StateController.add(deductions.certain50State ?? []);
        certain50PincodeController.add(deductions.certain50Pincode ?? []);
        certain50doneePanController.add(deductions.certain50doneePan ?? []);
        certain50donationCashController
            .add(deductions.certain50donationCash ?? [0]);
        certain50donationOtherController
            .add(deductions.certain50donationOther ?? [0]);
        certain50TotalController.add(deductions.certain50Total ?? []);

        scientificdoneeNameController.add(deductions.scientificdoneeName ?? []);
        scientificAddressController.add(deductions.scientificAddress ?? []);
        scientificCityController.add(deductions.scientificCity ?? []);
        scientificStateController.add(deductions.scientificState ?? []);
        scientificPincodeController.add(deductions.scientificPincode ?? []);
        scientificdoneePanController.add(deductions.scientificdoneePan ?? []);
        scientificdonationCashController
            .add(deductions.scientificdonationCash ?? [0]);
        scientificdonationOtherController
            .add(deductions.scientificdonationOther ?? [0]);
        scientificTotalController.add(deductions.scientificTotal ?? []);
        scientificDateController.add([""]);
        usertotalDeductionT80Controller.add("0");
        deduction80cccController.add(0);
        deductionTotalof80Controller.add(0);
        calculateDeduction();
      }

      if (result.data.exemptIncome == null) {
        initExemptIncome();
      } else {
        exemptIncomeController.add(exempt.exemptIncome ?? "0");
        insurancePolicy1010dController.add(exempt.insurancePolicy1010d ?? "0");
        statutoryPFController.add(exempt.statutoryPF ?? "0");
        recognisedPFController.add(exempt.recognisedPF ?? "0");
        exemptDividendController.add(exempt.exemptDividend ?? "0");
        exemptIncomeDescriptionController
            .add(exempt.exemptIncomeDescription ?? "0");
        calculateExemptIncome();
      }

      if (result.data.agricultureIncome == null) {
        initAgroIncome();
      } else {
        agroIncomeController.add(result.data.agricultureIncome);
        calculateAgro();
      }

      if (tds == null) {
        initTds();
      } else {
        tdsListController.add(tds.details);

        calculateTds();
      }

      if (advanceTax == null) {
        initAdvancedTax();
      } else {
        advancedTaxAmountController.add(advanceTax.amount ?? []);
        advancedTaxDateController.add(advanceTax.date ?? []);
        advanceTaxCINController.add(advanceTax.cin ?? []);
        advanceTaxBSRController.add(advanceTax.bsr ?? []);
        calculateAdvancedTax(
            advancedTaxAmountController.value, advancedTaxDateController.value);
      }

      if (selfTax == null) {
        initSelfTax();
      } else {
        selfTaxAmountController.add(selfTax.amount ?? []);
        selfTaxDateController.add(selfTax.date ?? []);
        selfTaxCINController.add(selfTax.cin ?? []);
        selfTaxBSRController.add(selfTax.bsr ?? []);
        Logger().e(selfTax.toJson());
        Logger().e(selfTaxBSRController.value.toString());
        Logger().e(selfTaxBSRController.value.toString());
        calculateSelfAssestTax(
            selfTaxAmountController.value, selfTaxDateController.value);
      }

      if (itr_information == null) {
        initItrInformation();
      } else {
        itrDropdownStringController.add(itr_information.itr_dropDown ?? "");
        uniqDocController.add(itr_information.unique_doc_no.toString() ?? "");
        dateOfNoticeController
            .add(DateTime.parse(itr_information.date_of_notice) ?? DateTime.now());
        Logger().wtf(itr_information.date);
        dateOfITRController.add( itr_information.date != null ? DateTime.parse(itr_information.date) ?? DateTime.now():DateTime.now());
        receiptNoController.add(itr_information.receipt_no ?? "");
        Logger().e(itr_information.date_of_notice);
        Logger().e(itr_information.date_of_filing);
        dateOfFilingController
            .add(itr_information.date_of_filing  != null ? itr_information.date_of_filing.toString() != "" ? DateTime.parse(itr_information.date_of_filing) ?? DateTime.now() : DateTime.now(): DateTime.now());
        depositeAmtExceedController
            .add(itr_information.depositeAmt_exceed ?? "");
        foreignTravelExpensesController
            .add(itr_information.foreignTravelExpenses ?? "");
        electricitybillsExceedingController
            .add(itr_information.electricityBill ?? "");
        // middleNameController.add(itr_information.son_of ?? "");
        // employeePanController.add(itr_information.pan_no ?? "");
        // ifscCodeController.add(itr_information.ifsc_code ?? []);
        // nameOfBankController.add(itr_information.bank_name ?? []);
        // accountNoController.add(itr_information.account_no ?? []);
        Logger().wtf(itr_information.bank_details);
        Logger().wtf(itr_information.electricityBill);
        bankListController.value.addAll(itr_information.bank_details ?? []);
        notifyListeners();
        Logger().e(bankListController.value);

        // refundCreditCheckbox.add(itr_information.refundCreditCheckbox);
      }
    } else if (result.responseCode == "400") {
      initBasicDetails();
      initSalary();
      initHouseProperty();
      initBusiness();
      initCapitalGain();
      initOtherSources();
      initOtherSpecialIncome();
      initLossBfAdjusted();
      initDeduction();
      initExemptIncome();
      initAgroIncome();
      initTds();
      initAdvancedTax();
      initSelfTax();
    } else if (result.responseCode == "401") {
      _services.navigateToLoginScreen();
    } else {
      initBasicDetails();
      initSalary();
      initHouseProperty();
      initBusiness();
      initCapitalGain();
      initOtherSources();
      initOtherSpecialIncome();
      initLossBfAdjusted();
      initDeduction();
      initExemptIncome();
      initAgroIncome();
      initTds();
      initAdvancedTax();
      initSelfTax();
    }
  }

  Future<dynamic> getAuthToken() async {
    setBusy(true);
    // String caCode = _services.ca_code;
    // String caPan = _services.ca_pan;

    Map map = {"cust_id": "100", "password": "1234"};

    GetTokenModel result = await _services.getSinewaveToken(map);
    if (result.statusCd == "true") {
      _services.saveSinewaveToken(result.authToken);
      readBackendData();
    } else {
      _services.showErrorDialog(title: "Failed", description: result.message);
      getAuthToken();
    }
    setBusy(false);
  }

  void calculateGrossTotalIncome() {
    _grossTotalIncomeController.add(
      ((double.parse(totalSalaryController.value.toString()).round() +
                  double.parse(totalHousPartyController.value.toString())
                      .round() +
                  double.parse(totalBusinessIncomeController.value.toString())
                      .round() +
                  double.parse(totalCapitalGainController.value.toString())
                      .round() +
                  double.parse(totalOtherSourcersController.value.toString())
                      .round() +
                  double.parse(totalDividentController.value.toString())
                      .round()) +
              double.parse(lossBfAdjustedController.value.toString()).round())
          .toString(),
    );
    Logger().e(_grossTotalIncomeController.value.toString());
    notifyListeners();
  }

// ^ basic details

  initBasicDetails() {
    Logger().wtf("---------------initBasicDetails--------------");
    String employeePan = _services.getUserPan;
    String town = _services.getUserAddress;
    String mobile = _services.user;
    String userName = _services.getUserName;
    String userGender = _services.getUserGender ?? "";
    String flat = _services.getUserFlatNo;
    String premiseName = _services.getUserPremise;
    String getUserRoad = _services.getUserRoad;
    String getUserArea = _services.getUserArea;
    String getUserPin = _services.getUserPin;
    String getUserState = _services.getUserState;
    String getUserCountry = _services.getUserCountry;

    String firstName = _services.getUserFirstName;
    String middleName = _services.getUserMiddleName;
    String lastName = _services.getUserLastName;
    String getUserDOB = _services.getUserDOB;
    String gender = _services.getUserGender;

    firstNameController.add(firstName ?? "");
    middleNameController.add(middleName ?? "");
    lastNameController.add(lastName ?? "");
    genderController.add(gender ?? "");
    dobController.add(getUserDOB ?? "");
    Logger().e(town);
    Logger().e(town.toString() != "null");
    Logger().e(town != null);
    // addreessController.add();
    employeePanController.add(employeePan);

    flatNumberController.add(flat ?? "");
    townController.add(town.toString() != "null" ? town : "");
    premiseNameController.add(premiseName ?? "");
    streetNameController.add(getUserRoad ?? "");
    areaController.add(getUserArea ?? "");
    // townController.add(town != null ? town : "");
    pinController.add(getUserPin ?? "");
    selectedStateController.add(getUserState ?? 1);
    countryController.add(getUserCountry ?? "");

    mobileController.add(mobile ?? "");
    // if (userName.toString().contains(' ')) {
    //   firstNameController
    //       .add(userName.toString().substring(0, userName.indexOf(' ')) ?? "");
    // } else {
    //   firstNameController.add(userName.toString() ?? "");
    // }

    // genderController.add(userGender ?? "");

    filingDateController.add("");
    dueDateController.add("");
    taxMethodController.add("N");
    bool isNewRegime =
        taxMethodController.value.toString() == "R" ? true : false;
    _exemptAllwnropdownController.add(
        isNewRegime ? exemptAllwnList_newRegime : exemptAllwnList_oldRegime);
    residencyStatusController.add("R");
    selectedYearController.add("2021-2022");
    selectedITRController.add("01");
    selectedDomesticCompanyController.add("");
    // middleNameController.add("");
    // lastNameController.add("");
    // dobController.add("");
    // employeePanController.add("");
    fatherNameController.add(middleName ?? "");

    aadharController.add("");
    emailController.add("");

    basicDetails();
  }

  basicDetails() {
    filingdate = filingDateController.value.toString();
    duedate = dueDateController.value.toString();
    selectedyear = selectedYearController.value.toString();
    taxmethod = taxMethodController.value.toString();
    residencystatus = residencyStatusController.value.toString();
    selecteditr = selectedITRController.value.toString();
    selecteddomesticcompany =
        selectedDomesticCompanyController.value.toString();
  }

  // "leads": mobile.toString(),
  saveBasicDetails() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": {
        "year": selectedYearController.value.toString(),
        "filingDate": filingDateController.value.toString(),
        "dueDate": dueDateController.value.toString(),
        "taxMethod": taxMethodController.value.toString(),
        "residency": residencyStatusController.value.toString(),
        "itrStatus": selectedITRController.value.toString(),
        "domesticCompany": selectedDomesticCompanyController.value.toString(),
        "firstName": firstNameController.value.toString(),
        "middleName": middleNameController.value.toString(),
        "lastName": lastNameController.value.toString(),
        "gender": genderController.value.toString(),
        "dob": dobController.value.toString(),
        "pan": employeePanController.value.toString(),
        "fatherName": fatherNameController.value.toString(),
        "flatNumber": flatNumberController.value.toString(),
        "premiseName": premiseNameController.value.toString(),
        "streetName": streetNameController.value.toString(),
        "area": areaController.value.toString(),
        "town": townController.value.toString(),
        "pin": pinController.value.toString(),
        "state": selectedStateController.value.toString(),
        "country": countryController.value.toString(),
        "mobileNumber": mobileController.value.toString(),
        "aadharNumber": aadharController.value.toString(),
        "emailId": emailController.value.toString(),
      },
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      bool isNewRegime =
          taxMethodController.value.toString() == "R" ? true : false;
      _exemptAllwnropdownController.add(
          isNewRegime ? exemptAllwnList_newRegime : exemptAllwnList_oldRegime);
      _services.saveUserPan(employeePanController.value.toString());
      _services.saveFlatNo(flatNumberController.value.toString());
      _services.savepremiseName(premiseNameController.value.toString());
      _services.saveStreetName(streetNameController.value.toString());
      _services.saveArea(areaController.value.toString());
      _services.saveUserTown(townController.value.toString());
      _services.saveUserPin(pinController.value.toString());
      _services.saveUserState(selectedStateController.value.toString());
      _services.saveUserCountry(countryController.value.toString());
      notifyListeners();
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 1 Salary

  initSalary() {
    var customerPan = _services.getUserPan;
    var customerName = _services.getUserName;

    employerNameController.sink.add("");
    employerTanController.sink.add(customerPan);
    employerTypeController.sink.add("Other");
    employerBasicController.sink.add(0);
    employerHRAController.sink.add(0);
    employerLATAController.sink.add(0);
    employerAllowancePerquisitesController.sink.add(0);
    employerOtherController.add([0]);
    employerPerquistesController.sink.add([0]);
    employerProfitInLieuController.sink.add([0]);
    employerExemptAllowancesController.sink.add([0]);
    employerExemptAllowancesDescriptionController.sink.add([""]);
    employerEntertainementController.sink.add("0");
    employerProfTaxController.sink.add(0);
    totalSalaryController.sink.add("0");
    employerExemptAllowanceStringController.add([""]);
    employeExemptAllwnStringController.add([""]);
    isAnyOtherController.add([false]);
    employerOtherStringController.add([""]);
    employerValueOfPerquisitesStringController.add([""]);
    employeLieuStringController.add([""]);
    employeExemptAllwnStringController.add([""]);
    calculateSalary();
    notifyListeners();
  }

  void navigateToCalculationScreen({Widget child}) {
    _services.navigateToCalculationScreen(child);
  }

  void calculateOther(List<int> otherDoubleList) {
    print("=======================other list================");
    print(otherDoubleList.length);
    for (var i = 0; i < otherDoubleList.length; i++) {
      employerOtherController.sink.add(otherDoubleList);
    }
  }

  void calculatePerquisites(List<int> perquisitesDoubleList) {
    for (var i = 0; i < perquisitesDoubleList.length; i++) {
      employerPerquistesController.sink.add(perquisitesDoubleList);
    }
  }

  void calculateExempt(List<int> exemptDoubleList) {
    for (var i = 0; i < exemptDoubleList.length; i++) {
      employerExemptAllowancesController.sink.add(exemptDoubleList);
    }
  }

  void calculateLieu(List<int> lieuDoubleList) {
    for (var i = 0; i < lieuDoubleList.length; i++) {
      employerProfitInLieuController.sink.add(lieuDoubleList);
    }
  }

  calculateSalary() {
    setBusy(true);

    employername = employerNameController.value.toString();
    employertan = employerTanController.value.toString();
    employercategory = employerTypeController.value.toString();
    employerbasic = employerBasicController.value.toString();
    employerhra = employerHRAController.value.toString();
    employerlata = employerLATAController.value.toString();
    employerallowanceperquisites =
        employerAllowancePerquisitesController.value.toString();
    employerprofessionaltax = employerProfTaxController.value.toString();

    if (int.tryParse(employerEntertainementController.value) > 5000) {
      employerEntertainementController.add("5000");
    }

    employerSalaryBy17Controller.sink.add(
        (double.parse(employerBasicController.value.toString()).round() +
                double.parse(employerHRAController.value.toString()).round())
            .toString());

    _employerBalanceController.sink.add(
        ((double.parse(employerSalaryBy17Controller.value.toString()).round() +
                double.tryParse(employerAllowancePerquisitesController.value.toString().isEmpty ? "0" : employerAllowancePerquisitesController.value.toString())
                    .round() +
                double.tryParse(employerLATAController.value.toString().isEmpty ? "0" : employerLATAController.value.toString())
                    .round() +
                double.tryParse(employerOtherController.value
                            .reduce((a, b) => a + b)
                            .toString()
                            .isEmpty
                        ? "0"
                        : employerOtherController.value
                            .reduce((a, b) => a + b)
                            .toString())
                    .round() +
                double.tryParse(employerPerquistesController.value
                            .reduce((a, b) => a + b)
                            .toString()
                            .isEmpty
                        ? "0"
                        : employerPerquistesController.value.reduce((a, b) => a + b).toString())
                    .round() +
                double.parse(employerProfitInLieuController.value.reduce((a, b) => a + b).toString()).round() -
                double.parse(employerExemptAllowancesController.value.reduce((a, b) => a + b).toString()).round() -
                double.parse(employerEntertainementController.value.toString()).round()))
            .toString());
    notifyListeners();
    if (selectedYearController.value == "2021-2022" &&
        taxMethodController.value == "R") {
      _employerStdDeductionController.add("0");
      employerProfTaxController.add("0");
    } else {
      if (double.parse(_employerBalanceController.value.toString()).round() >
          50000) {
        _employerStdDeductionController.sink.add("50000");
        print("=================if ");
        notifyListeners();
      } else {
        _employerStdDeductionController.sink
            .add(_employerBalanceController.value.toString());

        print("=================else ");
        notifyListeners();
      }
    }

    if (double.parse(employerProfTaxController.value.toString()).round() >
        2500) {
      employerProfTaxController.sink.add(2500);
    }

    totalSalaryController.sink.add(
        (double.parse(_employerBalanceController.value.toString()).round() -
                double.parse(_employerStdDeductionController.value.toString())
                    .round() -
                double.parse(employerProfTaxController.value.toString())
                    .round())
            .toString());
    calculateGrossTotalIncome();

    notifyListeners();
    setBusy(false);
  }

  saveSalary() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": {
        "employerName": employerNameController.value.toString(),
        "employerPan": employerTanController.value.toString(),
        "employerCategory": employerTypeController.value.toString(),
        "employerBasic": employerBasicController.value.toString(),
        "employerHra": employerHRAController.value.toString(),
        "lta": employerLATAController.value.toString(),
        "employerAllowancePerquisites":
            employerAllowancePerquisitesController.value.toString(),
        "other": employerOtherController.value,
        "perquisites": employerPerquistesController.value,
        "lieu": employerProfitInLieuController.value,
        "exemptAllowance": employerExemptAllowancesController.value,
        "profTax": employerProfTaxController.value.toString(),
        "tanDeducter": employerTanDeducterController.value.toString(),
        "panDeducter": employerPanDeducterController.value.toString(),
        "entertainment": employerEntertainementController.value.toString(),
        "otherString": employerOtherStringController.value,
        "perquisitesString": employerValueOfPerquisitesStringController.value,
        "lieuString": employeLieuStringController.value,
        "exemptAllowanceString": employerExemptAllowanceStringController.value,
      },
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

  Future<dynamic> getFor16File() async {
    setBusy(true);
    FilePickerResult result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: [FILETYPE_PDF, FILETYPE_DOC, FILETYPE_DOCX]);
    if (result != null) {
      document = File(result.files.single.path);
    } else {
      // User canceled the picker
    }
    setBusy(false);
    fileController.sink.add(document);
    //await _cropImage(image);
    notifyListeners();
  }

  Future<dynamic> uploadForm16() async {
    setBusy(true);
    if (fileController.value != null) {
      Form16Model result = await _services.uploadForm16(
          fileController.value, _services.sinewaveToken);
      if (result.statusCode == 200) {
        logger.e(result.details.toJson());
        logger.d(result.master.toJson());
        // if (selectedPanController.value.toString() ==
        //     result.master.pAN.toString()) {
        String firstName = result.master.firstName.toString() + " ";
        String middleName = result.master.middleName.toString() + " ";
        String lastName = result.master.lastName.toString();
        _form16DataController.add(result);
        reliefController.add(result.details.relief.toString());
        employerNameController.add(firstName + middleName + lastName);
        employerGenderController.add(result.master.gender.toString());
        employerfNoController.add(result.master.fno.toString());
        employerPremisesNoController
            .add(result.master.nameOfPremises.toString());
        employerStreetNameController.add(result.master.streetName.toString());
        employerLocalityController.add(result.master.locality.toString());
        employerCityController.add(result.master.city.toString());
        employerPinController.add(result.master.pin.toString());
        employerStateController.add(result.master.state.toString());
        employerCountryController.add(result.master.country.toString());
        employerTanController.add(result.master.pAN.toString());
        employerTypeController.add(result.details.categoryOfEmployer.isEmpty
            ? "Other"
            : result.details.categoryOfEmployer);
        employerBasicController.add(result.details.basic.toString());
        employerHRAController
            .add(result.details.houseRentAllowance2.toString());
        employerLATAController
            .add(result.details.leaveTravelAllowance.toString());
        employerAllowancePerquisitesController.sink
            .add(result.details.perquisites.toString());
        if (double.tryParse(result.details.profitInLieu.toString()) != null) {
          employerProfitInLieuController.sink.add(
              [double.tryParse(result.details.profitInLieu.toString()) ?? 0]);
        }
        if (double.tryParse(result.details.exempt.toString()) != null) {
          employerExemptAllowancesController.sink
              .add([double.parse(result.details.exempt.toString()).round()]);
        }
        _employerStdDeductionController.sink
            .add(result.details.standardDeduction.toString());
        calculateSalary();
        // } else {
        //   _services.showErrorDialog(
        //       title: 'Failed!', description: "PAN Number doesn't match");
        // }
      } else {
        _services.showErrorDialog(
            title: 'Failed!', description: "Not Able to Fetch Details");
      }
    }
    setBusy(false);
    notifyListeners();
  }

//  ^ step 2  house property

  initHouseProperty() {
    interestPaidHPController.add(0);
    rendtReceivedHPController.add(0);
    muncipalTaxController.add(0);
    inrealisedRentController.add(0);
    totalHousPartyController.sink.add("0");
    housePropertyTypeController.add("Self Occupied");

    calculateHouseProperty();
  }

  calculateHouseProperty() {
    var totalHouseProperty = 0;
    anualValueController.add(
        (double.parse(rendtReceivedHPController.value.toString()).round() -
            double.parse(muncipalTaxController.value.toString()).round()));

    if (selectedYearController.value == "2021-2022" &&
        taxMethodController.value == "R") {
      interestPaidHPController.add(0);
      totalHouseProperty =
          (double.parse("-" + interestPaidHPController.value.toString())
                  .round() +
              double.parse(rendtReceivedHPController.value.toString()).round());
    } else {
      if (double.parse(interestPaidHPController.value.toString()) > 200000) {
        interestPaidHPController.add(200000);
        totalHouseProperty =
            (double.parse(anualValueController.value.toString()).round() -
                (double.parse(anualValueController.value.toString()) * 0.3)
                    .round() -
                double.parse("200000").round() +
                double.parse(inrealisedRentController.value.toString())
                    .round());
      } else {
        totalHouseProperty =
            (double.parse(anualValueController.value.toString()).round() -
                (double.parse(anualValueController.value.toString()) * 0.3)
                    .round() -
                double.parse(interestPaidHPController.value.toString())
                    .round() +
                double.parse(inrealisedRentController.value.toString())
                    .round());
      }
    }

    if (totalHouseProperty == 0) {
      totalHousPartyController.sink.add(totalHouseProperty.toString());
    } else {
      totalHousPartyController.sink.add(totalHouseProperty.toString());
    }

    calculateGrossTotalIncome();
    notifyListeners();
  }

  saveHoueProperty() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": {
        "self": interestPaidHPController.value.toString(),
        "rented": rendtReceivedHPController.value.toString(),
        "muncipalTax": muncipalTaxController.value.toString(),
        "inrealisedRent": inrealisedRentController.value.toString(),
        "housePropertyType": housePropertyTypeController.value.toString(),
      },
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 3 Business

  initBusiness() {
    profitFromFirmController.sink.add(0);
    remunerationFromFirmController.sink.add(0);
    interestFromFirmController.sink.add(0);
    nameOfBusinessController.sink.add("");
    profitFromBusinessController.sink.add(0);
    totalBusinessIncomeController.add("0");
    calculateBusiness();
  }

  calculateBusiness() {
    var totalBusiness = 0;

    totalBusiness =
        (double.parse(remunerationFromFirmController.value.toString()).round() +
            double.parse(interestFromFirmController.value.toString()).round() +
            double.parse(profitFromBusinessController.value.toString())
                .round());

    totalBusinessIncomeController.sink.add(totalBusiness.toString());
    calculateGrossTotalIncome();
  }

  saveBusiness() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": {
        "firmProfit": profitFromFirmController.value,
        "remuneration": remunerationFromFirmController.value,
        "interest": interestFromFirmController.value,
        "businessName": nameOfBusinessController.value.toString(),
        "businessProfit": profitFromBusinessController.value,
      },
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 4 Capital Gain

  initCapitalGain() {
    // ! STCG NORMAL
    stcgNormal1509Controller.sink.add(0);
    stcgNormal1512Controller.sink.add(0);
    stcgNormal1503Controller.sink.add(0);
    stcgNormal1506Controller.sink.add(0);
    stcgNormal3103Controller.sink.add(0);

    // ! STCG 111A
    stcg111A1506Controller.sink.add(0);
    stcg111A1509Controller.sink.add(0);
    stcg111A1512Controller.sink.add(0);
    stcg111A1503Controller.sink.add(0);
    stcg111A3103Controller.sink.add(0);

    // ! LTCG 112A
    ltcg112A1506Controller.sink.add(0);
    ltcg112A1509Controller.sink.add(0);
    ltcg112A1512Controller.sink.add(0);
    ltcg112A1503Controller.sink.add(0);
    ltcg112A3103Controller.sink.add(0);

    // ! LTCG 10
    ltcg101506Controller.sink.add(0);
    ltcg101509Controller.sink.add(0);
    ltcg101512Controller.sink.add(0);
    ltcg101503Controller.sink.add(0);
    ltcg103103Controller.sink.add(0);

    // ! LTCG 20

    ltcg201506Controller.sink.add(0);
    ltcg201509Controller.sink.add(0);
    ltcg201512Controller.sink.add(0);
    ltcg201503Controller.sink.add(0);
    ltcg203103Controller.sink.add(0);

    totalCapitalGainController.add("0");
    calculateCapitalGain();
  }

  calculateCapitalGain() {
    var totalGain = 0;
    var totalStcgNormal = 0;
    var totalStcg111A = 0;
    var totalLtcg112A = 0;
    var totalLtcg10 = 0;
    var totalLtcg20 = 0;

    stcgnormal1506 = stcgNormal1506Controller.value.toString();
    stcgnormal1509 = stcgNormal1509Controller.value.toString();
    stcgnormal1512 = stcgNormal1512Controller.value.toString();
    stcgnormal1503 = stcgNormal1503Controller.value.toString();
    stcgnormal3103 = stcgNormal3103Controller.value.toString();

    stcg111a1506 = stcg111A1506Controller.value.toString();
    stcg111a1509 = stcg111A1509Controller.value.toString();
    stcg111a1512 = stcg111A1512Controller.value.toString();
    stcg111a1503 = stcg111A1503Controller.value.toString();
    stcg111a3103 = stcg111A3103Controller.value.toString();

    ltcg112a1506 = ltcg112A1506Controller.value.toString();
    ltcg112a1509 = ltcg112A1509Controller.value.toString();
    ltcg112a1512 = ltcg112A1512Controller.value.toString();
    ltcg112a1503 = ltcg112A1503Controller.value.toString();
    ltcg112a3103 = ltcg112A3103Controller.value.toString();

    ltcg10_1506 = ltcg101506Controller.value.toString();
    ltcg10_1509 = ltcg101509Controller.value.toString();
    ltcg10_1512 = ltcg101512Controller.value.toString();
    ltcg10_1503 = ltcg101503Controller.value.toString();
    ltcg10_3103 = ltcg103103Controller.value.toString();

    ltcg20_1506 = ltcg201506Controller.value.toString();
    ltcg20_1509 = ltcg201509Controller.value.toString();
    ltcg20_1512 = ltcg201512Controller.value.toString();
    ltcg20_1503 = ltcg201503Controller.value.toString();
    ltcg20_3103 = ltcg203103Controller.value.toString();

    totalStcgNormal =
        (double.parse(stcgNormal1506Controller.value.toString()).round() +
            double.parse(stcgNormal1509Controller.value.toString()).round() +
            double.parse(stcgNormal1512Controller.value.toString()).round() +
            double.parse(stcgNormal1503Controller.value.toString()).round() +
            double.parse(stcgNormal3103Controller.value.toString()).round());
    _totalStcgNormalController.sink.add(totalStcgNormal.toString());

    totalStcg111A =
        (double.parse(stcg111A1506Controller.value.toString()).round() +
            double.parse(stcg111A1509Controller.value.toString()).round() +
            double.parse(stcg111A1512Controller.value.toString()).round() +
            double.parse(stcg111A1503Controller.value.toString()).round() +
            double.parse(stcg111A3103Controller.value.toString()).round());
    _totalStcg111AController.sink.add(totalStcg111A.toString());

    totalLtcg112A =
        (double.parse(ltcg112A1506Controller.value.toString()).round() +
            double.parse(ltcg112A1509Controller.value.toString()).round() +
            double.parse(ltcg112A1512Controller.value.toString()).round() +
            double.parse(ltcg112A1503Controller.value.toString()).round() +
            double.parse(ltcg112A3103Controller.value.toString()).round());

    totalLtcg112AController.sink.add(totalLtcg112A.toString());

    totalLtcg10 = (double.parse(ltcg101506Controller.value.toString()).round() +
        double.parse(ltcg101509Controller.value.toString()).round() +
        double.parse(ltcg101512Controller.value.toString()).round() +
        double.parse(ltcg101503Controller.value.toString()).round() +
        double.parse(ltcg103103Controller.value.toString()).round());

    totalLtcg10Controller.sink.add(totalLtcg10.toString());

    totalLtcg20 = (double.parse(ltcg201506Controller.value.toString()).round() +
        double.parse(ltcg201509Controller.value.toString()).round() +
        double.parse(ltcg201512Controller.value.toString()).round() +
        double.parse(ltcg201503Controller.value.toString()).round() +
        double.parse(ltcg203103Controller.value.toString()).round());
    _totalLtcg20Controller.sink.add(totalLtcg20.toString());

    totalGain = (totalStcgNormal +
        totalStcg111A +
        totalLtcg112A +
        totalLtcg10 +
        totalLtcg20);

    totalCapitalGainController.sink.add(totalGain.toString());
    calculateGrossTotalIncome();
    notifyListeners();
  }

  saveCapitalGain() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": {
        "stcgNormal1506": stcgNormal1506Controller.value,
        "stcgNormal1509": stcgNormal1509Controller.value,
        "stcgNormal1512": stcgNormal1512Controller.value,
        "stcgNormal1503": stcgNormal1503Controller.value,
        "stcgNormal3103": stcgNormal3103Controller.value,
        "stcg111A1506": stcg111A1506Controller.value,
        "stcg111A1509": stcg111A1509Controller.value,
        "stcg111A1512": stcg111A1512Controller.value,
        "stcg111A1503": stcg111A1503Controller.value,
        "stcg111A3103": stcg111A3103Controller.value,
        "ltcg112A1506": ltcg112A1506Controller.value,
        "ltcg112A1509": ltcg112A1509Controller.value,
        "ltcg112A1512": ltcg112A1512Controller.value,
        "ltcg112A1503": ltcg112A1503Controller.value,
        "ltcg112A3103": ltcg112A3103Controller.value,
        "ltcg101506": ltcg101506Controller.value,
        "ltcg101509": ltcg101509Controller.value,
        "ltcg101512": ltcg101512Controller.value,
        "ltcg101503": ltcg101503Controller.value,
        "ltcg103103": ltcg103103Controller.value,
        "ltcg201506": ltcg201506Controller.value,
        "ltcg201509": ltcg201509Controller.value,
        "ltcg201512": ltcg201512Controller.value,
        "ltcg201503": ltcg201503Controller.value,
        "ltcg203103": ltcg203103Controller.value,
      },
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 5  other Sources

  initOtherSources() {
    interestFromBankDepositController.sink.add(0);
    interestFromSavingController.sink.add(0);
    otherIncomeController.sink.add([0]);
    interestTaxIncomeController.add(0);
    pensionReceivedController.add(0);
    otherSourceDeduction57Controller.add(0);
    totalOtherSourcersController.add("0");
    calculateOtherSources();
  }

  calculateOtherSources() {
    var totalOtherSource = 0;
    interestfrombank = interestFromBankDepositController.value.toString();
    interestfromsaving = interestFromSavingController.value.toString();
    otherincome = otherIncomeController.value.toString();
    int limit = 0;
    if (pensionReceivedController.value * 0.3333 > 15000) {
      limit = 15000;
    } else {
      limit = (pensionReceivedController.value * 0.3333).round();
    }
    if (taxMethodController.value == "R") {
      otherSourceDeduction57Controller.add(0);
    } else {
      if (otherSourceDeduction57Controller.value > limit) {
        otherSourceDeduction57Controller.add(limit);
      }
    }

    totalOtherSource =
        (double.parse(interestFromBankDepositController.value.toString())
                .round() +
            double.parse(interestFromSavingController.value.toString())
                .round() +
            double.parse(interestTaxIncomeController.value.toString()).round() +
            (double.parse(pensionReceivedController.value.toString()).round() -
                double.parse(otherSourceDeduction57Controller.value.toString())
                    .round()) +
            double.tryParse(otherIncomeController.value
                        .reduce((a, b) => a + b)
                        .toString()
                        .isEmpty
                    ? "0"
                    : otherIncomeController.value
                        .reduce((a, b) => a + b)
                        .toString())
                .round());

    totalOtherSourcersController.sink.add(totalOtherSource.toString());
    calculateGrossTotalIncome();
    notifyListeners();
  }

  saveOtherSources() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": {
        "interestBank": interestFromBankDepositController.value,
        "interestSaving": interestFromSavingController.value,
        "otherIncome": otherIncomeController.value,
        "interestTaxIncome": interestTaxIncomeController.value,
        "pensionReceived": pensionReceivedController.value,
        "otherSourceDeduction57": otherSourceDeduction57Controller.value,
      },
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 6 special income

  initOtherSpecialIncome() {
    divident1506Controller.sink.add(0);
    divident1509Controller.sink.add(0);
    divident1512Controller.sink.add(0);
    divident1503Controller.sink.add(0);
    divident3103Controller.sink.add(0);
    lottery1506Controller.sink.add(0);
    lottery1509Controller.sink.add(0);
    lottery1512Controller.sink.add(0);
    lottery1503Controller.sink.add(0);
    lottery3103Controller.sink.add(0);
    totalDividentController.add("0");
    calculateOtherSpecialIncome();
  }

  calculateOtherSpecialIncome() {
    var _totalSpecialIncome = 0;
    var _totalLottery = 0.round();

    divident_1506 = divident1506Controller.value.toString();
    divident_1509 = divident1509Controller.value.toString();
    divident_1512 = divident1512Controller.value.toString();
    divident_1503 = divident1503Controller.value.toString();
    divident_3103 = divident3103Controller.value.toString();
    lottery_1506 = lottery1506Controller.value.toString();
    lottery_1509 = lottery1509Controller.value.toString();
    lottery_1512 = lottery1512Controller.value.toString();
    lottery_1503 = lottery1503Controller.value.toString();
    lottery_3103 = lottery3103Controller.value.toString();
    _totalSpecialIncome =
        (double.parse(divident1506Controller.value.toString()).round() +
            double.parse(divident1509Controller.value.toString()).round() +
            double.parse(divident1512Controller.value.toString()).round() +
            double.parse(divident1503Controller.value.toString()).round() +
            double.parse(divident3103Controller.value.toString()).round());

    _totalLottery =
        (double.parse(lottery1506Controller.value.toString()).round() +
            double.parse(lottery1509Controller.value.toString()).round() +
            double.parse(lottery1512Controller.value.toString()).round() +
            double.parse(lottery1503Controller.value.toString()).round() +
            double.parse(lottery3103Controller.value.toString()).round());
    _totalLotteryController.sink.add(_totalLottery.toString());
    totalDividentController.sink
        .add((_totalSpecialIncome + _totalLottery).toString());
    calculateGrossTotalIncome();
    notifyListeners();
  }

  saveOtherSpecial() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": {
        "divident1506": divident1506Controller.value,
        "divident1509": divident1509Controller.value,
        "divident1512": divident1512Controller.value,
        "divident1503": divident1503Controller.value,
        "divident3103": divident3103Controller.value,
        "lottery1506": lottery1506Controller.value,
        "lottery1509": lottery1509Controller.value,
        "lottery1512": lottery1512Controller.value,
        "lottery1503": lottery1503Controller.value,
        "lottery3103": lottery3103Controller.value,
      },
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

  // ^ step 7 loss bf and adjusted

  initLossBfAdjusted() {
    lossBfAdjustedController.add("0");
    calculateLossBfAdjusted();
  }

  calculateLossBfAdjusted() {
    lossBfAdjusted = lossBfAdjustedController.value.toString();
    calculateGrossTotalIncome();
    notifyListeners();
  }

  saveLoss() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": lossBfAdjustedController.value.toString(),
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 8 deductions

  initDeduction() {
    licDeductionController.sink.add(0);
    licLimitDeductionController.sink.add(0);
    pfDeductionController.sink.add(0);
    hlDeductionController.sink.add(0);
    publicPfDeductionController.sink.add(0);
    nscInterestDeductionController.sink.add(0);
    nscDepositsDeductionController.sink.add(0);
    educationExpensesDeductionController.sink.add(0);
    certainFundsDeductionController.sink.add(0);
    groupInsuranceDeductionController.sink.add(0);
    mutualFundsDeductionController.sink.add(0);

    selfController.add(false);
    parentController.add(false);
    parentAgeController.add(false);
    medicalInsuranceController.sink.add(0);
    interestForHigherEduController.add(0);
    donation100Controller.add(0);
    donation50Controller.add(0);
    handicapController.add(false);
    severeController.sink.add(false);
    _adjustedGtiController.add("0");
    _qualifyingAmountController.add("0");
    rentPaidController.add("0");
    totalDeductionT80Controller.add("0");
    usertotalDeductionT80Controller.add("0");
    totalDeductionUnderChapter6.add("0");

    deduction80ccd1Controller.add(0);
    deduction80ccd1bController.add(0);
    deduction80ccd2Controller.add(0);
    selfMediclaimController.add(0);
    selfHealthcheckupController.add(0);
    selfMedicalExpenditureController.add(0);
    parentMediclaimController.add(0);
    parentHealthcheckupController.add(0);
    parentMedicalExpenditureController.add(0);
    senior80ddbController.add(false);
    medical80ddbController.add(0);
    parentMedicalInsuranceController.add(0);
    first80EEController.add(false);
    withoutLimitController.add(false);
    houseProperty80EEController.add(0);
    houseProperty80EEAController.add(0);
    houseProperty80EEBController.add(0);
    political80GGCController.add(0);
    deduction80TTAController.add(0);
    deduction80TTBController.add(0);

    certain100doneeNameController.add([""]);
    certain100AddressController.add([""]);
    certain100CityController.add([""]);
    certain100StateController.add(["Maharashtra"]);
    certain100PincodeController.add([0]);
    certain100doneePanController.add([""]);
    certain100donationCashController.add([0]);
    certain100donationOtherController.add([0]);
    certain100TotalController.add([0]);

    certain50doneeNameController.add([""]);
    certain50AddressController.add([""]);
    certain50CityController.add([""]);
    certain50StateController.add(["Maharashtra"]);
    certain50PincodeController.add([0]);
    certain50doneePanController.add([""]);
    certain50donationCashController.add([0]);
    certain50donationOtherController.add([0]);
    certain50TotalController.add([0]);

    scientificdoneeNameController.add([""]);
    scientificAddressController.add([""]);
    scientificCityController.add([""]);
    scientificStateController.add(["Maharashtra"]);
    scientificPincodeController.add([0]);
    scientificdoneePanController.add([""]);
    scientificdonationCashController.add([0]);
    scientificdonationOtherController.add([0]);
    scientificTotalController.add([0]);
    scientificDateController.add([""]);
    calculateDeduction();
  }

  calculateDeduction() {
    var _totalDeduction = 0;
    var qualifyingamount = 0.0;
    Logger().e(usertotalDeductionT80Controller.value);
    var total = (double.parse(usertotalDeductionT80Controller.value.toString())
            .round() +
        double.parse(deduction80cccController.value.toString()).round() +
        double.parse(deduction80ccd1Controller.value.toString()).round());
    deductionTotalof80Controller.add(total);
    // if (total < 150000) {
    //   deductionTotalof80Controller.add(total);
    // } else {
    //   deductionTotalof80Controller.add(150000);
    // }
    if (age == null) {
      String getUserDOB = _services.getUserDOB;
      // String birthDate = _services.birthDate;
      print(getUserDOB);
      if (getUserDOB == null) {
        String dateOfBirth = _services.birthDate;
        print(dateOfBirth);
        // int year = int.parse(dateOfBirth.substring(6, 10));
        // int month = int.parse(dateOfBirth.substring(3, 5));
        // int day = int.parse(dateOfBirth.substring(0, 2));

        int year = int.parse(dateOfBirth.substring(0, 4));
        int month = int.parse(dateOfBirth.substring(5, 7));
        int day = int.parse(dateOfBirth.substring(8, 10));
        print(day);
        print(month);
        print(year);

        DateTime birthday = DateTime(year, month, day);
        DateTime today = DateTime.now();

        age1 = Age.dateDifference(
            fromDate: birthday, toDate: today, includeToDate: false);
        // var date = (birthDate.toString().substring(0, 1));
        // print("Date: " + date.toString());

        // var month = birthDate.toString().substring(2, 3);
        // print("month: " + month.toString());

        // var year = birthDate.toString().substring(4, 8);
        // print(year.toString());
        // DateTime newBday = DateTime(
        //   int.parse(year),
        //   int.parse(month),
        //   int.parse(date),
        // );

        // Logger().e(newBday);
        // age1 = Age.dateDifference(
        //     fromDate: newBday, toDate: DateTime.now(), includeToDate: false);
        // Logger().e(age1);
      } else {
        DateTime newBday = DateTime.parse(getUserDOB.toString());

        Logger().e(getUserDOB);
        age1 = Age.dateDifference(
            fromDate: newBday, toDate: DateTime.now(), includeToDate: false);
        Logger().e(age1);
      }
    }
    if (selectedYearController.value == "2021-2022" &&
        taxMethodController.value == "R") {
      totalDeductionUnderChapter6.add("0");
      totalDeductionT80Controller.add("0");
      usertotalDeductionT80Controller.add("0");
    } else {
      licdeduction = licDeductionController.value.toString();
      pfdeduction = pfDeductionController.value.toString();
      hldeduction = hlDeductionController.value.toString();
      publicpfdeduction = publicPfDeductionController.value.toString();
      nscinterestdeduction = nscInterestDeductionController.value.toString();
      nscdepositdeduction = nscDepositsDeductionController.value.toString();
      eduexpensesdeduction =
          educationExpensesDeductionController.value.toString();
      certainfundsdeduction = certainFundsDeductionController.value.toString();
      grpinsurancededuction =
          groupInsuranceDeductionController.value.toString();
      mutualfunddeduction = mutualFundsDeductionController.value.toString();

      medialinsurancededuction = medicalInsuranceController.value.toString();
      interesthigheredu = interestForHigherEduController.value.toString();
      donation_100 = donation100Controller.value.toString();
      donation_50 = donation50Controller.value.toString();
      adjustedgti = _adjustedGtiController.value.toString();
      rentpaid = rentPaidController.value.toString();

      _totalDeduction = (double.parse(licDeductionController.value.toString())
              .round() +
          double.parse(pfDeductionController.value.toString()).round() +
          double.parse(hlDeductionController.value.toString()).round() +
          double.parse(publicPfDeductionController.value.toString()).round() +
          double.parse(nscInterestDeductionController.value.toString())
              .round() +
          double.parse(nscDepositsDeductionController.value.toString())
              .round() +
          double.parse(educationExpensesDeductionController.value.toString())
              .round() +
          double.parse(certainFundsDeductionController.value.toString())
              .round() +
          double.parse(groupInsuranceDeductionController.value.toString())
              .round() +
          double.parse(mutualFundsDeductionController.value.toString())
              .round());

      if (double.parse(employerBasicController.value.toString()) > 0) {
        if (double.parse(deduction80ccd1Controller.value.toString()) >
            (double.parse(employerBasicController.value.toString()) * 0.1)) {
          deduction80ccd1Controller.add(
              (double.parse(employerBasicController.value.toString()) * 0.1)
                  .round());
        }
      } else {
        if (double.parse(deduction80ccd1Controller.value.toString()) >
            (double.parse(_grossTotalIncomeController.value) * 0.2)) {
          deduction80ccd1Controller.add(
              (double.parse(_grossTotalIncomeController.value) * 0.2).round());
        }
      }

      if (double.parse(deduction80ccd1bController.value.toString()) > 50000) {
        deduction80ccd1bController.add(50000);
      }

      if (employerTypeController.value == "Central Govt") {
        if (double.parse(deduction80ccd2Controller.value.toString()) >
            (double.parse(employerBasicController.value.toString()) * 0.14)) {
          deduction80ccd2Controller.add(
              (double.parse(employerBasicController.value.toString()) * 0.14)
                  .round());
        }
      } else {
        if (double.parse(deduction80ccd2Controller.value.toString()) >
            (double.parse(employerBasicController.value.toString()) * 0.10)) {
          deduction80ccd2Controller.add(
              (double.parse(employerBasicController.value.toString()) * 0.10)
                  .round());
        }
      }

      if (senior80ddbController.value) {
        if (double.parse(medical80ddbController.value.toString()) > 100000) {
          medical80ddbController.add(100000);
        }
      } else {
        if (double.parse(medical80ddbController.value.toString()) > 40000) {
          medical80ddbController.add(40000);
        }
      }

      if (_totalDeduction > 150000) {
        usertotalDeductionT80Controller.add(_totalDeduction.toString());
        totalDeductionT80Controller.add("150000");
      } else {
        usertotalDeductionT80Controller.add(_totalDeduction.toString());
        totalDeductionT80Controller.add(_totalDeduction.toString());
      }

      if (selfMediclaimController.value != 0 && !selfController.value) {
        selfMedicalExpenditureController.add(0);
      }

      if (double.parse(selfHealthcheckupController.value.toString()) > 5000) {
        selfHealthcheckupController.add(5000);
      }
      if (double.parse(parentHealthcheckupController.value.toString()) > 5000) {
        parentHealthcheckupController.add(5000);
      }
      int limit = 0;
      int parentLimit = 0;

      if (selfController.value) {
        if ((double.parse(selfMediclaimController.value.toString()).round() +
                double.parse(selfHealthcheckupController.value.toString())
                    .round()) >
            50000) {
          limit = 50000;
        } else {
          // limit =
          //     (double.parse(selfMediclaimController.value.toString()).round() +
          //         double.parse(selfHealthcheckupController.value.toString())
          //             .round());
          limit = 25000;
        }
      } else {
        if ((double.parse(selfMediclaimController.value.toString()).round() +
                double.parse(selfHealthcheckupController.value.toString())
                    .round()) >
            25000) {
          limit = 25000;
        } else {
          limit =
              (double.parse(selfMediclaimController.value.toString()).round() +
                  double.parse(selfHealthcheckupController.value.toString())
                      .round());
        }
      }

      if (double.parse(medicalInsuranceController.value.toString()).round() >
          limit) {
        medicalInsuranceController.add(limit);
      }

      if (parentController.value) {
        if ((double.parse(parentMedicalExpenditureController.value.toString())
                    .round() +
                double.parse(parentMediclaimController.value.toString())
                    .round() +
                double.parse(parentHealthcheckupController.value.toString())
                    .round()) >
            50000) {
          parentLimit = 50000;
        } else {
          parentLimit =
              (double.parse(parentMediclaimController.value.toString())
                      .round() +
                  double.parse(parentHealthcheckupController.value.toString())
                      .round());
        }
      } else {
        if ((double.parse(parentMedicalExpenditureController.value.toString())
                    .round() +
                double.parse(parentMediclaimController.value.toString())
                    .round() +
                double.parse(parentHealthcheckupController.value.toString())
                    .round()) >
            25000) {
          parentLimit = 25000;
        } else {
          parentLimit =
              (double.parse(parentMediclaimController.value.toString())
                      .round() +
                  double.parse(parentHealthcheckupController.value.toString())
                      .round());
        }
      }

      if (double.parse(parentMedicalInsuranceController.value.toString())
              .round() >
          parentLimit) {
        parentMedicalInsuranceController.add(parentLimit);
      }

      if (first80EEController.value) {
        if (double.parse(houseProperty80EEController.value.toString()) !=
            null) {
          if (double.parse(houseProperty80EEController.value.toString()) >
              50000) {
            houseProperty80EEController.add(50000);
          }
          houseProperty80EEAController.add(0);
        } else {
          houseProperty80EEController.add(0);
        }
      }

      if (double.parse(houseProperty80EEAController.value.toString()) >
          150000) {
        houseProperty80EEAController.add(150000);
        houseProperty80EEController.add(0);
      }

      if (double.parse(houseProperty80EEBController.value.toString()) >
          150000) {
        houseProperty80EEBController.add(150000);
      }
      if (age1 == null) {
        print("----------nulllll--------------");
        print(age);
        deduction80TTAController.add(0);
        int limit =
            double.parse(interestFromBankDepositController.value.toString())
                    .round() +
                double.parse(interestFromSavingController.value.toString())
                    .round() +
                double.parse(interestTaxIncomeController.value.toString())
                    .round();
        if (double.parse(deduction80TTAController.value.toString()) > 10000) {
          deduction80TTAController.add(10000);
        }
      } else {
        Logger().e(age1);

        if (age1.years >= 60) {
          Logger().e(age);
          deduction80TTAController.add(0);
        } else {
          int limit =
              double.parse(interestFromBankDepositController.value.toString())
                      .round() +
                  double.parse(interestFromSavingController.value.toString())
                      .round() +
                  double.parse(interestTaxIncomeController.value.toString())
                      .round();
          if (double.parse(deduction80TTAController.value.toString()) > 10000) {
            deduction80TTAController.add(10000);
          }
        }

        if (age1.years <= 60) {
          deduction80TTBController.add(0);
        } else {
          int limit =
              double.parse(interestFromBankDepositController.value.toString())
                      .round() +
                  double.parse(interestFromSavingController.value.toString())
                      .round() +
                  double.parse(interestTaxIncomeController.value.toString())
                      .round();
          if (double.parse(deduction80TTBController.value.toString()) > 50000) {
            deduction80TTBController.add(50000);
          }
        }
      }

      // if (age <= 60 &&
      //     (!parentController.value || parentController.value == null)) {
      //   if (double.parse(medicalInsuranceController.value.toString()).round() >
      //       25000) {
      //     medicalInsuranceController.add("25000");
      //     medialinsurancededuction =
      //         medicalInsuranceController.value.toString();
      //   }
      // } else if (age >= 60 && !parentController.value ||
      //     parentController.value == null) {
      //   if (double.parse(medicalInsuranceController.value.toString()).round() >
      //       50000) {
      //     medicalInsuranceController.add("50000");
      //     medialinsurancededuction =
      //         medicalInsuranceController.value.toString();
      //   }
      // } else if (age <= 60 &&
      //     parentController.value &&
      //     !parentAgeController.value) {
      //   if (double.parse(medicalInsuranceController.value.toString()).round() >
      //       75000) {
      //     medicalInsuranceController.add("75000");
      //     medialinsurancededuction =
      //         medicalInsuranceController.value.toString();
      //   }
      // } else if (age >= 60 &&
      //     parentController.value &&
      //     parentAgeController.value) {
      //   if (double.parse(medicalInsuranceController.value.toString()).round() >
      //       10000) {
      //     medicalInsuranceController.add("100000");
      //     medialinsurancededuction =
      //         medicalInsuranceController.value.toString();
      //   }
      // } else if (age <= 60 &&
      //     parentController.value &&
      //     parentAgeController.value) {
      //   if (double.parse(medicalInsuranceController.value.toString()).round() >
      //       25000) {
      //     medicalInsuranceController.add("25000");
      //     medialinsurancededuction =
      //         medicalInsuranceController.value.toString();
      //   }
      // } else {
      //   medicalInsuranceController.add("0");
      // }

      _adjustedGtiController.add(
          (double.parse(_grossTotalIncomeController.value.toString()).round() -
                  double.parse(totalDeductionT80Controller.value.toString())
                      .round())
              .toString());

      qualifyingamount =
          (double.parse(_grossTotalIncomeController.value.toString()).round() -
                      double.parse(totalDeductionT80Controller.value.toString())
                          .round() -
                      double.parse(medicalInsuranceController.value.toString()))
                  .round() *
              0.1;

      _qualifyingAmountController.add(qualifyingamount.toStringAsFixed(0));
      donationLimit = qualifyingamount * 0.1;

      if (certain100donationCashController.value.isEmpty) {
        certain100donationCashController.add([0]);
      }
      if (certain100donationOtherController.value.isEmpty) {
        certain100donationOtherController.add([0]);
      }
      if (certain50donationCashController.value.isEmpty) {
        certain50donationCashController.add([0]);
      }
      if (certain50donationOtherController.value.isEmpty) {
        certain50donationOtherController.add([0]);
      }

      dynamic donation100 = 0;
      dynamic donation50 = 0;
      dynamic scientific = 0;

      certain100donationCashController.value.forEach((element) {
        print(element);
        var mydonationLimit = donationLimit;
        if (withoutLimitController.value) {
          if (double.parse(element) > donationLimit) {
            Logger().e("VALUE IS MORE THAN LIMIT");
            // _services.showErrorDialog(
            //     title: 'Failed!',
            //     description: "You Cannot Enter More Than " +
            //         mydonationLimit.toStringAsFixed(2).toString());
          } else {
            mydonationLimit = mydonationLimit - double.parse(element);
            Logger().e("VALUE IS NOT MORE THAN LIMIT");
          }
          print(element);
        } else {}

        if (element != "") {
          donation100 += double.parse(element.toString()).round();
        }
      });

      certain100donationOtherController.value.forEach((element) {
        var mydonationLimit = donationLimit;

        if (element != "") {
          if (withoutLimitController.value) {
            if (double.parse(element) > donationLimit) {
              Logger().e("VALUE IS MORE THAN LIMIT");
              // _services.showErrorDialog(
              //     title: 'Failed!',
              //     description: "You Cannot Enter More Than " +
              //         mydonationLimit.toStringAsFixed(2).toString());
            } else {
              mydonationLimit = mydonationLimit - double.parse(element);
              Logger().e("VALUE IS NOT MORE THAN LIMIT");
            }
            print(element);
          } else {}
          donation100 += double.parse(element.toString()).round();
        }
      });

      certain50donationOtherController.value.forEach((element) {
        var mydonationLimit = donationLimit;

        if (element != "") {
          if (withoutLimitController.value) {
            if (double.parse(element.toString()) > donationLimit) {
              Logger().e("VALUE IS MORE THAN LIMIT");
              // _services.showErrorDialog(
              //     title: 'Failed!',
              //     description: "You Cannot Enter More Than " +
              //         mydonationLimit.toStringAsFixed(2).toString());
            } else {
              mydonationLimit =
                  mydonationLimit - double.parse(element.toString());
              Logger().e("VALUE IS NOT MORE THAN LIMIT");
            }
            print(element);
          } else {}
          donation50 += double.parse(element.toString()).round();
        }
      });

      certain50donationOtherController.value.forEach((element) {
        var mydonationLimit = donationLimit;

        if (element != "") {
          if (withoutLimitController.value) {
            if (double.parse(element.toString()) > donationLimit) {
              Logger().e("VALUE IS MORE THAN LIMIT");
              // _services.showErrorDialog(
              //     title: 'Failed!',
              //     description: "You Cannot Enter More Than " +
              //         mydonationLimit.toStringAsFixed(2).toString());
            } else {
              mydonationLimit =
                  mydonationLimit - double.parse(element.toString());
              Logger().e("VALUE IS NOT MORE THAN LIMIT");
            }
            print(element);
          } else {}
          donation50 += double.parse(element.toString()).round();
        }
      });

      scientificdonationCashController.value.forEach((element) {
        if (element != "") {
          scientific += double.parse(element.toString()).round();
        }
      });

      scientificdonationOtherController.value.forEach((element) {
        if (element != "") {
          scientific += double.parse(element.toString()).round();
        }
      });

      if (withoutLimitController.value) {
        if (double.parse(donation100.toString()) >= donationLimit) {
          if (donationLimit < 0) {
            donation100Controller.add(0);
            donation50Controller.add(0);
          } else {
            donation100Controller.add(donationLimit.round());
            donation50Controller.add(0);
          }
        } else {
          donation100Controller
              .add(double.parse(donation100.toString()).round());
          donationLimit = donationLimit - double.parse(donation100.toString());
          if (double.parse(donation50.toString()) >= donationLimit) {
            donation50Controller.add(donationLimit.round());
          } else {
            donation50Controller
                .add(double.parse(donation50.toString()).round());
          }
        }
      } else {
        donation100Controller.add(double.parse(donation100.toString()).round());
        // donationLimit = donationLimit - double.parse(donation100.toString());
        // if (double.parse(donation50.toString()) >= donationLimit) {
        // donation50Controller.add(donationLimit.round());
        // } else {
        donation50Controller.add(double.parse(donation50.toString()).round());
        // }
      }

      var severeAmount = 0;
      if (handicapController.value) {
        if (severeController.value) {
          severeAmount = 125000;
        } else {
          severeAmount = 75000;
        }
      } else {
        severeAmount = 0;
      }

      var case1 = 60000;
      var rentpaidValue =
          double.parse(rentPaidController.value.toString()).round();
      var adjustedGti =
          (double.parse(_adjustedGtiController.value.toString()).round() * 0.1)
              .round();
      var case2 = rentpaidValue - adjustedGti;
      var case3 = (double.parse(_adjustedGtiController.value.toString()) * 0.25)
          .round();

      List list = [case1, case2, case3];
      logger.d(list);

      var minValue = list.reduce((curr, next) => curr < next ? curr : next);
      logger.wtf(minValue);

      if (minValue < 0) {
        _80GController.add(minValue.toString());
      } else {
        _80GController.add(minValue.round().toString());
      }
      sec80g = _80GController.value.toString();

      totalDeductionUnderChapter6.add((double.parse(
                      totalDeductionT80Controller.value.toString())
                  .round() +
              double.parse(interestForHigherEduController.value.toString())
                  .round() +
              double.parse(severeAmount.toString()).round() +
              double.parse(deduction80ccd1Controller.value.toString()).round() +
              double.parse(deduction80ccd1bController.value.toString())
                  .round() +
              double.parse(deduction80ccd2Controller.value.toString()).round() +
              double.parse(donation100Controller.value.toString()).round() +
              double.parse(houseProperty80EEAController.value.toString())
                  .round() +
              double.parse(houseProperty80EEController.value.toString())
                  .round() +
              double.parse(houseProperty80EEBController.value.toString())
                  .round() +
              double.parse(deduction80TTAController.value.toString()).round() +
              double.parse(deduction80TTBController.value.toString()).round() +
              double.parse(rentPaidController.value.toString()).round() +
              double.parse(medical80ddbController.value.toString()).round() +
              double.parse(parentMedicalInsuranceController.value.toString())
                  .round() +
              double.parse(medicalInsuranceController.value.toString())
                  .round() +
              double.parse(scientific.toString()).round() +
              double.parse(political80GGCController.value.toString()).round() +
              double.parse(donation50Controller.value.toString()).round() +
              double.parse(donation50Controller.value.toString()).round() +
              double.parse(donation50Controller.value.toString()).round())
          .toString());

      Logger().e(double.parse(totalDeductionT80Controller.value.toString())
              .round() +
          double.parse(interestForHigherEduController.value.toString())
              .round() +
          double.parse(severeAmount.toString()).round() +
          double.parse(deduction80ccd1Controller.value.toString()).round() +
          double.parse(deduction80ccd1bController.value.toString()).round() +
          double.parse(deduction80ccd2Controller.value.toString()).round() +
          double.parse(donation100Controller.value.toString()).round() +
          double.parse(houseProperty80EEAController.value.toString()).round() +
          double.parse(houseProperty80EEController.value.toString()).round() +
          double.parse(houseProperty80EEBController.value.toString()).round() +
          double.parse(deduction80TTAController.value.toString()).round() +
          double.parse(deduction80TTBController.value.toString()).round() +
          double.parse(rentPaidController.value.toString()).round() +
          double.parse(medical80ddbController.value.toString()).round() +
          double.parse(parentMedicalInsuranceController.value.toString())
              .round() +
          double.parse(medicalInsuranceController.value.toString()).round() +
          double.parse(scientific.toString()).round() +
          double.parse(political80GGCController.value.toString()).round() +
          double.parse(donation50Controller.value.toString()).round() +
          double.parse(donation50Controller.value.toString()).round() +
          double.parse(donation50Controller.value.toString()).round());

      if (double.parse(totalDeductionUnderChapter6.value.toString()) >
          double.parse(_grossTotalIncomeController.value.toString())) {
        totalDeductionUnderChapter6.add(_grossTotalIncomeController.value);
      }
    }

    notifyListeners();
  }

  saveDeduction() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": {
        "lic": licDeductionController.value,
        "licLimit": licLimitDeductionController.value,
        "pf": pfDeductionController.value,
        "hl": hlDeductionController.value,
        "publicPf": publicPfDeductionController.value,
        "nscInterest": nscInterestDeductionController.value,
        "nscDeposit": nscDepositsDeductionController.value,
        "educationExpenses": educationExpensesDeductionController.value,
        "certainFunds": certainFundsDeductionController.value,
        "groupInsurance": groupInsuranceDeductionController.value,
        "mf": mutualFundsDeductionController.value,
        "self": selfController.value,
        "parent": parentController.value,
        "parentAge": parentAgeController.value,
        "medicalInsurance": medicalInsuranceController.value,
        "higherEducation": interestForHigherEduController.value,
        "donation100": donation100Controller.value,
        "donation50": donation50Controller.value,
        "handicap": handicapController.value,
        "severe": severeController.value,
        "rent": rentPaidController.value.toString(),
        "deduction80ccd1": deduction80ccd1Controller.value.toString(),
        "deduction80ccd1b": deduction80ccd1bController.value.toString(),
        "deduction80ccd2": deduction80ccd2Controller.value.toString(),
        "selfMediclaim": selfMediclaimController.value.toString(),
        "selfHealthcheckup": selfHealthcheckupController.value.toString(),
        "selfMedicalExpenditure":
            selfMedicalExpenditureController.value.toString(),
        "parentMediclaim": parentMediclaimController.value.toString(),
        "parentHealthcheckup": parentHealthcheckupController.value.toString(),
        "parentMedicalExpenditure":
            parentMedicalExpenditureController.value.toString(),
        "senior80ddb": senior80ddbController.value,
        "medical80ddb": medical80ddbController.value.toString(),
        "parentMedicalInsurance":
            parentMedicalInsuranceController.value.toString(),
        "first80EE": first80EEController.value,
        "houseProperty80EE": houseProperty80EEController.value.toString(),
        "houseProperty80EEA": houseProperty80EEAController.value.toString(),
        "houseProperty80EEB": houseProperty80EEBController.value.toString(),
        "political80GGC": political80GGCController.value.toString(),
        "deduction80TTA": deduction80TTAController.value.toString(),
        "deduction80TTB": deduction80TTBController.value.toString(),
        "certain100doneeName": certain100doneeNameController.value,
        "certain100Address": certain100AddressController.value,
        "certain100City": certain100CityController.value,
        "certain100State": certain100StateController.value,
        "certain100Pincode": certain100PincodeController.value,
        "certain100doneePan": certain100doneePanController.value,
        "certain100donationCash": certain100donationCashController.value,
        "certain100donationOther": certain100donationOtherController.value,
        "certain100Total": certain100TotalController.value,
        "certain50doneeName": certain50doneeNameController.value,
        "certain50Address": certain50AddressController.value,
        "certain50City": certain50CityController.value,
        "certain50State": certain50StateController.value,
        "certain50Pincode": certain50PincodeController.value,
        "certain50doneePan": certain50doneePanController.value,
        "certain50donationCash": certain50donationCashController.value,
        "certain50donationOther": certain50donationOtherController.value,
        "certain50Total": certain50TotalController.value,
        "scientificdoneeName": scientificdoneeNameController.value,
        "scientificAddress": scientificAddressController.value,
        "scientificCity": scientificCityController.value,
        "scientificState": scientificStateController.value,
        "scientificPincode": scientificPincodeController.value,
        "scientificdoneePan": scientificdoneePanController.value,
        "scientificdonationCash": scientificdonationCashController.value,
        "scientificdonationOther": scientificdonationOtherController.value,
        "scientificTotal": scientificTotalController.value,
        "scientificDate": scientificDateController.value
      },
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };
    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 9 exempt

  initExemptIncome() {
    exemptIncomeController.add("0");
    insurancePolicy1010dController.add("0");
    statutoryPFController.add("0");
    recognisedPFController.add("0");
    exemptDividendController.add("0");
    exemptIncomeDescriptionController.add("0");
    totalExemptIncomeController.add("0");

    calculateExemptIncome();
  }

  calculateExemptIncome() {
    exemptincome = exemptIncomeController.value.toString();

    totalExemptIncomeController.add(
        (double.parse(exemptIncomeController.value).round() +
                double.parse(insurancePolicy1010dController.value).round() +
                double.parse(statutoryPFController.value).round() +
                double.parse(recognisedPFController.value).round() +
                double.parse(exemptDividendController.value).round())
            .toString());
  }

  saveExemptIncome() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": {
        "exemptIncome": exemptIncomeController.value,
        "insurancePolicy1010d": insurancePolicy1010dController.value,
        "statutoryPF": statutoryPFController.value,
        "recognisedPF": recognisedPFController.value,
        "exemptDividend": exemptDividendController.value,
        "exemptIncomeDescription": exemptIncomeDescriptionController.value,
      },
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 10 agro

  initAgroIncome() {
    agroIncomeController.add("0");
    calculateAgro();
  }

  calculateAgro() {
    agroincome = agroIncomeController.value.toString();
  }

  saveAgroIncome() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": agroIncomeController.value.toString(),
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 14 TDS

  initTds() {
    tdsController.add("0");
    tdsListController.add([]);
  }

  saveTds() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": {
        "details": tdsListController.value.map((e) => e.toJson()).toList()
      },
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

  calculateTds() {
    var totalTds = 0;
    if (tdsListController.value.isNotEmpty) {
      tdsListController.value.forEach((element) {
        totalTds += element.creditClaimed;
      });
      tdsController.add(totalTds.toString());
    } else {
      tdsController.add("0".toString());
    }
  }

// ^ step 15 advanced tax

  initAdvancedTax() {
    advancedTaxAmountController.sink.add([0]);
    advancedTaxDateController.sink.add([""]);
    advanceTaxCINController.add([0]);
    advanceTaxBSRController.add([0]);
    totalAdvancedTaxController.add("0");

    calculateAdvancedTax(
        advancedTaxAmountController.value, advancedTaxDateController.value);
  }

  void calculateAdvancedTax(List<int> taxAmount, List<String> taxDate) {
    if (taxAmount != null) {
      print(taxAmount.toList());
      var totalTax = 0.toString();
      if (taxAmount.isNotEmpty) {
        totalTax = taxAmount.reduce((a, b) => a + b).toString();
      }
      totalAdvancedTaxController.add(totalTax.toString());

      DateTime date;
      DateTime filledDate;
      DateTime currentDate = DateTime.now().toUtc();
      List<int> firstInstallationAmount = [];
      List<int> secondInstallationAmount = [];
      List<int> thirdInstallationAmount = [];
      List<int> fourthInstallationAmount = [];
      List<int> fifthInstallationAmount = [];

      var firstInstallationDate;
      var secondInstallationDate;
      var thirdInstallationDate;
      var fourthInstallationDate;
      var fifthInstallationDate;
      var previousDate;
      if (selectedYearController.value.toString() == "2020-2021") {
        previousDate = DateTime.utc(2019, 03, 31);
        firstInstallationDate = DateTime.utc(2019, 06, 15);
        secondInstallationDate = DateTime.utc(2019, 09, 15);
        thirdInstallationDate = DateTime.utc(2019, 12, 15);
        fourthInstallationDate = DateTime.utc(2020, 03, 15);
        fifthInstallationDate = DateTime.utc(2020, 03, 31);
      } else {
        previousDate = DateTime.utc(2020, 03, 31);
        firstInstallationDate = DateTime.utc(2020, 06, 15);
        secondInstallationDate = DateTime.utc(2020, 09, 15);
        thirdInstallationDate = DateTime.utc(2020, 12, 15);
        fourthInstallationDate = DateTime.utc(2021, 03, 15);
        fifthInstallationDate = DateTime.utc(2021, 03, 31);
      }
      advancedtax.length = taxAmount.length;
      advancedtaxDate.length = taxAmount.length;
      for (var i = 0; i < taxAmount.length; i++) {
        advancedtax[i] = taxAmount[i].round();
        advancedtaxDate[i] = taxDate[i];
        if (taxDate[i].isEmpty) {
          taxDate[i] = selectedYearController.value.toString() == "2021-2022"
              ? DateTime(2020, 4, 1).toString()
              : DateTime(2019, 4, 1).toString();
        }
        date = DateTime.parse(taxDate[i]);
        filledDate = DateTime.utc(date.year, date.month, date.day);

        print(filledDate);
        print(filledDate.isAfter(firstInstallationDate));
        print(firstInstallationDate);
        print(secondInstallationDate);
        print(filledDate.isBefore(secondInstallationDate));

        if (filledDate.toString() == firstInstallationDate.toString() ||
            filledDate.isAfter(firstInstallationDate) &&
                filledDate.isBefore(secondInstallationDate)) {
          print("=================first===============");
          firstInstallationAmount
              .add(double.parse(taxAmount[i].toString()).round());
        } else if (filledDate.toString() == secondInstallationDate.toString() ||
            filledDate.isAfter(secondInstallationDate) &&
                filledDate.isBefore(thirdInstallationDate)) {
          print("=================Second===============");
          secondInstallationAmount
              .add(double.parse(taxAmount[i].toString()).round());
        } else if (filledDate.toString() == thirdInstallationDate.toString() ||
            filledDate.isAfter(thirdInstallationDate) &&
                filledDate.isBefore(fourthInstallationDate)) {
          print("=================Third===============");
          thirdInstallationAmount
              .add(double.parse(taxAmount[i].toString()).round());
        } else if (filledDate.toString() == fourthInstallationDate.toString() ||
            filledDate.isAfter(fourthInstallationDate) &&
                filledDate.isBefore(fifthInstallationDate)) {
          print("=================fourth===============");
          fourthInstallationAmount
              .add(double.parse(taxAmount[i].toString()).round());
        } else {
          print("=================fifth===============");

          fifthInstallationAmount
              .add(double.parse(taxAmount[i].toString()).round());
        }
      }

      _advancedFirstInstallationController.sink.add(firstInstallationAmount);
      _advancedSecondInstallationController.sink.add(secondInstallationAmount);
      _advancedThirdInstallationController.sink.add(thirdInstallationAmount);
      _advancedFourthInstallationController.sink.add(fourthInstallationAmount);
      _advancedFifthInstallationController.sink.add(fifthInstallationAmount);
    }

    // addAdvanceTaxToStorage();
  }

  saveAdvanceTax() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": {
        "amount": advancedTaxAmountController.value,
        "date": advancedTaxDateController.value,
        "cin": advanceTaxCINController.value,
        "bsr": advanceTaxBSRController.value,
      },
      "self_assesment_tax": null,
      "itr_information": null,
    };
    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

// ^ step 16 self tax

  initSelfTax() {
    selfTaxAmountController.sink.add([0]);
    selfTaxDateController.sink
        .add([DateTime.now().toString().substring(0, 10)]);
    selfTaxCINController.add([0]);
    selfTaxBSRController.add([0]);
    totalSelfTaxController.add("0");
    calculateSelfAssestTax(
        selfTaxAmountController.value, selfTaxDateController.value);
  }

  void calculateSelfAssestTax(List<int> taxAmount, List<String> taxDate) {
    if (taxAmount != null) {
      var totalTax = 0.toString();
      if (taxAmount.isNotEmpty) {
        totalTax = taxAmount.reduce((a, b) => a + b).toString();
      }
      totalSelfTaxController.sink.add(totalTax.toString());

      selftax.length = taxAmount.length;
      selftaxDate.length = taxDate.length;
      for (var i = 0; i < taxAmount.length; i++) {
        selftax[i] = taxAmount[i].round();
        selftaxDate[i] = taxDate[i];
        if (taxDate[i].isEmpty) {
          taxDate[i] = selectedYearController.value.toString() == "2021-2022"
              ? DateTime(2020, 01, 31).toString()
              : DateTime(2019, 3, 31).toString();
        }
      }
    }
  }

  saveSelfTax() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": {
        "amount": selfTaxAmountController.value,
        "date": selfTaxDateController.value,
        "cin": selfTaxCINController.value,
        "bsr": selfTaxBSRController.value,
      },
      "itr_information": null,
    };

    print(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }

//^  tax calculator API CAll

  Future<dynamic> taxcalculatorAPI({TaxCalculationViewModel model}) async {
    if (filingDateController.value == null ||
        filingDateController.value == "" && dueDateController.value == null ||
        dueDateController.value == "") {
      _services.showErrorDialog(
          title: "Failed", description: "Please add Filing Date / Due Date");
    } else {
      setBusy(true);
      List<Map<String, dynamic>> selfAssesmentTax = [];

      Logger().e(selftax.length);
      Logger().wtf(selftax.toList());

      if (selftax.length > 0) {
        for (int i = 0; i < selftax.length; i++) {
          if (selftax[i] != 0) {
            selfAssesmentTax.add({
              "self_Date": selftaxDate[i].isEmpty
                  ? DateTime.now().toString().substring(0, 10)
                  : selftaxDate[i],
              "self_Amt": selftax[i].round(),
            });
          }
        }
      }

      String dob = _services.birthDate;

      // var deductedTaxAmount = 0;
      // if (totalTaxDeductedAmount.length > 0) {
      //   deductedTaxAmount = totalTaxDeductedAmount.reduce((a, b) => a + b);
      // } else {
      //   deductedTaxAmount = 0;
      // }

      var firstInst = 0;
      var secondInst = 0;
      var thirdInst = 0;
      var fourthInst = 0;
      var fifthInst = 0;
      print(_advancedFirstInstallationController.value);
      if (_advancedFirstInstallationController.value.isNotEmpty) {
        firstInst =
            _advancedFirstInstallationController.value.reduce((a, b) => a + b);
      }

      if (_advancedSecondInstallationController.value.isNotEmpty) {
        secondInst =
            _advancedSecondInstallationController.value.reduce((a, b) => a + b);
      }

      if (_advancedThirdInstallationController.value.isNotEmpty) {
        thirdInst =
            _advancedThirdInstallationController.value.reduce((a, b) => a + b);
      }

      if (_advancedFourthInstallationController.value.isNotEmpty) {
        fourthInst =
            _advancedFourthInstallationController.value.reduce((a, b) => a + b);
      }

      if (_advancedFifthInstallationController.value.isNotEmpty) {
        fifthInst =
            _advancedFifthInstallationController.value.reduce((a, b) => a + b);
      }

      Map map = {
        "Filing_Date": filingDateController.value,
        "Due_Date": dueDateController.value,
        "TaxMethod": taxMethodController.value,
        "DOB": "",
        "ResiStatus": residencyStatusController.value,
        "ITR_Status": selectedITRController.value,
        "Gender": "",
        "strAY": selectedYearController.value,
        "Salary": totalSalaryController.value,
        "HouseProperty": totalHousPartyController.value,
        "BusinessProfession": totalBusinessIncomeController.value,
        "OtherSources": totalOtherSourcersController.value,
        "DedutionUSCHVIA":
            double.parse(totalDeductionUnderChapter6.value.toString()) -
                double.parse(totalDeductionT80Controller.value.toString()),
        "TDSAmt": tdsController.value.toString(),
        "T80C_In": totalDeductionT80Controller.value,
        "AgricultureIncome": agroIncomeController.value,
        "STCG_Normal_1506": stcgNormal1506Controller.value,
        "STCG_Normal_1509": stcgNormal1509Controller.value,
        "STCG_Normal_1512": stcgNormal1512Controller.value,
        "STCG_Normal_1503": stcgNormal1503Controller.value,
        "STCG_Normal_3103": stcgNormal3103Controller.value,
        "STCG_15Per_1506": stcg111A1506Controller.value,
        "STCG_15Per_1509": stcg111A1509Controller.value,
        "STCG_15Per_1512": stcg111A1512Controller.value,
        "STCG_15Per_1503": stcg111A1503Controller.value,
        "STCG_15Per_3103": stcg111A3103Controller.value,
        "LTCG_112A_10Per_1506": ltcg112A1506Controller.value,
        "LTCG_112A_10Per_1509": ltcg112A1509Controller.value,
        "LTCG_112A_10Per_1513": ltcg112A1512Controller.value,
        "LTCG_112A_10Per_1503": ltcg112A1503Controller.value,
        "LTCG_112A_10Per_3103": ltcg112A3103Controller.value,
        "LTCG_10Per_1506": ltcg101506Controller.value,
        "LTCG_10Per_1509": ltcg101509Controller.value,
        "LTCG_10Per_1512": ltcg101512Controller.value,
        "LTCG_10Per_1503": ltcg101503Controller.value,
        "LTCG_10Per_3103": ltcg103103Controller.value,
        "LTCG_20Per_1506": ltcg201506Controller.value,
        "LTCG_20Per_1509": ltcg201509Controller.value,
        "LTCG_20Per_1512": ltcg201512Controller.value,
        "LTCG_20Per_1503": ltcg201503Controller.value,
        "LTCG_20Per_3103": ltcg203103Controller.value,
        "Lottery_WinAmt_1506": lottery1506Controller.value,
        "Lottery_WinAmt_1509": lottery1509Controller.value,
        "Lottery_WinAmt_1512": lottery1512Controller.value,
        "Lottery_WinAmt_1503": lottery1503Controller.value,
        "Lottery_WinAmt_3103": lottery3103Controller.value,
        "Divident_115BBDAAmt_1506": divident1506Controller.value,
        "Divident_115BBDAAmt_1509": divident1509Controller.value,
        "Divident_115BBDAAmt_1512": divident1512Controller.value,
        "Divident_115BBDAAmt_1503": divident1503Controller.value,
        "Divident_115BBDAAmt_3103": divident3103Controller.value,
        "Self_AssAmt": totalSelfTaxController.value,
        "Relief_Amt": reliefController.value,
        "AdvanceTax": {
          "FirstInst": firstInst,
          "SecondInst": secondInst,
          "ThirdInst": thirdInst,
          "ForthInst": fourthInst,
          "FifthInst": fifthInst
        },
        "selefAssments": selfAssesmentTax,
        "IS_115BA_BAA_BAB": selectedDomesticCompanyController.value
      };

      var sinewaveToken = _services.sinewaveToken;

      logger.e(map);

      CalculateTaxResponseModel result =
          await _services.calculateTax(map, sinewaveToken);
      Logger().e(result.toJson());
      if (result.status_code == 200) {
        taxableIncomeController.add(result.taxableIncome.toString());
        totalIncomeController.add(result.grossTotalIncome.toString());
        _t80coutController.add(result.t80cout.toString());
        taxSurchargeController.add(result.taxwoSurcharge.toString());
        lessRebate87AController.add(result.lessrebate87A.toString());
        surchargeController.add(result.surcharge.toString());
        educationCessController.add(result.educationCess.toString());
        taxPayableContrller.add(result.taxPayable.toString());
        balancePayableController.add(result.balancePayable.toString());
        taxPayableRefundableController
            .add(result.taxPayableRefundable.toString());
        _incomeTaxController.add(result.inccomeTax.toString());
        t234AController.add(result.interestUS == null
            ? "0"
            : result.interestUS.t234A.toString());
        t234BController.add(result.interestUS == null
            ? "0"
            : result.interestUS.t234B.toString());
        t234CController.add(result.interestUS == null
            ? "0"
            : result.interestUS.t234C.toString());
        total234Controller.add(result.interestUS == null
            ? "0"
            : result.interestUS.total234.toString());
        normalTaxController.add(result.normalTax.toString());
        specialTaxController.add(result.specialTax.toString());
        _services.navigateToOutputScreen(model);
        setBusy(false);
      } else {
        _services.showErrorDialog(title: "Failed", description: result.message);
        setBusy(false);
      }
      notifyListeners();
    }
  }

  generateJson(BuildContext context) {
    var userTotal = 0.0;
    var severeAmount = 0;
    dynamic scientific = 0;
    if (handicapController.value) {
      if (severeController.value) {
        severeAmount = 125000;
      } else {
        severeAmount = 75000;
      }
    } else {
      severeAmount = 0;
    }
    scientificdonationCashController.value.forEach((element) {
      if (element != "") {
        scientific += double.parse(element.toString()).round();
      }
    });

    scientificdonationOtherController.value.forEach((element) {
      if (element != "") {
        scientific += double.parse(element.toString()).round();
      }
    });
    Logger().wtf(totalDeductionT80Controller.value);
    var totalDividend = (double.parse(divident1506Controller.value.toString()) +
            double.parse(divident1509Controller.value.toString()) +
            double.parse(divident1512Controller.value.toString()) +
            double.parse(divident1503Controller.value.toString()) +
            double.parse(divident3103Controller.value.toString()))
        .toInt();

    var scientificDonation = scientificTotalController.value
        .reduce((value, element) => value + element);

    var section80D =
        (double.parse(medicalInsuranceController.value.toString()) +
            double.parse(parentMedicalInsuranceController.value.toString()));

    var totalDonationsUs80GGA = (double.parse(scientificdonationCashController
                .value
                .reduce((value, element) => value + element)) +
            double.parse(scientificdonationOtherController.value
                .reduce((value, element) => value + element)))
        .toInt();

    userTotal = ((double.parse(licDeductionController.value.toString())
            .round() +
        double.parse(certainFundsDeductionController.value.toString()).round() +
        double.parse(deductionTotalof80Controller.value.toString()).round() +
        double.parse(deduction80ccd1bController.value.toString()).round() +
        double.parse(deduction80ccd2Controller.value.toString()).round() +
        double.parse(section80D.toString()).round() +
        double.parse(severeController.value ? "75000" : "125000") +
        double.parse(medical80ddbController.value.toString()).round() +
        double.parse(interestForHigherEduController.value.toString()).round() +
        double.parse(houseProperty80EEController.value.toString()).round() +
        double.parse(rentPaidController.value.toString()).round() +
        double.parse(scientificDonation.toString()).round() +
        double.parse(political80GGCController.value.toString()).round() +
        double.parse(severeController.value ? "75000" : "125000").round() +
        double.parse(deduction80TTAController.value.toString()).round() +
        double.parse(deduction80TTBController.value.toString()).round()));
    // print(dobController.value.toString());
    var date = (dobController.value.toString().substring(0, 1));
    print("Date: " + date.toString());
    print("Original Date: " + dobController.value.toString());

    var month = dobController.value.toString().substring(2, 3);
    print("month: " + month.toString());

    var year = dobController.value.toString().substring(4, 8);
    print(year.toString());
    String date2 = year + "-" + month + "-" + date;
    // DateTime converted = DateTime.parse(date2);
    // Logger().wtf(converted);
    // DateTime converted = DateTime.parse(dobController.value);
    // var formatedDOB = DateFormat('yyyy-MM-dd').format(converted);
    var employerCategory = employerTypeController.value.toString();
    if (employerCategory == "Other") {
      employerCategory = "OTH";
    } else {
      employerCategory = "OTH";
    }
    List<AllwncExemptUs10Dtls> allwncExemptUs10DtlsList = [];
    List<int> allwncExemptUs10Dtls = [];
    allwncExemptUs10Dtls.addAll(employerExemptAllowancesController.value);
    Logger().e(allwncExemptUs10Dtls);

    for (int i = 0; i < allwncExemptUs10Dtls.length; i++) {
      AllwncExemptUs10Dtls allwncExemptUs10DtlsData = AllwncExemptUs10Dtls(
        salNatureDesc: "10(5)",
        salOthAmount: 0,
      );

      allwncExemptUs10DtlsData.salOthAmount = allwncExemptUs10Dtls[i];
      allwncExemptUs10DtlsList.add(allwncExemptUs10DtlsData);
    }

    var totalAllwncExemptUs10 =
        allwncExemptUs10Dtls.reduce((value, element) => value + element);

    var taxMethod = taxMethodController.value.toString();
    var newTaxRegime;
    if (taxMethod == "N") {
      taxMethod = "Normal";
      newTaxRegime = "N";
    } else if (taxMethod == "M") {
      taxMethod = "MMR";
      newTaxRegime = "N";
    } else if (taxMethod == "R") {
      taxMethod = "New Regime";
      newTaxRegime = "Y";
    } else if (taxMethod == "I") {
      taxMethod = "NIL";
      newTaxRegime = "N";
    }

    generateJsonModel = GenerateJsonModel(
      creationInfo: CreationInfo(
          sWVersionNo: SWVersionNo,
          sWCreatedBy: SWCreatedBy,
          jSONCreatedBy: JSONCreatedBy,
          jSONCreationDate:
              DateFormat('yyyy-MM-dd').format(DateTime.now()).toString(),
          intermediaryCity: IntermediaryCity,
          digest: Digest),
      formITR1: FormITR1(
          formName: FormName,
          formVer: FormVer,
          schemaVer: SchemaVer,
          assessmentYear: AssessmentYear,
          description: Description),
      personalInfo: PersonalInfo(
        assesseeName: AssesseeName(
          firstName: firstNameController.value.toString(),
          middleName: middleNameController.value.toString(),
          surNameOrOrgName: lastNameController.value.toString(),
        ),
        address: Address(
          residenceNo: flatNumberController.value.toString(),
          localityOrArea: areaController.value.toString(),
          cityOrTownOrDistrict: townController.value.toString(),
          stateCode: selectedStateController.value.toString(),
          countryCode: "91",
          pinCode: int.parse(pinController.value.toString()),
          countryCodeMobile: 91,
          mobileNo: int.parse(mobileController.value.toString()),
          emailAddress: emailController.value.toString(),
        ),
        pAN: employeePanController.value.toString(),
        dOB: date2,
        aadhaarCardNo: aadharController.value.toString(),
        // aadhaarEnrolmentId: "",
        employerCategory: employerCategory,
      ),
      filingStatus: FilingStatus(
          returnFileSec: int.parse(selectedITRController.value),
          newTaxRegime: newTaxRegime,
          seventhProvisio139: ""),
      iTR1IncomeDeductions: ITR1IncomeDeductions(
          allwncExemptUs10: AllwncExemptUs10(
              allwncExemptUs10Dtls: allwncExemptUs10DtlsList,
              totalAllwncExemptUs10: totalAllwncExemptUs10),
          othersInc: OthersInc(
            totDividendInc: totalDividend,
          ),
          usrDeductUndChapVIA: UsrDeductUndChapVIA(
            section80C: int.parse(licDeductionController.value.toString()),
            section80CCC:
                int.parse(certainFundsDeductionController.value.toString()),
            section80CCDEmployeeOrSE:
                int.parse(deductionTotalof80Controller.value.toString()),
            section80CCD1B:
                int.parse(deduction80ccd1bController.value.toString()),
            section80CCDEmployer:
                int.parse(deduction80ccd2Controller.value.toString()),
            section80D: (section80D.round()),
            section80DD: severeController.value ? 75000 : 125000,
            section80DDB: int.parse(medical80ddbController.value.toString()),
            section80E:
                int.parse(interestForHigherEduController.value.toString()),
            section80EE:
                int.parse(houseProperty80EEController.value.toString()),
            section80G: 0,
            section80GG: int.parse(rentPaidController.value.toString()),
            section80GGA: scientificDonation,
            section80GGC: int.parse(political80GGCController.value.toString()),
            section80U: severeController.value ? 75000 : 125000,
            section80TTA: int.parse(deduction80TTAController.value.toString()),
            section80TTB: deduction80TTBController.value,
            totalChapVIADeductions: double.parse(userTotal.toString()).round(),
          ),
          deductUndChapVIA: DeductUndChapVIA(
            section80C:
                int.parse(licDeductionController.value.toString()) > 150000
                    ? 150000
                    : int.parse(licDeductionController.value.toString()),
            section80CCC: int.parse(
                        certainFundsDeductionController.value.toString()) >
                    150000
                ? 150000
                : int.parse(certainFundsDeductionController.value.toString()),
            section80CCDEmployeeOrSE:
                int.parse(deductionTotalof80Controller.value.toString()) >
                        150000
                    ? 150000
                    : int.parse(deductionTotalof80Controller.value.toString()),
            section80CCD1B:
                int.parse(deduction80ccd1bController.value.toString()),
            section80CCDEmployer:
                int.parse(deduction80ccd2Controller.value.toString()) > 84000
                    ? 84000
                    : int.parse(deduction80ccd2Controller.value.toString()),
            section80D: selfController.value
                ? 2500
                : parentController.value
                    ? 50000
                    : parentAgeController.value
                        ? 100000
                        : (section80D.round()),
            section80DD: severeController.value ? 75000 : 125000,
            section80DDB: parentAgeController.value
                ? 40000
                : int.parse(medical80ddbController.value.toString()) > 100000
                    ? 100000
                    : int.parse(medical80ddbController.value.toString()),
            section80E:
                int.parse(interestForHigherEduController.value.toString()),
            section80EE:
                int.parse(houseProperty80EEController.value.toString()) > 150000
                    ? 150000
                    : int.parse(houseProperty80EEController.value.toString()),
            section80EEA:
                int.parse(houseProperty80EEAController.value.toString()) >
                        150000
                    ? 150000
                    : int.parse(houseProperty80EEAController.value.toString()),
            section80EEB:
                int.parse(houseProperty80EEBController.value.toString()) >
                        150000
                    ? 150000
                    : int.parse(houseProperty80EEBController.value.toString()),
            section80G: 0,
            section80GG: int.parse(rentPaidController.value.toString()) > 60000
                ? 60000
                : int.parse(rentPaidController.value.toString()),
            section80GGA:
                scientificDonation > 10000 ? 10000 : scientificDonation,
            section80GGC: int.parse(political80GGCController.value.toString()),
            section80U: severeController.value ? 75000 : 125000,
            section80TTA:
                int.parse(deduction80TTAController.value.toString()) > 10000
                    ? 10000
                    : int.parse(deduction80TTAController.value.toString()),
            section80TTB: selfController.value
                ? deduction80TTBController.value > 50000
                    ? deduction80TTBController.value
                    : 50000
                : 0,
            totalChapVIADeductions:
                double.parse(totalDeductionUnderChapter6.value).round() > 175000
                    ? 175000
                    : double.parse(totalDeductionUnderChapter6.value).round(),
          ),
          exemptIncAgriOthUs10: ExemptIncAgriOthUs10(
            exemptIncAgriOthUs10Total:
                int.parse(agroIncomeController.value.toString()),
          ),
          grossSalary: int.parse(_grossTotalIncomeController.value.toString()),
          salary: int.parse(totalSalaryController.value.toString()),
          netSalary: int.parse(totalSalaryController.value.toString()),
          deductionUs16: 0,
          deductionUs16ia: 0,
          entertainmentAlw16ii:
              int.parse(employerEntertainementController.value.toString()),
          professionalTaxUs16iii:
              int.parse(employerProfTaxController.value.toString()),
          incomeFromSal: 0,
          annualValue: int.parse(totalHousPartyController.value.toString()),
          standardDeduction:
              int.parse(_employerStdDeductionController.value.toString()),
          totalIncomeOfHP: int.parse(totalHousPartyController.value.toString()),
          incomeOthSrc:
              int.parse(totalOtherSourcersController.value.toString()),
          grossTotIncome:
              int.parse(_grossTotalIncomeController.value.toString()),
          totalIncome: int.parse(totalIncomeController.value.toString())),
      schedule80GGA: Schedule80GGA(
          totalDonationsUs80GGA: totalDonationsUs80GGA,
          totalDonationAmtCash80GGA: int.parse(scientificdonationCashController
              .value
              .reduce((value, element) => value + element)),
          totalDonationAmtOtherMode80GGA: int.parse(
              scientificdonationOtherController.value
                  .reduce((value, element) => value + element)),
          totalEligibleDonationAmt80GGA: (scientificTotalController.value
              .reduce((value, element) => value + element))),
      iTR1TaxComputation: ITR1TaxComputation(
        intrstPay: IntrstPay(
          intrstPayUs234A: int.parse(t234AController.value.toString()),
          intrstPayUs234B: int.parse(t234BController.value.toString()),
          intrstPayUs234C: int.parse(t234CController.value.toString()),
          lateFilingFee234F: 0,
        ),
        totalTaxPayable: int.parse(balancePayableController.value.toString()),
        rebate87A: int.parse(lessRebate87AController.value.toString()),
        taxPayableOnRebate: 0,
        educationCess: int.parse(educationCessController.value.toString()),
        grossTaxLiability: 0,
        section89: 0,
        netTaxLiability: 0,
        totalIntrstPay: 0,
        totTaxPlusIntrstPay: 0,
      ),
      taxPaid: TaxPaid(
        taxesPaid: TaxesPaid(
          advanceTax: advancedTaxAmountController.value
              .reduce((value, element) => value + element),
          tDS: int.parse(tdsController.value.toString()),
          tCS: 0,
          selfAssessmentTax: int.parse(selfTaxAmountController.value
              .reduce((value, element) => value + element)
              .toString()),
          totalTaxesPaid: 0,
        ),
      ),
    );
    // _services.showErrorDialog(
    //     title: 'GENERATE JSON!',
    //     description: generateJsonModel.toJson().toString());
    Logger().e(generateJsonModel.toJson());
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              ViewJsonScreen(json: generateJsonModel.toJson())),
    );
  }

  alertInfo(BuildContext context, String title, String info) {
    return showDialog<void>(
      barrierDismissible: true,
      context: context,
      builder: (BuildContext context) {
        return new Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(12),
              child: new Container(
                height: screenHeight(context) / 2,
                width: screenWidth(context),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            child: Text(
                              title.toString(),
                              style: Theme.of(context)
                                  .textTheme
                                  .subtitle1
                                  .copyWith(
                                    fontStyle: FontStyle.normal,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1,
                                  ),
                            ),
                          ),
                          // Container(
                          //   padding: const EdgeInsets.all(12),
                          //   child: Text(
                          //     "X",
                          //     style: Theme.of(context)
                          //         .textTheme
                          //         .subtitle1
                          //         .copyWith(
                          //           fontStyle: FontStyle.normal,
                          //           fontSize: 15,
                          //           fontWeight: FontWeight.w700,
                          //           letterSpacing: 1,
                          //         ),
                          //   ),
                          // ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          info.toString(),
                          style: Theme.of(context).textTheme.subtitle1.copyWith(
                                fontStyle: FontStyle.normal,
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                letterSpacing: 1,
                                color: Colors.grey,
                              ),
                        ),
                      ),
                    ]),
              ),
            )
          ],
        );
      },
    );
  }

  initItrInformation() {
    itrDropdownStringController.add("119(2)(b)");
    uniqDocController.add("");
    // dateOfNoticeController.add("");
    receiptNoController.add("");
    // dateOfFilingController.add("");
    depositeAmtExceedController.add("");
    foreignTravelExpensesController.add("");
    electricitybillsExceedingController.add("");
    // middleNameController.add("");
    // employeePanController.add("");
    ifscCodeController.add([]);
    nameOfBankController.add([]);
    accountNoController.add([]);
    // refundCreditCheckbox.add(itr_information.refundCreditCheckbox);
  }

  saveITRinfo() async {
    var token = _services.getAccessToken;
    var mobile = _services.user;
    Map map = {
      "leads": mobile.toString(),
      "basic_details": null,
      "salary": null,
      "house_property": null,
      "business": null,
      "capital_gain": null,
      "other_sources": null,
      "other_special_income": null,
      "loss_bf_adjusted": null,
      "deductions": null,
      "exempt_income": null,
      "agriculture_income": null,
      "tds": null,
      "advance_tax": null,
      "self_assesment_tax": null,
      "itr_information": {
        "itr_dropDown": itrDropdownStringController.value != null
            ? itrDropdownStringController.value.toString()
            : "",
        "unique_doc_no": uniqDocController.value != null
            ? uniqDocController.value.toString()
            : "",
        "date_of_notice": dateOfNoticeController.value.toString() ?? "",
        "receipt_no": receiptNoController.value != null
            ? receiptNoController.value.toString()
            : "",
        "date_of_filing": dateOfFilingController.value != null
            ? dateOfFilingController.value.toString()
            : "",
        "depositeAmt_exceed": depositeAmtExceedController.value != null
            ? depositeAmtExceedController.value.toString()
            : "",
        "foreignTravelExpenses": foreignTravelExpensesController.value != null
            ? foreignTravelExpensesController.value.toString()
            : "",
        "electricityBill": electricitybillsExceedingController.value != null
            ? electricitybillsExceedingController.value.toString()
            : "",
        "name": (firstNameController.value.toString() +
                middleNameController.value.toString() +
                " " +
                lastNameController.value.toString()) ??
            "",
        "son_of": middleNameController.value.toString() ?? "",
        "pan_no": employeePanController.value.toString() ?? "",
        "place": "Pune",
        "date": dateOfITRController.value.toString() ?? "",
        "bank_details": bankListController.value,
        "ifsc_code": ifscCodeController.value,
        "bank_name": nameOfBankController.value,
        "account_no": accountNoController.value,
        "refundCreditCheckbox": refundCreditCheckbox,
      }
    };

    Logger().e(map);

    StorageModel result = await _services.saveToBackend(token, map);
    if (result.responseCode == "200") {
      print("success result");
      print(result);
    } else {
      print(" fail result");
      print(result);
    }
  }
}
//       );
//       },
//     );
//   }
// }
