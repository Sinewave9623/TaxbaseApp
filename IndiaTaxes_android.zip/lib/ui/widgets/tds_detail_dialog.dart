import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/sinewaveModel/head_income_model.dart';
import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
import 'package:taxbase_general/ui/widgets/custom_bottom_bar.dart';
import 'package:taxbase_general/values/values.dart';

tdsDetailDialog(
    BuildContext context, TaxCalculationViewModel model) {
  // ^ show dialog to add Company
  dynamic totalPaidAmount = 0;

  List<Widget> _getTdsDetailWidget({
    TaxCalculationViewModel model,
    Function setState,
  }) {
    List<Widget> tdsDetailCard = [];
    String selectedSectionValue;
    String selectedHeadValue;

    if (model.tdsListController.value != null) {
      for (int i = 0; i < model.tdsListController.value.length; i++) {
        tdsDetailCard.add(
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ExpansionTile(
              title: Text(
                  model.tdsListController.value[i].headIncome ?? "Section"),
              maintainState: true,
              children: [
                Container(
                  height: screenHeight(context) / 1.4,
                  width: screenWidth(context),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        TextField(
                          decoration: InputDecoration(
                            hintText: "Tan of Deductor",
                            labelText: "Tan of Deductor",
                          ),
                          controller: TextEditingController()
                            ..text = model.tdsListController.value[i].tanNumber
                            ..selection = TextSelection.fromPosition(
                                TextPosition(
                                    offset: model.tdsListController.value[i]
                                        .tanNumber.length)),
                          onChanged: (value) {
                            setState(() {
                              model.tdsListController.value[i].tanNumber =
                                  value;
                            });
                          },
                        ),
                        TextField(
                          decoration: InputDecoration(
                            hintText: "Name of Deductor",
                            labelText: "Name of Deductor",
                          ),
                          controller: TextEditingController()
                            ..text =
                                model.tdsListController.value[i].deductorName
                            ..selection = TextSelection.fromPosition(
                              TextPosition(
                                  offset: model.tdsListController.value[i]
                                      .deductorName.length),
                            ),
                          onChanged: (value) {
                            setState(() {
                              model.tdsListController.value[i].deductorName =
                                  value;
                            });
                          },
                        ),
                         TextField(
                          decoration: InputDecoration(
                            hintText: "Deduction Year",
                            labelText: "Deduction Year",
                          ),
                          controller: TextEditingController()
                            ..text =
                                model.tdsListController.value[i].deductionYear
                            ..selection = TextSelection.fromPosition(
                              TextPosition(
                                  offset: model.tdsListController.value[i]
                                      .deductionYear.length),
                            ),
                          onChanged: (value) {
                            setState(() {
                              model.tdsListController.value[i].deductionYear =
                                  value;
                            });
                          },
                        ),
                        TextField(
                          decoration: InputDecoration(
                              hintText: "Paid Amount", labelText: "Amount"),
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          controller: TextEditingController()
                            ..text = model.tdsListController.value[i].amount
                                .toString()
                            ..selection = TextSelection.fromPosition(
                                TextPosition(
                                    offset: model
                                        .tdsListController.value[i].amount
                                        .toString()
                                        .length)),
                          onChanged: (value) {
                            setState(() {
                              if (value.toString().isEmpty) {
                                model.tdsListController.value[i].amount =
                                    double.parse("0").round();
                                model.calculateTds();
                              } else {
                                model.tdsListController.value[i].amount =
                                    double.parse(value).round();
                                model.calculateTds();
                              }
                            });
                          },
                        ),
                        TextField(
                          decoration: InputDecoration(
                              hintText: "Tax Deducted",
                              labelText: "Tax Deducted"),
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          controller: TextEditingController()
                            ..text = model
                                .tdsListController.value[i].taxDeducted
                                .toString()
                            ..selection = TextSelection.fromPosition(
                                TextPosition(
                                    offset: model
                                        .tdsListController.value[i].taxDeducted
                                        .toString()
                                        .length)),
                          onChanged: (value) {
                            setState(() {
                              if (value.toString().isEmpty) {
                                model.tdsListController.value[i].taxDeducted =
                                    double.parse("0").round();
                                model.calculateTds();
                              } else {
                                model.tdsListController.value[i].taxDeducted =
                                    double.parse(value).round();
                                model.calculateTds();
                              }
                            });
                          },
                        ),
                         TextField(
                          decoration: InputDecoration(
                              hintText: "Credit Claimed",
                              labelText: "Credit Claimed"),
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          controller: TextEditingController()
                            ..text = model
                                .tdsListController.value[i].creditClaimed
                                .toString()
                            ..selection = TextSelection.fromPosition(
                                TextPosition(
                                    offset: model
                                        .tdsListController.value[i].creditClaimed
                                        .toString()
                                        .length)),
                          onChanged: (value) {
                            setState(() {
                              if (value.toString().isEmpty) {
                                model.tdsListController.value[i].creditClaimed =
                                    double.parse("0").round();
                                model.calculateTds();
                              } else {
                                model.tdsListController.value[i].creditClaimed =
                                    double.parse(value).round();
                                model.calculateTds();
                              }
                            });
                          },
                        ),
                        FloatingActionButton(
                            child: Icon(Icons.delete),
                            onPressed: () {
                              model.tdsListController.value.removeAt(i);
                              model.calculateTds();
                              setState(() {});
                            })
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    }
    return tdsDetailCard;
  }

  return showGeneralDialog(
    context: context,
    useRootNavigator: false,
    pageBuilder: (context, _, __) {
      return StatefulBuilder(
        builder: (context, setState) {
          return Scaffold(
            appBar: AppBar(
              title: Text(TDS),
            ),
            floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
            floatingActionButton: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(width: 10),
                FloatingActionButton(
                  onPressed: () {
                    setState(() {
                      model.tdsListController.value.insert(
                          model.tdsListController.value.length,
                          TdsDetails(
                            srNumber:
                                model.tdsListController.value.length.toString(),
                            section: "",
                            tanNumber: "",
                            amount: 0,
                            taxDeducted: 0,
                            headIncome: "",
                            creditClaimed: 0,
                            deductionYear: "",
                            deductorName: "",
                          ));
                    });
                  },
                  child: Icon(Icons.add),
                ),
              ],
            ),
            bottomNavigationBar: CustomBotomBar(
              onCancelButtonPressed: () {
                print("Cancel Pressed");
                Navigator.of(context).pop();
              },
              onSaveButtonPressed: () {
                print("==============");
                model.saveTds();
                Navigator.of(context).pop();
              },
            ),
            body: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: screenHeight(context) - AppBar().preferredSize.height,
                width: screenWidth(context),
                child: model.tdsListController == null &&
                        model.tdsListController.value.length == 0
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Lottie.asset(
                              'assets/animations/noReturns.json',
                              height: screenHeight(context) * .13,
                            ),
                            Text("Please Add section by Clicking Add Button")
                          ],
                        ),
                      )
                    : SingleChildScrollView(
                        child: Column(
                          children: [
                            ..._getTdsDetailWidget(
                              model: model,
                              setState: setState,
                            ),
                          ],
                        ),
                      ),
              ),
            ),
          );
        },
      );
    },
  );
}
