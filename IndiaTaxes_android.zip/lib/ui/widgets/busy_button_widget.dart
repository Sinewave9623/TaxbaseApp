import 'package:flutter/material.dart';
import 'package:taxbase_general/values/values.dart';

class BusyButton extends StatefulWidget {
  final bool busy;
  final IconData iconImage;
  final String title;
  final Function onPressed;
  final bool enabled;
  final Color buttonColor;
  final Color splashColor;
  final double width;
  final double height;
  final double corner;

  const BusyButton({
    this.iconImage,
    this.title,
    this.busy = false,
    this.onPressed,
    this.width = 280,
    this.height = 50,
    this.corner = 10.0,
    this.buttonColor = AppColors.primaryColor,
    this.splashColor = AppColors.whiteColor,
    this.enabled = true,
  });

  @override
  _BusyButtonState createState() => _BusyButtonState();
}

class _BusyButtonState extends State<BusyButton> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.onPressed,
      child: ButtonTheme(
        disabledColor: AppColors.subtitleColor,
        buttonColor: AppColors.primaryColor,
        splashColor: AppColors.primaryColorLight,
        shape: CircleBorder(),
        child: RaisedButton(
          onPressed: widget.onPressed,
          child: Container(
              child: widget.busy
                  ? Container(
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor:
                            AlwaysStoppedAnimation<Color>(AppColors.whiteColor),
                      ),
                      height: 30.0,
                      width: 30.0,
                    )
                  : widget.iconImage != null
                      ? Icon(
                          widget.iconImage,
                          size: widget.height,
                          color: AppColors.whiteColor,
                        )
                      : Text(
                          widget.title,
                        )),
        ),
      ),
    );
  }
}
