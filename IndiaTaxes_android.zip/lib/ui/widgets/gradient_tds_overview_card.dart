import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/values/values.dart';

class GradientTdsOverviewCard extends StatefulWidget {
  final int index;
  final String companyName;
  final String companyTan;
  final Function delete;

  const GradientTdsOverviewCard({
    Key key,
    this.index,
    this.companyName,
    this.companyTan,
    this.delete
  }) : super(key: key);

  @override
  _GradientTdsOverviewCardState createState() =>
      _GradientTdsOverviewCardState();
}

class _GradientTdsOverviewCardState extends State<GradientTdsOverviewCard> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 8.0,
        vertical: 5,
      ),
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(
            Radius.circular(20),
          ),
        ),
        child: Container(
          height: screenHeight(context) * 0.10,
          width: screenWidth(context),
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: <Color>[
                  AppColors.mydocumentBG_COLOR,
                  AppColors.mydocumentBG_COLOR2
                ]),
            borderRadius: BorderRadius.all(
              Radius.circular(20),
            ),
          ),
          alignment: Alignment.center,
          child: ListTile(
            leading: Text(
              widget.index.toString(),
              style: Theme.of(context).textTheme.headline6.copyWith(
                    color: Colors.white,
                    fontFamily: 'D-DIN',
                  ),
            ),
            title: Text(
              "Name: " + widget.companyName ?? "-",
              style: Theme.of(context).textTheme.subtitle1.copyWith(
                    color: Colors.white,
                    fontFamily: 'D-DIN',
                  ),
            ),
            subtitle: Text(
              "TAN: " + widget.companyTan ?? "-",
              style: Theme.of(context).textTheme.subtitle2.copyWith(
                    color: Colors.white,
                    fontFamily: 'D-DIN',
                  ),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
              
                IconButton(
                  icon: Icon(Icons.delete, color:Colors.red),
                  onPressed: widget.delete ?? null,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
