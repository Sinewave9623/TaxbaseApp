import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/values/values.dart';

class GradientContainerWidget extends StatefulWidget {
  final String title;
  final  Stream<String> model;
  final String amount;
  const GradientContainerWidget({Key key, this.title, this.model, this.amount}) : super(key: key);

  @override
  _GradientContainerWidgetState createState() => _GradientContainerWidgetState();
}

class _GradientContainerWidgetState extends State<GradientContainerWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8.0,
                              vertical: 5,
                            ),
                            child: Card(
                              elevation: 5,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(20),
                                ),
                              ),
                              child: Container(
                                height: screenHeight(context) * 0.10,
                                width: screenWidth(context),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topRight,
                                      end: Alignment.bottomLeft,
                                      colors: <Color>[
                                        AppColors.mydocumentBG_COLOR,
                                        AppColors.mydocumentBG_COLOR2
                                      ]),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(20),
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: ListTile(
                                  leading: Text(
                                    widget.title,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6
                                        .copyWith(
                                          color: Colors.white,
                                          fontFamily: 'D-DIN',
                                        ),
                                  ),
                                  trailing: widget.amount != null 
                                  ?  Text(widget.amount,
                                  style:Theme.of(context)
                                              .textTheme
                                              .subtitle1
                                              .copyWith(
                                                color: Colors.white,
                                                fontFamily: 'D-DIN',
                                              ),
                                  ) 
                                  : widget.model == null ? SizedBox.shrink() :StreamBuilder<String>(
                                      stream: widget.model,
                                      builder: (context, snapshot) {
                                        return Text(
                                          snapshot.data ?? "",
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline6
                                              .copyWith(
                                                color: Colors.white,
                                                fontFamily: 'D-DIN',
                                              ),
                                        );
                                      }),
                                ),
                              ),
                            ),
                          );
  }
}