import 'package:flutter/material.dart';
import 'package:taxbase_general/values/values.dart';

class CustomBotomBar extends StatefulWidget {
  final Function onCancelButtonPressed;
  final Function onSaveButtonPressed;

  const CustomBotomBar({
    Key key,
    this.onCancelButtonPressed,
    this.onSaveButtonPressed,
  }) : super(key: key);

  @override
  _CustomBotomBarState createState() => _CustomBotomBarState();
}

class _CustomBotomBarState extends State<CustomBotomBar> {
  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      color: Theme.of(context).primaryColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          FlatButton.icon(
            onPressed: widget.onCancelButtonPressed,
            icon: Icon(Icons.remove_circle, color: Colors.white),
            label: Text(CANCEL, style: TextStyle(color: Colors.white)),
          ),
          FlatButton.icon(
            icon: Icon(Icons.check_box, color: Colors.white),
            onPressed: widget.onSaveButtonPressed,
            label: Text(SAVE, style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
