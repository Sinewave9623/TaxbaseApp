import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/values/values.dart';

final double _borderRadius = 24.0;

Widget buildTile(Widget child, BuildContext context, {Function() onTap}) {
  return InkWell(
    onTap: onTap != null
        ? () => onTap()
        : () {
            print('Not set yet');
          },
    child: Container(
      width: screenWidth(context) * 1,
      height: screenHeight(context) * .2,
      margin: EdgeInsets.only(
        top: screenHeight(context) * .02,
        left: screenWidth(context) * .05,
        right: screenWidth(context) * .05,
        bottom: screenWidth(context) * .05,
      ),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(_borderRadius),
          border: Border.all(color: AppColors.whiteColor)),
      child: CustomPaint(
        size: Size(100, 150),
        painter: CustomCardShapePainter(_borderRadius,
            AppColors.mydocumentBG_COLOR, AppColors.mydocumentBG_COLOR2),
        child: child,
      ),
    ),
  );
}

class CustomCardShapePainter extends CustomPainter {
  final double radius;
  final Color startColor;
  final Color endColor;

  CustomCardShapePainter(this.radius, this.startColor, this.endColor);

  @override
  void paint(Canvas canvas, Size size) {
    var radius = 9.0;

    var paint = Paint();
    paint.shader = ui.Gradient.linear(
        Offset(50, 0), Offset(size.width, size.height), [
      HSLColor.fromColor(startColor).withLightness(0.8).toColor(),
      endColor
    ]);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
