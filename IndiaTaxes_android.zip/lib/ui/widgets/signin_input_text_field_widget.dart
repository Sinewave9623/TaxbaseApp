import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SignInMainTextFieldWidget extends StatelessWidget {
  SignInMainTextFieldWidget(
      {this.hint,
      this.inputAction,
      this.inputType = TextInputType.text,
      this.error,
      this.labelText,
      this.onChanged,
      this.obscureText = false,
      this.enabled = true,
      this.prefixIcon,
      this.suffixIcon,
      this.focusNode,
      this.onFieldSubmitted,
      this.editingController});

  final Function(dynamic) onChanged;
  final String hint;
  final TextInputAction inputAction;
  final TextInputType inputType;
  final String error;
  final String labelText;
  final bool obscureText;
  final bool enabled;
  final IconData prefixIcon;
  final IconData suffixIcon;
  final TextEditingController editingController;
  final Function(String) onFieldSubmitted;
  final FocusNode focusNode;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: TextFormField(
        enabled: enabled,
        controller: editingController,
        textInputAction: inputAction,
        style: TextStyle(
          fontSize: 15,
        ),
        focusNode: focusNode,
        onChanged: onChanged,
        obscureText: obscureText,
        keyboardType: inputType,
        onFieldSubmitted: onFieldSubmitted,
        decoration: InputDecoration(
//           border: UnderlineInputBorder(
//             borderSide: BorderSide(color: Theme.of(context).accentColor),
//           ),
//           enabledBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: Theme.of(context).accentColor),
//           ),
//           disabledBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: Theme.of(context).accentColor),
//           ),
//           focusedBorder: UnderlineInputBorder(
//             borderSide: BorderSide(color: Theme.of(context).accentColor),
//           ),
// //          errorText: error,
// //          errorStyle: TextStyle(fontFamily: 'D-DIN',
// //          fontSize: 15,
// //          color:errorColor,
// //        ),
          hintStyle: TextStyle(
            fontSize: 15,
          ),
          hintText: hint,
        ),
      ),
    );
  }
}
