import 'package:flutter/material.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/dialog/dialog_model.dart';
import 'package:taxbase_general/services/common/dialog_service.dart';
import 'package:taxbase_general/values/values.dart';

import '../../locator.dart';

class DialogLayoutWidget extends StatelessWidget {
  final String title;
  final String description;
  final String icon;
  final String positiveButtonLabel;
  final String negativeButtonLabel;
  final VoidCallback onPositiveButtonClick;
  final VoidCallback onNegativeButtonClick;

  const DialogLayoutWidget({
    Key key,
    this.title,
    this.icon,
    this.description,
    this.positiveButtonLabel,
    this.negativeButtonLabel,
    this.onPositiveButtonClick,
    this.onNegativeButtonClick,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var isConfirmationDialog = negativeButtonLabel != null;
    return Scaffold(
//      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.0)),
//      backgroundColor: Colors.white,
//      elevation: 2.0,
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Container(
                height: screenHeight(context) * 0.30,
                child: Image.asset(
                  icon ?? 'assets/images/no_connection.png',
                  fit: BoxFit.fitHeight,
                ),
              ),
              Container(
                width: 200.0,
                child: Text("${(title) ?? title}",
                    textAlign: TextAlign.center, style: errorTitleStyle),
              ),
              Container(
                width: 200.0,
                child: Text("${(description) ?? description}",
                    textAlign: TextAlign.center, style: errorMessageStyle),
              ),
              verticalSpace(24.0),
              if (isConfirmationDialog)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    horizontalSpaceMediumSmall,
                    verticalSpaceLarge,
                    Expanded(
                      child: ButtonTheme(
                        height: 40.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: OutlineButton(
                          splashColor: AppColors.primaryColorDark,
                          highlightColor: AppColors.primaryColorLight,
                          onPressed: () {
                            if (onNegativeButtonClick != null) {
                              onNegativeButtonClick();
                            }
                            locator<DialogService>().dialogComplete(
                                DialogResponse(confirmed: true));
                          },
                          color: Colors.white,
                          highlightedBorderColor: AppColors.primaryColorDark,
                          borderSide: BorderSide(
                              width: 1.0, color: AppColors.primaryColorDark),
                          disabledBorderColor: Colors.grey[400],
                          disabledTextColor: Colors.grey[400],
                          child: Text(
                            "${(negativeButtonLabel)}",
                            style: buttonTextStyle,
                          ),
                        ),
                      ),
                    ),
                    horizontalSpaceMediumSmall,
                    Expanded(
                      child: ButtonTheme(
                        height: 40.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: OutlineButton(
                          splashColor: AppColors.whiteColor,
                          highlightColor: AppColors.whiteColor,
                          onPressed: () {
                            if (onPositiveButtonClick != null) {
                              onPositiveButtonClick();
                            }
                            locator<DialogService>().dialogComplete(
                                DialogResponse(confirmed: true));
                          },
                          color: Colors.white,
                          child: Text(
                            "${(positiveButtonLabel)}",
                            style: buttonTextStyle,
                          ),
                          highlightedBorderColor: AppColors.primaryColorDark,
                          borderSide: BorderSide(
                              width: 1.0, color: AppColors.primaryColorDark),
                          disabledBorderColor: Colors.grey[400],
                          disabledTextColor: Colors.grey[400],
                        ),
                      ),
                    ),
                    horizontalSpaceMediumSmall,
                  ],
                ),
              if (!isConfirmationDialog)
                ButtonTheme(
                  minWidth: screenWidthFraction(context, dividedBy: 2),
                  height: 40.0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0)),
                  child: OutlineButton(
                    splashColor: AppColors.whiteColor,
                    highlightColor: AppColors.whiteColor,
                    onPressed: () {
                      if (onPositiveButtonClick != null) {
                        onPositiveButtonClick();
                      }
                      locator<DialogService>()
                          .dialogComplete(DialogResponse(confirmed: true));
                    },
                    color: Colors.white,
                    borderSide: BorderSide(
                        width: 1.0, color: AppColors.primaryColorLight),
                    highlightedBorderColor: AppColors.primaryColorDark,
                    disabledBorderColor: Colors.grey[400],
                    disabledTextColor: Colors.grey[400],
                    child: Text(
                      "${(positiveButtonLabel)}",
                      style: buttonTextStyle,
                    ),
                  ),
                ),
              verticalSpace(24.0),
            ],
          ),
        ),
      ),
    );
  }
}
