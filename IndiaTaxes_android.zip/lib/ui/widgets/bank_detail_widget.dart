// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:logger/logger.dart';
// import 'package:lottie/lottie.dart';
// import 'package:taxbase_general/helpers/ui_helper.dart';
// import 'package:taxbase_general/models/sinewaveModel/head_income_model.dart';
// import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
// import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
// import 'package:taxbase_general/ui/widgets/custom_bottom_bar.dart';
// import 'package:taxbase_general/values/values.dart';

// bankDetailDialog(BuildContext context, TaxCalculationViewModel model) {
//   // ^ show dialog to add Company

//   List<Widget> _getBankDetailWidget({
//     TaxCalculationViewModel model,
//     Function setState,
//   }) {
//     List<Widget> bankDetailCard = [];
//     String selectedSectionValue;
//     String selectedHeadValue;
//     Padding buildTextField(
//         {String hint,
//         String label,
//         int maxLength,
//         Function onTap,
//         Function(dynamic p1) onChanged,
//         TextInputType keyBoardType,
//         List<TextInputFormatter> numbersAllowd,
//         TextEditingController controller}) {
//       return Padding(
//         padding: const EdgeInsets.all(8.0),
//         child: TextField(
//           onTap: onTap ?? () {},
//           keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
//           inputFormatters: numbersAllowd ??
//               <TextInputFormatter>[
//                 FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
//               ],
//           maxLength: maxLength,
//           decoration: InputDecoration(
//             hintText: hint,
//             labelText: label,
//           ),
//           onChanged: onChanged,
//           controller: controller ?? TextEditingController(),
//         ),
//       );
//     }

//     Logger().e(model.bankListController.value.length);

//     if (model.bankListController.value != null) {
//       for (int i = 0; i < model.bankListController.value.length; i++) {
//         bankDetailCard.add(
//           Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Column(
//                 children: [
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Text("Bank Details"),
//                   ),
//                   Container(
//                     child: buildTextField(
//                       hint: "IFSC Code",
//                       label: "IFSC Code",
//                       keyBoardType: TextInputType.text,
//                       numbersAllowd: <TextInputFormatter>[
//                         FilteringTextInputFormatter.allow(
//                             RegExp(r'[aA-zZ, , ]')),
//                       ],
//                       // controller: TextEditingController()
//                       //   ..text = model.uniqDocController.value ?? "",
//                       // // maxLenth: 7,
//                       // onChanged: (value) {
//                       //   if (value.toString().isEmpty) {
//                       //     model.uniqDocController.value =
//                       //         double.parse("0").round();
//                       //   } else {
//                       //     model.uniqDocController.value =
//                       //         double.parse(value).round();
//                       //   }
//                       // }
//                     ),
//                   ),
//                   Container(
//                     child: buildTextField(
//                       hint: "Name of Bank",
//                       label: "Name of Bank",
//                       keyBoardType: TextInputType.text,
//                       numbersAllowd: <TextInputFormatter>[
//                         FilteringTextInputFormatter.allow(
//                             RegExp(r'[aA-zZ, , ]')),
//                       ],
//                       // controller: TextEditingController()
//                       //   ..text = model.uniqDocController.value ?? "",
//                       // maxLenth: 7,
//                       // onChanged: (value) {
//                       //   if (value.toString().isEmpty) {
//                       //     model.uniqDocController.value =
//                       //         double.parse("0").round();
//                       //   } else {
//                       //     model.uniqDocController.value =
//                       //         double.parse(value).round();
//                       //   }
//                       // }
//                     ),
//                   ),
//                   Container(
//                     child: buildTextField(
//                       hint: "Account No.",
//                       label: "Account No.",
//                       numbersAllowd: <TextInputFormatter>[
//                         FilteringTextInputFormatter.allow(RegExp(r'[0-9, , ]')),
//                       ],
//                       // controller: TextEditingController()
//                       //   ..text = model.uniqDocController.value ?? "",
//                       // maxLenth: 7,
//                       // onChanged: (value) {
//                       //   if (value.toString().isEmpty) {
//                       //     model.uniqDocController.value =
//                       //         double.parse("0").round();
//                       //   } else {
//                       //     model.uniqDocController.value =
//                       //         double.parse(value).round();
//                       //   }
//                       // }
//                     ),
//                   ),
//                   Row(
//                     children: [
//                       Padding(
//                         padding: EdgeInsets.all(10),
//                         child: Text("Select for Refund credit"),
//                       ),
//                       Checkbox(
//                         value: model.refundCreditCheckbox,
//                         onChanged: (bool value) {
//                           setState(() {
//                             model.refundCreditCheckbox = value;
//                           });
//                         },
//                       ),
//                     ],
//                   ),
//                 ],
//               )),
//         );
//       }
//     }
//     return bankDetailCard.toList();
//   }
// }
