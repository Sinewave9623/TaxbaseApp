import 'dart:io';

import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:logger/logger.dart';
import 'package:lottie/lottie.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/models/ITR_Information_model/itr_information_model.dart';
import 'package:taxbase_general/models/sinewaveModel/form_16_model.dart';
import 'package:taxbase_general/models/sinewaveModel/get_heads_model.dart';
import 'package:taxbase_general/models/sinewaveModel/read_storage_model.dart';
import 'package:taxbase_general/ui/viewModels/TaxCalculationViewModel/tax_calculation_viewModel.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';
import 'package:taxbase_general/ui/widgets/custom_bottom_bar.dart';
import 'package:taxbase_general/ui/widgets/gradient_container_widget.dart';
import 'package:taxbase_general/values/values.dart';

import 'bank_detail_widget.dart';

class RadioValues {
  String name;
  int index;
  RadioValues({this.name, this.index});
}

// ^ ITR INFORMATION
itrInformationDialog(
  BuildContext context,
  TaxCalculationViewModel model,
) {
  String selectedValue1;
  return showGeneralDialog(
      context: context,
      useRootNavigator: false,
      pageBuilder: (context, _, __) {
        Padding buildTextField(
            {String hint,
            String label,
            int maxLength,
            Function onTap,
            Function(dynamic p1) onChanged,
            TextInputType keyBoardType,
            List<TextInputFormatter> numbersAllowd,
            TextEditingController controller}) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              onTap: onTap ?? () {},
              keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
              inputFormatters: numbersAllowd ??
                  <TextInputFormatter>[
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                  ],
              maxLength: maxLength,
              decoration: InputDecoration(
                hintText: hint,
                labelText: label,
              ),
              onChanged: onChanged,
              controller: controller ?? TextEditingController(),
            ),
          );
        }

        Widget _addRemoveButtonBank(
            bool add, int index, int value, Function setState) {
          return InkWell(
            onTap: () {
              if (add) {
                setState(() {
                  model.bankListController.value.insert(
                      index,
                      BankDetails(
                          accntNo: "",
                          ifscCode: "",
                          nameOfBank: "",
                          refundCredit: false));
                });
                model.refundCreditCheckbox.insert(index, false);
                model.ifscCodeController.value.insert(index, "");
                model.nameOfBankController.value.insert(index, "");
                model.accountNoController.value.insert(index, "");
                setState(() {});
              } else {
                model.bankListController.value.removeAt(index);
              }

              setState(() {});
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Icon(
                  (add) ? Icons.add : Icons.delete,
                  color: Colors.white,
                ),
              ),
            ),
          );
        }

        List<Widget> _getdynamicBank(
            TaxCalculationViewModel model, Function setState) {
          List<Widget> bankFields = [];
          String ifscCode;
          String nameOfBank;
          String accountNo;

          if (model.bankListController.value != null) {
            for (int i = 0; i < model.bankListController.value.length; i++) {
              // ifscCode = model.ifscCodeController.value[i];
              // nameOfBank = model.nameOfBankController.value[i];
              // accountNo = model.accountNoController.value[i];

              bankFields.add(Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  model.bankListController.value.toString() != [].toString() ||
                          model.bankListController.value.length > 0
                      ? Card(
                          elevation: 5,
                          color: Colors.green,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Container(
                            height: screenHeight(context) / 2.4,
                            width: screenWidth(context),
                            decoration: BoxDecoration(
                              color: Colors.red,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Scaffold(
                              appBar: AppBar(
                                leading: Text(""),
                                title: Text("Bank Details"),
                                actions: [
                                  Padding(
                                      padding: const EdgeInsets.all(15.0),
                                      child: model.bankListController.value
                                                  .length ==
                                              1
                                          ? SizedBox.shrink()
                                          : _addRemoveButtonBank(
                                              false, i, 0, setState)),
                                ],
                                centerTitle: true,
                                flexibleSpace: Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                        begin: Alignment.topRight,
                                        end: Alignment.bottomLeft,
                                        colors: <Color>[
                                          AppColors.mydocumentBG_COLOR,
                                          AppColors.mydocumentBG_COLOR2
                                        ]),
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(20),
                                      topRight: Radius.circular(20),
                                    ),
                                  ),
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              body: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      child: buildTextField(
                                          hint: "IFSC Code",
                                          label: "IFSC Code",
                                          keyBoardType: TextInputType.text,
                                          numbersAllowd: <TextInputFormatter>[
                                            FilteringTextInputFormatter.allow(
                                                RegExp(r'[aA-zZ,0-9, ]')),
                                          ],
                                          controller: TextEditingController()
                                            ..text = model.bankListController
                                                    .value[i].ifscCode ??
                                                "",
                                          // // maxLenth: 7,
                                          onChanged: (value) {
                                            if (value.toString().isEmpty) {
                                              model.ifscCodeController
                                                  .value[i] = "";
                                            } else {
                                              model.bankListController.value[i]
                                                  .ifscCode = value;
                                              model.ifscCodeController
                                                  .value[i] = value;
                                            }
                                          }),
                                    ),
                                    Container(
                                      child: buildTextField(
                                        hint: "Name of Bank",
                                        label: "Name of Bank",
                                        keyBoardType: TextInputType.text,
                                        numbersAllowd: <TextInputFormatter>[
                                          FilteringTextInputFormatter.allow(
                                              RegExp(r'[aA-zZ,0-9, ,]')),
                                        ],
                                        controller: TextEditingController()
                                          ..text = model.bankListController
                                                  .value[i].nameOfBank
                                                  .toString() ??
                                              "",
                                        // // maxLenth: 7,
                                        onChanged: (value) {
                                          if (value.toString().isEmpty) {
                                            model.nameOfBankController
                                                .value[i] = "";
                                          } else {
                                            model.bankListController.value[i]
                                                .nameOfBank = value;
                                            model.nameOfBankController
                                                .value[i] = value;
                                          }
                                        },
                                      ),
                                    ),
                                    Container(
                                      child: buildTextField(
                                        hint: "Account No.",
                                        label: "Account No.",
                                        keyBoardType: TextInputType.number,
                                        numbersAllowd: <TextInputFormatter>[
                                          FilteringTextInputFormatter.allow(
                                              RegExp(r'[0-9, , ]')),
                                        ],
                                        controller: TextEditingController()
                                          ..text = model.bankListController
                                                  .value[i].accntNo
                                                  .toString() ??
                                              "",
                                        // // maxLenth: 7,
                                        onChanged: (value) {
                                          if (value.toString().isEmpty) {
                                            model.accountNoController.value[i] =
                                                "";
                                          } else {
                                            model.bankListController.value[i]
                                                .accntNo = value;
                                            model.accountNoController.value[i] =
                                                value;
                                          }
                                        },
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(10),
                                          child:
                                              Text("Select for Refund credit"),
                                        ),
                                        Checkbox(
                                          value: model.bankListController
                                              .value[i].refundCredit,
                                          onChanged: (bool value) {
                                            setState(() {
                                              model.bankListController.value[i]
                                                  .refundCredit = value;
                                            });
                                            Logger().e(model.bankListController
                                                .value[i].refundCredit);
                                            for (int j = 0;
                                                j <
                                                    model.bankListController
                                                        .value.length;
                                                j++) {
                                              if (j != i) {
                                                if (model.bankListController
                                                    .value[j].refundCredit) {
                                                  model
                                                      .bankListController
                                                      .value[j]
                                                      .refundCredit = false;
                                                }
                                              }
                                            }
                                          },
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        )
                      : Container(
                          child: Text(
                          'hiii',
                        ))
                ],
              ));
            }
          }

          return bankFields;
        }

        return StatefulBuilder(
          builder: (BuildContext ctx, setState) {
            return Scaffold(
              resizeToAvoidBottomInset: true,
              appBar: AppBar(
                title: Text(ITR_INFORMATION),
              ),
              bottomNavigationBar: CustomBotomBar(
                onCancelButtonPressed: () {
                  print("Cancel Pressed");
                  Navigator.of(context).pop();
                },
                onSaveButtonPressed: () {
                  print("==============");

                  model.saveITRinfo();
                  Navigator.of(context).pop();
                },
              ),
              body: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    StreamBuilder<List<ItrDropDown>>(
                        stream: model.itrDropdown,
                        builder: (context, snapshot) {
                          return snapshot.data == null
                              ? SizedBox.shrink()
                              : Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: new DropdownButtonFormField(
                                    isExpanded: true,
                                    items:
                                        snapshot.data.map((ItrDropDown value) {
                                      return new DropdownMenuItem<String>(
                                        value: value.itrDropDwnName,
                                        child: new Text(value.itrDropDwnName,
                                            overflow: TextOverflow.ellipsis),
                                      );
                                    }).toList(),
                                    hint: Text("Please choose  "),
                                    value: model
                                        .itrDropdownStringController.value
                                        .toString(),
                                    onChanged: (value) {
                                      selectedValue1 = value;
                                      Logger().wtf(selectedValue1);
                                      Logger().e(
                                          selectedValue1.contains("119(2)(b)"));
                                      if (selectedValue1 !=
                                          model
                                              .itrDropdownStringController.value
                                              .toString()) {
                                        model.itrDropdownStringController
                                            .value = value;
                                      }
                                      model.onitrDropdownStringChanged;

                                      if (model.itrDropdownStringController
                                                  .value
                                                  .toString() ==
                                              "119(2)(b)" ||
                                          model.itrDropdownStringController
                                                  .value
                                                  .toString() ==
                                              "142(1)" ||
                                          model.itrDropdownStringController
                                                  .value
                                                  .toString() ==
                                              "148" ||
                                          model.itrDropdownStringController
                                                  .value
                                                  .toString() ==
                                              "153A" ||
                                          model.itrDropdownStringController
                                                  .value
                                                  .toString() ==
                                              "153C") {
                                        setState(() {
                                          Logger()
                                              .wtf(selectedValue1.toString());
                                          print(
                                              "-------------------------SELECTED-----------");
                                          model.isShowUniqDocController.value =
                                              true;
                                          model.isShowReceiptNoController
                                              .value = false;
                                        });
                                      } else if (model
                                              .itrDropdownStringController.value
                                              .toString() ==
                                          "139(5)") {
                                        Logger().wtf(selectedValue1.toString());
                                        print(
                                            "-----------------NOT---SELECTED-----------");
                                        model.isShowReceiptNoController.value =
                                            true;
                                        model.isShowUniqDocController.value =
                                            false;
                                      } else if (model
                                              .itrDropdownStringController.value
                                              .toString() ==
                                          "139(9)") {
                                        model.isShowReceiptNoController.value =
                                            true;
                                        model.isShowUniqDocController.value =
                                            true;
                                      }
                                      setState(() {});
                                    },
                                  ),
                                );
                        }),
                    StreamBuilder<bool>(
                        stream: model.isShowUniqDoc,
                        builder: (context, snapshot) {
                          return snapshot.data == null
                              ? SizedBox.shrink()
                              : snapshot.data
                                  ? Container(
                                      child: buildTextField(
                                          hint:
                                              "Unique Doc Identification Number (Mandatory)",
                                          label:
                                              "Unique Doc Identification Number (Mandatory)",
                                          numbersAllowd: <TextInputFormatter>[
                                            FilteringTextInputFormatter.allow(
                                                RegExp(r'[0-9]')),
                                          ],
                                          controller: TextEditingController()
                                            ..text = model.uniqDocController
                                                        .value !=
                                                    null
                                                ? model.uniqDocController.value
                                                    .toString()
                                                : "",
                                          // maxLenth: 7,
                                          onChanged: (value) {
                                            if (value.toString().isEmpty) {
                                              model.uniqDocController.value =
                                                  double.parse("0").round();
                                            } else {
                                              model.uniqDocController.value =
                                                  double.parse(value).round();
                                            }
                                          }),
                                    )
                                  : SizedBox.shrink();
                        }),
                    StreamBuilder<bool>(
                        stream: model.isShowUniqDoc,
                        builder: (context, snapshot) {
                          return snapshot.data == null
                              ? SizedBox.shrink()
                              : snapshot.data
                                  ? StreamBuilder<DateTime>(
                                      stream: model.dateofNotice,
                                      builder: (context, snapshot) {
                                        return Container(
                                          child: buildTextField(
                                            hint:
                                                "Date of Notice/ Order (Mandatory)",
                                            label:
                                                "Date of Notice/ Order (Mandatory)",
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            controller: TextEditingController()
                                              ..text = snapshot.data != null
                                                  ? DateFormat('dd-MM-yyyy')
                                                      .format(snapshot.data)
                                                      .toString()
                                                  : "",
                                            // maxLenth: 7,
                                            onTap: () {
                                              model.getNoticeDate(context);
                                            },
                                          ),
                                        );
                                      })
                                  : SizedBox.shrink();
                        }),
                    StreamBuilder<bool>(
                        stream: model.isShowReceiptNo,
                        builder: (context, snapshot) {
                          return snapshot.data == null
                              ? SizedBox.shrink()
                              : snapshot.data
                                  ? Container(
                                      child: buildTextField(
                                          hint:
                                              "Receipt No. of original return",
                                          label:
                                              "Receipt No. of original return",
                                          numbersAllowd: <TextInputFormatter>[
                                            FilteringTextInputFormatter.allow(
                                                RegExp(r'[0-9]')),
                                          ],
                                          controller: TextEditingController()
                                            ..text = model.receiptNoController
                                                        .value !=
                                                    null
                                                ? model
                                                    .receiptNoController.value
                                                    .toString()
                                                : "",
                                          // maxLenth: 7,
                                          onChanged: (value) {
                                            if (value.toString().isEmpty) {
                                              model.receiptNoController.value =
                                                  double.parse("0").round();
                                            } else {
                                              model.receiptNoController.value =
                                                  double.parse(value).round();
                                            }
                                          }),
                                    )
                                  : SizedBox.shrink();
                        }),
                    StreamBuilder<bool>(
                        stream: model.isShowReceiptNo,
                        builder: (context, snapshot) {
                          return snapshot.data == null
                              ? SizedBox.shrink()
                              : snapshot.data
                                  ? StreamBuilder<DateTime>(
                                      stream: model.dateOfFiling,
                                      builder: (context, snapshot) {
                                        return Container(
                                          child: buildTextField(
                                            hint:
                                                "Date of filing original return",
                                            label:
                                                "Date of filing original return",
                                            numbersAllowd: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            controller: TextEditingController()
                                              ..text = snapshot.data != null
                                                  ? DateFormat('dd-MM-yyyy')
                                                      .format(snapshot.data)
                                                      .toString()
                                                  : "",
                                            // maxLenth: 7,
                                            onTap: () {
                                              model.getFilingDate(context);
                                            },
                                          ),
                                        );
                                      })
                                  : SizedBox.shrink();
                        }),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                          "Are you filing return under Seventh provison to Section 139(1), but otherwise not required to furnish ITR?"),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        new Radio(
                          value: 0,
                          groupValue: model.radioValue1,
                          onChanged: (value) {
                            setState(() {
                              model.handleRadioValueChange1(value);

                              setState(() {});
                            });
                          },
                        ),
                        new Text(
                          'Yes',
                          style: new TextStyle(fontSize: 16.0),
                        ),
                        new Radio(
                          value: 1,
                          groupValue: model.radioValue1,
                          onChanged: (value) {
                            setState(() {
                              model.handleRadioValueChange1(value);

                              setState(() {});
                            });
                          },
                        ),
                        new Text(
                          'No',
                          style: new TextStyle(
                            fontSize: 16.0,
                          ),
                        ),
                      ],
                    ),
                    model.radioValue1 == 0
                        ? Container(
                            child: buildTextField(
                                hint:
                                    "Deposited amount exceeding Rs. 1 Cr in Bank account during year",
                                label:
                                    "Deposited amount exceeding Rs. 1 Cr in Bank account during year",
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                controller: TextEditingController()
                                  ..text = model.depositeAmtExceedController
                                              .value !=
                                          null
                                      ? model.depositeAmtExceedController.value
                                          .toString()
                                      : "",
                                // maxLenth: 7,
                                onChanged: (value) {
                                  if (value.toString().isEmpty) {
                                    model.depositeAmtExceedController.value =
                                        double.parse("0").round();
                                  } else {
                                    model.depositeAmtExceedController.value =
                                        double.parse(value).round();
                                  }
                                }),
                          )
                        : SizedBox.shrink(),
                    model.radioValue1 == 0
                        ? Container(
                            child: buildTextField(
                                hint:
                                    "Foreign Travel expenses exceeding Rs. 2 Lakhs during year",
                                label:
                                    "Foreign Travel expenses exceeding Rs. 2 Lakhs during year",
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                controller: TextEditingController()
                                  ..text = model.foreignTravelExpensesController
                                              .value !=
                                          null
                                      ? model
                                          .foreignTravelExpensesController.value
                                          .toString()
                                      : "",
                                // maxLenth: 7,
                                onChanged: (value) {
                                  if (value.toString().isEmpty) {
                                    model.foreignTravelExpensesController
                                        .value = double.parse("0").round();
                                  } else {
                                    model.foreignTravelExpensesController
                                        .value = double.parse(value).round();
                                  }
                                }),
                          )
                        : SizedBox.shrink(),
                    model.radioValue1 == 0
                        ? Container(
                            child: buildTextField(
                                hint:
                                    "Electricity bills exceeding Rs. 1 Lakh during year",
                                label:
                                    "Electricity bills exceeding Rs. 1 Lakh during year",
                                numbersAllowd: <TextInputFormatter>[
                                  FilteringTextInputFormatter.allow(
                                      RegExp(r'[0-9]')),
                                ],
                                controller: TextEditingController()
                                  ..text = model
                                              .electricitybillsExceedingController
                                              .value !=
                                          null
                                      ? model
                                          .electricitybillsExceedingController
                                          .value
                                          .toString()
                                      : "",
                                // maxLenth: 7,
                                onChanged: (value) {
                                  if (value.toString().isEmpty) {
                                    model.electricitybillsExceedingController
                                        .value = double.parse("0").round();
                                  } else {
                                    model.electricitybillsExceedingController
                                        .value = double.parse(value).round();
                                  }
                                }),
                          )
                        : SizedBox.shrink(),
                    ..._getdynamicBank(model, setState),

                    // model.bankListController.value != null ||
                    //         model.bankListController.value.length == 0
                    //     ? bankDetailDialog(context, model)
                    //     : SizedBox.shrink(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(width: 10),
                        FloatingActionButton(
                          onPressed: () {
                            setState(() {
                              model.bankListController.value.insert(
                                  model.bankListController.value.length,
                                  BankDetails(
                                      accntNo: "",
                                      ifscCode: "",
                                      nameOfBank: "",
                                      refundCredit: false));
                              model.refundCreditCheckbox.insert(
                                  model.refundCreditCheckbox.length, false);
                              model.ifscCodeController.value.insert(
                                  model.ifscCodeController.value.length, "");
                              model.nameOfBankController.value.insert(
                                  model.nameOfBankController.value.length, "");
                              model.accountNoController.value.insert(
                                  model.accountNoController.value.length, "");
                            });
                          },
                          child: Icon(Icons.add),
                        ),
                      ],
                    ),
                    Padding(
                      padding: EdgeInsets.all(10),
                      child: Text(
                        "Verification",
                        textAlign: TextAlign.left,
                      ),
                    ),
                    Container(
                      child: buildTextField(
                        hint: "Name",
                        label: "Name",
                        keyBoardType: TextInputType.text,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[aA-zZ,0-9, ,]')),
                        ],
                        controller: TextEditingController()
                          ..text = (model.firstNameController.value.toString() +
                                  " " +
                                  model.middleNameController.value.toString() +
                                  " " +
                                  model.lastNameController.value.toString()) ??
                              "",
                        // maxLenth: 7,
                        // onChanged: (value) {
                        //   if (value.toString().isEmpty) {
                        //     model.uniqDocController.value =
                        //         double.parse("0").round();
                        //   } else {
                        //     model.uniqDocController.value =
                        //         double.parse(value).round();
                        //   }
                        // }
                      ),
                    ),
                    Container(
                      child: buildTextField(
                        hint: "Son/Daughter of",
                        label: "Son/Daughter of",
                        keyBoardType: TextInputType.text,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[aA-zZ,0-9, ,]')),
                        ],
                        controller: TextEditingController()
                          ..text = model.middleNameController.value ?? "",
                        // maxLenth: 7,
                        // onChanged: (value) {
                        //   if (value.toString().isEmpty) {
                        //     model.uniqDocController.value =
                        //         double.parse("0").round();
                        //   } else {
                        //     model.uniqDocController.value =
                        //         double.parse(value).round();
                        //   }
                        // }
                      ),
                    ),
                    Container(
                      child: buildTextField(
                        hint: "PAN",
                        label: "PAN",
                        keyBoardType: TextInputType.text,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[aA-zZ,0-9, ,]')),
                        ],
                        controller: TextEditingController()
                          ..text = model.employeePanController.value ?? "",
                        // maxLenth: 7,
                        // onChanged: (value) {
                        //   if (value.toString().isEmpty) {
                        //     model.uniqDocController.value =
                        //         double.parse("0").round();
                        //   } else {
                        //     model.uniqDocController.value =
                        //         double.parse(value).round();
                        //   }
                        // }
                      ),
                    ),
                    Container(
                      child: buildTextField(
                        hint: "Place",
                        label: "Place",
                        keyBoardType: TextInputType.text,
                        numbersAllowd: <TextInputFormatter>[
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[aA-zZ,0-9, ,]')),
                        ],
                        controller: TextEditingController()..text = "Pune",
                        // maxLenth: 7,
                        // onChanged: (value) {
                        //   if (value.toString().isEmpty) {
                        //     model.uniqDocController.value =
                        //         double.parse("0").round();
                        //   } else {
                        //     model.uniqDocController.value =
                        //         double.parse(value).round();
                        //   }
                        // }
                      ),
                    ),
                    StreamBuilder<DateTime>(
                        stream: model.dateofITR,
                        builder: (context, snapshot) {
                          return Container(
                            child: buildTextField(
                              hint: "Date ",
                              label: "Date ",
                              numbersAllowd: <TextInputFormatter>[
                                FilteringTextInputFormatter.allow(
                                    RegExp(r'[0-9]')),
                              ],
                              controller: TextEditingController()
                                ..text = snapshot.data != null
                                    ? DateFormat('dd-MM-yyyy')
                                        .format(snapshot.data)
                                        .toString()
                                    : "",
                              onTap: () {
                                model.setITRDate(context);
                              },
                            ),
                          );
                        }),
                  ],
                ),
              ),
            );
          },
        );
      });
}

// ^ self assesment Tax
selfAssesmentTaxDialog(
  BuildContext context,
  List<int> amountList,
  List<String> amountDate,
  TaxCalculationViewModel model,
) {
  return showGeneralDialog(
    context: context,
    useRootNavigator: false,
    pageBuilder: (context, _, __) {
      Padding buildTextField(
          {String hint,
          String label,
          int maxLenth,
          Function(dynamic p1) onChanged,
          TextInputType keyBoardType,
          TextEditingController controller,
          List<TextInputFormatter> numbersAllowd}) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
            maxLength: maxLenth,
            inputFormatters: numbersAllowd ??
                <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
            decoration: InputDecoration(
              hintText: hint,
              labelText: label,
            ),
            onChanged: onChanged,
            controller: controller ?? TextEditingController(),
          ),
        );
      }

      // ^ dynamic Other self Tax
      List<Widget> _getdynamicDateAmount(
          [TaxCalculationViewModel model, Function setState]) {
        List<Widget> selfTaxTextFields = [];
        for (int i = 0; i < model.selfTaxAmountController.value.length; i++) {
          selfTaxTextFields.add(Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              model.selfTaxAmountController.value.toString() != [].toString() ||
                      model.selfTaxAmountController.value.length > 0
                  ? Column(
                      children: [
                        Container(
                          height: 50,
                          width: screenWidth(context),
                          child: DateTimePicker(
                            firstDate:
                                model.selectedYearController.value.toString() ==
                                        "2021-2022"
                                    ? DateTime(2020, 01, 31)
                                    : DateTime(2019, 3, 31),
                            lastDate: DateTime(2100),
                            dateLabelText: 'Date',
                            dateMask: 'dd-MMM-yyyy',
                            controller: TextEditingController()
                              ..text = model.selfTaxDateController.value[i]
                                  .toString(),
                            onChanged: (value) {
                              model.selfTaxDateController.value[i] =
                                  value.toString().substring(0, 10);

                              model.onSelfTaxDateChanged;
                              model.calculateSelfAssestTax(
                                  model.selfTaxAmountController.value,
                                  model.selfTaxDateController.value);
                            },
                          ),
                        ),
                        buildTextField(
                            hint: "BSR",
                            label: "BSR",
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            controller: TextEditingController()
                              ..text = model.selfTaxBSRController.value[i]
                                  .toString(),
                            maxLenth: 7,
                            onChanged: (value) {
                              if (value.toString().isEmpty) {
                                model.selfTaxBSRController.value[i] =
                                    double.parse("0").round();
                              } else {
                                model.selfTaxBSRController.value[i] =
                                    double.parse(value).round();
                              }
                            }),
                        buildTextField(
                            hint: "CIN",
                            label: "CIN",
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            maxLenth: 5,
                            controller: TextEditingController()
                              ..text = model.selfTaxCINController.value[i]
                                  .toString(),
                            onChanged: (value) {
                              if (value.toString().isEmpty) {
                                model.selfTaxCINController.value[i] =
                                    double.parse("0").round();
                              } else {
                                model.selfTaxCINController.value[i] =
                                    double.parse(value).round();
                              }
                            }),
                        buildTextField(
                          hint: AMOUNT,
                          label: AMOUNT,
                          controller: TextEditingController()
                            ..text = model.selfTaxAmountController.value[i]
                                .toString(),
                          numbersAllowd: <TextInputFormatter>[
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          onChanged: (value) {
                            if (value.toString().isEmpty) {
                              model.selfTaxAmountController.value[i] =
                                  double.parse("0").round();
                              model.selfTaxDateController.value[i].isEmpty
                                  ?
                                  // ignore: unnecessary_statements
                                  model.selfTaxDateController.value[i] = model
                                              .selectedYearController.value
                                              .toString() ==
                                          "2021-2022"
                                      ? DateTime(2020, 01, 31).toString()
                                      : DateTime(2019, 3, 31).toString()
                                  : "";
                              model.onSelfTaxAmountChanged;
                              model.calculateSelfAssestTax(
                                  model.selfTaxAmountController.value,
                                  model.selfTaxDateController.value);
                            } else {
                              model.selfTaxAmountController.value[i] =
                                  double.parse(value).round();
                              model.selfTaxDateController.value[i].isEmpty
                                  ?
                                  // ignore: unnecessary_statements
                                  model.selfTaxDateController.value[i] = model
                                              .selectedYearController.value
                                              .toString() ==
                                          "2021-2022"
                                      ? DateTime(2020, 01, 31).toString()
                                      : DateTime(2019, 3, 31).toString()
                                  : "";
                              model.onSelfTaxAmountChanged;
                              model.calculateSelfAssestTax(
                                  model.selfTaxAmountController.value,
                                  model.selfTaxDateController.value);
                            }
                          },
                        ),
                      ],
                    )
                  : Container(
                      child: Text(
                      'hiii',
                    ))
            ],
          ));
        }

        return selfTaxTextFields;
      }

      return StatefulBuilder(
        builder: (BuildContext ctx, setState) {
          return Scaffold(
            resizeToAvoidBottomInset: true,
            appBar: AppBar(
              title: Text(SELF_ASSESMENT_TAX),
            ),
            bottomNavigationBar: CustomBotomBar(
              onCancelButtonPressed: () {
                print("Cancel Pressed");
                Navigator.of(context).pop();
              },
              onSaveButtonPressed: () {
                print("==============");
                model.calculateSelfAssestTax(
                    model.selfTaxAmountController.value,
                    model.selfTaxDateController.value);
                model.saveSelfTax();
                Navigator.of(context).pop();
              },
            ),
            floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
            floatingActionButton: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                model.selfTaxAmountController.value.length > 0
                    ? FloatingActionButton(
                        child: Icon(Icons.delete),
                        onPressed: () {
                          setState(() {
                            print(amountList.toList());
                            model.selfTaxAmountController.value.removeAt(
                                model.selfTaxAmountController.value.length - 1);
                            model.selfTaxDateController.value.removeAt(
                                model.selfTaxDateController.value.length - 1);
                            model.selfTaxCINController.value.removeAt(
                                model.selfTaxCINController.value.length - 1);
                            model.selfTaxBSRController.value.removeAt(
                                model.selfTaxBSRController.value.length - 1);
                            model.calculateSelfAssestTax(
                                model.selfTaxAmountController.value,
                                model.selfTaxDateController.value);
                            setState(() {});
                          });
                        })
                    : SizedBox.shrink(),
                SizedBox(
                  width: Sizes.WIDTH_10,
                ),
                FloatingActionButton(
                    child: Icon(Icons.add),
                    onPressed: () {
                      setState(() {
                        model.selfTaxAmountController.value.insert(
                            model.selfTaxAmountController.value.length, 0);
                        model.selfTaxDateController.value.insert(
                            model.selfTaxDateController.value.length,
                            DateTime.now().toString().substring(0, 10));
                        model.selfTaxCINController.value
                            .insert(model.selfTaxCINController.value.length, 0);
                        model.selfTaxBSRController.value
                            .insert(model.selfTaxBSRController.value.length, 0);
                        model.calculateSelfAssestTax(
                            model.selfTaxAmountController.value,
                            model.selfTaxDateController.value);
                      });
                    }),
              ],
            ),
            body: model.selfTaxAmountController.value.length == 0
                ? Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Center(
                        child: Lottie.asset(
                          'assets/animations/addTax.json',
                          height: screenHeight(context) / 5,
                          fit: BoxFit.fill,
                        ),
                      ),
                      Text(
                        ADD_TAX,
                        style: Theme.of(context).textTheme.headline6.copyWith(
                              color: Colors.black45,
                            ),
                      )
                    ],
                  )
                : Container(
                    height:
                        screenHeight(context) - AppBar().preferredSize.height,
                    width: screenWidth(context),
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: EdgeInsets.all(Sizes.PADDING_10),
                        child: Column(
                          children: [
                            ..._getdynamicDateAmount(model, setState),
                          ],
                        ),
                      ),
                    ),
                  ),
          );
        },
      );
    },
  );
}

// ^ advanced Tax
advancedTaxDialog(
  BuildContext context,
  List<int> amountList,
  List<String> amountDate,
  TaxCalculationViewModel model,
) {
  return showGeneralDialog(
    context: context,
    useRootNavigator: false,
    pageBuilder: (context, _, __) {
      Padding buildTextField(
          {String hint,
          String label,
          int maxLength,
          Function(dynamic p1) onChanged,
          TextInputType keyBoardType,
          List<TextInputFormatter> numbersAllowd,
          TextEditingController controller}) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
            inputFormatters: numbersAllowd ??
                <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
            maxLength: maxLength,
            decoration: InputDecoration(
              hintText: hint,
              labelText: label,
            ),
            onChanged: onChanged,
            controller: controller ?? TextEditingController(),
          ),
        );
      }

      // ^ dynamic advancedTaxDialog TextFields
      List<Widget> _getdynamicDateAmount(
          [TaxCalculationViewModel model, Function setState]) {
        List<Widget> advancedTaxTextFields = [];

        for (int i = 0;
            i < model.advancedTaxAmountController.value.length;
            i++) {
          advancedTaxTextFields.add(Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              model.advancedTaxAmountController.value.toString() !=
                          [].toString() ||
                      model.advancedTaxAmountController.value.length > 0
                  ? Column(
                      children: [
                        Container(
                          height: 50,
                          width: screenWidth(context),
                          child: DateTimePicker(
                            firstDate:
                                model.selectedYearController.value.toString() ==
                                        "2021-2022"
                                    ? DateTime(2020, 4, 1)
                                    : DateTime(2019, 4, 1),
                            lastDate:
                                model.selectedYearController.value.toString() ==
                                        "2021-2022"
                                    ? DateTime(2021, 3, 31)
                                    : DateTime(2020, 3, 31),
                            dateLabelText: 'Date',
                            dateMask: 'dd-MMM-yyyy',
                            controller: TextEditingController()
                              ..text = model.advancedTaxDateController.value[i]
                                  .toString(),
                            onChanged: (value) {
                              model.advancedTaxDateController.value[i] =
                                  value.toString();
                              model.onAdvancedTaxDateChanged;
                              model.calculateAdvancedTax(
                                model.advancedTaxAmountController.value,
                                model.advancedTaxDateController.value,
                              );
                              setState(() {});
                            },
                          ),
                        ),
                        buildTextField(
                            hint: "BSR",
                            label: "BSR",
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            maxLength: 7,
                            controller: TextEditingController()
                              ..text = model.advanceTaxBSRController.value[i]
                                  .toString(),
                            onChanged: (value) {
                              if (value.toString().isEmpty) {
                                model.advanceTaxBSRController.value[i] =
                                    double.parse("0").round();
                              } else {
                                model.advanceTaxBSRController.value[i] =
                                    double.parse(value).round();
                              }
                            }),
                        buildTextField(
                            hint: "CIN",
                            label: "CIN",
                            numbersAllowd: <TextInputFormatter>[
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9]')),
                            ],
                            maxLength: 5,
                            controller: TextEditingController()
                              ..text = model.advanceTaxCINController.value[i]
                                  .toString(),
                            onChanged: (value) {
                              if (value.toString().isEmpty) {
                                model.advanceTaxCINController.value[i] =
                                    double.parse("0").round();
                              } else {
                                model.advanceTaxCINController.value[i] =
                                    double.parse(value).round();
                              }
                            }),
                        buildTextField(
                          hint: AMOUNT,
                          label: AMOUNT,
                          numbersAllowd: <TextInputFormatter>[
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                          ],
                          controller: TextEditingController()
                            ..text = model.advancedTaxAmountController.value[i]
                                .toString()
                            ..selection = TextSelection.fromPosition(
                                TextPosition(
                                    offset: model
                                        .advancedTaxAmountController.value[i]
                                        .toString()
                                        .length)),
                          onChanged: (value) {
                            if (value.toString().isEmpty) {
                              model.advancedTaxAmountController.value[i] =
                                  double.parse("0".toString()).round();
                              model.onAdvancedTaxAmountChanged;
                              model.calculateAdvancedTax(
                                model.advancedTaxAmountController.value,
                                model.advancedTaxDateController.value,
                              );
                            } else {
                              model.advancedTaxAmountController.value[i] =
                                  double.parse(value.toString()).round();
                              model.onAdvancedTaxAmountChanged;
                              model.calculateAdvancedTax(
                                model.advancedTaxAmountController.value,
                                model.advancedTaxDateController.value,
                              );
                            }
                            setState(() {});
                          },
                        ),
                      ],
                    )
                  : Container(
                      child: Text(
                      'hiii',
                    ))
            ],
          ));
        }

        return advancedTaxTextFields;
      }

      return StatefulBuilder(
        builder: (context, setState) {
          return SizedBox.expand(
            child: Scaffold(
              resizeToAvoidBottomInset: true,
              appBar: AppBar(
                title: Text(ADVANCED_TAX),
              ),
              bottomNavigationBar: CustomBotomBar(
                onCancelButtonPressed: () {
                  print("Cancel Pressed");
                  Navigator.of(context).pop();
                },
                onSaveButtonPressed: () {
                  model.saveAdvanceTax();
                  Navigator.of(context).pop();
                },
              ),
              floatingActionButtonLocation:
                  FloatingActionButtonLocation.endFloat,
              floatingActionButton: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  model.advancedTaxAmountController.value != null
                      ? model.advancedTaxAmountController.value.length > 0
                          ? FloatingActionButton(
                              child: Icon(Icons.delete),
                              onPressed: () {
                                model.advancedTaxAmountController.value
                                    .removeAt(model.advancedTaxAmountController
                                            .value.length -
                                        1);
                                model.advancedTaxDateController.value.removeAt(
                                    model.advancedTaxDateController.value
                                            .length -
                                        1);
                                model.advanceTaxCINController.value.removeAt(
                                    model.advanceTaxCINController.value.length -
                                        1);
                                model.advanceTaxBSRController.value.removeAt(
                                    model.advanceTaxBSRController.value.length -
                                        1);
                                model.calculateAdvancedTax(
                                  model.advancedTaxAmountController.value,
                                  model.advancedTaxDateController.value,
                                );
                                setState(() {});
                              })
                          : SizedBox.shrink()
                      : SizedBox.shrink(),
                  SizedBox(
                    width: 10,
                  ),
                  FloatingActionButton(
                      child: Icon(Icons.add),
                      onPressed: () {
                        model.advancedTaxAmountController.value.insert(
                            model.advancedTaxAmountController.value.length, 0);
                        model.advancedTaxDateController.value.insert(
                            model.advancedTaxDateController.value.length,
                            model.selectedYearController.value.toString() ==
                                    "2021-2022"
                                ? DateTime(2020, 4, 1).toString()
                                : DateTime(2019, 4, 1).toString());
                        model.advanceTaxCINController.value.insert(
                            model.advanceTaxCINController.value.length, 0);
                        model.advanceTaxBSRController.value.insert(
                            model.advanceTaxBSRController.value.length, 0);
                        model.calculateAdvancedTax(
                          model.advancedTaxAmountController.value,
                          model.advancedTaxDateController.value,
                        );
                        setState(() {});
                      }),
                ],
              ),
              body: model.advancedTaxAmountController.value.length == 0
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Center(
                          child: Lottie.asset(
                            'assets/animations/addTax.json',
                            height: screenHeight(context) / 5,
                            fit: BoxFit.fill,
                          ),
                        ),
                        Text(
                          ADD_TAX,
                          style: Theme.of(context).textTheme.headline6.copyWith(
                                color: Colors.black45,
                              ),
                        )
                      ],
                    )
                  : Container(
                      height:
                          screenHeight(context) - AppBar().preferredSize.height,
                      width: screenWidth(context),
                      child: SingleChildScrollView(
                        child: Padding(
                          padding: EdgeInsets.all(Sizes.PADDING_10),
                          child: Column(
                            children: [
                              ..._getdynamicDateAmount(model, setState),
                            ],
                          ),
                        ),
                      ),
                    ),
            ),
          );
        },
      );
    },
  );
}

// ^ salary dialog
salaryDialog(BuildContext context, List<int> perquisitesList,
    List<int> lieuList, List<int> exemptList, TaxCalculationViewModel model) {
  var selectedEmployerCategory;

  showGeneralDialog(
    context: context,
    useRootNavigator: false,
    pageBuilder: (context, _, __) {
      Padding buildTextField(
          {String hint,
          String label,
          Function(dynamic p1) onChanged,
          TextInputType keyBoardType,
          String controllerText,
          bool readOnly,
          int maxLength,
          TextEditingController controller,
          String intialValue,
          Function validator,
          TextCapitalization textCapitalization,
          List<TextInputFormatter> numberAllowed}) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextFormField(
            maxLength: maxLength,
            textCapitalization: textCapitalization ?? TextCapitalization.none,
            keyboardType: keyBoardType ?? TextInputType.numberWithOptions(),
            controller: controller ?? TextEditingController(),
            inputFormatters: numberAllowed ??
                <TextInputFormatter>[
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                ],
            readOnly: readOnly ?? false,
            decoration: InputDecoration(
              hintText: hint,
              labelText: label,
            ),
            onChanged: onChanged,
            validator: validator,
          ),
        );
      }

      Widget _addRemoveButtonOther(
          bool add, int index, int value, Function setState) {
        return InkWell(
          onTap: () {
            if (add) {
              setState(() {
                model.employerOtherController.value.insert(index, value);
              });
              setState(() {});
            } else {
              model.employerOtherController.value.removeAt(index);
              model.employerOtherStringController.value.removeAt(index);
            }

            setState(() {});
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                (add) ? Icons.add : Icons.delete,
                color: Colors.red,
              ),
            ),
          ),
        );
      }

      Widget _addRemoveButtonPerquisites(
          bool add, int index, int value, setState) {
        return InkWell(
          onTap: () {
            if (add) {
              model.employerPerquistesController.value.insert(index, value);
            } else
              model.employerPerquistesController.value.removeAt(index);
            model.employerValueOfPerquisitesStringController.value
                .removeAt(index);
            setState(() {});
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                (add) ? Icons.add : Icons.delete,
                color: Colors.red,
              ),
            ),
          ),
        );
      }

      Widget _addRemoveButtonLieu(
          bool add, int index, int value, Function setState) {
        return InkWell(
          onTap: () {
            if (add) {
              print(index);
              model.employerProfitInLieuController.value.insert(index, value);
            } else {
              model.employerProfitInLieuController.value.removeAt(index);
            }
            model.employeLieuStringController.value.removeAt(index);
            model.calculateSalary();
            setState(() {});
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                (add) ? Icons.add : Icons.delete,
                color: Colors.red,
              ),
            ),
          ),
        );
      }

      Widget _addRemoveButtonExempt(
          bool add, int index, int value, Function setState) {
        print(index);
        return InkWell(
          onTap: () {
            if (add) {
              print(index);
              model.employerExemptAllowancesController.value
                  .insert(index, value);
            } else {
              model.employerExemptAllowancesController.value.removeAt(index);
              model.isAnyOtherController.value.removeAt(index);
            }
            model.employeExemptAllwnStringController.value.removeAt(index);
            setState(() {});
          },
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                (add) ? Icons.add : Icons.delete,
                color: Colors.red,
              ),
            ),
          ),
        );
      }

      // ^ dynamic Other TextFields
      List<Widget> _getdynamicOther(
          TaxCalculationViewModel model, Function setState) {
        List<Widget> otherTextFields = [];
        String selectedValue;

        if (model.employerOtherController.value != null) {
          for (int i = 0; i < model.employerOtherController.value.length; i++) {
            selectedValue = model.employerOtherStringController.value[i];

            otherTextFields.add(Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                model.employerOtherController.value.toString() !=
                            [].toString() ||
                        model.employerOtherController.value.length > 0
                    ? Card(
                        elevation: 5,
                        color: Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Container(
                          height: screenHeight(context) / 3,
                          width: screenWidth(context),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Scaffold(
                            appBar: AppBar(
                              leading: Text(""),
                              title: Text(OTHER),
                              centerTitle: true,
                              flexibleSpace: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topRight,
                                      end: Alignment.bottomLeft,
                                      colors: <Color>[
                                        AppColors.mydocumentBG_COLOR,
                                        AppColors.mydocumentBG_COLOR2
                                      ]),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                  ),
                                ),
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            body: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  StreamBuilder<List<Others>>(
                                      stream: model.otherDropdown,
                                      builder: (context, snapshot) {
                                        return snapshot.data == null
                                            ? SizedBox.shrink()
                                            : Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child:
                                                    new DropdownButtonFormField(
                                                  isExpanded: true,
                                                  items: snapshot.data
                                                      .map((Others value) {
                                                    return new DropdownMenuItem<
                                                        String>(
                                                      value: value.nameOfOther,
                                                      child: new Text(
                                                          value.nameOfOther,
                                                          overflow: TextOverflow
                                                              .ellipsis),
                                                    );
                                                  }).toList(),
                                                  hint: Text(
                                                      "Please choose a  Other"),
                                                  onChanged: (value) {
                                                    selectedValue = value;
                                                    if (selectedValue !=
                                                        model
                                                            .employerOtherStringController
                                                            .value[i]
                                                            .toString()) {
                                                      model
                                                          .employerOtherStringController
                                                          .value[i] = value;
                                                    }
                                                    model
                                                        .onEmployerOtherStrinChanged;
                                                    setState(() {});
                                                  },
                                                ),
                                              );
                                      }),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(selectedValue ?? ""),
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                            height: 60,
                                            width: screenWidth(context),
                                            child: buildTextField(
                                              hint: selectedValue,
                                              label: selectedValue,
                                              numberAllowed: <
                                                  TextInputFormatter>[
                                                FilteringTextInputFormatter
                                                    .allow(RegExp(r'[0-9]')),
                                              ],
                                              controller:
                                                  TextEditingController()
                                                    ..text = model
                                                        .employerOtherController
                                                        .value[i]
                                                        .toString(),
                                              onChanged: (value) {
                                                if (value.toString().isEmpty) {
                                                  model.employerOtherController
                                                      .value[i] = 0;
                                                  model.onEmployerOtherChange;
                                                  model.calculateSalary();
                                                } else {
                                                  model.employerOtherController
                                                          .value[i] =
                                                      double.parse(value)
                                                          .round();
                                                  model.onEmployerOtherChange;
                                                  model.calculateSalary();
                                                }
                                              },
                                            )),
                                      ),
                                      model.employerOtherController.value
                                                  .length ==
                                              1
                                          ? SizedBox.shrink()
                                          : _addRemoveButtonOther(
                                              false, i, 0, setState),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    : Container(
                        child: Text(
                        'hiii',
                      ))
              ],
            ));
          }
        }

        return otherTextFields;
      }

// ^ dynamic perquisites TextFields
      List<Widget> _getdynamicPerquisites(
          TaxCalculationViewModel model, Function setState) {
        List<Widget> perquisitesTextFields = [];
        String selectedValue;
        if (model.employerPerquistesController.value != null) {
          for (int i = 0;
              i < model.employerPerquistesController.value.length;
              i++) {
            selectedValue =
                model.employerValueOfPerquisitesStringController.value[i];

            perquisitesTextFields.add(Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                model.employerPerquistesController.value.length.toString() !=
                            [].toString() ||
                        model.employerPerquistesController.value.length > 0
                    ? Card(
                        elevation: 5,
                        color: Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Container(
                          height: screenHeight(context) / 3,
                          width: screenWidth(context),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Scaffold(
                            appBar: AppBar(
                              leading: Text(""),
                              title: Text(VALUE_OF_PERQUISITES),
                              centerTitle: true,
                              flexibleSpace: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topRight,
                                      end: Alignment.bottomLeft,
                                      colors: <Color>[
                                        AppColors.mydocumentBG_COLOR,
                                        AppColors.mydocumentBG_COLOR2
                                      ]),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                  ),
                                ),
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            body: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  StreamBuilder<List<Perquisites>>(
                                      stream: model.perquisitesDropdown,
                                      builder: (context, snapshot) {
                                        return snapshot.data == null
                                            ? SizedBox.shrink()
                                            : Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child:
                                                    new DropdownButtonFormField(
                                                  isExpanded: true,
                                                  items: snapshot.data
                                                      .map((Perquisites value) {
                                                    return new DropdownMenuItem<
                                                        String>(
                                                      value: value
                                                          .nameOfPerquisites,
                                                      child: new Text(
                                                        value.nameOfPerquisites,
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                      ),
                                                    );
                                                  }).toList(),
                                                  hint: Text(
                                                      "Please choose a  Perquisites"),
                                                  onChanged: (value) {
                                                    selectedValue = value;
                                                    if (selectedValue !=
                                                        model
                                                            .employerValueOfPerquisitesStringController
                                                            .value[i]
                                                            .toString()) {
                                                      model
                                                          .employerValueOfPerquisitesStringController
                                                          .value[i] = value;
                                                    }
                                                    model
                                                        .onEmployerValueOfPerquisitesStringChanged;

                                                    setState(() {});
                                                  },
                                                ),
                                              );
                                      }),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(selectedValue ?? ""),
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          height: 60,
                                          width: screenWidth(context),
                                          child: StreamBuilder<Object>(
                                              stream: model.form16Data,
                                              builder: (context, snapshot) {
                                                return buildTextField(
                                                  hint: VALUE_OF_PERQUISITES,
                                                  label: VALUE_OF_PERQUISITES,
                                                  controller:
                                                      TextEditingController()
                                                        ..text = model
                                                            .employerPerquistesController
                                                            .value[i]
                                                            .toString(),
                                                  numberAllowed: <
                                                      TextInputFormatter>[
                                                    FilteringTextInputFormatter
                                                        .allow(
                                                            RegExp(r'[0-9]')),
                                                  ],
                                                  onChanged: (value) {
                                                    if (value
                                                        .toString()
                                                        .isEmpty) {
                                                      perquisitesList[i] = 0;
                                                      model
                                                          .onEmployerPerquistesChange;
                                                      model
                                                          .calculatePerquisites(
                                                              perquisitesList);
                                                      model.calculateSalary();
                                                    } else {
                                                      perquisitesList[i] =
                                                          double.parse(value)
                                                              .round();
                                                      model
                                                          .onEmployerPerquistesChange;
                                                      model
                                                          .calculatePerquisites(
                                                              perquisitesList);
                                                      model.calculateSalary();
                                                    }
                                                  },
                                                );
                                              }),
                                        ),
                                      ),
                                      _addRemoveButtonPerquisites(
                                          false,
                                          i,
                                          model.employerPerquistesController
                                              .value[i],
                                          setState),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    : Container(
                        child: Text(
                          'hiii',
                        ),
                      )
              ],
            ));
          }
        }

        return perquisitesTextFields;
      }

// ^ dynamic Lieu TextFields
      List<Widget> _getdynamicLieu(
          TaxCalculationViewModel model, Function setState) {
        List<Widget> lieuTextFields = [];
        String selectedValue;
        if (model.employerProfitInLieuController.value != null) {
          for (int i = 0;
              i < model.employerProfitInLieuController.value.length;
              i++) {
            selectedValue = model.employeLieuStringController.value[i];
            Logger().wtf(selectedValue);
            lieuTextFields.add(Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                model.employerProfitInLieuController.value.toString() !=
                            [].toString() ||
                        model.employerProfitInLieuController.value.length > 0
                    ? Card(
                        elevation: 5,
                        color: Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Container(
                          height: screenHeight(context) / 3,
                          width: screenWidth(context),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Scaffold(
                            appBar: AppBar(
                              leading: Text(""),
                              title: Text(PROFIT_IN_LIEU_SALARY),
                              centerTitle: true,
                              flexibleSpace: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topRight,
                                    end: Alignment.bottomLeft,
                                    colors: <Color>[
                                      AppColors.mydocumentBG_COLOR,
                                      AppColors.mydocumentBG_COLOR2
                                    ],
                                  ),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                  ),
                                ),
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            body: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  StreamBuilder<List<Lieu>>(
                                      stream: model.lieuDropdown,
                                      builder: (context, snapshot) {
                                        return snapshot.data == null
                                            ? SizedBox.shrink()
                                            : Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child:
                                                    new DropdownButtonFormField(
                                                  isExpanded: true,
                                                  items: snapshot.data
                                                      .map((Lieu value) {
                                                    return new DropdownMenuItem<
                                                        String>(
                                                      value: value.nameOfLieu,
                                                      child: new Text(
                                                          value.nameOfLieu,
                                                          overflow: TextOverflow
                                                              .ellipsis),
                                                    );
                                                  }).toList(),
                                                  hint: Text(
                                                      "Please choose a  Lieu"),
                                                  onChanged: (value) {
                                                    selectedValue = value;
                                                    if (selectedValue !=
                                                        model
                                                            .employeLieuStringController
                                                            .value[i]
                                                            .toString()) {
                                                      model
                                                          .employeLieuStringController
                                                          .value[i] = value;
                                                    }
                                                    model
                                                        .onEmployeLieuStringChanged;

                                                    setState(() {});
                                                  },
                                                ),
                                              );
                                      }),
                                  Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text(selectedValue ?? ""),
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          height: 60,
                                          width: screenWidth(context),
                                          child: buildTextField(
                                            hint: PROFIT_IN_LIEU_SALARY,
                                            label: PROFIT_IN_LIEU_SALARY,
                                            numberAllowed: <TextInputFormatter>[
                                              FilteringTextInputFormatter.allow(
                                                  RegExp(r'[0-9]')),
                                            ],
                                            controller: TextEditingController()
                                              ..text = model
                                                  .employerProfitInLieuController
                                                  .value[i]
                                                  .toString(),
                                            onChanged: (value) {
                                              if (value.toString().isEmpty) {
                                                model
                                                    .employerProfitInLieuController
                                                    .value[i] = 0;
                                                model
                                                    .onEmployerProfitInLieuChange;
                                                // model.calculateLieu(lieuList);
                                                model.calculateSalary();
                                              } else {
                                                model
                                                    .employerProfitInLieuController
                                                    .value[i] = double.parse(
                                                        value)
                                                    .round();
                                                model
                                                    .onEmployerProfitInLieuChange;
                                                // model.calculateLieu(lieuList);
                                                model.calculateSalary();
                                              }
                                            },
                                          ),
                                        ),
                                      ),
                                      _addRemoveButtonLieu(
                                          false,
                                          i,
                                          model.employerProfitInLieuController
                                              .value[i],
                                          setState),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      )
                    : Container(
                        child: Text(
                          'hiii',
                        ),
                      )
              ],
            ));
          }
        }

        return lieuTextFields;
      }

      // ^ dynamic  exempt textfields
      List<Widget> _getdynamicExempt(
          TaxCalculationViewModel model, Function setState) {
        List<Widget> exemptTextFields = [];
        String selectedValue1;

        if (model.employerExemptAllowancesController.value != null) {
          for (int i = 0;
              i < model.employeExemptAllwnStringController.value.length;
              i++) {
            selectedValue1 =
                model.employeExemptAllwnStringController.value[i].toString();
            Logger().wtf(selectedValue1);
            exemptTextFields.add(Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                model.employerExemptAllowancesController.value.toString() !=
                            [].toString() ||
                        model.employerExemptAllowancesController.value.length >
                            0
                    ? Card(
                        elevation: 5,
                        color: Colors.green,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Container(
                          height: screenHeight(context) / 2.5,
                          width: screenWidth(context),
                          decoration: BoxDecoration(
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Scaffold(
                            appBar: AppBar(
                              leading: Text(""),
                              title: Text(EXEMPT_ALLOWANCE),
                              centerTitle: true,
                              flexibleSpace: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topRight,
                                      end: Alignment.bottomLeft,
                                      colors: <Color>[
                                        AppColors.mydocumentBG_COLOR,
                                        AppColors.mydocumentBG_COLOR2
                                      ]),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(20),
                                    topRight: Radius.circular(20),
                                  ),
                                ),
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                            body: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    StreamBuilder<List<ExemptAllwn>>(
                                        stream: model.exemptAllwnropdown,
                                        builder: (context, snapshot) {
                                          return snapshot.data == null
                                              ? SizedBox.shrink()
                                              : Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child:
                                                      new DropdownButtonFormField(
                                                    isExpanded: true,
                                                    items: snapshot.data.map(
                                                        (ExemptAllwn value) {
                                                      return new DropdownMenuItem<
                                                          String>(
                                                        value: value
                                                            .nameOfExemptAllwn,
                                                        child: new Text(
                                                            value
                                                                .nameOfExemptAllwn,
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis),
                                                      );
                                                    }).toList(),
                                                    hint: Text(
                                                        "Please choose a Nature of Exempt Allowance "),
                                                    onChanged: (value) {
                                                      selectedValue1 = value;
                                                      Logger()
                                                          .wtf(selectedValue1);
                                                      Logger().e(selectedValue1
                                                          .contains(
                                                              "Any Other"));
                                                      if (selectedValue1 !=
                                                          model
                                                              .employeExemptAllwnStringController
                                                              .value[i]
                                                              .toString()) {
                                                        model
                                                            .employeExemptAllwnStringController
                                                            .value[i] = value;
                                                      }
                                                      model
                                                          .onEmployeExemptAllwncStringChanged;

                                                      if (selectedValue1
                                                          .contains(
                                                              "Any Other")) {
                                                        setState(() {
                                                          model
                                                              .isAnyOtherController
                                                              .value[i] = true;
                                                        });
                                                      } else {
                                                        setState(() {
                                                          model
                                                              .isAnyOtherController
                                                              .value[i] = false;
                                                        });
                                                      }
                                                      setState(() {});
                                                    },
                                                  ),
                                                );
                                        }),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        children: [
                                          Expanded(
                                              child:
                                                  Text(selectedValue1 ?? "")),
                                          _addRemoveButtonExempt(
                                              false,
                                              i,
                                              model
                                                  .employerExemptAllowancesController
                                                  .value[i],
                                              setState),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      height: 60,
                                      width: screenWidth(context),
                                      child: buildTextField(
                                        hint: EXEMPT_ALLOWANCE,
                                        label: EXEMPT_ALLOWANCE,
                                        numberAllowed: <TextInputFormatter>[
                                          FilteringTextInputFormatter.allow(
                                              RegExp(r'[0-9]')),
                                        ],
                                        controller: TextEditingController()
                                          ..text = model
                                              .employerExemptAllowancesController
                                              .value[i]
                                              .toString(),
                                        onChanged: (value) {
                                          if (value.toString().isEmpty) {
                                            model
                                                .employerExemptAllowancesController
                                                .value[i] = 0;
                                            model
                                                .onEmployerExemptAllowancesChange;
                                            model.calculateSalary();
                                          } else {
                                            model
                                                .employerExemptAllowancesController
                                                .value[i] = double.parse(
                                                    value)
                                                .round();
                                            model
                                                .onEmployerExemptAllowancesChange;
                                            model.calculateSalary();
                                          }
                                        },
                                      ),
                                    ),
                                    StreamBuilder<List<bool>>(
                                        stream: model.isAnyOther,
                                        builder: (context, snapshot) {
                                          Logger().e(snapshot.data);
                                          Logger().e(snapshot.data[i]);
                                          return snapshot.data[i]
                                              ? Container(
                                                  width: screenWidth(context),
                                                  child: buildTextField(
                                                    hint: DESC_ALLOWANCE,
                                                    label: DESC_ALLOWANCE,
                                                    keyBoardType:
                                                        TextInputType.text,
                                                    numberAllowed: <
                                                        TextInputFormatter>[
                                                      FilteringTextInputFormatter
                                                          .allow(RegExp(
                                                              r'[a-z,A-Z,0-9,, ,]')),
                                                    ],
                                                    maxLength: 150,
                                                    controller:
                                                        TextEditingController()
                                                          ..text = model
                                                              .employerExemptAllowancesDescriptionController
                                                              .value[i]
                                                              .toString(),
                                                    onChanged: (value) {
                                                      if (value
                                                          .toString()
                                                          .isEmpty) {
                                                        model
                                                            .employerExemptAllowancesDescriptionController
                                                            .value[i] = "";
                                                        model
                                                            .onEmployerExemptAllowancesDescriptionChange;
                                                      } else {
                                                        model.employerExemptAllowancesDescriptionController
                                                                .value[i] =
                                                            value.toString();
                                                        model
                                                            .onEmployerExemptAllowancesDescriptionChange;
                                                      }
                                                    },
                                                  ),
                                                )
                                              : SizedBox.shrink();
                                        })
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      )
                    : Container(
                        child: Text(
                          'hiii',
                        ),
                      )
              ],
            ));
          }
        }

        return exemptTextFields;
      }

      return StatefulBuilder(builder: (context, setState) {
        return SizedBox.expand(
          child: Scaffold(
            resizeToAvoidBottomInset: true,
            appBar: AppBar(
              title: Text(SALARY),
            ),
            bottomNavigationBar: CustomBotomBar(
              onCancelButtonPressed: () {
                print("Cancel Pressed");
                Navigator.of(context).pop();
              },
              onSaveButtonPressed: () {
                model.saveSalary();
                Navigator.of(context).pop();
              },
            ),
            body: Container(
              height: screenHeight(context) - AppBar().preferredSize.height,
              width: screenWidth(context),
              child: SingleChildScrollView(
                  child: Padding(
                      padding: EdgeInsets.all(Sizes.PADDING_10),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              ButtonTheme(
                                height: 50,
                                minWidth: screenWidth(context) / 1.5,
                                child: OutlinedButton.icon(
                                  onPressed: () {
                                    model.getFor16File();
                                  },
                                  label: Container(
                                    child: StreamBuilder<File>(
                                        stream: model.file,
                                        builder: (context, snapshot) {
                                          return Text(
                                            snapshot.data == null
                                                ? SELECT_FILE_16
                                                : snapshot.data.path
                                                            .split('/')
                                                            .last
                                                            .toString()
                                                            .length >
                                                        15
                                                    ? snapshot.data.path
                                                        .split('/')
                                                        .last
                                                        .toString()
                                                        .substring(0, 15)
                                                    : snapshot.data.path
                                                        .split('/')
                                                        .last
                                                        .toString(),
                                            style: Theme.of(context)
                                                .textTheme
                                                .headline6
                                                .copyWith(color: Colors.blue),
                                          );
                                        }),
                                  ),
                                  icon:
                                      Icon(Icons.file_copy, color: Colors.blue),
                                ),
                              ),
                              StreamBuilder<bool>(
                                  stream: model.validateButton,
                                  builder: (context, snapshot) {
                                    return BusyButton(
                                      height: 30,
                                      iconImage: Icons.arrow_forward_rounded,
                                      busy: model.loading,
                                      onPressed: snapshot.hasData
                                          ? () {
                                              model.uploadForm16();
                                            }
                                          : null,
                                    );
                                  }),
                            ],
                          ),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                    hint: NAME_OF_EMPLOYER,
                                    label: NAME_OF_EMPLOYER,
                                    numberAllowed: <TextInputFormatter>[
                                      FilteringTextInputFormatter.allow(
                                          RegExp(r'[A-Z,a-z, ,]')),
                                    ],
                                    controller: TextEditingController()
                                      ..text =
                                          model.employerNameController.value,
                                    textCapitalization:
                                        TextCapitalization.words,
                                    keyBoardType: TextInputType.name,
                                    onChanged: (value) {
                                      if (value.isEmpty) {
                                        model.onEmployerNameChange("");
                                        model.calculateSalary();
                                      } else {
                                        model.onEmployerNameChange(value);
                                        model.calculateSalary();
                                      }
                                    });
                              }),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: "TAN of Deducter",
                                  label: "TAN of Deducter",
                                  numberAllowed: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[A-Z,0-9]')),
                                  ],
                                  controller: TextEditingController()
                                    ..text = model
                                        .employerTanDeducterController.value,
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEmployerTanDeducterChange("");
                                      model.calculateSalary();
                                    } else {
                                      model.onEmployerTanDeducterChange(value);
                                      model.calculateSalary();
                                    }
                                  },
                                  keyBoardType: TextInputType.name,
                                  textCapitalization:
                                      TextCapitalization.characters,
                                );
                              }),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: "PAN of Deducter",
                                  label: "PAN of Deducter",
                                  numberAllowed: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[A-Z,0-9]')),
                                  ],
                                  controller: TextEditingController()
                                    ..text = model
                                        .employerPanDeducterController.value,
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEmployerPanDeducterChange("");
                                      model.calculateSalary();
                                    } else {
                                      model.onEmployerPanDeducterChange(value);
                                      model.calculateSalary();
                                    }
                                  },
                                  keyBoardType: TextInputType.name,
                                  textCapitalization:
                                      TextCapitalization.characters,
                                );
                              }),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: DropdownButtonFormField(
                              isExpanded: true,
                              value: model.employerTypeController.value,
                              items: [
                                'Central Govt',
                                'State Govt',
                                'PSU',
                                'Other',
                                'Pensioner',
                                'Not Applicable'
                              ].map((value) {
                                return new DropdownMenuItem<String>(
                                  value: value,
                                  child: new Text(value,
                                      overflow: TextOverflow.ellipsis),
                                );
                              }).toList(),
                              hint: Text("Please choose a  Employer Category"),
                              onChanged: (value) {
                                selectedEmployerCategory = value;
                                setState(() {});
                                model.onEmployerTypeChange(
                                    selectedEmployerCategory);
                                model.calculateSalary();
                              },
                            ),
                          ),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: BASIC,
                                  label: BASIC,
                                  controller: TextEditingController()
                                    ..text = model.employerBasicController
                                                .value !=
                                            null
                                        ? model.employerBasicController.value
                                            .toString()
                                        : BASIC,
                                  numberAllowed: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[0-9]')),
                                  ],
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEmployerBasicChange(0);
                                      model.calculateSalary();
                                    } else {
                                      model.onEmployerBasicChange(value);
                                      model.calculateSalary();
                                    }
                                  },
                                  //  c
                                );
                              }),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: HRA,
                                  label: HRA,
                                  numberAllowed: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[0-9]')),
                                  ],
                                  controller: TextEditingController()
                                    ..text =
                                        model.employerHRAController.value !=
                                                null
                                            ? model.employerHRAController.value
                                                .toString()
                                            : HRA,
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEmployerHRAChange(0);
                                      model.calculateSalary();
                                    } else {
                                      model.onEmployerHRAChange(value);
                                      model.calculateSalary();
                                    }
                                  },
                                );
                              }),
                          GradientContainerWidget(
                              title: SALARY_PER_17,
                              model: model.employerSalaryBy17),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                    hint: LEAVE_TRAVEL_ALLOWANCE,
                                    label: LEAVE_TRAVEL_ALLOWANCE,
                                    numberAllowed: <TextInputFormatter>[
                                      FilteringTextInputFormatter.allow(
                                          RegExp(r'[0-9]')),
                                    ],
                                    controller: TextEditingController()
                                      ..text = model.employerLATAController
                                                  .value !=
                                              null
                                          ? model.employerLATAController.value
                                              .toString()
                                          : LEAVE_TRAVEL_ALLOWANCE,
                                    onChanged: (value) {
                                      if (value.isEmpty) {
                                        model.onEmployerLATAChange(0);
                                        model.calculateSalary();
                                      } else {
                                        model.onEmployerLATAChange(value);
                                        model.calculateSalary();
                                      }
                                    });
                              }),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: ALLOWANCE_PERQUISITES,
                                  label: ALLOWANCE_PERQUISITES,
                                  numberAllowed: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[0-9]')),
                                  ],
                                  controller: TextEditingController()
                                    ..text = model
                                                .employerAllowancePerquisitesController
                                                .value !=
                                            null
                                        ? model
                                            .employerAllowancePerquisitesController
                                            .value
                                            .toString()
                                        : ALLOWANCE_PERQUISITES,
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEmployerAllowancePerquisites(0);
                                      model.calculateSalary();
                                    } else {
                                      model.onEmployerAllowancePerquisites(
                                          value);
                                      model.calculateSalary();
                                    }
                                  },
                                );
                              }),
                          ..._getdynamicOther(model, setState),
                          FloatingActionButton(
                              mini: true,
                              child: Icon(Icons.add),
                              onPressed: () {
                                setState(() {
                                  model.employerOtherController.value.insert(
                                      model
                                          .employerOtherController.value.length,
                                      0);
                                  model.employerOtherStringController.value
                                      .insert(
                                          model.employerOtherStringController
                                              .value.length,
                                          null);
                                  // model.calculateOther(otherList);
                                  model.calculateSalary();
                                });
                              }),
                          ..._getdynamicPerquisites(model, setState),
                          FloatingActionButton(
                              mini: true,
                              child: Icon(Icons.add),
                              onPressed: () {
                                setState(() {
                                  model.employerPerquistesController.value
                                      .insert(
                                          model.employerPerquistesController
                                              .value.length,
                                          0);
                                  model
                                      .employerValueOfPerquisitesStringController
                                      .value
                                      .insert(
                                          model
                                              .employerValueOfPerquisitesStringController
                                              .value
                                              .length,
                                          null);
                                  // model.calculatePerquisites(perquisitesList);
                                  model.calculateSalary();
                                });
                              }),
                          ..._getdynamicLieu(model, setState),
                          FloatingActionButton(
                              mini: true,
                              child: Icon(Icons.add),
                              onPressed: () {
                                setState(() {
                                  model.employerProfitInLieuController.value
                                      .insert(
                                          model.employerProfitInLieuController
                                              .value.length,
                                          0);
                                  model.employeLieuStringController.value
                                      .insert(
                                          model.employeLieuStringController
                                              .value.length,
                                          null);
                                  // model.calculateLieu(lieuList);
                                  model.calculateSalary();
                                });
                              }),
                          ..._getdynamicExempt(model, setState),
                          FloatingActionButton(
                              mini: true,
                              child: Icon(Icons.add),
                              onPressed: () {
                                setState(() {
                                  model.employerExemptAllowancesController.value
                                      .insert(
                                          model
                                              .employerExemptAllowancesController
                                              .value
                                              .length,
                                          0);
                                  model.employeExemptAllwnStringController.value
                                      .insert(
                                          model
                                              .employeExemptAllwnStringController
                                              .value
                                              .length,
                                          0);
                                  model
                                      .employerExemptAllowancesDescriptionController
                                      .value
                                      .insert(
                                          model
                                              .employerExemptAllowancesDescriptionController
                                              .value
                                              .length,
                                          "");
                                  model.isAnyOtherController.value.insert(
                                      model.isAnyOtherController.value.length,
                                      false);
                                  // model.calculateExempt(exemptList);
                                  model.calculateSalary();
                                });
                              }),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8.0,
                              vertical: 5,
                            ),
                            child: Card(
                              elevation: 5,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(20),
                                ),
                              ),
                              child: Container(
                                height: screenHeight(context) * 0.10,
                                width: screenWidth(context),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topRight,
                                      end: Alignment.bottomLeft,
                                      colors: <Color>[
                                        AppColors.mydocumentBG_COLOR,
                                        AppColors.mydocumentBG_COLOR2
                                      ]),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(20),
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: ListTile(
                                  leading: Text(
                                    BALANCE,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6
                                        .copyWith(
                                          color: Colors.white,
                                          fontFamily: 'D-DIN',
                                        ),
                                  ),
                                  trailing: StreamBuilder<String>(
                                      stream: model.employerBalance,
                                      builder: (context, snapshot) {
                                        return Text(
                                          snapshot.data ?? "",
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline6
                                              .copyWith(
                                                color: Colors.white,
                                                fontFamily: 'D-DIN',
                                              ),
                                        );
                                      }),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8.0,
                              vertical: 5,
                            ),
                            child: Card(
                              elevation: 5,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(20),
                                ),
                              ),
                              child: Container(
                                height: screenHeight(context) * 0.10,
                                width: screenWidth(context),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      begin: Alignment.topRight,
                                      end: Alignment.bottomLeft,
                                      colors: <Color>[
                                        AppColors.mydocumentBG_COLOR,
                                        AppColors.mydocumentBG_COLOR2
                                      ]),
                                  borderRadius: BorderRadius.all(
                                    Radius.circular(20),
                                  ),
                                ),
                                alignment: Alignment.center,
                                child: ListTile(
                                  leading: Text(
                                    STD_DEDUCTION,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6
                                        .copyWith(
                                          color: Colors.white,
                                          fontFamily: 'D-DIN',
                                        ),
                                  ),
                                  trailing: StreamBuilder<String>(
                                      stream: model.employerStdDeduction,
                                      builder: (context, snapshot) {
                                        return Text(
                                          snapshot.data ?? "",
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline6
                                              .copyWith(
                                                color: Colors.white,
                                                fontFamily: 'D-DIN',
                                              ),
                                        );
                                      }),
                                ),
                              ),
                            ),
                          ),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: PROFESSION_TAX,
                                  label: PROFESSION_TAX,
                                  controller: TextEditingController()
                                    ..text = model.employerProfTaxController
                                                .value !=
                                            null
                                        ? model.employerProfTaxController.value
                                            .toString()
                                        : PROFESSION_TAX,
                                  numberAllowed: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[0-9]')),
                                  ],
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEmployerProfTaxChange(0);
                                      model.calculateSalary();
                                    } else {
                                      if (model.selectedYearController.value ==
                                              "2021-2022" &&
                                          model.taxMethodController.value ==
                                              "R") {
                                        model.onEmployerProfTaxChange(0);
                                        model.calculateSalary();
                                      } else {
                                        model.onEmployerProfTaxChange(value);
                                        model.calculateSalary();
                                      }
                                    }
                                  },
                                );
                              }),
                          StreamBuilder<Form16Model>(
                              stream: model.form16Data,
                              builder: (context, snapshot) {
                                return buildTextField(
                                  hint: ENTERTAINMENT,
                                  label: ENTERTAINMENT,
                                  controller: TextEditingController()
                                    ..text = model
                                                .employerEntertainementController
                                                .value !=
                                            null
                                        ? model.employerEntertainementController
                                            .value
                                            .toString()
                                        : ENTERTAINMENT,
                                  numberAllowed: <TextInputFormatter>[
                                    FilteringTextInputFormatter.allow(
                                        RegExp(r'[0-9]')),
                                  ],
                                  onChanged: (value) {
                                    if (value.isEmpty) {
                                      model.onEntertainmentChanged("0");
                                      model.calculateSalary();
                                    } else {
                                      if (model.selectedYearController.value ==
                                              "2021-2022" &&
                                          model.taxMethodController.value ==
                                              "R") {
                                        model.onEntertainmentChanged("0");
                                        model.calculateSalary();
                                      } else {
                                        model.onEntertainmentChanged(value);
                                        model.calculateSalary();
                                      }
                                    }
                                  },
                                );
                              }),
                        ],
                      ))),
            ),
          ),
        );
      });
    },
  );
}
