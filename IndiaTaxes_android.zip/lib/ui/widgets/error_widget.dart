import 'package:flutter/material.dart';
import 'package:taxbase_general/constants/extensions/string_extension.dart';
import 'package:taxbase_general/helpers/ui_helper.dart';
import 'package:taxbase_general/ui/widgets/busy_button_widget.dart';

class ErrorPopupView extends StatelessWidget {
  final String title;
  final String message;
  final String buttonLabel;
  final String icon;
  final VoidCallback onButtonClick;
  final Color backgroundColor;
  final bool showButton;

  const ErrorPopupView(
      {Key key,
      this.title = "assets/images/oops.png",
      this.message,
      this.buttonLabel,
      this.icon = "assets/images/no_connection.png",
      this.onButtonClick,
      this.backgroundColor = Colors.transparent,
      this.showButton = true})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Container(
//          elevation: 3,
//          shape: RoundedRectangleBorder(
//            borderRadius: new BorderRadius.circular(15.0)
//          ),
          child: Container(
            width: screenWidth(context),
            height: screenHeight(context),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Container(
                  height: screenHeight(context) * 0.19,
                  child: Image.asset(
                    icon,
                  ),
                ),
                verticalSpace(16.0),
                Container(
                  height: screenHeight(context) * 0.06,
                  child: Image.asset(
                    title,
                  ),
                ),
                verticalSpace(16.0),
                if (message.isNotNullOrEmpty) verticalSpace(8.0),
                if (message.isNotNullOrEmpty)
                  Container(
                    width: screenWidth(context),
                    child: Text(
                      "${message}",
                      textAlign: TextAlign.center,
                      style: errorMessageStyle,
                    ),
                  ),
                verticalSpace(16.0),
                if (showButton)
                  BusyButton(
                    title: buttonLabel,
                    onPressed: onButtonClick,
                    busy: false,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
