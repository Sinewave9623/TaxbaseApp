class UpdateUserDetailsModel {
  String responseCode;
  String msg;

  UpdateUserDetailsModel({this.responseCode, this.msg});

  UpdateUserDetailsModel.withError({String msg, String responseCode}) {
    this.msg = msg;
    this.responseCode = responseCode;
  }

  UpdateUserDetailsModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    return data;
  }
}
