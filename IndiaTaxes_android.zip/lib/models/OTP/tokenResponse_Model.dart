class TokenResponse {
  String refresh;
  String access;

  TokenResponse({this.refresh, this.access});


        TokenResponse.withError({String msg, String responseCode}) {
    this.refresh = msg;
    this.access = responseCode;
  }
  

  TokenResponse.fromJson(Map<String, dynamic> json) {
    refresh = json['refresh'];
    access = json['access'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['refresh'] = this.refresh;
    data['access'] = this.access;
    return data;
  }
}
