class VerifyResponseOtpModel {
  String result;
  String timelapse;
  String name;
  String pan;
  String address;
  String age;
  String responseCode;

  VerifyResponseOtpModel(
      {this.result,
      this.timelapse,
      this.name,
      this.pan,
      this.address,
      this.age,
      this.responseCode});

  VerifyResponseOtpModel.withError({String result, String responseCode}) {
    this.result = result;
    this.responseCode = responseCode;
  }

  VerifyResponseOtpModel.fromJson(Map<String, dynamic> json) {
    result = json['result'];
    timelapse = json['timelapse'];
    name = json['name'];
    pan = json['pan'];
    address = json['address'];
    age = json['age'];
    responseCode = json['response_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['result'] = this.result;
    data['timelapse'] = this.timelapse;
    data['name'] = this.name;
    data['pan'] = this.pan;
    data['address'] = this.address;
    data['age'] = this.age;
    data['response_code'] = this.responseCode;
    return data;
  }
}
