class GetOtpResponseModel {
  String msg;
  String otpNumber;
  dynamic transactionId;
  String access;
  String responseCode;

  GetOtpResponseModel(
      {this.msg,
      this.otpNumber,
      this.transactionId,
      this.access,
      this.responseCode});

  GetOtpResponseModel.withError({String msg, String responseCode}) {
    this.msg = msg;
    this.responseCode = responseCode;
  }

  GetOtpResponseModel.fromJson(Map<String, dynamic> json) {
    msg = json['msg'];
    otpNumber = json['otpNumber'];
    transactionId = json['transaction_id'];
    access = json['access'];
    responseCode = json['response_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['msg'] = this.msg;
    data['otpNumber'] = this.otpNumber;
    data['transaction_id'] = this.transactionId;
    data['access'] = this.access;
    data['response_code'] = this.responseCode;
    return data;
  }
}
