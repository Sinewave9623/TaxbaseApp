class ReminderTypeResponseModel {
  String responseCode;
  String msg;
  List<ReminderTypeData> data;

  ReminderTypeResponseModel({this.responseCode, this.msg, this.data});

  ReminderTypeResponseModel.withError({String msg, String responseCode}) {
    this.msg = msg;
    this.responseCode = responseCode;
  }

  ReminderTypeResponseModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
    if (json['data'] != null) {
      data = new List<ReminderTypeData>();
      json['data'].forEach((v) {
        data.add(new ReminderTypeData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ReminderTypeData {
  int id;
  String uId;
  String reminderType;

  ReminderTypeData({this.id, this.uId, this.reminderType});

  ReminderTypeData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    reminderType = json['reminder_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['reminder_type'] = this.reminderType;
    return data;
  }
}
