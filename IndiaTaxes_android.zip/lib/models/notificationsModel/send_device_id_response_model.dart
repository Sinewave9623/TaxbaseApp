class SendDeviceResponseModel {
  String responseCode;
  String msg;
  String data;

  SendDeviceResponseModel({this.responseCode, this.msg, this.data});

  SendDeviceResponseModel.withError({String msg, String responseCode}) {
    this.msg = msg;
    this.responseCode = responseCode;
  }

  SendDeviceResponseModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
    data = json['data'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    data['data'] = this.data;
    return data;
  }
}
