class GstinResponseModel {
  String responseCode;
  List<GSTINData> data;

  GstinResponseModel({this.responseCode, this.data});

  GstinResponseModel.withError({ String responseCode}) {
    this.responseCode = responseCode;
  }

  GstinResponseModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    if (json['data'] != null) {
      data = new List<GSTINData>();
      json['data'].forEach((v) {
        data.add(new GSTINData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class GSTINData {
  int id;
  String uId;
  String gstin;
  String mobileno;

  GSTINData({this.id, this.uId, this.gstin, this.mobileno});

  GSTINData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    gstin = json['gstin'];
    mobileno = json['mobileno'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['gstin'] = this.gstin;
    data['mobileno'] = this.mobileno;
    return data;
  }
}
