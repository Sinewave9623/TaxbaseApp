class CreateGSTINResponseModel {
  String responseCode;
  String msg;

  CreateGSTINResponseModel({this.responseCode, this.msg});

  CreateGSTINResponseModel.withError({String msg, String responseCode}) {
    this.msg = msg;
    this.responseCode = responseCode;
  }

  CreateGSTINResponseModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    return data;
  }
}
