class AllReturnsModel {
  dynamic gstin;
  dynamic retPeriod;
  dynamic type;
  List<Efiledlist> efiledlist;

  AllReturnsModel({this.gstin, this.retPeriod, this.type, this.efiledlist});

  AllReturnsModel.fromJson(Map<String, dynamic> json) {
    gstin = json['gstin'];
    retPeriod = json['ret_period'];
    type = json['type'];
    if (json['Efiledlist'] != null) {
      efiledlist = new List<Efiledlist>();
      json['Efiledlist'].forEach((v) {
        efiledlist.add(new Efiledlist.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['gstin'] = this.gstin;
    data['ret_period'] = this.retPeriod;
    data['type'] = this.type;
    if (this.efiledlist != null) {
      data['Efiledlist'] = this.efiledlist.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Efiledlist {
  String arn;
  String retPrd;
  String mof;
  String dof;
  String rtntype;
  String status;
  String valid;

  Efiledlist(
      {this.arn,
      this.retPrd,
      this.mof,
      this.dof,
      this.rtntype,
      this.status,
      this.valid});

  Efiledlist.fromJson(Map<String, dynamic> json) {
    arn = json['arn'];
    retPrd = json['ret_prd'];
    mof = json['mof'];
    dof = json['dof'];
    rtntype = json['rtntype'];
    status = json['status'];
    valid = json['valid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['arn'] = this.arn;
    data['ret_prd'] = this.retPrd;
    data['mof'] = this.mof;
    data['dof'] = this.dof;
    data['rtntype'] = this.rtntype;
    data['status'] = this.status;
    data['valid'] = this.valid;
    return data;
  }
}
