class ReturnsModel {
  String responseCode;
  String msg;
  List<GSTdata> gSTdata;
  List<ITRdata> iTRdata;
  List<TDSdata> tDSdata;

  ReturnsModel(
      {this.responseCode, this.msg, this.gSTdata, this.iTRdata, this.tDSdata});

  ReturnsModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
    if (json['GSTdata'] != null) {
      gSTdata = new List<GSTdata>();
      json['GSTdata'].forEach((v) {
        gSTdata.add(new GSTdata.fromJson(v));
      });
    }
    if (json['ITRdata'] != null) {
      iTRdata = new List<ITRdata>();
      json['ITRdata'].forEach((v) {
        iTRdata.add(new ITRdata.fromJson(v));
      });
    }
    if (json['TDSdata'] != null) {
      tDSdata = new List<TDSdata>();
      json['TDSdata'].forEach((v) {
        tDSdata.add(new TDSdata.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    if (this.gSTdata != null) {
      data['GSTdata'] = this.gSTdata.map((v) => v.toJson()).toList();
    }
    if (this.iTRdata != null) {
      data['ITRdata'] = this.iTRdata.map((v) => v.toJson()).toList();
    }
    if (this.tDSdata != null) {
      data['TDSdata'] = this.tDSdata.map((v) => v.toJson()).toList();
    }
    return data;
  }

  ReturnsModel.withError({String msg, String responseCode}) {
    this.msg = msg;
    this.responseCode = responseCode;
  }
}

class FileUrl {
  String filename;
  String fileurl;

  FileUrl({this.filename, this.fileurl});

  FileUrl.fromJson(Map<String, dynamic> json) {
    filename = json['filename'];
    fileurl = json['fileurl'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['filename'] = this.filename;
    data['fileurl'] = this.fileurl;
    return data;
  }
}

class GSTdata {
  int id;
  String uId;
  String fy;
  String taxPeriod;
  String returnType;
  String dateOfFiling;
  String filingStatus;
  String aRN;
  String customer;
  String file;
  String month;
  List<FileUrl> fileUrls;

  GSTdata(
      {this.id,
      this.uId,
      this.fy,
      this.taxPeriod,
      this.returnType,
      this.dateOfFiling,
      this.filingStatus,
      this.aRN,
      this.customer,
      this.file,
      this.month,
      this.fileUrls});

  GSTdata.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    fy = json['fy'];
    taxPeriod = json['taxPeriod'];
    returnType = json['returnType'];
    dateOfFiling = json['dateOfFiling'];
    filingStatus = json['filingStatus'];
    aRN = json['ARN'];
    customer = json['customer'];
    month = json['month'];
    file = json['file'];
    if (json['file_url'] != null) {
      fileUrls = new List<FileUrl>();
      json['file_url'].forEach((v) {
        fileUrls.add(new FileUrl.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['fy'] = this.fy;
    data['taxPeriod'] = this.taxPeriod;
    data['returnType'] = this.returnType;
    data['dateOfFiling'] = this.dateOfFiling;
    data['filingStatus'] = this.filingStatus;
    data['ARN'] = this.aRN;
    data['month'] = this.month;
    data['customer'] = this.customer;
    data['file'] = this.file;
    if (this.fileUrls != null) {
      data['file_url'] = this.fileUrls.map((v) => v.toJson()).toList();
    }
    return data;
  }

  String getIndex(int col, int index) {
    switch (col) {
      case 0:
        return (index + 1).toString();
      case 1:
        return id.toString();
      case 2:
        return uId;
      case 3:
        return fy.toString();
      case 4:
        return taxPeriod.toString();
      case 5:
        return month.toString();  
      case 6:
        return returnType.toString();
      case 7:
        return dateOfFiling.toString();
      case 8:
        return filingStatus.toString();
      case 9:
        return aRN.toString();
    }
    return '';
  }
}

class ITRdata {
  int id;
  String uId;
  String itrForm;
  String filingType;
  String dateOfFiling;
  String filingStatus;
  String ackNo;
  String customer;
  String file;
  String ay;
  List<FileUrl> fileUrl;

  ITRdata(
      {this.id,
      this.uId,
      this.itrForm,
      this.filingType,
      this.dateOfFiling,
      this.filingStatus,
      this.ackNo,
      this.customer,
       this.file,
       this.ay,
      this.fileUrl
      });

  ITRdata.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    itrForm = json['itrForm'];
    filingType = json['filingType'];
    dateOfFiling = json['dateOfFiling'];
    filingStatus = json['filingStatus'];
    ackNo = json['ackNo'];
    customer = json['customer'];
    ay = json['ay'];
     file = json['file'];
    if (json['file_url'] != null) {
      fileUrl = new List<FileUrl>();
      json['file_url'].forEach((v) {
        fileUrl.add(new FileUrl.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['itrForm'] = this.itrForm;
    data['filingType'] = this.filingType;
    data['dateOfFiling'] = this.dateOfFiling;
    data['filingStatus'] = this.filingStatus;
    data['ackNo'] = this.ackNo;
    data['customer'] = this.customer;
    data['ay'] = this.ay;
    data['file'] = this.file;
    if (this.fileUrl != null) {
      data['file_url'] = this.fileUrl.map((v) => v.toJson()).toList();
    }
    return data;
  }

  String getIndex(int col, int index) {
    switch (col) {
      case 0:
        return (index + 1).toString();
      case 1:
        return ay ?? "-";  
      case 2:
        return id.toString();
      case 3:
        return uId;
      case 4:
        return itrForm.toString();
      case 5:
        return filingType.toString();
      case 6:
        return dateOfFiling.toString();
      case 7:
        return filingStatus.toString();
      case 8:
        return ackNo.toString();
    }
    return '';
  }
}

class TDSdata {
  int id;
  String uId;
  String fy;
  String returnType;
  String formType;
  String quarter;
  String dateOfFiling;
  String tokenNo;
  String ackNo;
  String defaultAmtPayable;
  String status;
  String customer;
String file;
  List<FileUrl> fileUrl;
  TDSdata(
      {this.id,
      this.uId,
      this.fy,
      this.returnType,
      this.formType,
      this.quarter,
      this.dateOfFiling,
      this.tokenNo,
      this.ackNo,
      this.defaultAmtPayable,
      this.status,
      this.customer,
        this.file,
      this.fileUrl
      });

  TDSdata.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    fy = json['fy'];
    returnType = json['returnType'];
    formType = json['formType'];
    quarter = json['quarter'];
    dateOfFiling = json['dateOfFiling'];
    tokenNo = json['tokenNo'];
    ackNo = json['ackNo'];
    defaultAmtPayable = json['defaultAmtPayable'];
    status = json['status'];
    customer = json['customer'];
    file = json['file'];
    if (json['file_url'] != null) {
      fileUrl = new List<FileUrl>();
      json['file_url'].forEach((v) {
        fileUrl.add(new FileUrl.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['fy'] = this.fy;
    data['returnType'] = this.returnType;
    data['formType'] = this.formType;
    data['quarter'] = this.quarter;
    data['dateOfFiling'] = this.dateOfFiling;
    data['tokenNo'] = this.tokenNo;
    data['ackNo'] = this.ackNo;
    data['defaultAmtPayable'] = this.defaultAmtPayable;
    data['status'] = this.status;
    data['customer'] = this.customer;
      data['file'] = this.file;
    if (this.fileUrl != null) {
      data['file_url'] = this.fileUrl.map((v) => v.toJson()).toList();
    }
    return data;
  }

  String getIndex(int col, int index) {
    switch (col) {
      case 0:
        return (index + 1).toString();
      case 1:
        return id.toString();
      case 2:
        return uId;
      case 3:
        return fy.toString();
      case 4:
        return returnType.toString();
      case 5:
        return formType.toString();
      case 6:
        return quarter.toString();
      case 7:
        return dateOfFiling.toString();
      case 8:
        return tokenNo.toString();
      case 9:
        return ackNo.toString();
      case 10:
        return defaultAmtPayable.toString();
      case 11:
        return status.toString();
    }
    return '';
  }
}
