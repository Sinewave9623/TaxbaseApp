class SaveReturnsModel {
  dynamic gstin;
  dynamic year;
  List<SaveReturnData> efiledlist;

  SaveReturnsModel({this.gstin, this.year, this.efiledlist});

  SaveReturnsModel.fromJson(Map<String, dynamic> json) {
    gstin = json['gstin'];
    year = json['year'];
    
    if (json['data'] != null) {
      efiledlist = new List<SaveReturnData>();
      json['data'].forEach((v) {
        efiledlist.add(new SaveReturnData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['gstin'] = this.gstin;
    data['year'] = this.year;
    
    if (this.efiledlist != null) {
      data['data'] = this.efiledlist.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SaveReturnData {
  String arn;
  String retPrd;
  String mof;
  String dof;
  String rtntype;
  String status;
  String valid;

  SaveReturnData(
      {this.arn,
      this.retPrd,
      this.mof,
      this.dof,
      this.rtntype,
      this.status,
      this.valid});

  SaveReturnData.fromJson(Map<String, dynamic> json) {
    arn = json['arn'];
    retPrd = json['ret_prd'];
    mof = json['mof'];
    dof = json['dof'];
    rtntype = json['rtntype'];
    status = json['status'];
    valid = json['valid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['arn'] = this.arn;
    data['ret_prd'] = this.retPrd;
    data['mof'] = this.mof;
    data['dof'] = this.dof;
    data['rtntype'] = this.rtntype;
    data['status'] = this.status;
    data['valid'] = this.valid;
    return data;
  }
}
