class ReadGstinDataModel {
  String responseCode;
  List<ReadGstData> readGstData;

  ReadGstinDataModel({this.responseCode, this.readGstData});

  ReadGstinDataModel.withError({String responseCode}) {
    this.responseCode = responseCode;
  }

  ReadGstinDataModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    if (json['data'] != null) {
      readGstData = new List<ReadGstData>();
      json['data'].forEach((v) {
        readGstData.add(new ReadGstData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    if (this.readGstData != null) {
      data['data'] = this.readGstData.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ReadGstData {
  int id;
  String uId;
  String year;
  List<Gstdata> gstdata;
  String leadsGstin;

  ReadGstData({this.id, this.uId, this.year, this.gstdata, this.leadsGstin});

  ReadGstData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    year = json['year'];
    if (json['data'] != null) {
      gstdata = new List<Gstdata>();
      json['data'].forEach((v) {
        gstdata.add(new Gstdata.fromJson(v));
      });
    }
    leadsGstin = json['leadsGstin'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['year'] = this.year;
    if (this.gstdata != null) {
      data['data'] = this.gstdata.map((v) => v.toJson()).toList();
    }
    data['leadsGstin'] = this.leadsGstin;
    return data;
  }
}

class Gstdata {
  String arn;
  String dof;
  String mof;
  dynamic valid;
  String status;
  String retPrd;
  String rtntype;

  Gstdata(
      {this.arn,
      this.dof,
      this.mof,
      this.valid,
      this.status,
      this.retPrd,
      this.rtntype});

  Gstdata.fromJson(Map<String, dynamic> json) {
    arn = json['arn'];
    dof = json['dof'];
    mof = json['mof'];
    valid = json['valid'];
    status = json['status'];
    retPrd = json['ret_prd'];
    rtntype = json['rtntype'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['arn'] = this.arn;
    data['dof'] = this.dof;
    data['mof'] = this.mof;
    data['valid'] = this.valid;
    data['status'] = this.status;
    data['ret_prd'] = this.retPrd;
    data['rtntype'] = this.rtntype;
    return data;
  }
}
