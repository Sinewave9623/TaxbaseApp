class ViewTrackReturnsModel {
  dynamic isAuth;
  String message;
  String statusCd;

  ViewTrackReturnsModel({this.isAuth, this.message, this.statusCd});

  ViewTrackReturnsModel.fromJson(Map<String, dynamic> json) {
    isAuth = json['is_Auth'];
    message = json['message'];
    statusCd = json['status_cd'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['is_Auth'] = this.isAuth;
    data['message'] = this.message;
    data['status_cd'] = this.statusCd;
    return data;
  }
}
