class CreateReturnStatusModel {
  String responseCode;
  String msg;

  CreateReturnStatusModel({this.responseCode, this.msg});

  CreateReturnStatusModel.withError({String responseCode, String msg}) {
    this.responseCode = responseCode;
    this.msg = msg;
  }

  CreateReturnStatusModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    return data;
  }
}
