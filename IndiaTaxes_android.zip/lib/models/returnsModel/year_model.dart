class YearModel {
  String responseCode;
  String msg;
  List<Year> year;

  YearModel({this.responseCode, this.msg, this.year});

  YearModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
    if (json['Year'] != null) {
      year = new List<Year>();
      json['Year'].forEach((v) {
        year.add(new Year.fromJson(v));
      });
    }
  }
    YearModel.withError({String msg, String responseCode}){
     this.msg = msg;
    this.responseCode = responseCode;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    if (this.year != null) {
      data['Year'] = this.year.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Year {
  int id;
  String uId;
  String year;

  Year({this.id, this.uId, this.year});

  Year.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    year = json['year'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['year'] = this.year;
    return data;
  }
}
