class DurationListModel {
  String responseCode;
  String msg;
  List<DurationList> data;

  DurationListModel({this.responseCode, this.msg, this.data});

  DurationListModel.withError({String msg, String responseCode}) {
    this.msg = msg;
    this.responseCode = responseCode;
  }
  DurationListModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    msg = json['msg'];
    if (json['data'] != null) {
      data = new List<DurationList>();
      json['data'].forEach((v) {
        data.add(new DurationList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['msg'] = this.msg;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class DurationList {
  int id;
  String uId;
  String frequencyType;

  DurationList({this.id, this.uId, this.frequencyType});

  DurationList.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    frequencyType = json['frequencyType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['frequencyType'] = this.frequencyType;
    return data;
  }
}
