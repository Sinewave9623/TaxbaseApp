class GenerateJsonModel {
  CreationInfo creationInfo;
  FormITR1 formITR1;
  PersonalInfo personalInfo;
  FilingStatus filingStatus;
  ITR1IncomeDeductions iTR1IncomeDeductions;
  Schedule80GGA schedule80GGA;
  ITR1TaxComputation iTR1TaxComputation;
  TaxPaid taxPaid;
  Refund refund;
  Schedule80G schedule80G;
  Schedule80D schedule80D;
  TDSonSalaries tDSonSalaries;
  TDSonOthThanSals tDSonOthThanSals;
  ScheduleTDS3Dtls scheduleTDS3Dtls;
  ScheduleTCS scheduleTCS;
  TaxPayments taxPayments;
  Verification verification;

  GenerateJsonModel(
      {this.creationInfo,
      this.formITR1,
      this.personalInfo,
      this.filingStatus,
      this.iTR1IncomeDeductions,
      this.schedule80GGA,
      this.iTR1TaxComputation,
      this.taxPaid,
      this.refund,
      this.schedule80G,
      this.schedule80D,
      this.tDSonSalaries,
      this.tDSonOthThanSals,
      this.scheduleTDS3Dtls,
      this.scheduleTCS,
      this.taxPayments,
      this.verification});

  GenerateJsonModel.fromJson(Map<String, dynamic> json) {
    creationInfo = json['CreationInfo'] != null
        ? new CreationInfo.fromJson(json['CreationInfo'])
        : null;
    formITR1 = json['Form_ITR1'] != null
        ? new FormITR1.fromJson(json['Form_ITR1'])
        : null;
    personalInfo = json['PersonalInfo'] != null
        ? new PersonalInfo.fromJson(json['PersonalInfo'])
        : null;
    filingStatus = json['FilingStatus'] != null
        ? new FilingStatus.fromJson(json['FilingStatus'])
        : null;
    iTR1IncomeDeductions = json['ITR1_IncomeDeductions'] != null
        ? new ITR1IncomeDeductions.fromJson(json['ITR1_IncomeDeductions'])
        : null;
    schedule80GGA = json['Schedule80GGA'] != null
        ? new Schedule80GGA.fromJson(json['Schedule80GGA'])
        : null;
    iTR1TaxComputation = json['ITR1_TaxComputation'] != null
        ? new ITR1TaxComputation.fromJson(json['ITR1_TaxComputation'])
        : null;
    taxPaid =
        json['TaxPaid'] != null ? new TaxPaid.fromJson(json['TaxPaid']) : null;
    refund =
        json['Refund'] != null ? new Refund.fromJson(json['Refund']) : null;
    schedule80G = json['Schedule80G'] != null
        ? new Schedule80G.fromJson(json['Schedule80G'])
        : null;
    schedule80D = json['Schedule80D'] != null
        ? new Schedule80D.fromJson(json['Schedule80D'])
        : null;
    tDSonSalaries = json['TDSonSalaries'] != null
        ? new TDSonSalaries.fromJson(json['TDSonSalaries'])
        : null;
    tDSonOthThanSals = json['TDSonOthThanSals'] != null
        ? new TDSonOthThanSals.fromJson(json['TDSonOthThanSals'])
        : null;
    scheduleTDS3Dtls = json['ScheduleTDS3Dtls'] != null
        ? new ScheduleTDS3Dtls.fromJson(json['ScheduleTDS3Dtls'])
        : null;
    scheduleTCS = json['ScheduleTCS'] != null
        ? new ScheduleTCS.fromJson(json['ScheduleTCS'])
        : null;
    taxPayments = json['TaxPayments'] != null
        ? new TaxPayments.fromJson(json['TaxPayments'])
        : null;
    verification = json['Verification'] != null
        ? new Verification.fromJson(json['Verification'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.creationInfo != null) {
      data['CreationInfo'] = this.creationInfo.toJson();
    }
    if (this.formITR1 != null) {
      data['Form_ITR1'] = this.formITR1.toJson();
    }
    if (this.personalInfo != null) {
      data['PersonalInfo'] = this.personalInfo.toJson();
    }
    if (this.filingStatus != null) {
      data['FilingStatus'] = this.filingStatus.toJson();
    }
    if (this.iTR1IncomeDeductions != null) {
      data['ITR1_IncomeDeductions'] = this.iTR1IncomeDeductions.toJson();
    }
    if (this.schedule80GGA != null) {
      data['Schedule80GGA'] = this.schedule80GGA.toJson();
    }
    if (this.iTR1TaxComputation != null) {
      data['ITR1_TaxComputation'] = this.iTR1TaxComputation.toJson();
    }
    if (this.taxPaid != null) {
      data['TaxPaid'] = this.taxPaid.toJson();
    }
    if (this.refund != null) {
      data['Refund'] = this.refund.toJson();
    }
    if (this.schedule80G != null) {
      data['Schedule80G'] = this.schedule80G.toJson();
    }
    if (this.schedule80D != null) {
      data['Schedule80D'] = this.schedule80D.toJson();
    }
    if (this.tDSonSalaries != null) {
      data['TDSonSalaries'] = this.tDSonSalaries.toJson();
    }
    if (this.tDSonOthThanSals != null) {
      data['TDSonOthThanSals'] = this.tDSonOthThanSals.toJson();
    }
    if (this.scheduleTDS3Dtls != null) {
      data['ScheduleTDS3Dtls'] = this.scheduleTDS3Dtls.toJson();
    }
    if (this.scheduleTCS != null) {
      data['ScheduleTCS'] = this.scheduleTCS.toJson();
    }
    if (this.taxPayments != null) {
      data['TaxPayments'] = this.taxPayments.toJson();
    }
    if (this.verification != null) {
      data['Verification'] = this.verification.toJson();
    }
    return data;
  }
}

class CreationInfo {
  String sWVersionNo;
  String sWCreatedBy;
  String jSONCreatedBy;
  String jSONCreationDate;
  String intermediaryCity;
  String digest;

  CreationInfo(
      {this.sWVersionNo,
      this.sWCreatedBy,
      this.jSONCreatedBy,
      this.jSONCreationDate,
      this.intermediaryCity,
      this.digest});

  CreationInfo.fromJson(Map<String, dynamic> json) {
    sWVersionNo = json['SWVersionNo'];
    sWCreatedBy = json['SWCreatedBy'];
    jSONCreatedBy = json['JSONCreatedBy'];
    jSONCreationDate = json['JSONCreationDate'];
    intermediaryCity = json['IntermediaryCity'];
    digest = json['Digest'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['SWVersionNo'] = this.sWVersionNo;
    data['SWCreatedBy'] = this.sWCreatedBy;
    data['JSONCreatedBy'] = this.jSONCreatedBy;
    data['JSONCreationDate'] = this.jSONCreationDate;
    data['IntermediaryCity'] = this.intermediaryCity;
    data['Digest'] = this.digest;
    return data;
  }
}

class FormITR1 {
  String formName;
  String formVer;
  String schemaVer;
  String assessmentYear;
  String description;

  FormITR1(
      {this.formName,
      this.formVer,
      this.schemaVer,
      this.assessmentYear,
      this.description});

  FormITR1.fromJson(Map<String, dynamic> json) {
    formName = json['FormName'];
    formVer = json['FormVer'];
    schemaVer = json['SchemaVer'];
    assessmentYear = json['AssessmentYear'];
    description = json['Description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['FormName'] = this.formName;
    data['FormVer'] = this.formVer;
    data['SchemaVer'] = this.schemaVer;
    data['AssessmentYear'] = this.assessmentYear;
    data['Description'] = this.description;
    return data;
  }
}

class PersonalInfo {
  AssesseeName assesseeName;
  Address address;
  String pAN;
  String dOB;
  String aadhaarCardNo;
  String aadhaarEnrolmentId;
  String employerCategory;

  PersonalInfo(
      {this.assesseeName,
      this.address,
      this.pAN,
      this.dOB,
      this.aadhaarCardNo,
      this.aadhaarEnrolmentId,
      this.employerCategory});

  PersonalInfo.fromJson(Map<String, dynamic> json) {
    assesseeName = json['AssesseeName'] != null
        ? new AssesseeName.fromJson(json['AssesseeName'])
        : null;
    address =
        json['Address'] != null ? new Address.fromJson(json['Address']) : null;
    pAN = json['PAN'];
    dOB = json['DOB'];
    aadhaarCardNo = json['aadhaarCardNo'];
    aadhaarEnrolmentId = json['aadhaarEnrolmentId'];
    employerCategory = json['EmployerCategory'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.assesseeName != null) {
      data['AssesseeName'] = this.assesseeName.toJson();
    }
    if (this.address != null) {
      data['Address'] = this.address.toJson();
    }
    data['PAN'] = this.pAN;
    data['DOB'] = this.dOB;
    data['DOB'] = this.dOB;
    data['aadhaarCardNo'] = this.aadhaarCardNo;
    data['EmployerCategory'] = this.employerCategory;
    return data;
  }
}

class AssesseeName {
  String firstName;
  String middleName;
  String surNameOrOrgName;

  AssesseeName({this.firstName, this.middleName, this.surNameOrOrgName});

  AssesseeName.fromJson(Map<String, dynamic> json) {
    firstName = json['FirstName'];
    middleName = json['MiddleName'];
    surNameOrOrgName = json['SurNameOrOrgName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['FirstName'] = this.firstName;
    data['MiddleName'] = this.middleName;
    data['SurNameOrOrgName'] = this.surNameOrOrgName;
    return data;
  }
}

class Address {
  String residenceNo;
  String localityOrArea;
  String cityOrTownOrDistrict;
  String stateCode;
  String countryCode;
  int pinCode;
  int countryCodeMobile;
  int mobileNo;
  String emailAddress;

  Address(
      {this.residenceNo,
      this.localityOrArea,
      this.cityOrTownOrDistrict,
      this.stateCode,
      this.countryCode,
      this.pinCode,
      this.countryCodeMobile,
      this.mobileNo,
      this.emailAddress});

  Address.fromJson(Map<String, dynamic> json) {
    residenceNo = json['ResidenceNo'];
    localityOrArea = json['LocalityOrArea'];
    cityOrTownOrDistrict = json['CityOrTownOrDistrict'];
    stateCode = json['StateCode'];
    countryCode = json['CountryCode'];
    pinCode = json['PinCode'];
    countryCodeMobile = json['CountryCodeMobile'];
    mobileNo = json['MobileNo'];
    emailAddress = json['EmailAddress'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ResidenceNo'] = this.residenceNo;
    data['LocalityOrArea'] = this.localityOrArea;
    data['CityOrTownOrDistrict'] = this.cityOrTownOrDistrict;
    data['StateCode'] = this.stateCode;
    data['CountryCode'] = this.countryCode;
    data['PinCode'] = this.pinCode;
    data['CountryCodeMobile'] = this.countryCodeMobile;
    data['MobileNo'] = this.mobileNo;
    data['EmailAddress'] = this.emailAddress;
    return data;
  }
}

class FilingStatus {
  int returnFileSec;
  String newTaxRegime;
  String seventhProvisio139;

  FilingStatus(
      {this.returnFileSec, this.newTaxRegime, this.seventhProvisio139});

  FilingStatus.fromJson(Map<String, dynamic> json) {
    returnFileSec = json['ReturnFileSec'];
    newTaxRegime = json['NewTaxRegime'];
    seventhProvisio139 = json['SeventhProvisio139'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ReturnFileSec'] = this.returnFileSec;
    data['NewTaxRegime'] = this.newTaxRegime;
    data['SeventhProvisio139'] = this.seventhProvisio139;
    return data;
  }
}

class ITR1IncomeDeductions {
  AllwncExemptUs10 allwncExemptUs10;
  OthersInc othersInc;
  UsrDeductUndChapVIA usrDeductUndChapVIA;
  DeductUndChapVIA deductUndChapVIA;
  ExemptIncAgriOthUs10 exemptIncAgriOthUs10;
  int grossSalary;
  int salary;
  int netSalary;
  int deductionUs16;
  int deductionUs16ia;
  int entertainmentAlw16ii;
  int professionalTaxUs16iii;
  int incomeFromSal;
  int annualValue;
  int standardDeduction;
  int totalIncomeOfHP;
  int incomeOthSrc;
  int grossTotIncome;
  int totalIncome;

  ITR1IncomeDeductions(
      {this.allwncExemptUs10,
      this.othersInc,
      this.usrDeductUndChapVIA,
      this.deductUndChapVIA,
      this.exemptIncAgriOthUs10,
      this.grossSalary,
      this.salary,
      this.netSalary,
      this.deductionUs16,
      this.deductionUs16ia,
      this.entertainmentAlw16ii,
      this.professionalTaxUs16iii,
      this.incomeFromSal,
      this.annualValue,
      this.standardDeduction,
      this.totalIncomeOfHP,
      this.incomeOthSrc,
      this.grossTotIncome,
      this.totalIncome});

  ITR1IncomeDeductions.fromJson(Map<String, dynamic> json) {
    allwncExemptUs10 = json['AllwncExemptUs10'] != null
        ? new AllwncExemptUs10.fromJson(json['AllwncExemptUs10'])
        : null;
    othersInc = json['OthersInc'] != null
        ? new OthersInc.fromJson(json['OthersInc'])
        : null;
    usrDeductUndChapVIA = json['UsrDeductUndChapVIA'] != null
        ? new UsrDeductUndChapVIA.fromJson(json['UsrDeductUndChapVIA'])
        : null;
    deductUndChapVIA = json['DeductUndChapVIA'] != null
        ? new DeductUndChapVIA.fromJson(json['DeductUndChapVIA'])
        : null;
    exemptIncAgriOthUs10 = json['ExemptIncAgriOthUs10'] != null
        ? new ExemptIncAgriOthUs10.fromJson(json['ExemptIncAgriOthUs10'])
        : null;
    grossSalary = json['GrossSalary'];
    salary = json['Salary'];
    netSalary = json['NetSalary'];
    deductionUs16 = json['DeductionUs16'];
    deductionUs16ia = json['DeductionUs16ia'];
    entertainmentAlw16ii = json['EntertainmentAlw16ii'];
    professionalTaxUs16iii = json['ProfessionalTaxUs16iii'];
    incomeFromSal = json['IncomeFromSal'];
    annualValue = json['AnnualValue'];
    standardDeduction = json['StandardDeduction'];
    totalIncomeOfHP = json['TotalIncomeOfHP'];
    incomeOthSrc = json['IncomeOthSrc'];
    grossTotIncome = json['GrossTotIncome'];
    totalIncome = json['TotalIncome'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.allwncExemptUs10 != null) {
      data['AllwncExemptUs10'] = this.allwncExemptUs10.toJson();
    }
    if (this.othersInc != null) {
      data['OthersInc'] = this.othersInc.toJson();
    }
    if (this.usrDeductUndChapVIA != null) {
      data['UsrDeductUndChapVIA'] = this.usrDeductUndChapVIA.toJson();
    }
    if (this.deductUndChapVIA != null) {
      data['DeductUndChapVIA'] = this.deductUndChapVIA.toJson();
    }
    if (this.exemptIncAgriOthUs10 != null) {
      data['ExemptIncAgriOthUs10'] = this.exemptIncAgriOthUs10.toJson();
    }
    data['GrossSalary'] = this.grossSalary;
    data['Salary'] = this.salary;
    data['NetSalary'] = this.netSalary;
    data['DeductionUs16'] = this.deductionUs16;
    data['DeductionUs16ia'] = this.deductionUs16ia;
    data['EntertainmentAlw16ii'] = this.entertainmentAlw16ii;
    data['ProfessionalTaxUs16iii'] = this.professionalTaxUs16iii;
    data['IncomeFromSal'] = this.incomeFromSal;
    data['AnnualValue'] = this.annualValue;
    data['StandardDeduction'] = this.standardDeduction;
    data['TotalIncomeOfHP'] = this.totalIncomeOfHP;
    data['IncomeOthSrc'] = this.incomeOthSrc;
    data['GrossTotIncome'] = this.grossTotIncome;
    data['TotalIncome'] = this.totalIncome;
    return data;
  }
}

class AllwncExemptUs10 {
  List<AllwncExemptUs10Dtls> allwncExemptUs10Dtls;
  int totalAllwncExemptUs10;

  AllwncExemptUs10({this.allwncExemptUs10Dtls, this.totalAllwncExemptUs10});

  AllwncExemptUs10.fromJson(Map<String, dynamic> json) {
    if (json['AllwncExemptUs10Dtls'] != null) {
      allwncExemptUs10Dtls = new List<AllwncExemptUs10Dtls>();
      json['AllwncExemptUs10Dtls'].forEach((v) {
        allwncExemptUs10Dtls.add(new AllwncExemptUs10Dtls.fromJson(v));
      });
    }
    totalAllwncExemptUs10 = json['TotalAllwncExemptUs10'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.allwncExemptUs10Dtls != null) {
      data['AllwncExemptUs10Dtls'] =
          this.allwncExemptUs10Dtls.map((v) => v.toJson()).toList();
    }
    data['TotalAllwncExemptUs10'] = this.totalAllwncExemptUs10;
    return data;
  }
}

class AllwncExemptUs10Dtls {
  String salNatureDesc;
  int salOthAmount;

  AllwncExemptUs10Dtls({this.salNatureDesc, this.salOthAmount});

  AllwncExemptUs10Dtls.fromJson(Map<String, dynamic> json) {
    salNatureDesc = json['SalNatureDesc'];
    salOthAmount = json['SalOthAmount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['SalNatureDesc'] = this.salNatureDesc;
    data['SalOthAmount'] = this.salOthAmount;
    return data;
  }
}

class OthersInc {
  int totDividendInc;

  OthersInc({this.totDividendInc});

  OthersInc.fromJson(Map<String, dynamic> json) {
    totDividendInc = json['TotDividendInc'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotDividendInc'] = this.totDividendInc;
    return data;
  }
}

class UsrDeductUndChapVIA {
  int section80C;
  int section80CCC;
  int section80CCDEmployeeOrSE;
  int section80CCD1B;
  int section80CCDEmployer;
  int section80D;
  int section80DD;
  int section80DDB;
  int section80E;
  int section80EE;
  int section80G;
  int section80GG;
  int section80GGA;
  int section80GGC;
  int section80U;
  int section80TTA;
  int section80TTB;
  int totalChapVIADeductions;

  UsrDeductUndChapVIA(
      {this.section80C,
      this.section80CCC,
      this.section80CCDEmployeeOrSE,
      this.section80CCD1B,
      this.section80CCDEmployer,
      this.section80D,
      this.section80DD,
      this.section80DDB,
      this.section80E,
      this.section80EE,
      this.section80G,
      this.section80GG,
      this.section80GGA,
      this.section80GGC,
      this.section80U,
      this.section80TTA,
      this.section80TTB,
      this.totalChapVIADeductions});

  UsrDeductUndChapVIA.fromJson(Map<String, dynamic> json) {
    section80C = json['Section80C'];
    section80CCC = json['Section80CCC'];
    section80CCDEmployeeOrSE = json['Section80CCDEmployeeOrSE'];
    section80CCD1B = json['Section80CCD1B'];
    section80CCDEmployer = json['Section80CCDEmployer'];
    section80D = json['Section80D'];
    section80DD = json['Section80DD'];
    section80DDB = json['Section80DDB'];
    section80E = json['Section80E'];
    section80EE = json['Section80EE'];
    section80G = json['Section80G'];
    section80GG = json['Section80GG'];
    section80GGA = json['Section80GGA'];
    section80GGC = json['Section80GGC'];
    section80U = json['Section80U'];
    section80TTA = json['Section80TTA'];
    section80TTB = json['Section80TTB'];
    totalChapVIADeductions = json['TotalChapVIADeductions'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Section80C'] = this.section80C;
    data['Section80CCC'] = this.section80CCC;
    data['Section80CCDEmployeeOrSE'] = this.section80CCDEmployeeOrSE;
    data['Section80CCD1B'] = this.section80CCD1B;
    data['Section80CCDEmployer'] = this.section80CCDEmployer;
    data['Section80D'] = this.section80D;
    data['Section80DD'] = this.section80DD;
    data['Section80DDB'] = this.section80DDB;
    data['Section80E'] = this.section80E;
    data['Section80EE'] = this.section80EE;
    data['Section80G'] = this.section80G;
    data['Section80GG'] = this.section80GG;
    data['Section80GGA'] = this.section80GGA;
    data['Section80GGC'] = this.section80GGC;
    data['Section80U'] = this.section80U;
    data['Section80TTA'] = this.section80TTA;
    data['Section80TTB'] = this.section80TTB;
    data['TotalChapVIADeductions'] = this.totalChapVIADeductions;
    return data;
  }
}

class DeductUndChapVIA {
  int section80C;
  int section80CCC;
  int section80CCDEmployeeOrSE;
  int section80CCD1B;
  int section80CCDEmployer;
  int section80D;
  int section80DD;
  int section80DDB;
  int section80E;
  int section80EE;
  int section80EEA;
  int section80EEB;
  int section80G;
  int section80GG;
  int section80GGA;
  int section80GGC;
  int section80U;
  int section80TTA;
  int section80TTB;
  int totalChapVIADeductions;

  DeductUndChapVIA(
      {this.section80C,
      this.section80CCC,
      this.section80CCDEmployeeOrSE,
      this.section80CCD1B,
      this.section80CCDEmployer,
      this.section80D,
      this.section80DD,
      this.section80DDB,
      this.section80E,
      this.section80EE,
      this.section80EEA,
      this.section80EEB,
      this.section80G,
      this.section80GG,
      this.section80GGA,
      this.section80GGC,
      this.section80U,
      this.section80TTA,
      this.section80TTB,
      this.totalChapVIADeductions});

  DeductUndChapVIA.fromJson(Map<String, dynamic> json) {
    section80C = json['Section80C'];
    section80CCC = json['Section80CCC'];
    section80CCDEmployeeOrSE = json['Section80CCDEmployeeOrSE'];
    section80CCD1B = json['Section80CCD1B'];
    section80CCDEmployer = json['Section80CCDEmployer'];
    section80D = json['Section80D'];
    section80DD = json['Section80DD'];
    section80DDB = json['Section80DDB'];
    section80E = json['Section80E'];
    section80EE = json['Section80EE'];
    section80EEA = json['Section80EEA'];
    section80EEB = json['Section80EEB'];
    section80G = json['Section80G'];
    section80GG = json['Section80GG'];
    section80GGA = json['Section80GGA'];
    section80GGC = json['Section80GGC'];
    section80U = json['Section80U'];
    section80TTA = json['Section80TTA'];
    section80TTB = json['Section80TTB'];
    totalChapVIADeductions = json['TotalChapVIADeductions'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Section80C'] = this.section80C;
    data['Section80CCC'] = this.section80CCC;
    data['Section80CCDEmployeeOrSE'] = this.section80CCDEmployeeOrSE;
    data['Section80CCD1B'] = this.section80CCD1B;
    data['Section80CCDEmployer'] = this.section80CCDEmployer;
    data['Section80D'] = this.section80D;
    data['Section80DD'] = this.section80DD;
    data['Section80DDB'] = this.section80DDB;
    data['Section80E'] = this.section80E;
    data['Section80EE'] = this.section80EE;
    data['Section80EEA'] = this.section80EEA;
    data['Section80EEB'] = this.section80EEB;
    data['Section80G'] = this.section80G;
    data['Section80GG'] = this.section80GG;
    data['Section80GGA'] = this.section80GGA;
    data['Section80GGC'] = this.section80GGC;
    data['Section80U'] = this.section80U;
    data['Section80TTA'] = this.section80TTA;
    data['Section80TTB'] = this.section80TTB;
    data['TotalChapVIADeductions'] = this.totalChapVIADeductions;
    return data;
  }
}

class ExemptIncAgriOthUs10 {
  int exemptIncAgriOthUs10Total;

  ExemptIncAgriOthUs10({this.exemptIncAgriOthUs10Total});

  ExemptIncAgriOthUs10.fromJson(Map<String, dynamic> json) {
    exemptIncAgriOthUs10Total = json['ExemptIncAgriOthUs10Total'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ExemptIncAgriOthUs10Total'] = this.exemptIncAgriOthUs10Total;
    return data;
  }
}

class Schedule80GGA {
  int totalDonationsUs80GGA;
  int totalDonationAmtCash80GGA;
  int totalDonationAmtOtherMode80GGA;
  int totalEligibleDonationAmt80GGA;

  Schedule80GGA(
      {this.totalDonationsUs80GGA,
      this.totalDonationAmtCash80GGA,
      this.totalDonationAmtOtherMode80GGA,
      this.totalEligibleDonationAmt80GGA});

  Schedule80GGA.fromJson(Map<String, dynamic> json) {
    totalDonationsUs80GGA = json['TotalDonationsUs80GGA'];
    totalDonationAmtCash80GGA = json['TotalDonationAmtCash80GGA'];
    totalDonationAmtOtherMode80GGA = json['TotalDonationAmtOtherMode80GGA'];
    totalEligibleDonationAmt80GGA = json['TotalEligibleDonationAmt80GGA'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotalDonationsUs80GGA'] = this.totalDonationsUs80GGA;
    data['TotalDonationAmtCash80GGA'] = this.totalDonationAmtCash80GGA;
    data['TotalDonationAmtOtherMode80GGA'] =
        this.totalDonationAmtOtherMode80GGA;
    data['TotalEligibleDonationAmt80GGA'] = this.totalEligibleDonationAmt80GGA;
    return data;
  }
}

class ITR1TaxComputation {
  IntrstPay intrstPay;
  int totalTaxPayable;
  int rebate87A;
  int taxPayableOnRebate;
  int educationCess;
  int grossTaxLiability;
  int section89;
  int netTaxLiability;
  int totalIntrstPay;
  int totTaxPlusIntrstPay;

  ITR1TaxComputation(
      {this.intrstPay,
      this.totalTaxPayable,
      this.rebate87A,
      this.taxPayableOnRebate,
      this.educationCess,
      this.grossTaxLiability,
      this.section89,
      this.netTaxLiability,
      this.totalIntrstPay,
      this.totTaxPlusIntrstPay});

  ITR1TaxComputation.fromJson(Map<String, dynamic> json) {
    intrstPay = json['IntrstPay'] != null
        ? new IntrstPay.fromJson(json['IntrstPay'])
        : null;
    totalTaxPayable = json['TotalTaxPayable'];
    rebate87A = json['Rebate87A'];
    taxPayableOnRebate = json['TaxPayableOnRebate'];
    educationCess = json['EducationCess'];
    grossTaxLiability = json['GrossTaxLiability'];
    section89 = json['Section89'];
    netTaxLiability = json['NetTaxLiability'];
    totalIntrstPay = json['TotalIntrstPay'];
    totTaxPlusIntrstPay = json['TotTaxPlusIntrstPay'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.intrstPay != null) {
      data['IntrstPay'] = this.intrstPay.toJson();
    }
    data['TotalTaxPayable'] = this.totalTaxPayable;
    data['Rebate87A'] = this.rebate87A;
    data['TaxPayableOnRebate'] = this.taxPayableOnRebate;
    data['EducationCess'] = this.educationCess;
    data['GrossTaxLiability'] = this.grossTaxLiability;
    data['Section89'] = this.section89;
    data['NetTaxLiability'] = this.netTaxLiability;
    data['TotalIntrstPay'] = this.totalIntrstPay;
    data['TotTaxPlusIntrstPay'] = this.totTaxPlusIntrstPay;
    return data;
  }
}

class IntrstPay {
  int intrstPayUs234A;
  int intrstPayUs234B;
  int intrstPayUs234C;
  int lateFilingFee234F;

  IntrstPay(
      {this.intrstPayUs234A,
      this.intrstPayUs234B,
      this.intrstPayUs234C,
      this.lateFilingFee234F});

  IntrstPay.fromJson(Map<String, dynamic> json) {
    intrstPayUs234A = json['IntrstPayUs234A'];
    intrstPayUs234B = json['IntrstPayUs234B'];
    intrstPayUs234C = json['IntrstPayUs234C'];
    lateFilingFee234F = json['LateFilingFee234F'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['IntrstPayUs234A'] = this.intrstPayUs234A;
    data['IntrstPayUs234B'] = this.intrstPayUs234B;
    data['IntrstPayUs234C'] = this.intrstPayUs234C;
    data['LateFilingFee234F'] = this.lateFilingFee234F;
    return data;
  }
}

class TaxPaid {
  TaxesPaid taxesPaid;
  int balTaxPayable;

  TaxPaid({this.taxesPaid, this.balTaxPayable});

  TaxPaid.fromJson(Map<String, dynamic> json) {
    taxesPaid = json['TaxesPaid'] != null
        ? new TaxesPaid.fromJson(json['TaxesPaid'])
        : null;
    balTaxPayable = json['BalTaxPayable'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.taxesPaid != null) {
      data['TaxesPaid'] = this.taxesPaid.toJson();
    }
    data['BalTaxPayable'] = this.balTaxPayable;
    return data;
  }
}

class TaxesPaid {
  int advanceTax;
  int tDS;
  int tCS;
  int selfAssessmentTax;
  int totalTaxesPaid;

  TaxesPaid(
      {this.advanceTax,
      this.tDS,
      this.tCS,
      this.selfAssessmentTax,
      this.totalTaxesPaid});

  TaxesPaid.fromJson(Map<String, dynamic> json) {
    advanceTax = json['AdvanceTax'];
    tDS = json['TDS'];
    tCS = json['TCS'];
    selfAssessmentTax = json['SelfAssessmentTax'];
    totalTaxesPaid = json['TotalTaxesPaid'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['AdvanceTax'] = this.advanceTax;
    data['TDS'] = this.tDS;
    data['TCS'] = this.tCS;
    data['SelfAssessmentTax'] = this.selfAssessmentTax;
    data['TotalTaxesPaid'] = this.totalTaxesPaid;
    return data;
  }
}

class Refund {
  BankAccountDtls bankAccountDtls;
  int refundDue;

  Refund({this.bankAccountDtls, this.refundDue});

  Refund.fromJson(Map<String, dynamic> json) {
    bankAccountDtls = json['BankAccountDtls'] != null
        ? new BankAccountDtls.fromJson(json['BankAccountDtls'])
        : null;
    refundDue = json['RefundDue'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.bankAccountDtls != null) {
      data['BankAccountDtls'] = this.bankAccountDtls.toJson();
    }
    data['RefundDue'] = this.refundDue;
    return data;
  }
}

class BankAccountDtls {
  List<AddtnlBankDetails> addtnlBankDetails;

  BankAccountDtls({this.addtnlBankDetails});

  BankAccountDtls.fromJson(Map<String, dynamic> json) {
    if (json['AddtnlBankDetails'] != null) {
      addtnlBankDetails = new List<AddtnlBankDetails>();
      json['AddtnlBankDetails'].forEach((v) {
        addtnlBankDetails.add(new AddtnlBankDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.addtnlBankDetails != null) {
      data['AddtnlBankDetails'] =
          this.addtnlBankDetails.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AddtnlBankDetails {
  String iFSCCode;
  String bankName;
  String bankAccountNo;
  String useForRefund;

  AddtnlBankDetails(
      {this.iFSCCode, this.bankName, this.bankAccountNo, this.useForRefund});

  AddtnlBankDetails.fromJson(Map<String, dynamic> json) {
    iFSCCode = json['IFSCCode'];
    bankName = json['BankName'];
    bankAccountNo = json['BankAccountNo'];
    useForRefund = json['UseForRefund'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['IFSCCode'] = this.iFSCCode;
    data['BankName'] = this.bankName;
    data['BankAccountNo'] = this.bankAccountNo;
    data['UseForRefund'] = this.useForRefund;
    return data;
  }
}

class Schedule80G {
  Don100Percent don100Percent;
  Don50PercentNoApprReqd don50PercentNoApprReqd;
  Don100PercentApprReqd don100PercentApprReqd;
  Don50PercentApprReqd don50PercentApprReqd;
  int totalDonationsUs80GCash;
  int totalDonationsUs80GOtherMode;
  int totalDonationsUs80G;
  int totalEligibleDonationsUs80G;

  Schedule80G(
      {this.don100Percent,
      this.don50PercentNoApprReqd,
      this.don100PercentApprReqd,
      this.don50PercentApprReqd,
      this.totalDonationsUs80GCash,
      this.totalDonationsUs80GOtherMode,
      this.totalDonationsUs80G,
      this.totalEligibleDonationsUs80G});

  Schedule80G.fromJson(Map<String, dynamic> json) {
    don100Percent = json['Don100Percent'] != null
        ? new Don100Percent.fromJson(json['Don100Percent'])
        : null;
    don50PercentNoApprReqd = json['Don50PercentNoApprReqd'] != null
        ? new Don50PercentNoApprReqd.fromJson(json['Don50PercentNoApprReqd'])
        : null;
    don100PercentApprReqd = json['Don100PercentApprReqd'] != null
        ? new Don100PercentApprReqd.fromJson(json['Don100PercentApprReqd'])
        : null;
    don50PercentApprReqd = json['Don50PercentApprReqd'] != null
        ? new Don50PercentApprReqd.fromJson(json['Don50PercentApprReqd'])
        : null;
    totalDonationsUs80GCash = json['TotalDonationsUs80GCash'];
    totalDonationsUs80GOtherMode = json['TotalDonationsUs80GOtherMode'];
    totalDonationsUs80G = json['TotalDonationsUs80G'];
    totalEligibleDonationsUs80G = json['TotalEligibleDonationsUs80G'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.don100Percent != null) {
      data['Don100Percent'] = this.don100Percent.toJson();
    }
    if (this.don50PercentNoApprReqd != null) {
      data['Don50PercentNoApprReqd'] = this.don50PercentNoApprReqd.toJson();
    }
    if (this.don100PercentApprReqd != null) {
      data['Don100PercentApprReqd'] = this.don100PercentApprReqd.toJson();
    }
    if (this.don50PercentApprReqd != null) {
      data['Don50PercentApprReqd'] = this.don50PercentApprReqd.toJson();
    }
    data['TotalDonationsUs80GCash'] = this.totalDonationsUs80GCash;
    data['TotalDonationsUs80GOtherMode'] = this.totalDonationsUs80GOtherMode;
    data['TotalDonationsUs80G'] = this.totalDonationsUs80G;
    data['TotalEligibleDonationsUs80G'] = this.totalEligibleDonationsUs80G;
    return data;
  }
}

class Don100Percent {
  int totDon100PercentCash;
  int totDon100PercentOtherMode;
  int totDon100Percent;
  int totEligibleDon100Percent;

  Don100Percent(
      {this.totDon100PercentCash,
      this.totDon100PercentOtherMode,
      this.totDon100Percent,
      this.totEligibleDon100Percent});

  Don100Percent.fromJson(Map<String, dynamic> json) {
    totDon100PercentCash = json['TotDon100PercentCash'];
    totDon100PercentOtherMode = json['TotDon100PercentOtherMode'];
    totDon100Percent = json['TotDon100Percent'];
    totEligibleDon100Percent = json['TotEligibleDon100Percent'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotDon100PercentCash'] = this.totDon100PercentCash;
    data['TotDon100PercentOtherMode'] = this.totDon100PercentOtherMode;
    data['TotDon100Percent'] = this.totDon100Percent;
    data['TotEligibleDon100Percent'] = this.totEligibleDon100Percent;
    return data;
  }
}

class Don50PercentNoApprReqd {
  int totDon50PercentNoApprReqdCash;
  int totDon50PercentNoApprReqdOtherMode;
  int totDon50PercentNoApprReqd;
  int totEligibleDon50Percent;

  Don50PercentNoApprReqd(
      {this.totDon50PercentNoApprReqdCash,
      this.totDon50PercentNoApprReqdOtherMode,
      this.totDon50PercentNoApprReqd,
      this.totEligibleDon50Percent});

  Don50PercentNoApprReqd.fromJson(Map<String, dynamic> json) {
    totDon50PercentNoApprReqdCash = json['TotDon50PercentNoApprReqdCash'];
    totDon50PercentNoApprReqdOtherMode =
        json['TotDon50PercentNoApprReqdOtherMode'];
    totDon50PercentNoApprReqd = json['TotDon50PercentNoApprReqd'];
    totEligibleDon50Percent = json['TotEligibleDon50Percent'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotDon50PercentNoApprReqdCash'] = this.totDon50PercentNoApprReqdCash;
    data['TotDon50PercentNoApprReqdOtherMode'] =
        this.totDon50PercentNoApprReqdOtherMode;
    data['TotDon50PercentNoApprReqd'] = this.totDon50PercentNoApprReqd;
    data['TotEligibleDon50Percent'] = this.totEligibleDon50Percent;
    return data;
  }
}

class Don100PercentApprReqd {
  int totDon100PercentApprReqdCash;
  int totDon100PercentApprReqdOtherMode;
  int totDon100PercentApprReqd;
  int totEligibleDon100PercentApprReqd;

  Don100PercentApprReqd(
      {this.totDon100PercentApprReqdCash,
      this.totDon100PercentApprReqdOtherMode,
      this.totDon100PercentApprReqd,
      this.totEligibleDon100PercentApprReqd});

  Don100PercentApprReqd.fromJson(Map<String, dynamic> json) {
    totDon100PercentApprReqdCash = json['TotDon100PercentApprReqdCash'];
    totDon100PercentApprReqdOtherMode =
        json['TotDon100PercentApprReqdOtherMode'];
    totDon100PercentApprReqd = json['TotDon100PercentApprReqd'];
    totEligibleDon100PercentApprReqd = json['TotEligibleDon100PercentApprReqd'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotDon100PercentApprReqdCash'] = this.totDon100PercentApprReqdCash;
    data['TotDon100PercentApprReqdOtherMode'] =
        this.totDon100PercentApprReqdOtherMode;
    data['TotDon100PercentApprReqd'] = this.totDon100PercentApprReqd;
    data['TotEligibleDon100PercentApprReqd'] =
        this.totEligibleDon100PercentApprReqd;
    return data;
  }
}

class Don50PercentApprReqd {
  int totDon50PercentApprReqdCash;
  int totDon50PercentApprReqdOtherMode;
  int totDon50PercentApprReqd;
  int totEligibleDon50PercentApprReqd;

  Don50PercentApprReqd(
      {this.totDon50PercentApprReqdCash,
      this.totDon50PercentApprReqdOtherMode,
      this.totDon50PercentApprReqd,
      this.totEligibleDon50PercentApprReqd});

  Don50PercentApprReqd.fromJson(Map<String, dynamic> json) {
    totDon50PercentApprReqdCash = json['TotDon50PercentApprReqdCash'];
    totDon50PercentApprReqdOtherMode = json['TotDon50PercentApprReqdOtherMode'];
    totDon50PercentApprReqd = json['TotDon50PercentApprReqd'];
    totEligibleDon50PercentApprReqd = json['TotEligibleDon50PercentApprReqd'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotDon50PercentApprReqdCash'] = this.totDon50PercentApprReqdCash;
    data['TotDon50PercentApprReqdOtherMode'] =
        this.totDon50PercentApprReqdOtherMode;
    data['TotDon50PercentApprReqd'] = this.totDon50PercentApprReqd;
    data['TotEligibleDon50PercentApprReqd'] =
        this.totEligibleDon50PercentApprReqd;
    return data;
  }
}

class Schedule80D {
  Sec80DSelfFamSrCtznHealth sec80DSelfFamSrCtznHealth;

  Schedule80D({this.sec80DSelfFamSrCtznHealth});

  Schedule80D.fromJson(Map<String, dynamic> json) {
    sec80DSelfFamSrCtznHealth = json['Sec80DSelfFamSrCtznHealth'] != null
        ? new Sec80DSelfFamSrCtznHealth.fromJson(
            json['Sec80DSelfFamSrCtznHealth'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.sec80DSelfFamSrCtznHealth != null) {
      data['Sec80DSelfFamSrCtznHealth'] =
          this.sec80DSelfFamSrCtznHealth.toJson();
    }
    return data;
  }
}

class Sec80DSelfFamSrCtznHealth {
  String seniorCitizenFlag;
  int selfAndFamily;
  int healthInsPremSlfFam;
  int selfAndFamilySeniorCitizen;
  String parentsSeniorCitizenFlag;
  int parents;
  int parentsSeniorCitizen;
  int eligibleAmountOfDedn;

  Sec80DSelfFamSrCtznHealth(
      {this.seniorCitizenFlag,
      this.selfAndFamily,
      this.healthInsPremSlfFam,
      this.selfAndFamilySeniorCitizen,
      this.parentsSeniorCitizenFlag,
      this.parents,
      this.parentsSeniorCitizen,
      this.eligibleAmountOfDedn});

  Sec80DSelfFamSrCtznHealth.fromJson(Map<String, dynamic> json) {
    seniorCitizenFlag = json['SeniorCitizenFlag'];
    selfAndFamily = json['SelfAndFamily'];
    healthInsPremSlfFam = json['HealthInsPremSlfFam'];
    selfAndFamilySeniorCitizen = json['SelfAndFamilySeniorCitizen'];
    parentsSeniorCitizenFlag = json['ParentsSeniorCitizenFlag'];
    parents = json['Parents'];
    parentsSeniorCitizen = json['ParentsSeniorCitizen'];
    eligibleAmountOfDedn = json['EligibleAmountOfDedn'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['SeniorCitizenFlag'] = this.seniorCitizenFlag;
    data['SelfAndFamily'] = this.selfAndFamily;
    data['HealthInsPremSlfFam'] = this.healthInsPremSlfFam;
    data['SelfAndFamilySeniorCitizen'] = this.selfAndFamilySeniorCitizen;
    data['ParentsSeniorCitizenFlag'] = this.parentsSeniorCitizenFlag;
    data['Parents'] = this.parents;
    data['ParentsSeniorCitizen'] = this.parentsSeniorCitizen;
    data['EligibleAmountOfDedn'] = this.eligibleAmountOfDedn;
    return data;
  }
}

class TDSonSalaries {
  int totalTDSonSalaries;

  TDSonSalaries({this.totalTDSonSalaries});

  TDSonSalaries.fromJson(Map<String, dynamic> json) {
    totalTDSonSalaries = json['TotalTDSonSalaries'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotalTDSonSalaries'] = this.totalTDSonSalaries;
    return data;
  }
}

class TDSonOthThanSals {
  int totalTDSonOthThanSals;

  TDSonOthThanSals({this.totalTDSonOthThanSals});

  TDSonOthThanSals.fromJson(Map<String, dynamic> json) {
    totalTDSonOthThanSals = json['TotalTDSonOthThanSals'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotalTDSonOthThanSals'] = this.totalTDSonOthThanSals;
    return data;
  }
}

class ScheduleTDS3Dtls {
  int totalTDS3Details;

  ScheduleTDS3Dtls({this.totalTDS3Details});

  ScheduleTDS3Dtls.fromJson(Map<String, dynamic> json) {
    totalTDS3Details = json['TotalTDS3Details'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotalTDS3Details'] = this.totalTDS3Details;
    return data;
  }
}

class ScheduleTCS {
  int totalSchTCS;

  ScheduleTCS({this.totalSchTCS});

  ScheduleTCS.fromJson(Map<String, dynamic> json) {
    totalSchTCS = json['TotalSchTCS'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotalSchTCS'] = this.totalSchTCS;
    return data;
  }
}

class TaxPayments {
  int totalTaxPayments;

  TaxPayments({this.totalTaxPayments});

  TaxPayments.fromJson(Map<String, dynamic> json) {
    totalTaxPayments = json['TotalTaxPayments'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['TotalTaxPayments'] = this.totalTaxPayments;
    return data;
  }
}

class Verification {
  Declaration declaration;
  String capacity;
  String place;

  Verification({this.declaration, this.capacity, this.place});

  Verification.fromJson(Map<String, dynamic> json) {
    declaration = json['Declaration'] != null
        ? new Declaration.fromJson(json['Declaration'])
        : null;
    capacity = json['Capacity'];
    place = json['Place'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.declaration != null) {
      data['Declaration'] = this.declaration.toJson();
    }
    data['Capacity'] = this.capacity;
    data['Place'] = this.place;
    return data;
  }
}

class Declaration {
  String assesseeVerName;
  String fatherName;
  String assesseeVerPAN;

  Declaration({this.assesseeVerName, this.fatherName, this.assesseeVerPAN});

  Declaration.fromJson(Map<String, dynamic> json) {
    assesseeVerName = json['AssesseeVerName'];
    fatherName = json['FatherName'];
    assesseeVerPAN = json['AssesseeVerPAN'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['AssesseeVerName'] = this.assesseeVerName;
    data['FatherName'] = this.fatherName;
    data['AssesseeVerPAN'] = this.assesseeVerPAN;
    return data;
  }
}
