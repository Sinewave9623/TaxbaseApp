class StateList {
  String stateName;
  int stateId;

  StateList({this.stateName,this.stateId});

  StateList.fromJson(Map<String, dynamic> json) {
    stateName = json['stateName'];
    stateId = json['stateId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['stateName'] = this.stateName;
    data['stateId'] = this.stateId;
    return data;
  }
}
