class CaProfileModel {
  String responseCode;
  List<CaData> caData;
  int customerCount;
  List<CustomerData> customerData;
  CaProfileModel(
      {this.responseCode, this.caData, this.customerCount, this.customerData});


        CaProfileModel.withError({int count, String responseCode}) {
    this.customerCount = count;
    this.responseCode = responseCode;
  }

  CaProfileModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    if (json['ca_data'] != null) {
      caData = new List<CaData>();
      json['ca_data'].forEach((v) {
        caData.add(new CaData.fromJson(v));
      });
    }
    customerCount = json['customer_count'];
    if (json['customer_data'] != null) {
      customerData = new List<CustomerData>();
      json['customer_data'].forEach((v) {
        customerData.add(new CustomerData.fromJson(v));
      });
    }
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    if (this.caData != null) {
      data['ca_data'] = this.caData.map((v) => v.toJson()).toList();
    }
    data['customer_count'] = this.customerCount;
    if (this.customerData != null) {
      data['customer_data'] = this.customerData.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CaData {
  int id;
  String caListUid;
  String custId;
  String caEmail;
  String caPan;
  String caImage;
  String caName;
  String caAddress;
  String caGst;
  String startDate;
  String endDate;
  bool isActive;
  CaData(
      {this.id,
      this.caListUid,
      this.custId,
      this.caEmail,
      this.caPan,
      this.caImage,
      this.caName,
      this.caAddress,
      this.caGst,
      this.startDate,
      this.endDate,
      this.isActive});
  CaData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    caListUid = json['CaList_uid'];
    custId = json['cust_id'];
    caEmail = json['ca_email'];
    caPan = json['ca_pan'];
    caImage = json['ca_image'];
    caName = json['ca_name'];
    caAddress = json['ca_address'];
    caGst = json['ca_gst'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    isActive = json['isActive'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['CaList_uid'] = this.caListUid;
    data['cust_id'] = this.custId;
    data['ca_email'] = this.caEmail;
    data['ca_pan'] = this.caPan;
    data['ca_image'] = this.caImage;
    data['ca_name'] = this.caName;
    data['ca_address'] = this.caAddress;
    data['ca_gst'] = this.caGst;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['isActive'] = this.isActive;
    return data;
  }
}

class CustomerData {
  int id;

  CustomerData({
    this.id,
  });
  CustomerData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;

    return data;
  }
}
