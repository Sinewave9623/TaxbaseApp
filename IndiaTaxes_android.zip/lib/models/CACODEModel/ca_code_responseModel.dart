class CA_CODEResponseModel {
  String result;
  List<VerfiedCustomerDetails> data;
  List<CaData> caData;
  String responseCode;

  CA_CODEResponseModel(
      {this.result, this.data, this.caData, this.responseCode});

  CA_CODEResponseModel.withError({String result, String responseCode}) {
    this.result = result;
    this.responseCode = responseCode;
  }

  CA_CODEResponseModel.fromJson(Map<String, dynamic> json) {
    result = json['result'];
    if (json['data'] != null) {
      data = new List<VerfiedCustomerDetails>();
      json['data'].forEach((v) {
        data.add(new VerfiedCustomerDetails.fromJson(v));
      });
    }
    if (json['ca_data'] != null) {
      caData = new List<CaData>();
      json['ca_data'].forEach((v) {
        caData.add(new CaData.fromJson(v));
      });
    }
    responseCode = json['response_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['result'] = this.result;
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    if (this.caData != null) {
      data['ca_data'] = this.caData.map((v) => v.toJson()).toList();
    }
    data['response_code'] = this.responseCode;
    return data;
  }
}

class VerfiedCustomerDetails {
  int id;
  String uId;
  String custId;
  String group;
  String code;
  String payeeType;
  String payeeCode;
  String gaCode;
  String name;
  String name2;
  String pan;
  String tan;
  String gstin;
  String gstrMonthlyQuarterly;
  String status;
  String sex;
  String o5LADD1;
  String o5LADD2;
  String o5LADD3;
  String o5LADD4;
  String o5LADD5;
  String oCity;
  String oPin;
  String oState;
  String oTel;
  String r5LADD1;
  String r5LADD2;
  String r5LADD3;
  String r5LADD4;
  String r5LADD5;
  String rCity;
  String rPin;
  String rState;
  String rTel;
  String emailid;
  String mobileno;
  String father;
  String resOff;
  String residentStatus;
  String dateBirth;
  String anniversaryDate;
  String iTRXMLUploadLoginId;
  String iTRXMLUploadPassword;
  bool iTRXMLUploadSavePassword;
  String tanLoginId;
  String tanPassword;
  String tracesIdLoginId;
  String tracesIdPassword;
  bool isActive;

  VerfiedCustomerDetails(
      {this.id,
      this.uId,
      this.custId,
      this.group,
      this.code,
      this.payeeType,
      this.payeeCode,
      this.gaCode,
      this.name,
      this.name2,
      this.pan,
      this.tan,
      this.gstin,
      this.gstrMonthlyQuarterly,
      this.status,
      this.sex,
      this.o5LADD1,
      this.o5LADD2,
      this.o5LADD3,
      this.o5LADD4,
      this.o5LADD5,
      this.oCity,
      this.oPin,
      this.oState,
      this.oTel,
      this.r5LADD1,
      this.r5LADD2,
      this.r5LADD3,
      this.r5LADD4,
      this.r5LADD5,
      this.rCity,
      this.rPin,
      this.rState,
      this.rTel,
      this.emailid,
      this.mobileno,
      this.father,
      this.resOff,
      this.residentStatus,
      this.dateBirth,
      this.anniversaryDate,
      this.iTRXMLUploadLoginId,
      this.iTRXMLUploadPassword,
      this.iTRXMLUploadSavePassword,
      this.tanLoginId,
      this.tanPassword,
      this.tracesIdLoginId,
      this.tracesIdPassword,
      this.isActive});

  VerfiedCustomerDetails.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    custId = json['cust_id'];
    group = json['group'];
    code = json['code'];
    payeeType = json['payee_type'];
    payeeCode = json['payee_code'];
    gaCode = json['ga_code'];
    name = json['name'];
    name2 = json['name2'];
    pan = json['pan'];
    tan = json['tan'];
    gstin = json['gstin'];
    gstrMonthlyQuarterly = json['gstr_monthly_quarterly'];
    status = json['status'];
    sex = json['sex'];
    o5LADD1 = json['O_5L_ADD1'];
    o5LADD2 = json['O_5L_ADD2'];
    o5LADD3 = json['O_5L_ADD3'];
    o5LADD4 = json['O_5L_ADD4'];
    o5LADD5 = json['O_5L_ADD5'];
    oCity = json['O_City'];
    oPin = json['O_Pin'];
    oState = json['O_State'];
    oTel = json['O_Tel'];
    r5LADD1 = json['R_5L_ADD1'];
    r5LADD2 = json['R_5L_ADD2'];
    r5LADD3 = json['R_5L_ADD3'];
    r5LADD4 = json['R_5L_ADD4'];
    r5LADD5 = json['R_5L_ADD5'];
    rCity = json['R_City'];
    rPin = json['R_Pin'];
    rState = json['R_State'];
    rTel = json['R_Tel'];
    emailid = json['emailid'];
    mobileno = json['mobileno'];
    father = json['father'];
    resOff = json['res_off'];
    residentStatus = json['resident_status'];
    dateBirth = json['date_birth'];
    anniversaryDate = json['anniversary_date'];
    iTRXMLUploadLoginId = json['ITRXMLUploadLoginId'];
    iTRXMLUploadPassword = json['ITRXMLUploadPassword'];
    iTRXMLUploadSavePassword = json['ITRXMLUploadSavePassword'];
    tanLoginId = json['Tan_LoginId'];
    tanPassword = json['Tan_Password'];
    tracesIdLoginId = json['Traces_Id_Login_Id'];
    tracesIdPassword = json['Traces_Id_Password'];
    isActive = json['isActive'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    data['cust_id'] = this.custId;
    data['group'] = this.group;
    data['code'] = this.code;
    data['payee_type'] = this.payeeType;
    data['payee_code'] = this.payeeCode;
    data['ga_code'] = this.gaCode;
    data['name'] = this.name;
    data['name2'] = this.name2;
    data['pan'] = this.pan;
    data['tan'] = this.tan;
    data['gstin'] = this.gstin;
    data['gstr_monthly_quarterly'] = this.gstrMonthlyQuarterly;
    data['status'] = this.status;
    data['sex'] = this.sex;
    data['O_5L_ADD1'] = this.o5LADD1;
    data['O_5L_ADD2'] = this.o5LADD2;
    data['O_5L_ADD3'] = this.o5LADD3;
    data['O_5L_ADD4'] = this.o5LADD4;
    data['O_5L_ADD5'] = this.o5LADD5;
    data['O_City'] = this.oCity;
    data['O_Pin'] = this.oPin;
    data['O_State'] = this.oState;
    data['O_Tel'] = this.oTel;
    data['R_5L_ADD1'] = this.r5LADD1;
    data['R_5L_ADD2'] = this.r5LADD2;
    data['R_5L_ADD3'] = this.r5LADD3;
    data['R_5L_ADD4'] = this.r5LADD4;
    data['R_5L_ADD5'] = this.r5LADD5;
    data['R_City'] = this.rCity;
    data['R_Pin'] = this.rPin;
    data['R_State'] = this.rState;
    data['R_Tel'] = this.rTel;
    data['emailid'] = this.emailid;
    data['mobileno'] = this.mobileno;
    data['father'] = this.father;
    data['res_off'] = this.resOff;
    data['resident_status'] = this.residentStatus;
    data['date_birth'] = this.dateBirth;
    data['anniversary_date'] = this.anniversaryDate;
    data['ITRXMLUploadLoginId'] = this.iTRXMLUploadLoginId;
    data['ITRXMLUploadPassword'] = this.iTRXMLUploadPassword;
    data['ITRXMLUploadSavePassword'] = this.iTRXMLUploadSavePassword;
    data['Tan_LoginId'] = this.tanLoginId;
    data['Tan_Password'] = this.tanPassword;
    data['Traces_Id_Login_Id'] = this.tracesIdLoginId;
    data['Traces_Id_Password'] = this.tracesIdPassword;
    data['isActive'] = this.isActive;
    return data;
  }
}

class CaData {
  int id;
  String caListUid;
  String custId;
  String caEmail;
  String caPan;
  dynamic caImage;
  String caName;
  String caAddress;
  String caGst;
  String startDate;
  String endDate;
  bool isActive;

  CaData(
      {this.id,
      this.caListUid,
      this.custId,
      this.caEmail,
      this.caPan,
      this.caImage,
      this.caName,
      this.caAddress,
      this.caGst,
      this.startDate,
      this.endDate,
      this.isActive});

  CaData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    caListUid = json['CaList_uid'];
    custId = json['cust_id'];
    caEmail = json['ca_email'];
    caPan = json['ca_pan'];
    caImage = json['ca_image'];
    caName = json['ca_name'];
    caAddress = json['ca_address'];
    caGst = json['ca_gst'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    isActive = json['isActive'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['CaList_uid'] = this.caListUid;
    data['cust_id'] = this.custId;
    data['ca_email'] = this.caEmail;
    data['ca_pan'] = this.caPan;
    data['ca_image'] = this.caImage;
    data['ca_name'] = this.caName;
    data['ca_address'] = this.caAddress;
    data['ca_gst'] = this.caGst;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['isActive'] = this.isActive;
    return data;
  }
}
