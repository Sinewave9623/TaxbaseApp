class RequestOTPSineWaveModel {
  dynamic message;
  String statusCd;

  RequestOTPSineWaveModel({this.message, this.statusCd});

  RequestOTPSineWaveModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    statusCd = json['status_cd'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['status_cd'] = this.statusCd;
    return data;
  }
}
