class Form26Model {
  String message;
  int statusCode;
  Master master;
  List<PartaMaster> partaMaster;
  List<dynamic> taxpaid;
  List<Sft> sft;
  List<dynamic> trunover;
  List<dynamic> parta1Master;
  List<dynamic> parta2Master;
  List<dynamic> partbMaster;

  Form26Model(
      {this.message,
      this.statusCode,
      this.master,
      this.partaMaster,
      this.taxpaid,
      this.sft,
      this.trunover,
      this.parta1Master,
      this.parta2Master,
      this.partbMaster});

  Form26Model.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    statusCode = json['status_code'];
    master =
        json['master'] != null ? new Master.fromJson(json['master']) : null;
    if (json['parta_master'] != null) {
      partaMaster = new List<PartaMaster>();
      json['parta_master'].forEach((v) {
        partaMaster.add(new PartaMaster.fromJson(v));
      });
    }
    // if (json['taxpaid'] != null) {
    //   taxpaid = new List<Null>();
    //   json['taxpaid'].forEach((v) {
    //     taxpaid.add(new Null.fromJson(v));
    //   });
    // }
    if (json['sft'] != null) {
      sft = new List<Sft>();
      json['sft'].forEach((v) {
        sft.add(new Sft.fromJson(v));
      });
    }
    // if (json['trunover'] != null) {
    //   trunover = new List<Null>();
    //   json['trunover'].forEach((v) {
    //     trunover.add(new Null.fromJson(v));
    //   });
    // }
    // if (json['parta1_master'] != null) {
    //   parta1Master = new List<Null>();
    //   json['parta1_master'].forEach((v) {
    //     parta1Master.add(new Null.fromJson(v));
    //   });
    // }
    // if (json['parta2_master'] != null) {
    //   parta2Master = new List<Null>();
    //   json['parta2_master'].forEach((v) {
    //     parta2Master.add(new Null.fromJson(v));
    //   });
    // }
    // if (json['partb_master'] != null) {
    //   partbMaster = new List<Null>();
    //   json['partb_master'].forEach((v) {
    //     partbMaster.add(new Null.fromJson(v));
    //   });
    // }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['status_code'] = this.statusCode;
    if (this.master != null) {
      data['master'] = this.master.toJson();
    }
    if (this.partaMaster != null) {
      data['parta_master'] = this.partaMaster.map((v) => v.toJson()).toList();
    }
    // if (this.taxpaid != null) {
    //   data['taxpaid'] = this.taxpaid.map((v) => v.toJson()).toList();
    // }
    if (this.sft != null) {
      data['sft'] = this.sft.map((v) => v.toJson()).toList();
    }
    // if (this.trunover != null) {
    //   data['trunover'] = this.trunover.map((v) => v.toJson()).toList();
    // }
    // if (this.parta1Master != null) {
    //   data['parta1_master'] = this.parta1Master.map((v) => v.toJson()).toList();
    // }
    // if (this.parta2Master != null) {
    //   data['parta2_master'] = this.parta2Master.map((v) => v.toJson()).toList();
    // }
    // if (this.partbMaster != null) {
    //   data['partb_master'] = this.partbMaster.map((v) => v.toJson()).toList();
    // }
    return data;
  }


    Form26Model.withError({String msg, int statusCode}) {
    this.message = msg;
    this.statusCode = statusCode;
  }

}

class Master {
  String firstName;
  String lastName;
  String middleName;
  Null gender;
  String pAN;
  String pANStatus;
  String fno;
  String nameOfPremises;
  String streetName;
  String locality;
  String city;
  String pin;
  String state;
  String country;
  String fY;
  String aY;

  Master(
      {this.firstName,
      this.lastName,
      this.middleName,
      this.gender,
      this.pAN,
      this.pANStatus,
      this.fno,
      this.nameOfPremises,
      this.streetName,
      this.locality,
      this.city,
      this.pin,
      this.state,
      this.country,
      this.fY,
      this.aY});

  Master.fromJson(Map<String, dynamic> json) {
    firstName = json['FirstName'];
    lastName = json['LastName'];
    middleName = json['MiddleName'];
    gender = json['Gender'];
    pAN = json['PAN'];
    pANStatus = json['PAN_Status'];
    fno = json['fno'];
    nameOfPremises = json['Name_of_Premises'];
    streetName = json['StreetName'];
    locality = json['Locality'];
    city = json['City'];
    pin = json['Pin'];
    state = json['State'];
    country = json['Country'];
    fY = json['FY'];
    aY = json['AY'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['FirstName'] = this.firstName;
    data['LastName'] = this.lastName;
    data['MiddleName'] = this.middleName;
    data['Gender'] = this.gender;
    data['PAN'] = this.pAN;
    data['PAN_Status'] = this.pANStatus;
    data['fno'] = this.fno;
    data['Name_of_Premises'] = this.nameOfPremises;
    data['StreetName'] = this.streetName;
    data['Locality'] = this.locality;
    data['City'] = this.city;
    data['Pin'] = this.pin;
    data['State'] = this.state;
    data['Country'] = this.country;
    data['FY'] = this.fY;
    data['AY'] = this.aY;
    return data;
  }
}

class PartaMaster {
  String name;
  String tAN;
  String totalPaidAmount;
  String totalTaxDedcuted;
  String totalTaxDeposited;
  List<PartaDetails> partaDetails;

  PartaMaster(
      {this.name,
      this.tAN,
      this.totalPaidAmount,
      this.totalTaxDedcuted,
      this.totalTaxDeposited,
      this.partaDetails});

  PartaMaster.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    tAN = json['TAN'];
    totalPaidAmount = json['total_paid_amount'];
    totalTaxDedcuted = json['total_tax_dedcuted'];
    totalTaxDeposited = json['total_tax_deposited'];
    if (json['parta_details'] != null) {
      partaDetails = new List<PartaDetails>();
      json['parta_details'].forEach((v) {
        partaDetails.add(new PartaDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['TAN'] = this.tAN;
    data['total_paid_amount'] = this.totalPaidAmount;
    data['total_tax_dedcuted'] = this.totalTaxDedcuted;
    data['total_tax_deposited'] = this.totalTaxDeposited;
    if (this.partaDetails != null) {
      data['parta_details'] = this.partaDetails.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class PartaDetails {
  String section;
  String transactionDate;
  String bookingDate;
  String bookingStatus;
  String remarks;
  String paidAmount;
  String taxDedcuted;
  String taxDeposited;

  PartaDetails(
      {this.section,
      this.transactionDate,
      this.bookingDate,
      this.bookingStatus,
      this.remarks,
      this.paidAmount,
      this.taxDedcuted,
      this.taxDeposited});

  PartaDetails.fromJson(Map<String, dynamic> json) {
    section = json['section'];
    transactionDate = json['transaction_date'];
    bookingDate = json['booking_date'];
    bookingStatus = json['booking_status'];
    remarks = json['remarks'];
    paidAmount = json['paid_amount'];
    taxDedcuted = json['tax_dedcuted'];
    taxDeposited = json['tax_deposited'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['section'] = this.section;
    data['transaction_date'] = this.transactionDate;
    data['booking_date'] = this.bookingDate;
    data['booking_status'] = this.bookingStatus;
    data['remarks'] = this.remarks;
    data['paid_amount'] = this.paidAmount;
    data['tax_dedcuted'] = this.taxDedcuted;
    data['tax_deposited'] = this.taxDeposited;
    return data;
  }
}

class Sft {
  String transactionType;
  String nameOfSftFilter;
  String transactionDate;
  String amount;
  String remark;

  Sft(
      {this.transactionType,
      this.nameOfSftFilter,
      this.transactionDate,
      this.amount,
      this.remark});

  Sft.fromJson(Map<String, dynamic> json) {
    transactionType = json['transaction_type'];
    nameOfSftFilter = json['name_of_sft_filter'];
    transactionDate = json['transaction_date'];
    amount = json['amount'];
    remark = json['remark'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['transaction_type'] = this.transactionType;
    data['name_of_sft_filter'] = this.nameOfSftFilter;
    data['transaction_date'] = this.transactionDate;
    data['amount'] = this.amount;
    data['remark'] = this.remark;
    return data;
  }
}
