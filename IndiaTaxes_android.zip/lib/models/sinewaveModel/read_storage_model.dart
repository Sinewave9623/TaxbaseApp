class ReadStorageModel {
  String responseCode;
  Data data;

  ReadStorageModel({this.responseCode, this.data});

  ReadStorageModel.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }

  ReadStorageModel.withError({String responseCode}) {
    this.responseCode = responseCode;
  }
}

class Data {
  int id;
  String uId;
  BasicDetails basicDetails;
  SalaryModel salary;
  HouseProperty houseProperty;
  Business business;
  CapitalGain capitalGain;
  OtherSources otherSources;
  OtherSpecialIncome otherSpecialIncome;
  String lossBfAdjusted;
  Deductions deductions;
  Exempt exemptIncome;
  String agricultureIncome;
  Tds tds;
  AdvanceTax advanceTax;
  AdvanceTax selfAssesmentTax;
  String customer;
  ITRInformation itr_information;

  Data({
    this.id,
    this.uId,
    this.basicDetails,
    this.salary,
    this.houseProperty,
    this.business,
    this.capitalGain,
    this.otherSources,
    this.otherSpecialIncome,
    this.lossBfAdjusted,
    this.deductions,
    this.exemptIncome,
    this.agricultureIncome,
    this.tds,
    this.advanceTax,
    this.selfAssesmentTax,
    this.customer,
    this.itr_information,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    uId = json['uId'];
    basicDetails = json['basic_details'] != null
        ? new BasicDetails.fromJson(json['basic_details'])
        : null;
    salary = json['salary'] != null
        ? new SalaryModel.fromJson(json['salary'])
        : null;
    houseProperty = json['house_property'] != null
        ? new HouseProperty.fromJson(json['house_property'])
        : null;
    business = json['business'] != null
        ? new Business.fromJson(json['business'])
        : null;
    capitalGain = json['capital_gain'] != null
        ? new CapitalGain.fromJson(json['capital_gain'])
        : null;
    otherSources = json['other_sources'] != null
        ? new OtherSources.fromJson(json['other_sources'])
        : null;
    otherSpecialIncome = json['other_special_income'] != null
        ? new OtherSpecialIncome.fromJson(json['other_special_income'])
        : null;
    lossBfAdjusted = json['loss_bf_adjusted'];
    deductions = json['deductions'] != null
        ? new Deductions.fromJson(json['deductions'])
        : null;
    exemptIncome = json['exempt_income'] != null
        ? new Exempt.fromJson(json['exempt_income'])
        : null;
    agricultureIncome = json['agriculture_income'];
    tds = json['tds'] != null ? new Tds.fromJson(json['tds']) : null;
    advanceTax = json['advance_tax'] != null
        ? new AdvanceTax.fromJson(json['advance_tax'])
        : null;
    selfAssesmentTax = json['self_assesment_tax'] != null
        ? new AdvanceTax.fromJson(json['self_assesment_tax'])
        : null;
    itr_information = json['itr_information'] != null
        ? new ITRInformation.fromJson(json['itr_information'])
        : null;
    customer = json['customer'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['uId'] = this.uId;
    if (this.basicDetails != null) {
      data['basic_details'] = this.basicDetails.toJson();
    }
    if (this.salary != null) {
      data['salary'] = this.salary.toJson();
    }
    if (this.houseProperty != null) {
      data['house_property'] = this.houseProperty.toJson();
    }
    if (this.business != null) {
      data['business'] = this.business.toJson();
    }
    if (this.capitalGain != null) {
      data['capital_gain'] = this.capitalGain.toJson();
    }
    if (this.otherSources != null) {
      data['other_sources'] = this.otherSources.toJson();
    }
    if (this.otherSpecialIncome != null) {
      data['other_special_income'] = this.otherSpecialIncome.toJson();
    }
    data['loss_bf_adjusted'] = this.lossBfAdjusted;
    if (this.deductions != null) {
      data['deductions'] = this.deductions.toJson();
    }
    if (this.exemptIncome != null) {
      data['exempt_income'] = this.exemptIncome.toJson();
    }
    data['agriculture_income'] = this.agricultureIncome;
    if (this.tds != null) {
      data['tds'] = this.tds.toJson();
    }
    if (this.advanceTax != null) {
      data['advance_tax'] = this.advanceTax.toJson();
    }
    if (this.selfAssesmentTax != null) {
      data['self_assesment_tax'] = this.selfAssesmentTax.toJson();
    }
    if (this.itr_information != null) {
      data['itr_information'] = this.itr_information.toJson();
    }
    data['customer'] = this.customer;
    return data;
  }
}

class BasicDetails {
  String year;
  String dueDate;
  String itrStatus;
  String residency;
  String taxMethod;
  String filingDate;
  String domesticCompany;
  String firstName;
  String middleName;
  String lastName;
  String gender;
  String dob;
  String pan;
  String fatherName;
  String flatNumber;
  String premiseName;
  String streetName;
  String area;
  String town;
  String pin;
  String state;
  String country;
  String mobileNumber;
  String aadharNumber;
  String emailId;

  BasicDetails({
    this.year,
    this.dueDate,
    this.itrStatus,
    this.residency,
    this.taxMethod,
    this.filingDate,
    this.domesticCompany,
    this.firstName,
    this.middleName,
    this.lastName,
    this.gender,
    this.dob,
    this.pan,
    this.fatherName,
    this.flatNumber,
    this.premiseName,
    this.streetName,
    this.area,
    this.town,
    this.pin,
    this.state,
    this.country,
    this.mobileNumber,
    this.aadharNumber,
    this.emailId,
  });

  BasicDetails.fromJson(Map<String, dynamic> json) {
    year = json['year'];
    dueDate = json['dueDate'];
    itrStatus = json['itrStatus'];
    residency = json['residency'];
    taxMethod = json['taxMethod'];
    filingDate = json['filingDate'];
    domesticCompany = json['domesticCompany'];
    firstName = json['firstName'];
    middleName = json['middleName'];
    lastName = json['lastName'];
    gender = json['gender'];
    dob = json['dob'];
    pan = json['pan'];
    fatherName = json['fatherName'];
    flatNumber = json['flatNumber'];
    premiseName = json['premiseName'];
    streetName = json['streetName'];
    area = json['area'];
    town = json['town'];
    pin = json['pin'];
    state = json['state'];
    country = json['country'];
    mobileNumber = json['mobileNumber'];
    aadharNumber = json['aadharNumber'];
    emailId = json['emailId'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['year'] = this.year;
    data['dueDate'] = this.dueDate;
    data['itrStatus'] = this.itrStatus;
    data['residency'] = this.residency;
    data['taxMethod'] = this.taxMethod;
    data['filingDate'] = this.filingDate;
    data['domesticCompany'] = this.domesticCompany;
    data['firstName'] = this.firstName;
    data['middleName'] = this.middleName;
    data['lastName'] = this.lastName;
    data['gender'] = this.gender;
    data['dob'] = this.dob;
    data['pan'] = this.pan;
    data['fatherName'] = this.fatherName;
    data['flatNumber'] = this.flatNumber;
    data['premiseName'] = this.premiseName;
    data['streetName'] = this.streetName;
    data['area'] = this.area;
    data['town'] = this.town;
    data['pin'] = this.pin;
    data['state'] = this.state;
    data['country'] = this.country;
    data['mobileNumber'] = this.mobileNumber;
    data['aadharNumber'] = this.aadharNumber;
    data['emailId'] = this.emailId;
    return data;
  }
}

class SalaryModel {
  String lta;
  List<int> lieu;
  List<int> other;
  String profTax;
  String employerHra;
  String employerPan;
  List<int> perquisites;
  String employerName;
  String employerBasic;
  List<int> exemptAllowance;
  String employerCategory;
  String employerAllowancePerquisites;
  String tanDeducter;
  String panDeducter;
  dynamic entertainment;
  List<dynamic> otherString;
  List<dynamic> perquisitesString;
  List<dynamic> lieuString;
  List<dynamic> exemptAllowanceString;

  SalaryModel(
      {this.lta,
      this.lieu,
      this.other,
      this.profTax,
      this.employerHra,
      this.perquisites,
      this.employerPan,
      this.employerName,
      this.employerBasic,
      this.exemptAllowance,
      this.employerCategory,
      this.employerAllowancePerquisites,
      this.tanDeducter,
      this.entertainment,
      this.panDeducter,
      this.otherString,
      this.perquisitesString,
      this.lieuString,
      this.exemptAllowanceString});

  SalaryModel.fromJson(Map<String, dynamic> json) {
    lta = json['lta'];
    lieu = json['lieu'].cast<int>();
    other = json['other'].cast<int>();
    profTax = json['profTax'];
    employerPan = json['employerPan'];
    employerHra = json['employerHra'];
    perquisites = json['perquisites'].cast<int>();
    employerName = json['employerName'];
    employerBasic = json['employerBasic'];
    exemptAllowance = json['exemptAllowance'].cast<int>();
    employerCategory = json['employerCategory'];
    employerAllowancePerquisites = json['employerAllowancePerquisites'];
    tanDeducter = json['tanDeducter'];
    panDeducter = json['panDeducter'];
    entertainment = json['entertainment'];

    otherString = json['otherString'];
    perquisitesString = json['perquisitesString'];
    lieuString = json['lieuString'];
    exemptAllowanceString = json['exemptAllowanceString'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['lta'] = this.lta;
    data['lieu'] = this.lieu;
    data['other'] = this.other;
    data['profTax'] = this.profTax;
    data['employerPan'] = this.employerPan;
    data['employerHra'] = this.employerHra;
    data['perquisites'] = this.perquisites;
    data['employerName'] = this.employerName;
    data['employerBasic'] = this.employerBasic;
    data['exemptAllowance'] = this.exemptAllowance;
    data['employerCategory'] = this.employerCategory;
    data['employerAllowancePerquisites'] = this.employerAllowancePerquisites;
    data['tanDeducter'] = this.tanDeducter;
    data['panDeducter'] = this.panDeducter;
    data['entertainment'] = this.entertainment;

    data['otherString'] = this.otherString;
    data['perquisitesString'] = this.perquisitesString;
    data['lieuString'] = this.lieuString;
    data['exemptAllowanceString'] = this.exemptAllowanceString;

    return data;
  }
}

class HouseProperty {
  String self;
  String rented;
  String housePropertyType;
  dynamic muncipalTax;
  dynamic inrealisedRent;

  HouseProperty(
      {this.self,
      this.rented,
      this.muncipalTax,
      this.inrealisedRent,
      this.housePropertyType});

  HouseProperty.fromJson(Map<String, dynamic> json) {
    self = json['self'];
    rented = json['rented'];
    muncipalTax = json['muncipalTax'];
    inrealisedRent = json['inrealisedRent'];
    housePropertyType = json['housePropertyType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['self'] = this.self;
    data['rented'] = this.rented;
    data['muncipalTax'] = this.rented;
    data['inrealisedRent'] = this.inrealisedRent;
    data['housePropertyType'] = this.housePropertyType;

    return data;
  }
}

class Business {
  dynamic interest;
  dynamic firmProfit;
  String businessName;
  dynamic remuneration;
  dynamic businessProfit;

  Business(
      {this.interest,
      this.firmProfit,
      this.businessName,
      this.remuneration,
      this.businessProfit});

  Business.fromJson(Map<String, dynamic> json) {
    interest = json['interest'];
    firmProfit = json['firmProfit'];
    businessName = json['businessName'];
    remuneration = json['remuneration'];
    businessProfit = json['businessProfit'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['interest'] = this.interest;
    data['firmProfit'] = this.firmProfit;
    data['businessName'] = this.businessName;
    data['remuneration'] = this.remuneration;
    data['businessProfit'] = this.businessProfit;
    return data;
  }
}

class CapitalGain {
  dynamic ltcg101503;
  dynamic ltcg101506;
  dynamic ltcg101509;
  dynamic ltcg101512;
  dynamic ltcg103103;
  dynamic ltcg201503;
  dynamic ltcg201506;
  dynamic ltcg201509;
  dynamic ltcg201512;
  dynamic ltcg203103;
  dynamic ltcg112A1503;
  dynamic ltcg112A1506;
  dynamic ltcg112A1509;
  dynamic ltcg112A1512;
  dynamic ltcg112A3103;
  dynamic stcg111A1503;
  dynamic stcg111A1506;
  dynamic stcg111A1509;
  dynamic stcg111A1512;
  dynamic stcg111A3103;
  dynamic stcgNormal1503;
  dynamic stcgNormal1506;
  dynamic stcgNormal1509;
  dynamic stcgNormal1512;
  dynamic stcgNormal3103;

  CapitalGain(
      {this.ltcg101503,
      this.ltcg101506,
      this.ltcg101509,
      this.ltcg101512,
      this.ltcg103103,
      this.ltcg201503,
      this.ltcg201506,
      this.ltcg201509,
      this.ltcg201512,
      this.ltcg203103,
      this.ltcg112A1503,
      this.ltcg112A1506,
      this.ltcg112A1509,
      this.ltcg112A1512,
      this.ltcg112A3103,
      this.stcg111A1503,
      this.stcg111A1506,
      this.stcg111A1509,
      this.stcg111A1512,
      this.stcg111A3103,
      this.stcgNormal1503,
      this.stcgNormal1506,
      this.stcgNormal1509,
      this.stcgNormal1512,
      this.stcgNormal3103});

  CapitalGain.fromJson(Map<String, dynamic> json) {
    ltcg101503 = json['ltcg101503'];
    ltcg101506 = json['ltcg101506'];
    ltcg101509 = json['ltcg101509'];
    ltcg101512 = json['ltcg101512'];
    ltcg103103 = json['ltcg103103'];
    ltcg201503 = json['ltcg201503'];
    ltcg201506 = json['ltcg201506'];
    ltcg201509 = json['ltcg201509'];
    ltcg201512 = json['ltcg201512'];
    ltcg203103 = json['ltcg203103'];
    ltcg112A1503 = json['ltcg112A1503'];
    ltcg112A1506 = json['ltcg112A1506'];
    ltcg112A1509 = json['ltcg112A1509'];
    ltcg112A1512 = json['ltcg112A1512'];
    ltcg112A3103 = json['ltcg112A3103'];
    stcg111A1503 = json['stcg111A1503'];
    stcg111A1506 = json['stcg111A1506'];
    stcg111A1509 = json['stcg111A1509'];
    stcg111A1512 = json['stcg111A1512'];
    stcg111A3103 = json['stcg111A3103'];
    stcgNormal1503 = json['stcgNormal1503'];
    stcgNormal1506 = json['stcgNormal1506'];
    stcgNormal1509 = json['stcgNormal1509'];
    stcgNormal1512 = json['stcgNormal1512'];
    stcgNormal3103 = json['stcgNormal3103'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ltcg101503'] = this.ltcg101503;
    data['ltcg101506'] = this.ltcg101506;
    data['ltcg101509'] = this.ltcg101509;
    data['ltcg101512'] = this.ltcg101512;
    data['ltcg103103'] = this.ltcg103103;
    data['ltcg201503'] = this.ltcg201503;
    data['ltcg201506'] = this.ltcg201506;
    data['ltcg201509'] = this.ltcg201509;
    data['ltcg201512'] = this.ltcg201512;
    data['ltcg203103'] = this.ltcg203103;
    data['ltcg112A1503'] = this.ltcg112A1503;
    data['ltcg112A1506'] = this.ltcg112A1506;
    data['ltcg112A1509'] = this.ltcg112A1509;
    data['ltcg112A1512'] = this.ltcg112A1512;
    data['ltcg112A3103'] = this.ltcg112A3103;
    data['stcg111A1503'] = this.stcg111A1503;
    data['stcg111A1506'] = this.stcg111A1506;
    data['stcg111A1509'] = this.stcg111A1509;
    data['stcg111A1512'] = this.stcg111A1512;
    data['stcg111A3103'] = this.stcg111A3103;
    data['stcgNormal1503'] = this.stcgNormal1503;
    data['stcgNormal1506'] = this.stcgNormal1506;
    data['stcgNormal1509'] = this.stcgNormal1509;
    data['stcgNormal1512'] = this.stcgNormal1512;
    data['stcgNormal3103'] = this.stcgNormal3103;
    return data;
  }
}

class OtherSources {
  List<dynamic> otherIncome;
  dynamic interestBank;
  dynamic interestSaving;
  dynamic interestTaxIncome;
  dynamic pensionReceived;
  dynamic otherSourceDeduction57;

  OtherSources({this.otherIncome, this.interestBank, this.interestSaving});

  OtherSources.fromJson(Map<String, dynamic> json) {
    otherIncome = json['otherIncome'];
    interestBank = json['interestBank'];
    interestSaving = json['interestSaving'];
    interestTaxIncome = json['interestTaxIncome'];
    pensionReceived = json['pensionReceived'];
    otherSourceDeduction57 = json['otherSourceDeduction57'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();

    data['otherIncome'] = this.otherIncome;
    data['interestBank'] = this.interestBank;
    data['interestSaving'] = this.interestSaving;
    data['interestTaxIncome'] = this.interestTaxIncome;
    data['pensionReceived'] = this.pensionReceived;
    data['otherSourceDeduction57'] = this.otherSourceDeduction57;
    return data;
  }
}

class OtherSpecialIncome {
  dynamic divident1503;
  dynamic divident1506;
  dynamic divident1509;
  dynamic divident1512;
  dynamic divident3103;
  dynamic lottery1503;
  dynamic lottery1506;
  dynamic lottery1509;
  dynamic lottery1512;
  dynamic lottery3103;
  OtherSpecialIncome(
      {this.lottery1503,
      this.lottery1506,
      this.lottery1509,
      this.lottery1512,
      this.lottery3103,
      this.divident1503,
      this.divident1506,
      this.divident1509,
      this.divident1512,
      this.divident3103});

  OtherSpecialIncome.fromJson(Map<String, dynamic> json) {
    divident1503 = json['divident1503'];
    divident1506 = json['divident1506'];
    divident1509 = json['divident1509'];
    divident1512 = json['divident1512'];
    divident3103 = json['divident3103'];
    lottery1503 = json['lottery1503'];
    lottery1506 = json['lottery1506'];
    lottery1509 = json['lottery1509'];
    lottery1512 = json['lottery1512'];
    lottery3103 = json['lottery3103'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['divident1503'] = this.divident1503;
    data['divident1506'] = this.divident1506;
    data['divident1509'] = this.divident1509;
    data['divident1512'] = this.divident1512;
    data['divident3103'] = this.divident3103;
    data['lottery1503'] = this.lottery1503;
    data['lottery1506'] = this.lottery1506;
    data['lottery1509'] = this.lottery1509;
    data['lottery1512'] = this.lottery1512;
    data['lottery3103'] = this.lottery3103;
    return data;
  }
}

class Deductions {
  dynamic hl;
  dynamic mf;
  dynamic pf;
  dynamic lic;
  dynamic licLimit;
  dynamic self;
  bool parent;
  bool severe;
  bool handicap;
  dynamic publicPf;
  bool parentAge;
  dynamic donation50;
  dynamic nscDeposit;
  dynamic donation100;
  dynamic nscInterest;
  dynamic certainFunds;
  dynamic groupInsurance;
  dynamic higherEducation;
  dynamic medicalInsurance;
  dynamic educationExpenses;
  String rent;
  dynamic deduction80ccd1;
  dynamic deduction80ccd1b;
  dynamic deduction80ccd2;
  dynamic selfMediclaim;
  dynamic selfHealthcheckup;
  dynamic selfMedicalExpenditure;
  dynamic parentMediclaim;
  dynamic parentHealthcheckup;
  dynamic parentMedicalExpenditure;
  bool senior80ddb;
  dynamic medical80ddb;
  dynamic parentMedicalInsurance;
  dynamic first80EE;
  dynamic houseProperty80EE;
  dynamic houseProperty80EEA;
  dynamic houseProperty80EEB;
  dynamic political80GGC;
  dynamic deduction80TTA;
  dynamic deduction80TTB;

  List<dynamic> certain100doneeName;
  List<dynamic> certain100Address;
  List<dynamic> certain100City;
  List<dynamic> certain100State;
  List<int> certain100Pincode;
  List<dynamic> certain100doneePan;
  List<dynamic> certain100donationCash;
  List<dynamic> certain100donationOther;
  List<int> certain100Total;

  List<dynamic> certain50doneeName;
  List<dynamic> certain50Address;
  List<dynamic> certain50City;
  List<dynamic> certain50State;
  List<int> certain50Pincode;
  List<dynamic> certain50doneePan;
  List<dynamic> certain50donationCash;
  List<dynamic> certain50donationOther;
  List<int> certain50Total;

  List<dynamic> scientificdoneeName;
  List<dynamic> scientificAddress;
  List<dynamic> scientificCity;
  List<dynamic> scientificState;
  List<int> scientificPincode;
  List<dynamic> scientificdoneePan;
  List<dynamic> scientificdonationCash;
  List<dynamic> scientificdonationOther;
  List<int> scientificTotal;

  Deductions({
    this.hl,
    this.mf,
    this.pf,
    this.lic,
    this.licLimit,
    this.self,
    this.parent,
    this.severe,
    this.handicap,
    this.publicPf,
    this.parentAge,
    this.donation50,
    this.nscDeposit,
    this.donation100,
    this.nscInterest,
    this.certainFunds,
    this.groupInsurance,
    this.higherEducation,
    this.medicalInsurance,
    this.educationExpenses,
    this.rent,
    this.deduction80ccd1,
    this.deduction80ccd1b,
    this.deduction80ccd2,
    this.selfMediclaim,
    this.selfHealthcheckup,
    this.selfMedicalExpenditure,
    this.parentMediclaim,
    this.parentHealthcheckup,
    this.parentMedicalExpenditure,
    this.senior80ddb,
    this.medical80ddb,
    this.parentMedicalInsurance,
    this.first80EE,
    this.houseProperty80EE,
    this.houseProperty80EEA,
    this.houseProperty80EEB,
    this.political80GGC,
    this.deduction80TTA,
    this.deduction80TTB,
    this.certain100doneeName,
    this.certain100Address,
    this.certain100City,
    this.certain100State,
    this.certain100Pincode,
    this.certain100doneePan,
    this.certain100donationCash,
    this.certain100donationOther,
    this.certain100Total,
    this.certain50doneeName,
    this.certain50Address,
    this.certain50City,
    this.certain50State,
    this.certain50Pincode,
    this.certain50doneePan,
    this.certain50donationCash,
    this.certain50donationOther,
    this.certain50Total,
    this.scientificdoneeName,
    this.scientificAddress,
    this.scientificCity,
    this.scientificState,
    this.scientificPincode,
    this.scientificdoneePan,
    this.scientificdonationCash,
    this.scientificdonationOther,
    this.scientificTotal,
  });

  Deductions.fromJson(Map<String, dynamic> json) {
    hl = json['hl'];
    mf = json['mf'];
    pf = json['pf'];
    lic = json['lic'];
    licLimit = json['licLimit'];
    self = json['self'];
    parent = json['parent'];
    severe = json['severe'];
    handicap = json['handicap'];
    publicPf = json['publicPf'];
    parentAge = json['parentAge'];
    donation50 = json['donation50'];
    nscDeposit = json['nscDeposit'];
    donation100 = json['donation100'];
    nscInterest = json['nscInterest'];
    certainFunds = json['certainFunds'];
    groupInsurance = json['groupInsurance'];
    higherEducation = json['higherEducation'];
    medicalInsurance = json['medicalInsurance'];
    educationExpenses = json['educationExpenses'];
    rent = json['rent'];

    deduction80ccd1 = json['deduction80ccd1'];
    deduction80ccd1b = json['deduction80ccd1b'];
    deduction80ccd2 = json['deduction80ccd2'];
    selfMediclaim = json['selfMediclaim'];
    selfHealthcheckup = json['selfHealthcheckup'];
    selfMedicalExpenditure = json['selfMedicalExpenditure'];
    parentMediclaim = json['parentMediclaim'];
    parentHealthcheckup = json['parentHealthcheckup'];
    parentMedicalExpenditure = json['parentMedicalExpenditure'];
    senior80ddb = json['senior80ddb'];
    medical80ddb = json['medical80ddb'];
    parentMedicalInsurance = json['parentMedicalInsurance'];
    first80EE = json['first80EE'];
    houseProperty80EE = json['houseProperty80EE'];
    houseProperty80EEA = json['houseProperty80EEA'];
    houseProperty80EEB = json['houseProperty80EEB'];
    political80GGC = json['political80GGC'];
    deduction80TTA = json['deduction80TTA'];
    deduction80TTB = json['deduction80TTB'];

    certain100doneeName = json['certain100doneeName'];
    certain100Address = json['certain100Address'];
    certain100City = json['certain100City'];
    certain100State = json['certain100State'];
    certain100Pincode = json['certain100Pincode'].cast<int>();
    certain100doneePan = json['certain100doneePan'];
    certain100donationCash = json['certain100donationCash'];
    certain100donationOther = json['certain100donationOther'];
    certain100Total = json['certain100Total'].cast<int>();
    

    certain50doneeName = json['certain50doneeName'];
    certain50Address = json['certain50Address'];
    certain50City = json['certain50City'];
    certain50State = json['certain50State'];
    certain50Pincode = json['certain50Pincode'].cast<int>();
    certain50doneePan = json['certain50doneePan'];
    certain50donationCash = json['certain50donationCash'];
    certain50donationOther = json['certain50donationOther'];
    certain50Total = json['certain50Total'].cast<int>();

    scientificdoneeName = json['scientificdoneeName'];
    scientificAddress = json['scientificAddress'];
    scientificCity = json['scientificCity'];
    scientificState = json['scientificState'];
    scientificPincode = json['scientificPincode'].cast<int>();
    scientificdoneePan = json['scientificdoneePan'];
    scientificdonationCash = json['scientificdonationCash'];
    scientificdonationOther = json['scientificdonationOther'];
    scientificTotal = json['scientificTotal'].cast<int>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['hl'] = this.hl;
    data['mf'] = this.mf;
    data['pf'] = this.pf;
    data['lic'] = this.lic;
    data['licLimit'] = this.licLimit;
    data['self'] = this.self;
    data['parent'] = this.parent;
    data['severe'] = this.severe;
    data['handicap'] = this.handicap;
    data['publicPf'] = this.publicPf;
    data['parentAge'] = this.parentAge;
    data['donation50'] = this.donation50;
    data['nscDeposit'] = this.nscDeposit;
    data['donation100'] = this.donation100;
    data['nscInterest'] = this.nscInterest;
    data['certainFunds'] = this.certainFunds;
    data['groupInsurance'] = this.groupInsurance;
    data['higherEducation'] = this.higherEducation;
    data['medicalInsurance'] = this.medicalInsurance;
    data['educationExpenses'] = this.educationExpenses;
    data['rent'] = this.rent;

    data['deduction80ccd1'] = this.deduction80ccd1;
    data['deduction80ccd1b'] = this.deduction80ccd1b;
    data['deduction80ccd2'] = this.deduction80ccd2;
    data['selfMediclaim'] = this.selfMediclaim;
    data['selfHealthcheckup'] = this.selfHealthcheckup;
    data['selfMedicalExpenditure'] = this.selfMedicalExpenditure;
    data['parentMediclaim'] = this.parentMediclaim;
    data['parentHealthcheckup'] = this.parentHealthcheckup;
    data['parentMedicalExpenditure'] = this.parentMedicalExpenditure;
    data['senior80ddb'] = this.senior80ddb;
    data['medical80ddb'] = this.medical80ddb;
    data['parentMedicalInsurance'] = this.parentMedicalInsurance;
    data['first80EE'] = this.first80EE;
    data['houseProperty80EE'] = this.houseProperty80EE;
    data['houseProperty80EEA'] = this.houseProperty80EEA;
    data['houseProperty80EEB'] = this.houseProperty80EEB;
    data['political80GGC'] = this.political80GGC;
    data['deduction80TTA'] = this.deduction80TTA;
    data['deduction80TTB'] = this.deduction80TTB;

    data['certain100doneeName'] = this.certain100doneeName;
    data['certain100Address'] = this.certain100Address;
    data['certain100City'] = this.certain100City;
    data['certain100State'] = this.certain100State;
    data['certain100Pincode'] = this.certain100Pincode;
    data['certain100doneePan'] = this.certain100doneePan;
    data['certain100donationCash'] = this.certain100donationCash;
    data['certain100donationOther'] = this.certain100donationOther;
    data['certain100Total'] = this.certain100Total;

    data['certain50doneeName'] = this.certain50doneeName;
    data['certain50Address'] = this.certain50Address;
    data['certain50City'] = this.certain50City;
    data['certain50State'] = this.certain50State;
    data['certain50Pincode'] = this.certain50Pincode;
    data['certain50doneePan'] = this.certain50doneePan;
    data['certain50donationCash'] = this.certain50donationCash;
    data['certain50donationOther'] = this.certain50donationOther;
    data['certain50Total'] = this.certain50Total;

    data['scientificdoneeName'] = this.scientificdoneeName;
    data['scientificAddress'] = this.scientificAddress;
    data['scientificCity'] = this.scientificCity;
    data['scientificState'] = this.scientificState;
    data['scientificPincode'] = this.scientificPincode;
    data['scientificdoneePan'] = this.scientificdoneePan;
    data['scientificdonationCash'] = this.scientificdonationCash;
    data['scientificdonationOther'] = this.scientificdonationOther;
    data['scientificTotal'] = this.scientificTotal;

    return data;
  }
}

class Tds {
  List<TdsDetails> details;

  Tds({
    this.details,
  });

  Tds.fromJson(Map<String, dynamic> json) {
    if (json['details'] != null) {
      details = new List<TdsDetails>();
      json['details'].forEach((v) {
        details.add(new TdsDetails.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.details != null) {
      data['details'] = this.details.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class TdsDetails {
  String srNumber;
  String section;
  String headIncome;
  String tanNumber;
  String deductorName;
  String deductionYear;
  int amount;
  int taxDeducted;
  int creditClaimed;

  TdsDetails(
      {this.srNumber,
      this.section,
      this.tanNumber,
      this.amount,
      this.taxDeducted,
      this.headIncome,
      this.creditClaimed,
      this.deductionYear,
      this.deductorName});

  TdsDetails.fromJson(Map<String, dynamic> json) {
    srNumber = json['srNumber'];
    section = json['section'];
    tanNumber = json['tanNumber'];
    amount = json['amount'];
    taxDeducted = json['taxDeducted'];
    headIncome = json['headIncome'];

    deductorName = json['deductorName'];
    deductionYear = json['deductionYear'];
    creditClaimed = json['creditClaimed'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['srNumber'] = this.srNumber;
    data['section'] = this.section;
    data['tanNumber'] = this.tanNumber;
    data['amount'] = this.amount;
    data['taxDeducted'] = this.taxDeducted;
    data['headIncome'] = this.headIncome;
    data['deductorName'] = this.deductorName;
    data['deductionYear'] = this.deductionYear;
    data['creditClaimed'] = this.creditClaimed;
    return data;
  }
}

class AdvanceTax {
  List<String> date;
  List<int> amount;
  List<int> cin;
  List<int> bsr;

  AdvanceTax({this.date, this.amount, this.cin, this.bsr});

  AdvanceTax.fromJson(Map<String, dynamic> json) {
    date = json['date'].cast<String>();
    amount = json['amount'].cast<int>();
    cin = json['cin'].cast<int>();
    bsr = json['bsr'].cast<int>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['date'] = this.date;
    data['amount'] = this.amount;
    data['cin'] = this.cin;
    data['bsr'] = this.bsr;
    return data;
  }
}

class Exempt {
  String exemptIncome;
  String insurancePolicy1010d;
  String statutoryPF;
  String recognisedPF;
  String exemptDividend;
  String exemptIncomeDescription;

  Exempt({
    this.exemptIncome,
    this.insurancePolicy1010d,
    this.statutoryPF,
    this.recognisedPF,
    this.exemptDividend,
    this.exemptIncomeDescription,
  });

  Exempt.fromJson(Map<String, dynamic> json) {
    exemptIncome = json['exemptIncome'];
    insurancePolicy1010d = json['insurancePolicy1010d'];
    statutoryPF = json['statutoryPF'];
    exemptDividend = json['exemptDividend'];
    recognisedPF = json['recognisedPF'];
    exemptIncomeDescription = json['exemptIncomeDescription'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['exemptIncome'] = this.exemptIncome;
    data['insurancePolicy1010d'] = this.insurancePolicy1010d;
    data['statutoryPF'] = this.statutoryPF;
    data['exemptDividend'] = this.exemptDividend;
    data['recognisedPF'] = this.recognisedPF;
    data['exemptIncomeDescription'] = this.exemptIncomeDescription;
    return data;
  }
}

class ITRInformation {
  String itr_dropDown;
  String unique_doc_no;
  String date_of_notice;
  String receipt_no;
  String date_of_filing;
  String depositeAmt_exceed;
  String foreignTravelExpenses;
  String electricityBill;
  String name;
  String son_of;
  String pan_no;
  String place;
  String date;
  List<BankDetails> bank_details;
  List<dynamic> ifsc_code;
  List<dynamic> bank_name;
  List<dynamic> account_no;
  List<dynamic> refundCreditCheckbox;

  ITRInformation({
    this.itr_dropDown,
    this.unique_doc_no,
    this.date_of_notice,
    this.receipt_no,
    this.date_of_filing,
    this.depositeAmt_exceed,
    this.foreignTravelExpenses,
    this.electricityBill,
    this.name,
    this.son_of,
    this.pan_no,
    this.place,
    this.date,
    this.bank_details,
    this.ifsc_code,
    this.bank_name,
    this.account_no,
    this.refundCreditCheckbox,
  });

  ITRInformation.fromJson(Map<String, dynamic> json) {
    itr_dropDown = json['itr_dropDown'];
    unique_doc_no = json['unique_doc_no'];
    date_of_notice = json['date_of_notice'];
    date = json['date'];
    receipt_no = json['receipt_no'];
    date_of_filing = json['date_of_filing'];
    depositeAmt_exceed = json['depositeAmt_exceed'];
    foreignTravelExpenses = json['foreignTravelExpenses'];
    electricityBill = json['electricityBill'];
    name = json['name'];
    son_of = json['son_of'];
    pan_no = json['pan_no'];
    place = json['place'];

    if (json['bank_details'] != null) {
      bank_details = new List<BankDetails>();
      json['bank_details'].forEach((v) {
        bank_details.add(new BankDetails.fromJson(v));
      });
    }

    ifsc_code = json['ifsc_code'];
    bank_name = json['bank_name'];
    account_no = json['account_no'];
    refundCreditCheckbox = json['refundCreditCheckbox'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['itr_dropDown'] = this.itr_dropDown;
    data['unique_doc_no'] = this.unique_doc_no;
    data['date_of_notice'] = this.date_of_notice;
    data['date'] = this.date;
    data['receipt_no'] = this.receipt_no;
    data['date_of_filing'] = this.date_of_filing;
    data['depositeAmt_exceed'] = this.depositeAmt_exceed;
    data['foreignTravelExpenses'] = this.foreignTravelExpenses;
    data['electricityBill'] = this.electricityBill;
    data['name'] = this.name;
    data['son_of'] = this.son_of;
    data['pan_no'] = this.pan_no;
    data['place'] = this.place;
    if (this.bank_details != null) {
      data['bank_details'] = this.bank_details.map((v) => v.toJson()).toList();
    }
    data['ifsc_code'] = this.ifsc_code;
    data['bank_name'] = this.bank_name;
    data['account_no'] = this.account_no;
    data['refundCreditCheckbox'] = this.refundCreditCheckbox;

    return data;
  }
}

class BankDetails {
  String ifscCode;
  String nameOfBank;
  String accntNo;
  bool refundCredit;

  BankDetails(
      {this.ifscCode, this.nameOfBank, this.accntNo, this.refundCredit});

  BankDetails.fromJson(Map<String, dynamic> json) {
    ifscCode = json['ifscCode'];
    nameOfBank = json['nameOfBank'];
    accntNo = json['accntNo'];
    refundCredit = json['refundCredit'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ifscCode'] = this.ifscCode;
    data['nameOfBank'] = this.nameOfBank;
    data['accntNo'] = this.accntNo;
    data['refundCredit'] = this.refundCredit;
    return data;
  }
}
