class CalculateTaxResponseModel {
  dynamic t80cout;
  dynamic totalIncome;
  dynamic grossTotalIncome;
  dynamic taxwoSurcharge;
  dynamic lessrebate87A;
  dynamic surcharge;
  dynamic educationCess;
  dynamic taxPayable;
  dynamic balancePayable;
  dynamic taxPayableRefundable;
  dynamic inccomeTax;
  InterestUS interestUS;
  dynamic normalTax;
  dynamic specialTax;
  dynamic totalTax;
  dynamic taxableIncome;
  dynamic message;
  dynamic status_code;

  CalculateTaxResponseModel(
      {this.t80cout,
      this.totalIncome,
      this.grossTotalIncome,
      this.taxwoSurcharge,
      this.lessrebate87A,
      this.surcharge,
      this.educationCess,
      this.taxPayable,
      this.balancePayable,
      this.taxPayableRefundable,
      this.inccomeTax,
      this.interestUS,
      this.normalTax,
      this.specialTax,
      this.totalTax,
      this.taxableIncome,
      this.message,
      this.status_code,
      });

  CalculateTaxResponseModel.fromJson(Map<String, dynamic> json) {
    t80cout = json['T80cout'];
    totalIncome = json['TotalIncome'];
    grossTotalIncome = json['GrossTotalIncome'];
    taxwoSurcharge = json['TaxwoSurcharge'];
    lessrebate87A = json['Lessrebate87A'];
    surcharge = json['Surcharge'];
    educationCess = json['EducationCess'];
    taxPayable = json['TaxPayable'];
    balancePayable = json['BalancePayable'];
    taxPayableRefundable = json['TaxPayableRefundable'];
    inccomeTax = json['InccomeTax'];
    interestUS = json['InterestUS'] != null
        ? new InterestUS.fromJson(json['InterestUS'])
        : null;
    normalTax = json['NormalTax'];
    specialTax = json['SpecialTax'];
    totalTax = json['TotalTax'];
    taxableIncome = json['TaxableIncome'];
    message = json['message'];
    status_code = json['status_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['T80cout'] = this.t80cout;
    data['TotalIncome'] = this.totalIncome;
    data['GrossTotalIncome'] = this.grossTotalIncome;
    data['TaxwoSurcharge'] = this.taxwoSurcharge;
    data['Lessrebate87A'] = this.lessrebate87A;
    data['Surcharge'] = this.surcharge;
    data['EducationCess'] = this.educationCess;
    data['TaxPayable'] = this.taxPayable;
    data['BalancePayable'] = this.balancePayable;
    data['TaxPayableRefundable'] = this.taxPayableRefundable;
    data['InccomeTax'] = this.inccomeTax;
    if (this.interestUS != null) {
      data['InterestUS'] = this.interestUS.toJson();
    }
    data['NormalTax'] = this.normalTax;
    data['SpecialTax'] = this.specialTax;
    data['TotalTax'] = this.totalTax;
    data['TaxableIncome'] = this.taxableIncome;
    data['message'] = this.message;
    data['status_code'] = this.status_code;
    return data;
  }

  CalculateTaxResponseModel.withError({String msg, int statusCode}) {
    this.message = msg;
    this.status_code = statusCode;
  }
}

class InterestUS {
  dynamic t234A;
  dynamic t234B;
  dynamic t234C;
  dynamic total234;

  InterestUS({this.t234A, this.t234B, this.t234C, this.total234});

  InterestUS.fromJson(Map<String, dynamic> json) {
    t234A = json['T234A'];
    t234B = json['T234B'];
    t234C = json['T234C'];
    total234 = json['Total_234'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['T234A'] = this.t234A;
    data['T234B'] = this.t234B;
    data['T234C'] = this.t234C;
    data['Total_234'] = this.total234;
    return data;
  }
}
