class GetTokenModel {
  String statusCd;
  String message;
  String authToken;

  GetTokenModel({this.statusCd, this.message, this.authToken});

  GetTokenModel.fromJson(Map<String, dynamic> json) {
    statusCd = json['status_cd'];
    message = json['message'];
    authToken = json['AuthToken'];
  }
GetTokenModel.withError({String statusCode, String msg}) {
    this.statusCd = statusCode;
    this.message = msg;
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status_cd'] = this.statusCd;
    data['message'] = this.message;
    data['AuthToken'] = this.authToken;
    return data;
  }
}
