class HeadIncomeModel {
  String message;
  int statusCode;
  List<HeadOfIncome> headOfIncome;
  List<HeadOfIncome> sectionOfIncome;

  HeadIncomeModel(
      {this.message, this.statusCode, this.headOfIncome, this.sectionOfIncome});

  HeadIncomeModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    statusCode = json['status_code'];
    if (json['HeadOfIncome'] != null) {
      headOfIncome = <HeadOfIncome>[];
      json['HeadOfIncome'].forEach((v) {
        headOfIncome.add(new HeadOfIncome.fromJson(v));
      });
    }
     if (json['SectionOfIncome'] != null) {
      sectionOfIncome = <HeadOfIncome>[];
      json['SectionOfIncome'].forEach((v) {
        sectionOfIncome.add(new HeadOfIncome.fromJson(v));
      });
    }

    
  
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['status_code'] = this.statusCode;
    if (this.headOfIncome != null) {
      data['HeadOfIncome'] = this.headOfIncome.map((v) => v.toJson()).toList();
    }
    if (this.sectionOfIncome != null) {
      data['SectionOfIncome'] =
          this.sectionOfIncome.map((v) => v.toJson()).toList();
    }
    return data;
  }

    HeadIncomeModel.withError({int responseCode, String msg}) {
    this.statusCode = responseCode;
    this.message = msg;
  }
}

class HeadOfIncome {
  String displayMember;
  String valueMember;

  HeadOfIncome({this.displayMember, this.valueMember});

  HeadOfIncome.fromJson(Map<String, dynamic> json) {
    displayMember = json['DisplayMember'];
    valueMember = json['ValueMember'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['DisplayMember'] = this.displayMember;
    data['ValueMember'] = this.valueMember;
    return data;
  }
}
