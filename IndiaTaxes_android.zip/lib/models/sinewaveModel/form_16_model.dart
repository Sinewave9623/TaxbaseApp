class Form16Model {
  String message;
  int statusCode;
  Master master;
  Details details;

  Form16Model({this.message,this.statusCode, this.master, this.details});

  Form16Model.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    statusCode = json['status_code'];
    master =
        json['master'] != null ? new Master.fromJson(json['master']) : null;
    details =
        json['details'] != null ? new Details.fromJson(json['details']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['status_code'] = this.statusCode;
    if (this.master != null) {
      data['master'] = this.master.toJson();
    }
    if (this.details != null) {
      data['details'] = this.details.toJson();
    }
    return data;
  }

  Form16Model.withError({String msg, int statusCode}) {
    this.message = msg;
    this.statusCode = statusCode;
  }


}

class Master {
  String firstName;
  String lastName;
  String middleName;
  String gender;
  String pAN;
  String fno;
  String nameOfPremises;
  String streetName;
  String locality;
  String city;
  String pin;
  String state;
  String country;

  Master(
      {this.firstName,
      this.lastName,
      this.middleName,
      this.gender,
      this.pAN,
      this.fno,
      this.nameOfPremises,
      this.streetName,
      this.locality,
      this.city,
      this.pin,
      this.state,
      this.country});

  Master.fromJson(Map<String, dynamic> json) {
    firstName = json['FirstName'];
    lastName = json['LastName'];
    middleName = json['MiddleName'];
    gender = json['Gender'];
    pAN = json['PAN'];
    fno = json['fno'];
    nameOfPremises = json['Name_of_Premises'];
    streetName = json['StreetName'];
    locality = json['Locality'];
    city = json['City'];
    pin = json['Pin'];
    state = json['State'];
    country = json['Country'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['FirstName'] = this.firstName;
    data['LastName'] = this.lastName;
    data['MiddleName'] = this.middleName;
    data['Gender'] = this.gender;
    data['PAN'] = this.pAN;
    data['fno'] = this.fno;
    data['Name_of_Premises'] = this.nameOfPremises;
    data['StreetName'] = this.streetName;
    data['Locality'] = this.locality;
    data['City'] = this.city;
    data['Pin'] = this.pin;
    data['State'] = this.state;
    data['Country'] = this.country;
    return data;
  }
}

class Details {
  String nameOfEmployer;
  String categoryOfEmployer;
  String basic;
  String houseRentAllowance;
  String leaveTravelAllowance;
  String dearnessAllowance;
  String conveyanceAllowance;
  String childrenEducationAllowance;
  String otherAllowance;
  String contributionMade;
  String deemedAmountFirst;
  String deemedAmountSecond;
  String annuityOrPension;
  String commutedPension;
  String gratuity;
  String feesOrCommission;
  String advanceOfSalary;
  String leaveEncashment;
  String other;
  String perquisites;
  String accommodation;
  String carsOrOtherAutomobiles;
  String otherAttendant;
  String gasElectricity;
  String interestFree;
  String holidayExpenses;
  String concessionalTravel;
  String freeMeals;
  String freeEducation;
  String gifts;
  String creditCardExpenses;
  String clubExpenses;
  String movableAssets;
  String transferOfAssets;
  String otherBenefit;
  String stockOptions;
  String taxPaid;
  String otherBenefits;
  String profitInLieu;
  String compensation;
  String paymentReceived;
  String dueAmount;
  String exempt;
  String travelConcession;
  String deathCumRetirement;
  String cummutedValue;
  String salaryEncashment;
  String houseRentAllowance2;
  String otherExemption;
  String deductionSection;
  String standardDeduction;
  String entertainment;
  String taxOnEmployment;
  String houseProperty;
  String otherSources;
  String deductionsUnderChapter;
  String contributionToProvident;
  String pensionFund;
  String pensionScheme;
  String notifiedPension;
  String employerPensionScheme;
  String healthInsurance;
  String interestOnLoan;
  Null donations;
  String interestOnDeposits;
  String relief;

  Details(
      {this.nameOfEmployer,
      this.categoryOfEmployer,
      this.basic,
      this.houseRentAllowance,
      this.leaveTravelAllowance,
      this.dearnessAllowance,
      this.conveyanceAllowance,
      this.childrenEducationAllowance,
      this.otherAllowance,
      this.contributionMade,
      this.deemedAmountFirst,
      this.deemedAmountSecond,
      this.annuityOrPension,
      this.commutedPension,
      this.gratuity,
      this.feesOrCommission,
      this.advanceOfSalary,
      this.leaveEncashment,
      this.other,
      this.perquisites,
      this.accommodation,
      this.carsOrOtherAutomobiles,
      this.otherAttendant,
      this.gasElectricity,
      this.interestFree,
      this.holidayExpenses,
      this.concessionalTravel,
      this.freeMeals,
      this.freeEducation,
      this.gifts,
      this.creditCardExpenses,
      this.clubExpenses,
      this.movableAssets,
      this.transferOfAssets,
      this.otherBenefit,
      this.stockOptions,
      this.taxPaid,
      this.otherBenefits,
      this.profitInLieu,
      this.compensation,
      this.paymentReceived,
      this.dueAmount,
      this.exempt,
      this.travelConcession,
      this.deathCumRetirement,
      this.cummutedValue,
      this.salaryEncashment,
      this.houseRentAllowance2,
      this.otherExemption,
      this.deductionSection,
      this.standardDeduction,
      this.entertainment,
      this.taxOnEmployment,
      this.houseProperty,
      this.otherSources,
      this.deductionsUnderChapter,
      this.contributionToProvident,
      this.pensionFund,
      this.pensionScheme,
      this.notifiedPension,
      this.employerPensionScheme,
      this.healthInsurance,
      this.interestOnLoan,
      this.donations,
      this.interestOnDeposits,
      this.relief,
      
      });

  Details.fromJson(Map<String, dynamic> json) {
    nameOfEmployer = json['Name_of_Employer'];
    categoryOfEmployer = json['Category_of_employer'];
    basic = json['Basic'];
    houseRentAllowance = json['House_Rent_Allowance'];
    leaveTravelAllowance = json['Leave_Travel_Allowance'];
    dearnessAllowance = json['Dearness_Allowance'];
    conveyanceAllowance = json['Conveyance_Allowance'];
    childrenEducationAllowance = json['Children_Education_Allowance'];
    otherAllowance = json['Other_Allowance'];
    contributionMade = json['Contribution_made'];
    deemedAmountFirst = json['Deemed_amount_first'];
    deemedAmountSecond = json['Deemed_amount_second'];
    annuityOrPension = json['Annuity_or_pension'];
    commutedPension = json['Commuted_Pension'];
    gratuity = json['Gratuity'];
    feesOrCommission = json['Fees_or_commission'];
    advanceOfSalary = json['Advance_of_salary'];
    leaveEncashment = json['Leave_encashment'];
    other = json['Other'];
    perquisites = json['Perquisites'];
    accommodation = json['Accommodation'];
    carsOrOtherAutomobiles = json['Cars_or_other_automobiles'];
    otherAttendant = json['other_attendant'];
    gasElectricity = json['Gas_electricity'];
    interestFree = json['Interest_free'];
    holidayExpenses = json['Holiday_expenses'];
    concessionalTravel = json['concessional_travel'];
    freeMeals = json['Free_Meals'];
    freeEducation = json['Free_education'];
    gifts = json['Gifts'];
    creditCardExpenses = json['Credit_card_expenses'];
    clubExpenses = json['Club_expenses'];
    movableAssets = json['movable_assets'];
    transferOfAssets = json['Transfer_of_assets'];
    otherBenefit = json['other_benefit'];
    stockOptions = json['Stock_options'];
    taxPaid = json['Tax_paid'];
    otherBenefits = json['Other_benefits'];
    profitInLieu = json['Profit_in_lieu'];
    compensation = json['Compensation'];
    paymentReceived = json['Payment_received'];
    dueAmount = json['Due_amount'];
    exempt = json['Exempt'];
    travelConcession = json['Travel_Concession'];
    deathCumRetirement = json['Death_cum_retirement'];
    cummutedValue = json['Cummuted_value'];
    salaryEncashment = json['salary_encashment'];
    houseRentAllowance2 = json['House_rent_allowance'];
    otherExemption = json['other_exemption'];
    deductionSection = json['Deduction_section'];
    standardDeduction = json['Standard_Deduction'];
    entertainment = json['Entertainment'];
    taxOnEmployment = json['Tax_on_employment'];
    houseProperty = json['house_property'];
    otherSources = json['other_sources'];
    deductionsUnderChapter = json['Deductions_under_Chapter'];
    contributionToProvident = json['contribution_to_provident'];
    pensionFund = json['pension_fund'];
    pensionScheme = json['pension_scheme'];
    notifiedPension = json['notified_pension'];
    employerPensionScheme = json['employer_pension_scheme'];
    healthInsurance = json['health_insurance'];
    interestOnLoan = json['interest_on_loan'];
    donations = json['donations'];
    interestOnDeposits = json['interest_on_deposits'];
    relief = json['Relief'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Name_of_Employer'] = this.nameOfEmployer;
    data['Category_of_employer'] = this.categoryOfEmployer;
    data['Basic'] = this.basic;
    data['House_Rent_Allowance'] = this.houseRentAllowance;
    data['Leave_Travel_Allowance'] = this.leaveTravelAllowance;
    data['Dearness_Allowance'] = this.dearnessAllowance;
    data['Conveyance_Allowance'] = this.conveyanceAllowance;
    data['Children_Education_Allowance'] = this.childrenEducationAllowance;
    data['Other_Allowance'] = this.otherAllowance;
    data['Contribution_made'] = this.contributionMade;
    data['Deemed_amount_first'] = this.deemedAmountFirst;
    data['Deemed_amount_second'] = this.deemedAmountSecond;
    data['Annuity_or_pension'] = this.annuityOrPension;
    data['Commuted_Pension'] = this.commutedPension;
    data['Gratuity'] = this.gratuity;
    data['Fees_or_commission'] = this.feesOrCommission;
    data['Advance_of_salary'] = this.advanceOfSalary;
    data['Leave_encashment'] = this.leaveEncashment;
    data['Other'] = this.other;
    data['Perquisites'] = this.perquisites;
    data['Accommodation'] = this.accommodation;
    data['Cars_or_other_automobiles'] = this.carsOrOtherAutomobiles;
    data['other_attendant'] = this.otherAttendant;
    data['Gas_electricity'] = this.gasElectricity;
    data['Interest_free'] = this.interestFree;
    data['Holiday_expenses'] = this.holidayExpenses;
    data['concessional_travel'] = this.concessionalTravel;
    data['Free_Meals'] = this.freeMeals;
    data['Free_education'] = this.freeEducation;
    data['Gifts'] = this.gifts;
    data['Credit_card_expenses'] = this.creditCardExpenses;
    data['Club_expenses'] = this.clubExpenses;
    data['movable_assets'] = this.movableAssets;
    data['Transfer_of_assets'] = this.transferOfAssets;
    data['other_benefit'] = this.otherBenefit;
    data['Stock_options'] = this.stockOptions;
    data['Tax_paid'] = this.taxPaid;
    data['Other_benefits'] = this.otherBenefits;
    data['Profit_in_lieu'] = this.profitInLieu;
    data['Compensation'] = this.compensation;
    data['Payment_received'] = this.paymentReceived;
    data['Due_amount'] = this.dueAmount;
    data['Exempt'] = this.exempt;
    data['Travel_Concession'] = this.travelConcession;
    data['Death_cum_retirement'] = this.deathCumRetirement;
    data['Cummuted_value'] = this.cummutedValue;
    data['salary_encashment'] = this.salaryEncashment;
    data['House_rent_allowance'] = this.houseRentAllowance2;
    data['other_exemption'] = this.otherExemption;
    data['Deduction_section'] = this.deductionSection;
    data['Standard_Deduction'] = this.standardDeduction;
    data['Entertainment'] = this.entertainment;
    data['Tax_on_employment'] = this.taxOnEmployment;
    data['house_property'] = this.houseProperty;
    data['other_sources'] = this.otherSources;
    data['Deductions_under_Chapter'] = this.deductionsUnderChapter;
    data['contribution_to_provident'] = this.contributionToProvident;
    data['pension_fund'] = this.pensionFund;
    data['pension_scheme'] = this.pensionScheme;
    data['notified_pension'] = this.notifiedPension;
    data['employer_pension_scheme'] = this.employerPensionScheme;
    data['health_insurance'] = this.healthInsurance;
    data['interest_on_loan'] = this.interestOnLoan;
    data['donations'] = this.donations;
    data['interest_on_deposits'] = this.interestOnDeposits;
    data['Relief'] = this.relief;
    return data;
  }
}
