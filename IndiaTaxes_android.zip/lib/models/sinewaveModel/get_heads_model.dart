class GetHeadModel {
  String message;
  Salary salary;

  GetHeadModel({this.message, this.salary});

  GetHeadModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    salary =
        json['Salary'] != null ? new Salary.fromJson(json['Salary']) : null;
  }

  GetHeadModel.withError({String msg}) {
    this.message = msg;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    if (this.salary != null) {
      data['Salary'] = this.salary.toJson();
    }
    return data;
  }
}

class Salary {
  List<SalarySubs> salarySubs;
  List<Others> others;
  List<Perquisites> perquisites;
  List<Lieu> lieu;

  Salary({this.salarySubs, this.others, this.perquisites, this.lieu});

  Salary.fromJson(Map<String, dynamic> json) {
    if (json['SalarySubs'] != null) {
      salarySubs = new List<SalarySubs>();
      json['SalarySubs'].forEach((v) {
        salarySubs.add(new SalarySubs.fromJson(v));
      });
    }
    if (json['Others'] != null) {
      others = new List<Others>();
      json['Others'].forEach((v) {
        others.add(new Others.fromJson(v));
      });
    }
    if (json['perquisites'] != null) {
      perquisites = new List<Perquisites>();
      json['perquisites'].forEach((v) {
        perquisites.add(new Perquisites.fromJson(v));
      });
    }
    if (json['lieu'] != null) {
      lieu = new List<Lieu>();
      json['lieu'].forEach((v) {
        lieu.add(new Lieu.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.salarySubs != null) {
      data['SalarySubs'] = this.salarySubs.map((v) => v.toJson()).toList();
    }
    if (this.others != null) {
      data['Others'] = this.others.map((v) => v.toJson()).toList();
    }
    if (this.perquisites != null) {
      data['perquisites'] = this.perquisites.map((v) => v.toJson()).toList();
    }
    if (this.lieu != null) {
      data['lieu'] = this.lieu.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SalarySubs {
  String nameSalarySub;

  SalarySubs({this.nameSalarySub});

  SalarySubs.fromJson(Map<String, dynamic> json) {
    nameSalarySub = json['Name_salary_sub'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Name_salary_sub'] = this.nameSalarySub;
    return data;
  }
}

class Others {
  String nameOfOther;

  Others({this.nameOfOther});

  Others.fromJson(Map<String, dynamic> json) {
    nameOfOther = json['Name_of_other'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Name_of_other'] = this.nameOfOther;
    return data;
  }
}

class Perquisites {
  String nameOfPerquisites;

  Perquisites({this.nameOfPerquisites});

  Perquisites.fromJson(Map<String, dynamic> json) {
    nameOfPerquisites = json['Name_of_perquisites'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Name_of_perquisites'] = this.nameOfPerquisites;
    return data;
  }
}

class Lieu {
  String nameOfLieu;

  Lieu({this.nameOfLieu});

  Lieu.fromJson(Map<String, dynamic> json) {
    nameOfLieu = json['Name_of_lieu'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Name_of_lieu'] = this.nameOfLieu;
    return data;
  }
}

class ExemptAllwn {
  String nameOfExemptAllwn;

  ExemptAllwn({this.nameOfExemptAllwn});

  ExemptAllwn.fromJson(Map<String, dynamic> json) {
    nameOfExemptAllwn = json['nameOfExemptAllwn'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['nameOfExemptAllwn'] = this.nameOfExemptAllwn;
    return data;
  }
}