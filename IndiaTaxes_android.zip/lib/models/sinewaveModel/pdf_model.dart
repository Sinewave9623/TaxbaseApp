import 'package:flutter/material.dart';

class Invoice {
  Invoice({this.srNo, this.title, this.value});

  final String srNo;
  final String title;
  final String value;

  String getIndex(int col, int index) {
    switch (col) {
      case 0:
        return (index + 1).toString();
      case 1:
        return title;
      case 2:
        return value;  
    }
    return "";
  }
}



