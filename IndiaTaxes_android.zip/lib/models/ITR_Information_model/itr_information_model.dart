class ItrDropDown {
  String itrDropDwnName;

  ItrDropDown({this.itrDropDwnName});

  ItrDropDown.fromJson(Map<String, dynamic> json) {
    itrDropDwnName = json['itrDropDwnName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['itrDropDwnName'] = this.itrDropDwnName;
    return data;
  }
}